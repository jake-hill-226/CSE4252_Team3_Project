/* Generated code for Python source for module 'pdfminer.cmapdb'
 * created by Nuitka version 0.5.28.1
 *
 * This code is in part copyright 2017 Kay Hayen.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "nuitka/prelude.h"

#include "__helpers.h"

/* The _module_pdfminer$cmapdb is a Python object pointer of module type. */

/* Note: For full compatibility with CPython, every module variable access
 * needs to go through it except for cases where the module cannot possibly
 * have changed in the mean time.
 */

PyObject *module_pdfminer$cmapdb;
PyDictObject *moduledict_pdfminer$cmapdb;

/* The module constants used, if any. */
static PyObject *const_tuple_str_plain_begincidchar_tuple;
extern PyObject *const_str_plain_copy;
static PyObject *const_str_plain_endcidrange;
extern PyObject *const_int_neg_1;
extern PyObject *const_str_plain___package__;
extern PyObject *const_tuple_type_object_tuple;
extern PyObject *const_tuple_str_plain_literal_name_tuple;
extern PyObject *const_tuple_str_plain_PSStackParser_tuple;
extern PyObject *const_str_plain_data;
static PyObject *const_str_plain_IdentityCMap;
static PyObject *const_str_plain_dst;
static PyObject *const_str_plain_endcodespacerange;
static PyObject *const_str_plain_KEYWORD_ENDCMAP;
extern PyObject *const_tuple_str_plain_choplist_tuple;
extern PyObject *const_str_plain_decode;
static PyObject *const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple;
extern PyObject *const_dict_empty;
extern PyObject *const_str_plain_PSEOF;
extern PyObject *const_str_plain_PSSyntaxError;
extern PyObject *const_str_plain_name2unicode;
static PyObject *const_str_plain_usecmap;
extern PyObject *const_str_plain_get;
static PyObject *const_str_plain_pickle;
extern PyObject *const_tuple_str_plain_PSLiteral_tuple;
static PyObject *const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple;
extern PyObject *const_str_plain_vertical;
static PyObject *const_tuple_str_plain_beginbfchar_tuple;
extern PyObject *const_tuple_empty;
extern PyObject *const_str_plain_CMap;
extern PyObject *const_str_plain_popall;
static PyObject *const_str_digest_509739f7a70e1336a85c2b1d55989e3d;
extern PyObject *const_str_plain_choplist;
static PyObject *const_str_plain_KEYWORD_USECMAP;
extern PyObject *const_str_digest_e399ba4554180f37de594a6743234f17;
static PyObject *const_str_digest_eeb22152564a9374d5ef8cadef0c46d0;
extern PyObject *const_str_plain_v;
static PyObject *const_str_plain_gzfile;
extern PyObject *const_str_plain_do_keyword;
static PyObject *const_str_plain_UnicodeMap;
static PyObject *const_str_plain__cmap_cache;
extern PyObject *const_str_plain___repr__;
static PyObject *const_tuple_str_plain_endbfchar_tuple;
static PyObject *const_str_plain_beginbfchar;
static PyObject *const_str_plain_CMAP_PATH;
extern PyObject *const_str_plain_pack;
extern PyObject *const_str_plain_pop;
static PyObject *const_tuple_9a0f21938d54faa93743eba74420da5f_tuple;
static PyObject *const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple;
static PyObject *const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple;
static PyObject *const_tuple_a4c6aaf8631feb1e7b3d5f108949e4b2_tuple;
extern PyObject *const_str_plain_unichr;
extern PyObject *const_str_plain_fname;
static PyObject *const_tuple_str_plain_endcodespacerange_tuple;
static PyObject *const_str_plain_set_attr;
extern PyObject *const_tuple_str_plain_PSEOF_tuple;
static PyObject *const_tuple_36ed8d6860da18fa665ff101615207f9_tuple;
static PyObject *const_str_plain_filename;
extern PyObject *const_str_plain_FileUnicodeMap;
static PyObject *const_str_plain_KEYWORD_BEGINNOTDEFRANGE;
static PyObject *const_str_plain_begincodespacerange;
extern PyObject *const_str_plain_close;
extern PyObject *const_str_plain_iteritems;
static PyObject *const_str_plain_environ;
extern PyObject *const_str_plain_debug;
static PyObject *const_str_plain_PyUnicodeMap;
extern PyObject *const_tuple_str_plain_KWD_tuple;
extern PyObject *const_str_plain_rb;
static PyObject *const_str_plain_PyCMap;
static PyObject *const_str_plain_FileCMap;
static PyObject *const_str_plain_endbfchar;
extern PyObject *const_str_plain_write;
static PyObject *const_str_plain_code2cid;
static PyObject *const_tuple_e31735da1688856af07d842043d3b1e7_tuple;
static PyObject *const_str_digest_198febb53c9afa089092ea7e45bbe1fe;
static PyObject *const_tuple_str_plain_begincidrange_tuple;
extern PyObject *const_str_plain_sorted;
static PyObject *const_str_plain_endbfrange;
extern PyObject *const_str_plain_c;
static PyObject *const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple;
static PyObject *const_str_digest_4083d90c6f9c4663e999995b5eecbe81;
static PyObject *const_str_digest_9320efa7add6853c7ceff8f829714204;
extern PyObject *const_tuple_str_plain_self_tuple;
static PyObject *const_tuple_6514984971888835acacc41b1ed01e7a_tuple;
extern PyObject *const_str_plain_is_vertical;
static PyObject *const_str_plain_KEYWORD_BEGINCMAP;
extern PyObject *const_tuple_str_plain_self_str_plain_cid_tuple;
static PyObject *const_tuple_str_plain_endcmap_tuple;
extern PyObject *const_str_plain_os;
static PyObject *const_str_plain_KEYWORD_BEGINCODESPACERANGE;
static PyObject *const_str_digest_91bdb4bec0f6193ff3c892ab9c238e14;
static PyObject *const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple;
static PyObject *const_tuple_str_plain_begincodespacerange_tuple;
extern PyObject *const_int_pos_2;
static PyObject *const_str_plain_cPickle;
extern PyObject *const_str_plain___file__;
extern PyObject *const_str_plain_CMapParser;
static PyObject *const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple;
static PyObject *const_str_plain_KEYWORD_ENDCIDRANGE;
static PyObject *const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple;
extern PyObject *const_tuple_str_plain_PSSyntaxError_tuple;
extern PyObject *const_str_plain_args;
static PyObject *const_str_plain_cmap_paths;
extern PyObject *const_str_plain_main;
extern PyObject *const_str_plain_out;
extern PyObject *const_int_pos_1;
static PyObject *const_str_plain_begincmap;
extern PyObject *const_str_plain___module__;
static PyObject *const_dict_ce3809eb77b4cef6dc68a812b608cc09;
extern PyObject *const_int_pos_3;
static PyObject *const_tuple_str_plain_CMapName_tuple;
static PyObject *const_str_plain_endnotdefrange;
extern PyObject *const_str_plain_KWD;
extern PyObject *const_str_plain___metaclass__;
static PyObject *const_str_plain_CODE2CID;
static PyObject *const_str_digest_e7502d95d9606e3e619198e28527b862;
extern PyObject *const_str_plain_unpack;
extern PyObject *const_str_plain_exists;
static PyObject *const_str_digest_b21855e094b355d16316ad6dc0425407;
extern PyObject *const_str_plain___init__;
extern PyObject *const_str_plain_open;
static PyObject *const_tuple_str_plain_beginnotdefrange_tuple;
extern PyObject *const_str_plain_get_unicode_map;
extern PyObject *const_str_plain_utils;
static PyObject *const_tuple_str_plain_endbfrange_tuple;
static PyObject *const_str_plain_KEYWORD_BEGINBFRANGE;
static PyObject *const_str_plain_WMode;
extern PyObject *const_str_plain_cid;
extern PyObject *const_str_plain_PSLiteral;
extern PyObject *const_str_plain_run;
extern PyObject *const_tuple_str_plain_def_tuple;
static PyObject *const_str_plain_add_code2cid;
static PyObject *const_str_plain_IS_VERTICAL;
static PyObject *const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple;
extern PyObject *const_str_plain_join;
static PyObject *const_str_digest_9be5b4e2f6d190afc27e049db170f4a2;
static PyObject *const_tuple_str_plain_endcidrange_tuple;
static PyObject *const_str_plain_KEYWORD_ENDBFRANGE;
static PyObject *const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple;
extern PyObject *const_str_plain_get_unichr;
static PyObject *const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple;
static PyObject *const_str_plain_CID2UNICHR_V;
static PyObject *const_str_digest_578f15b8391035c916b128eb320b5c58;
extern PyObject *const_str_plain_info;
static PyObject *const_str_digest_7630f82f72cc55e315d978a3b1f3b902;
static PyObject *const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple;
extern PyObject *const_str_plain_path;
static PyObject *const_str_plain_CID2UNICHR_H;
static PyObject *const_tuple_str_plain_endnotdefrange_tuple;
extern PyObject *const_tuple_str_plain_name2unicode_tuple;
static PyObject *const_str_plain__load_data;
static PyObject *const_tuple_str_plain_begincmap_tuple;
extern PyObject *const_str_plain_name;
static PyObject *const_str_plain_dump;
static PyObject *const_str_digest_e82b2289dd840656dde2e4ac175f6e70;
static PyObject *const_tuple_str_plain_beginbfrange_tuple;
extern PyObject *const_str_plain_read;
static PyObject *const_str_plain_KEYWORD_BEGINCIDCHAR;
extern PyObject *const_str_plain_fp;
static PyObject *const_str_plain_beginbfrange;
static PyObject *const_str_digest_b59ff24f0306e1d3fc9e440d70c22e7b;
static PyObject *const_str_plain_KEYWORD_ENDCIDCHAR;
static PyObject *const_tuple_adb7e9cb592accf77f5da4f40375750f_tuple;
static PyObject *const_str_plain_KEYWORD_ENDNOTDEFRANGE;
extern PyObject *const_str_plain_stdout;
static PyObject *const_tuple_str_plain_WMode_int_0_tuple;
extern PyObject *const_str_plain_n;
extern PyObject *const_str_plain_KEYWORD_DEF;
extern PyObject *const_str_plain_CMapDB;
static PyObject *const_str_plain_endcmap;
extern PyObject *const_str_plain_k;
extern PyObject *const_str_plain_d;
static PyObject *const_str_plain_CMapError;
extern PyObject *const_str_plain_attrs;
extern PyObject *const_str_plain_argv;
static PyObject *const_str_plain_umaps;
extern PyObject *const_tuple_int_pos_2_tuple;
extern PyObject *const_str_digest_6d86adbb5b668bab4cd670281ea4b3e0;
static PyObject *const_str_plain_CMapBase;
static PyObject *const_str_plain__in_cmap;
extern PyObject *const_str_plain_t;
extern PyObject *const_str_plain_literal_name;
static PyObject *const_str_digest_5b68fb7448108f6baddc17ec34a02c5e;
static PyObject *const_str_plain_dirname;
static PyObject *const_str_plain_KEYWORD_ENDCODESPACERANGE;
extern PyObject *const_str_digest_a5f56e291553139a63a10626179e7804;
static PyObject *const_tuple_str_plain_endcidchar_tuple;
static PyObject *const_str_digest_81ff17319213b47b3b5f1e8319d6f3bf;
static PyObject *const_str_plain_kwargs;
extern PyObject *const_str_plain_struct;
extern PyObject *const_str_plain_get_cmap;
extern PyObject *const_str_plain_klass;
static PyObject *const_dict_47564eeef2ec8d21619ac66253a5cc5e;
extern PyObject *const_str_plain_logging;
static PyObject *const_str_digest_744fab9097f9fc4d67e451ba8fa53651;
static PyObject *const_str_plain_CMapName;
extern PyObject *const_str_plain_ignore;
static PyObject *const_str_plain_KEYWORD_BEGINBFCHAR;
static PyObject *const_tuple_false_true_tuple;
extern PyObject *const_str_plain_nextobject;
static PyObject *const_str_plain_begincidrange;
static PyObject *const_tuple_str_plain_self_str_plain_kwargs_tuple;
extern PyObject *const_str_plain_PSStackParser;
static PyObject *const_str_plain_use_cmap;
static PyObject *const_str_plain_module;
extern PyObject *const_str_digest_7532b9d7f11d8fedcf0f9e47d9f9d1da;
extern PyObject *const_tuple_int_pos_1_tuple;
extern PyObject *const_str_plain___doc__;
extern PyObject *const_str_plain_sys;
extern PyObject *const_str_plain_nunpack;
extern PyObject *const_str_plain_def;
extern PyObject *const_int_0;
static PyObject *const_str_plain_src;
static PyObject *const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple;
static PyObject *const_str_plain_beginnotdefrange;
extern PyObject *const_str_plain_cmap;
extern PyObject *const_str_plain_encodingdb;
static PyObject *const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple;
static PyObject *const_str_plain_begincidchar;
static PyObject *const_str_plain_KEYWORD_ENDBFCHAR;
extern PyObject *const_str_plain_add_cid2unichr;
extern PyObject *const_tuple_str_plain_nunpack_tuple;
extern PyObject *const_str_plain_push;
static PyObject *const_tuple_str_plain_usecmap_tuple;
static PyObject *const_str_plain_gzip;
static PyObject *const_str_plain_KEYWORD_BEGINCIDRANGE;
static PyObject *const_str_plain__umap_cache;
extern PyObject *const_str_plain_code;
static PyObject *const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple;
extern PyObject *const_str_plain_CMapNotFound;
extern PyObject *const_str_plain_self;
static PyObject *const_str_plain_cid2unichr;
static PyObject *const_tuple_str_plain_self_str_plain_cmap_tuple;
static PyObject *const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple;
extern PyObject *const_tuple_false_tuple;
extern PyObject *const_str_plain_psparser;
static PyObject *const_str_plain_loads;
static PyObject *const_str_plain_directory;
static PyObject *const_str_plain_endcidchar;
static PyObject *const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple;
static PyObject *module_filename_obj;

static bool constants_created = false;

static void createModuleConstants( void )
{
    const_tuple_str_plain_begincidchar_tuple = PyTuple_New( 1 );
    const_str_plain_begincidchar = UNSTREAM_STRING( &constant_bin[ 4659 ], 12, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_begincidchar_tuple, 0, const_str_plain_begincidchar ); Py_INCREF( const_str_plain_begincidchar );
    const_str_plain_endcidrange = UNSTREAM_STRING( &constant_bin[ 4671 ], 11, 1 );
    const_str_plain_IdentityCMap = UNSTREAM_STRING( &constant_bin[ 4682 ], 12, 1 );
    const_str_plain_dst = UNSTREAM_STRING( &constant_bin[ 4694 ], 3, 1 );
    const_str_plain_endcodespacerange = UNSTREAM_STRING( &constant_bin[ 4697 ], 17, 1 );
    const_str_plain_KEYWORD_ENDCMAP = UNSTREAM_STRING( &constant_bin[ 4714 ], 15, 1 );
    const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple, 1, const_str_plain_cmap ); Py_INCREF( const_str_plain_cmap );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple, 2, const_str_plain_fp ); Py_INCREF( const_str_plain_fp );
    const_str_plain_usecmap = UNSTREAM_STRING( &constant_bin[ 4729 ], 7, 1 );
    const_str_plain_pickle = UNSTREAM_STRING( &constant_bin[ 4736 ], 6, 1 );
    const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple = PyTuple_New( 5 );
    PyTuple_SET_ITEM( const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 0, const_str_plain_argv ); Py_INCREF( const_str_plain_argv );
    PyTuple_SET_ITEM( const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 1, const_str_plain_args ); Py_INCREF( const_str_plain_args );
    PyTuple_SET_ITEM( const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 2, const_str_plain_fname ); Py_INCREF( const_str_plain_fname );
    PyTuple_SET_ITEM( const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 3, const_str_plain_fp ); Py_INCREF( const_str_plain_fp );
    PyTuple_SET_ITEM( const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 4, const_str_plain_cmap ); Py_INCREF( const_str_plain_cmap );
    const_tuple_str_plain_beginbfchar_tuple = PyTuple_New( 1 );
    const_str_plain_beginbfchar = UNSTREAM_STRING( &constant_bin[ 4742 ], 11, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_beginbfchar_tuple, 0, const_str_plain_beginbfchar ); Py_INCREF( const_str_plain_beginbfchar );
    const_str_digest_509739f7a70e1336a85c2b1d55989e3d = UNSTREAM_STRING( &constant_bin[ 4753 ], 20, 0 );
    const_str_plain_KEYWORD_USECMAP = UNSTREAM_STRING( &constant_bin[ 4773 ], 15, 1 );
    const_str_digest_eeb22152564a9374d5ef8cadef0c46d0 = UNSTREAM_STRING( &constant_bin[ 4788 ], 259, 0 );
    const_str_plain_gzfile = UNSTREAM_STRING( &constant_bin[ 5047 ], 6, 1 );
    const_str_plain_UnicodeMap = UNSTREAM_STRING( &constant_bin[ 5053 ], 10, 1 );
    const_str_plain__cmap_cache = UNSTREAM_STRING( &constant_bin[ 5063 ], 11, 1 );
    const_tuple_str_plain_endbfchar_tuple = PyTuple_New( 1 );
    const_str_plain_endbfchar = UNSTREAM_STRING( &constant_bin[ 5074 ], 9, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endbfchar_tuple, 0, const_str_plain_endbfchar ); Py_INCREF( const_str_plain_endbfchar );
    const_str_plain_CMAP_PATH = UNSTREAM_STRING( &constant_bin[ 5083 ], 9, 1 );
    const_tuple_9a0f21938d54faa93743eba74420da5f_tuple = PyTuple_New( 5 );
    PyTuple_SET_ITEM( const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 0, const_str_plain___module__ ); Py_INCREF( const_str_plain___module__ );
    PyTuple_SET_ITEM( const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 1, const_str_plain___init__ ); Py_INCREF( const_str_plain___init__ );
    PyTuple_SET_ITEM( const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 2, const_str_plain___repr__ ); Py_INCREF( const_str_plain___repr__ );
    PyTuple_SET_ITEM( const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 3, const_str_plain_get_unichr ); Py_INCREF( const_str_plain_get_unichr );
    const_str_plain_dump = UNSTREAM_STRING( &constant_bin[ 5092 ], 4, 1 );
    PyTuple_SET_ITEM( const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 4, const_str_plain_dump ); Py_INCREF( const_str_plain_dump );
    const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple = PyTuple_New( 6 );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 0, const_str_plain___module__ ); Py_INCREF( const_str_plain___module__ );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 1, const_str_plain___init__ ); Py_INCREF( const_str_plain___init__ );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 2, const_str_plain___repr__ ); Py_INCREF( const_str_plain___repr__ );
    const_str_plain_use_cmap = UNSTREAM_STRING( &constant_bin[ 5096 ], 8, 1 );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 3, const_str_plain_use_cmap ); Py_INCREF( const_str_plain_use_cmap );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 4, const_str_plain_decode ); Py_INCREF( const_str_plain_decode );
    PyTuple_SET_ITEM( const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 5, const_str_plain_dump ); Py_INCREF( const_str_plain_dump );
    const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple, 1, const_str_plain_cmap ); Py_INCREF( const_str_plain_cmap );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple, 2, const_str_plain_copy ); Py_INCREF( const_str_plain_copy );
    const_tuple_a4c6aaf8631feb1e7b3d5f108949e4b2_tuple = PyMarshal_ReadObjectFromString( (char *)&constant_bin[ 5104 ], 444 );
    const_tuple_str_plain_endcodespacerange_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endcodespacerange_tuple, 0, const_str_plain_endcodespacerange ); Py_INCREF( const_str_plain_endcodespacerange );
    const_str_plain_set_attr = UNSTREAM_STRING( &constant_bin[ 5548 ], 8, 1 );
    const_tuple_36ed8d6860da18fa665ff101615207f9_tuple = PyTuple_New( 7 );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 0, const_str_plain___module__ ); Py_INCREF( const_str_plain___module__ );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 1, const_str_plain__cmap_cache ); Py_INCREF( const_str_plain__cmap_cache );
    const_str_plain__umap_cache = UNSTREAM_STRING( &constant_bin[ 5556 ], 11, 1 );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 2, const_str_plain__umap_cache ); Py_INCREF( const_str_plain__umap_cache );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 3, const_str_plain_CMapNotFound ); Py_INCREF( const_str_plain_CMapNotFound );
    const_str_plain__load_data = UNSTREAM_STRING( &constant_bin[ 5567 ], 10, 1 );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 4, const_str_plain__load_data ); Py_INCREF( const_str_plain__load_data );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 5, const_str_plain_get_cmap ); Py_INCREF( const_str_plain_get_cmap );
    PyTuple_SET_ITEM( const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 6, const_str_plain_get_unicode_map ); Py_INCREF( const_str_plain_get_unicode_map );
    const_str_plain_filename = UNSTREAM_STRING( &constant_bin[ 5577 ], 8, 1 );
    const_str_plain_KEYWORD_BEGINNOTDEFRANGE = UNSTREAM_STRING( &constant_bin[ 5482 ], 24, 1 );
    const_str_plain_begincodespacerange = UNSTREAM_STRING( &constant_bin[ 5585 ], 19, 1 );
    const_str_plain_environ = UNSTREAM_STRING( &constant_bin[ 5604 ], 7, 1 );
    const_str_plain_PyUnicodeMap = UNSTREAM_STRING( &constant_bin[ 5611 ], 12, 1 );
    const_str_plain_PyCMap = UNSTREAM_STRING( &constant_bin[ 5623 ], 6, 1 );
    const_str_plain_FileCMap = UNSTREAM_STRING( &constant_bin[ 5629 ], 8, 1 );
    const_str_plain_code2cid = UNSTREAM_STRING( &constant_bin[ 5637 ], 8, 1 );
    const_tuple_e31735da1688856af07d842043d3b1e7_tuple = PyTuple_New( 6 );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 1, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 2, const_str_plain_cid ); Py_INCREF( const_str_plain_cid );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 3, const_str_plain_d ); Py_INCREF( const_str_plain_d );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 4, const_str_plain_c ); Py_INCREF( const_str_plain_c );
    PyTuple_SET_ITEM( const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 5, const_str_plain_t ); Py_INCREF( const_str_plain_t );
    const_str_digest_198febb53c9afa089092ea7e45bbe1fe = UNSTREAM_STRING( &constant_bin[ 5645 ], 18, 0 );
    const_tuple_str_plain_begincidrange_tuple = PyTuple_New( 1 );
    const_str_plain_begincidrange = UNSTREAM_STRING( &constant_bin[ 5663 ], 13, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_begincidrange_tuple, 0, const_str_plain_begincidrange ); Py_INCREF( const_str_plain_begincidrange );
    const_str_plain_endbfrange = UNSTREAM_STRING( &constant_bin[ 5676 ], 10, 1 );
    const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple = PyTuple_New( 7 );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 1, const_str_plain_out ); Py_INCREF( const_str_plain_out );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 2, const_str_plain_code2cid ); Py_INCREF( const_str_plain_code2cid );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 3, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 4, const_str_plain_k ); Py_INCREF( const_str_plain_k );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 5, const_str_plain_v ); Py_INCREF( const_str_plain_v );
    PyTuple_SET_ITEM( const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 6, const_str_plain_c ); Py_INCREF( const_str_plain_c );
    const_str_digest_4083d90c6f9c4663e999995b5eecbe81 = UNSTREAM_STRING( &constant_bin[ 5686 ], 24, 0 );
    const_str_digest_9320efa7add6853c7ceff8f829714204 = UNSTREAM_STRING( &constant_bin[ 5710 ], 57, 0 );
    const_tuple_6514984971888835acacc41b1ed01e7a_tuple = PyMarshal_ReadObjectFromString( (char *)&constant_bin[ 5767 ], 221 );
    const_str_plain_KEYWORD_BEGINCMAP = UNSTREAM_STRING( &constant_bin[ 5150 ], 17, 1 );
    const_tuple_str_plain_endcmap_tuple = PyTuple_New( 1 );
    const_str_plain_endcmap = UNSTREAM_STRING( &constant_bin[ 5988 ], 7, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endcmap_tuple, 0, const_str_plain_endcmap ); Py_INCREF( const_str_plain_endcmap );
    const_str_plain_KEYWORD_BEGINCODESPACERANGE = UNSTREAM_STRING( &constant_bin[ 5228 ], 27, 1 );
    const_str_digest_91bdb4bec0f6193ff3c892ab9c238e14 = UNSTREAM_STRING( &constant_bin[ 5995 ], 11, 0 );
    const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple = PyTuple_New( 6 );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 0, const_str_plain_dst ); Py_INCREF( const_str_plain_dst );
    const_str_plain_src = UNSTREAM_STRING( &constant_bin[ 318 ], 3, 1 );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 1, const_str_plain_src ); Py_INCREF( const_str_plain_src );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 2, const_str_plain_k ); Py_INCREF( const_str_plain_k );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 3, const_str_plain_v ); Py_INCREF( const_str_plain_v );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 4, const_str_plain_d ); Py_INCREF( const_str_plain_d );
    PyTuple_SET_ITEM( const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 5, const_str_plain_copy ); Py_INCREF( const_str_plain_copy );
    const_tuple_str_plain_begincodespacerange_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_begincodespacerange_tuple, 0, const_str_plain_begincodespacerange ); Py_INCREF( const_str_plain_begincodespacerange );
    const_str_plain_cPickle = UNSTREAM_STRING( &constant_bin[ 6006 ], 7, 1 );
    const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple, 1, const_str_plain_cid ); Py_INCREF( const_str_plain_cid );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple, 2, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    const_str_plain_KEYWORD_ENDCIDRANGE = UNSTREAM_STRING( &constant_bin[ 5316 ], 19, 1 );
    const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple, 1, const_str_plain_name ); Py_INCREF( const_str_plain_name );
    const_str_plain_module = UNSTREAM_STRING( &constant_bin[ 36 ], 6, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple, 2, const_str_plain_module ); Py_INCREF( const_str_plain_module );
    const_str_plain_cmap_paths = UNSTREAM_STRING( &constant_bin[ 6013 ], 10, 1 );
    const_str_plain_begincmap = UNSTREAM_STRING( &constant_bin[ 6023 ], 9, 1 );
    const_dict_ce3809eb77b4cef6dc68a812b608cc09 = _PyDict_NewPresized( 1 );
    const_str_plain_WMode = UNSTREAM_STRING( &constant_bin[ 6032 ], 5, 1 );
    PyDict_SetItem( const_dict_ce3809eb77b4cef6dc68a812b608cc09, const_str_plain_WMode, const_int_pos_1 );
    assert( PyDict_Size( const_dict_ce3809eb77b4cef6dc68a812b608cc09 ) == 1 );
    const_tuple_str_plain_CMapName_tuple = PyTuple_New( 1 );
    const_str_plain_CMapName = UNSTREAM_STRING( &constant_bin[ 6037 ], 8, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_CMapName_tuple, 0, const_str_plain_CMapName ); Py_INCREF( const_str_plain_CMapName );
    const_str_plain_endnotdefrange = UNSTREAM_STRING( &constant_bin[ 6045 ], 14, 1 );
    const_str_plain_CODE2CID = UNSTREAM_STRING( &constant_bin[ 6059 ], 8, 1 );
    const_str_digest_e7502d95d9606e3e619198e28527b862 = UNSTREAM_STRING( &constant_bin[ 6067 ], 10, 0 );
    const_str_digest_b21855e094b355d16316ad6dc0425407 = UNSTREAM_STRING( &constant_bin[ 6077 ], 20, 0 );
    const_tuple_str_plain_beginnotdefrange_tuple = PyTuple_New( 1 );
    const_str_plain_beginnotdefrange = UNSTREAM_STRING( &constant_bin[ 6097 ], 16, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_beginnotdefrange_tuple, 0, const_str_plain_beginnotdefrange ); Py_INCREF( const_str_plain_beginnotdefrange );
    const_tuple_str_plain_endbfrange_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endbfrange_tuple, 0, const_str_plain_endbfrange ); Py_INCREF( const_str_plain_endbfrange );
    const_str_plain_KEYWORD_BEGINBFRANGE = UNSTREAM_STRING( &constant_bin[ 5388 ], 20, 1 );
    const_str_plain_add_code2cid = UNSTREAM_STRING( &constant_bin[ 6113 ], 12, 1 );
    const_str_plain_IS_VERTICAL = UNSTREAM_STRING( &constant_bin[ 6125 ], 11, 1 );
    const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple = PyTuple_New( 7 );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 0, const_str_plain_klass ); Py_INCREF( const_str_plain_klass );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 1, const_str_plain_name ); Py_INCREF( const_str_plain_name );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 2, const_str_plain_filename ); Py_INCREF( const_str_plain_filename );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 3, const_str_plain_cmap_paths ); Py_INCREF( const_str_plain_cmap_paths );
    const_str_plain_directory = UNSTREAM_STRING( &constant_bin[ 6136 ], 9, 1 );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 4, const_str_plain_directory ); Py_INCREF( const_str_plain_directory );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 5, const_str_plain_path ); Py_INCREF( const_str_plain_path );
    PyTuple_SET_ITEM( const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 6, const_str_plain_gzfile ); Py_INCREF( const_str_plain_gzfile );
    const_str_digest_9be5b4e2f6d190afc27e049db170f4a2 = UNSTREAM_STRING( &constant_bin[ 6145 ], 8, 0 );
    const_tuple_str_plain_endcidrange_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endcidrange_tuple, 0, const_str_plain_endcidrange ); Py_INCREF( const_str_plain_endcidrange );
    const_str_plain_KEYWORD_ENDBFRANGE = UNSTREAM_STRING( &constant_bin[ 5413 ], 18, 1 );
    const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple = PyTuple_New( 4 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple, 1, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple, 2, const_str_plain_d ); Py_INCREF( const_str_plain_d );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple, 3, const_str_plain_c ); Py_INCREF( const_str_plain_c );
    const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple = PyTuple_New( 6 );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 0, const_str_plain_klass ); Py_INCREF( const_str_plain_klass );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 1, const_str_plain_name ); Py_INCREF( const_str_plain_name );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 2, const_str_plain_vertical ); Py_INCREF( const_str_plain_vertical );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 3, const_str_plain_data ); Py_INCREF( const_str_plain_data );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 4, const_str_plain_v ); Py_INCREF( const_str_plain_v );
    const_str_plain_umaps = UNSTREAM_STRING( &constant_bin[ 6153 ], 5, 1 );
    PyTuple_SET_ITEM( const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 5, const_str_plain_umaps ); Py_INCREF( const_str_plain_umaps );
    const_str_plain_CID2UNICHR_V = UNSTREAM_STRING( &constant_bin[ 6158 ], 12, 1 );
    const_str_digest_578f15b8391035c916b128eb320b5c58 = UNSTREAM_STRING( &constant_bin[ 6170 ], 12, 0 );
    const_str_digest_7630f82f72cc55e315d978a3b1f3b902 = UNSTREAM_STRING( &constant_bin[ 6182 ], 16, 0 );
    const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple = PyTuple_New( 4 );
    PyTuple_SET_ITEM( const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple, 0, const_str_plain_klass ); Py_INCREF( const_str_plain_klass );
    PyTuple_SET_ITEM( const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple, 1, const_str_plain_name ); Py_INCREF( const_str_plain_name );
    PyTuple_SET_ITEM( const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple, 2, const_str_plain_data ); Py_INCREF( const_str_plain_data );
    PyTuple_SET_ITEM( const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple, 3, const_str_plain_cmap ); Py_INCREF( const_str_plain_cmap );
    const_str_plain_CID2UNICHR_H = UNSTREAM_STRING( &constant_bin[ 6198 ], 12, 1 );
    const_tuple_str_plain_endnotdefrange_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endnotdefrange_tuple, 0, const_str_plain_endnotdefrange ); Py_INCREF( const_str_plain_endnotdefrange );
    const_tuple_str_plain_begincmap_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_begincmap_tuple, 0, const_str_plain_begincmap ); Py_INCREF( const_str_plain_begincmap );
    const_str_digest_e82b2289dd840656dde2e4ac175f6e70 = UNSTREAM_STRING( &constant_bin[ 6210 ], 14, 0 );
    const_tuple_str_plain_beginbfrange_tuple = PyTuple_New( 1 );
    const_str_plain_beginbfrange = UNSTREAM_STRING( &constant_bin[ 6224 ], 12, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_beginbfrange_tuple, 0, const_str_plain_beginbfrange ); Py_INCREF( const_str_plain_beginbfrange );
    const_str_plain_KEYWORD_BEGINCIDCHAR = UNSTREAM_STRING( &constant_bin[ 5340 ], 20, 1 );
    const_str_digest_b59ff24f0306e1d3fc9e440d70c22e7b = UNSTREAM_STRING( &constant_bin[ 6236 ], 10, 0 );
    const_str_plain_KEYWORD_ENDCIDCHAR = UNSTREAM_STRING( &constant_bin[ 5365 ], 18, 1 );
    const_tuple_adb7e9cb592accf77f5da4f40375750f_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_adb7e9cb592accf77f5da4f40375750f_tuple, 0, const_str_plain_CMAP_PATH ); Py_INCREF( const_str_plain_CMAP_PATH );
    PyTuple_SET_ITEM( const_tuple_adb7e9cb592accf77f5da4f40375750f_tuple, 1, const_str_digest_509739f7a70e1336a85c2b1d55989e3d ); Py_INCREF( const_str_digest_509739f7a70e1336a85c2b1d55989e3d );
    const_str_plain_KEYWORD_ENDNOTDEFRANGE = UNSTREAM_STRING( &constant_bin[ 5511 ], 22, 1 );
    const_tuple_str_plain_WMode_int_0_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_str_plain_WMode_int_0_tuple, 0, const_str_plain_WMode ); Py_INCREF( const_str_plain_WMode );
    PyTuple_SET_ITEM( const_tuple_str_plain_WMode_int_0_tuple, 1, const_int_0 ); Py_INCREF( const_int_0 );
    const_str_plain_CMapError = UNSTREAM_STRING( &constant_bin[ 6246 ], 9, 1 );
    const_str_plain_CMapBase = UNSTREAM_STRING( &constant_bin[ 6255 ], 8, 1 );
    const_str_plain__in_cmap = UNSTREAM_STRING( &constant_bin[ 6263 ], 8, 1 );
    const_str_digest_5b68fb7448108f6baddc17ec34a02c5e = UNSTREAM_STRING( &constant_bin[ 6271 ], 10, 0 );
    const_str_plain_dirname = UNSTREAM_STRING( &constant_bin[ 6281 ], 7, 1 );
    const_str_plain_KEYWORD_ENDCODESPACERANGE = UNSTREAM_STRING( &constant_bin[ 5260 ], 25, 1 );
    const_tuple_str_plain_endcidchar_tuple = PyTuple_New( 1 );
    const_str_plain_endcidchar = UNSTREAM_STRING( &constant_bin[ 6288 ], 10, 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_endcidchar_tuple, 0, const_str_plain_endcidchar ); Py_INCREF( const_str_plain_endcidchar );
    const_str_digest_81ff17319213b47b3b5f1e8319d6f3bf = UNSTREAM_STRING( &constant_bin[ 6298 ], 17, 0 );
    const_str_plain_kwargs = UNSTREAM_STRING( &constant_bin[ 6315 ], 6, 1 );
    const_dict_47564eeef2ec8d21619ac66253a5cc5e = _PyDict_NewPresized( 1 );
    PyDict_SetItem( const_dict_47564eeef2ec8d21619ac66253a5cc5e, const_str_plain_WMode, const_int_0 );
    assert( PyDict_Size( const_dict_47564eeef2ec8d21619ac66253a5cc5e ) == 1 );
    const_str_digest_744fab9097f9fc4d67e451ba8fa53651 = UNSTREAM_STRING( &constant_bin[ 6321 ], 13, 0 );
    const_str_plain_KEYWORD_BEGINBFCHAR = UNSTREAM_STRING( &constant_bin[ 5436 ], 19, 1 );
    const_tuple_false_true_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_false_true_tuple, 0, Py_False ); Py_INCREF( Py_False );
    PyTuple_SET_ITEM( const_tuple_false_true_tuple, 1, Py_True ); Py_INCREF( Py_True );
    const_tuple_str_plain_self_str_plain_kwargs_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_kwargs_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_kwargs_tuple, 1, const_str_plain_kwargs ); Py_INCREF( const_str_plain_kwargs );
    const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple, 1, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple, 2, const_str_plain_n ); Py_INCREF( const_str_plain_n );
    const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple, 1, const_str_plain_code ); Py_INCREF( const_str_plain_code );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple, 2, const_str_plain_cid ); Py_INCREF( const_str_plain_cid );
    const_str_plain_KEYWORD_ENDBFCHAR = UNSTREAM_STRING( &constant_bin[ 5460 ], 17, 1 );
    const_tuple_str_plain_usecmap_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_usecmap_tuple, 0, const_str_plain_usecmap ); Py_INCREF( const_str_plain_usecmap );
    const_str_plain_gzip = UNSTREAM_STRING( &constant_bin[ 6334 ], 4, 1 );
    const_str_plain_KEYWORD_BEGINCIDRANGE = UNSTREAM_STRING( &constant_bin[ 5290 ], 21, 1 );
    const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple = PyTuple_New( 4 );
    PyTuple_SET_ITEM( const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple, 1, const_str_plain_name ); Py_INCREF( const_str_plain_name );
    PyTuple_SET_ITEM( const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple, 2, const_str_plain_module ); Py_INCREF( const_str_plain_module );
    PyTuple_SET_ITEM( const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple, 3, const_str_plain_vertical ); Py_INCREF( const_str_plain_vertical );
    const_str_plain_cid2unichr = UNSTREAM_STRING( &constant_bin[ 6338 ], 10, 1 );
    const_tuple_str_plain_self_str_plain_cmap_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_cmap_tuple, 1, const_str_plain_cmap ); Py_INCREF( const_str_plain_cmap );
    const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple = PyTuple_New( 4 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple, 1, const_str_plain_out ); Py_INCREF( const_str_plain_out );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple, 2, const_str_plain_k ); Py_INCREF( const_str_plain_k );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple, 3, const_str_plain_v ); Py_INCREF( const_str_plain_v );
    const_str_plain_loads = UNSTREAM_STRING( &constant_bin[ 6348 ], 5, 1 );
    const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple, 0, const_str_plain_self ); Py_INCREF( const_str_plain_self );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple, 1, const_str_plain_k ); Py_INCREF( const_str_plain_k );
    PyTuple_SET_ITEM( const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple, 2, const_str_plain_v ); Py_INCREF( const_str_plain_v );

    constants_created = true;
}

#ifndef __NUITKA_NO_ASSERT__
void checkModuleConstants_pdfminer$cmapdb( void )
{
    // The module may not have been used at all.
    if (constants_created == false) return;


}
#endif

// The module code objects.
static PyCodeObject *codeobj_453c250602a3594a72d093020d99368b;
static PyCodeObject *codeobj_1bcd1bf519e2b38557d857744ff7938c;
static PyCodeObject *codeobj_e27dfacafd4f0c6cafc37ccc00e56d00;
static PyCodeObject *codeobj_70c765a79ededee6fac819da4b485742;
static PyCodeObject *codeobj_6e3884fccc459a164677932fec301eae;
static PyCodeObject *codeobj_4241055d5ae190a4b1b81c41bc26fa03;
static PyCodeObject *codeobj_322e6ebbfec7df703f1414c055282bd3;
static PyCodeObject *codeobj_fd13000fe202a74bec55fd084fd66e0d;
static PyCodeObject *codeobj_a80f840bc8a1ed93b203ed21d320acaa;
static PyCodeObject *codeobj_393bff62988f703c8ec9fb622290849f;
static PyCodeObject *codeobj_eda9792646615076f73a487c13258da9;
static PyCodeObject *codeobj_e12ef1341a3f4da82b81099a3fb28678;
static PyCodeObject *codeobj_413e0f150c7511019171d87e84c9a71e;
static PyCodeObject *codeobj_e5e7e55f392592a385ee5efc197a73a2;
static PyCodeObject *codeobj_448023be2082b765d13e992240c4a9c8;
static PyCodeObject *codeobj_b8a1a2ca42dca93d288657257f607fc7;
static PyCodeObject *codeobj_39f92db23036c369bf860621db522420;
static PyCodeObject *codeobj_d45f9db8c770efe384eb416ddad3eb5f;
static PyCodeObject *codeobj_51ae9cf5786f0e86ed5f528254011a18;
static PyCodeObject *codeobj_6c9e14d04177bd2655d3c3028f48ff92;
static PyCodeObject *codeobj_eb5ba0b7e44a98324f539f14a326e09c;
static PyCodeObject *codeobj_dde973ae2c181782bcfe319ce801f19b;
static PyCodeObject *codeobj_23065d1938672ee05fa3dd3a75f30253;
static PyCodeObject *codeobj_97fad3ef23a1d8553a58ab6f39e4d675;
static PyCodeObject *codeobj_3689aab6f2005e7d6d6cba5bd05af69a;
static PyCodeObject *codeobj_91864749e5c8ffe960570370a9df7181;
static PyCodeObject *codeobj_af28b21103770807e407a40fb3bd2b78;
static PyCodeObject *codeobj_84dce90dcac2146b7ab8208a1813e950;
static PyCodeObject *codeobj_4470f8f74fc84dbe3ef6af9cb8351243;
static PyCodeObject *codeobj_96b1bf7efd688a60a724ef5995c02a1a;
static PyCodeObject *codeobj_08a7366c7a58a32fd3a114d82e1cfb5f;
static PyCodeObject *codeobj_36d9bc168446ebd066abe05baa90edb4;
static PyCodeObject *codeobj_cd9a0c5cca920731f1f4435051040467;

static void createModuleCodeObjects(void)
{
    module_filename_obj = const_str_digest_9320efa7add6853c7ceff8f829714204;
    codeobj_453c250602a3594a72d093020d99368b = MAKE_CODEOBJ( module_filename_obj, const_str_digest_4083d90c6f9c4663e999995b5eecbe81, 1, const_tuple_empty, 0, CO_NOFREE );
    codeobj_1bcd1bf519e2b38557d857744ff7938c = MAKE_CODEOBJ( module_filename_obj, const_str_plain_CMap, 68, const_tuple_d8913f12e70aad91e88259d12f7d53aa_tuple, 0, CO_NEWLOCALS | CO_NOFREE );
    codeobj_e27dfacafd4f0c6cafc37ccc00e56d00 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_CMapDB, 222, const_tuple_36ed8d6860da18fa665ff101615207f9_tuple, 0, CO_NEWLOCALS | CO_NOFREE );
    codeobj_70c765a79ededee6fac819da4b485742 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_CMapParser, 274, const_tuple_a4c6aaf8631feb1e7b3d5f108949e4b2_tuple, 0, CO_NEWLOCALS | CO_NOFREE );
    codeobj_6e3884fccc459a164677932fec301eae = MAKE_CODEOBJ( module_filename_obj, const_str_plain_UnicodeMap, 134, const_tuple_9a0f21938d54faa93743eba74420da5f_tuple, 0, CO_NEWLOCALS | CO_NOFREE );
    codeobj_4241055d5ae190a4b1b81c41bc26fa03 = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 45, const_tuple_str_plain_self_str_plain_kwargs_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_VARKEYWORDS | CO_NOFREE );
    codeobj_322e6ebbfec7df703f1414c055282bd3 = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 70, const_tuple_str_plain_self_str_plain_kwargs_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_VARKEYWORDS | CO_NOFREE );
    codeobj_fd13000fe202a74bec55fd084fd66e0d = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 136, const_tuple_str_plain_self_str_plain_kwargs_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_VARKEYWORDS | CO_NOFREE );
    codeobj_a80f840bc8a1ed93b203ed21d320acaa = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 198, const_tuple_str_plain_self_str_plain_name_str_plain_module_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_393bff62988f703c8ec9fb622290849f = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 210, const_tuple_f381350bf28fc904ca4ca505e7e9fb45_tuple, 4, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_eda9792646615076f73a487c13258da9 = MAKE_CODEOBJ( module_filename_obj, const_str_plain___init__, 276, const_tuple_str_plain_self_str_plain_cmap_str_plain_fp_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_e12ef1341a3f4da82b81099a3fb28678 = MAKE_CODEOBJ( module_filename_obj, const_str_plain___repr__, 75, const_tuple_str_plain_self_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_413e0f150c7511019171d87e84c9a71e = MAKE_CODEOBJ( module_filename_obj, const_str_plain___repr__, 141, const_tuple_str_plain_self_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_e5e7e55f392592a385ee5efc197a73a2 = MAKE_CODEOBJ( module_filename_obj, const_str_plain__load_data, 230, const_tuple_e8e04da2c4cc7a944d8bdbd1f946c052_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_448023be2082b765d13e992240c4a9c8 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_add_cid2unichr, 59, const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_b8a1a2ca42dca93d288657257f607fc7 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_add_cid2unichr, 179, const_tuple_str_plain_self_str_plain_cid_str_plain_code_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_39f92db23036c369bf860621db522420 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_add_code2cid, 56, const_tuple_str_plain_self_str_plain_code_str_plain_cid_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_d45f9db8c770efe384eb416ddad3eb5f = MAKE_CODEOBJ( module_filename_obj, const_str_plain_add_code2cid, 159, const_tuple_e31735da1688856af07d842043d3b1e7_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_51ae9cf5786f0e86ed5f528254011a18 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_copy, 81, const_tuple_ea49e4c0ec16ff976110ec157b3110df_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS );
    codeobj_6c9e14d04177bd2655d3c3028f48ff92 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_decode, 92, const_tuple_str_plain_self_str_plain_code_str_plain_d_str_plain_c_tuple, 2, CO_GENERATOR | CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_eb5ba0b7e44a98324f539f14a326e09c = MAKE_CODEOBJ( module_filename_obj, const_str_plain_decode, 124, const_tuple_str_plain_self_str_plain_code_str_plain_n_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_dde973ae2c181782bcfe319ce801f19b = MAKE_CODEOBJ( module_filename_obj, const_str_plain_do_keyword, 307, const_tuple_6514984971888835acacc41b1ed01e7a_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_23065d1938672ee05fa3dd3a75f30253 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_dump, 107, const_tuple_2fa8118297e23bc045b4b71cc13a7b84_tuple, 4, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_97fad3ef23a1d8553a58ab6f39e4d675 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_dump, 149, const_tuple_str_plain_self_str_plain_out_str_plain_k_str_plain_v_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_3689aab6f2005e7d6d6cba5bd05af69a = MAKE_CODEOBJ( module_filename_obj, const_str_plain_get_cmap, 247, const_tuple_str_plain_klass_str_plain_name_str_plain_data_str_plain_cmap_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_91864749e5c8ffe960570370a9df7181 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_get_unichr, 144, const_tuple_str_plain_self_str_plain_cid_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_af28b21103770807e407a40fb3bd2b78 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_get_unicode_map, 261, const_tuple_b9a5be3a4ea133b054a15417336110d9_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_84dce90dcac2146b7ab8208a1813e950 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_is_vertical, 49, const_tuple_str_plain_self_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_4470f8f74fc84dbe3ef6af9cb8351243 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_main, 424, const_tuple_20a481037a57dff5c7dbce7f0b6da523_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_96b1bf7efd688a60a724ef5995c02a1a = MAKE_CODEOBJ( module_filename_obj, const_str_plain_run, 283, const_tuple_str_plain_self_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_08a7366c7a58a32fd3a114d82e1cfb5f = MAKE_CODEOBJ( module_filename_obj, const_str_plain_set_attr, 52, const_tuple_str_plain_self_str_plain_k_str_plain_v_tuple, 3, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_36d9bc168446ebd066abe05baa90edb4 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_use_cmap, 62, const_tuple_str_plain_self_str_plain_cmap_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_cd9a0c5cca920731f1f4435051040467 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_use_cmap, 78, const_tuple_str_plain_self_str_plain_cmap_str_plain_copy_tuple, 2, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
}

// The module function declarations.
#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
static PyObject *pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_context( struct Nuitka_GeneratorObject *generator, PyObject *yield_return_value );
#else
static void pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_context( struct Nuitka_GeneratorObject *generator );
#endif


NUITKA_CROSS_MODULE PyObject *impl___internal__$$$function_3_complex_call_helper_pos_star_dict( PyObject **python_pars );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_10_decode(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_11_dump( PyObject *defaults );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_12_decode(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_13___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_14___repr__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_15_get_unichr(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_16_dump( PyObject *defaults );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_17_add_code2cid(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_18_add_cid2unichr(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_19___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_1___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_20___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_21__load_data(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_22_get_cmap(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_23_get_unicode_map( PyObject *defaults );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_24___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_25_run(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_26_do_keyword(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_27_main(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_2_is_vertical(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_3_set_attr(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_4_add_code2cid(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_5_add_cid2unichr(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_6_use_cmap(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_7___init__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_8___repr__(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap(  );


static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy( struct Nuitka_CellObject *closure_copy );


// The module function definitions.
static PyObject *impl_pdfminer$cmapdb$$$function_1___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_kwargs = python_pars[ 1 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_called_instance_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    static struct Nuitka_FrameObject *cache_frame_4241055d5ae190a4b1b81c41bc26fa03 = NULL;

    struct Nuitka_FrameObject *frame_4241055d5ae190a4b1b81c41bc26fa03;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_4241055d5ae190a4b1b81c41bc26fa03, codeobj_4241055d5ae190a4b1b81c41bc26fa03, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *) );
    frame_4241055d5ae190a4b1b81c41bc26fa03 = cache_frame_4241055d5ae190a4b1b81c41bc26fa03;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_4241055d5ae190a4b1b81c41bc26fa03 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_4241055d5ae190a4b1b81c41bc26fa03 ) == 2 ); // Frame stack

    // Framed code:
    tmp_called_instance_1 = par_kwargs;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_4241055d5ae190a4b1b81c41bc26fa03->m_frame.f_lineno = 46;
    tmp_assattr_name_1 = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_copy );
    if ( tmp_assattr_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 46;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_attrs, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_1 );

        exception_lineno = 46;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_1 );

#if 0
    RESTORE_FRAME_EXCEPTION( frame_4241055d5ae190a4b1b81c41bc26fa03 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_4241055d5ae190a4b1b81c41bc26fa03 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_4241055d5ae190a4b1b81c41bc26fa03, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_4241055d5ae190a4b1b81c41bc26fa03->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_4241055d5ae190a4b1b81c41bc26fa03, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_4241055d5ae190a4b1b81c41bc26fa03,
        type_description_1,
        par_self,
        par_kwargs
    );


    // Release cached frame.
    if ( frame_4241055d5ae190a4b1b81c41bc26fa03 == cache_frame_4241055d5ae190a4b1b81c41bc26fa03 )
    {
        Py_DECREF( frame_4241055d5ae190a4b1b81c41bc26fa03 );
    }
    cache_frame_4241055d5ae190a4b1b81c41bc26fa03 = NULL;

    assertFrameObject( frame_4241055d5ae190a4b1b81c41bc26fa03 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_1___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_1___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_2_is_vertical( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_compexpr_left_1;
    PyObject *tmp_compexpr_right_1;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    static struct Nuitka_FrameObject *cache_frame_84dce90dcac2146b7ab8208a1813e950 = NULL;

    struct Nuitka_FrameObject *frame_84dce90dcac2146b7ab8208a1813e950;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_84dce90dcac2146b7ab8208a1813e950, codeobj_84dce90dcac2146b7ab8208a1813e950, module_pdfminer$cmapdb, sizeof(void *) );
    frame_84dce90dcac2146b7ab8208a1813e950 = cache_frame_84dce90dcac2146b7ab8208a1813e950;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_84dce90dcac2146b7ab8208a1813e950 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_84dce90dcac2146b7ab8208a1813e950 ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_called_instance_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_attrs );
    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 50;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    frame_84dce90dcac2146b7ab8208a1813e950->m_frame.f_lineno = 50;
    tmp_compexpr_left_1 = CALL_METHOD_WITH_ARGS2( tmp_called_instance_1, const_str_plain_get, &PyTuple_GET_ITEM( const_tuple_str_plain_WMode_int_0_tuple, 0 ) );

    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_compexpr_left_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 50;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    tmp_compexpr_right_1 = const_int_0;
    tmp_return_value = RICH_COMPARE_NE( tmp_compexpr_left_1, tmp_compexpr_right_1 );
    Py_DECREF( tmp_compexpr_left_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 50;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_84dce90dcac2146b7ab8208a1813e950 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_84dce90dcac2146b7ab8208a1813e950 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_84dce90dcac2146b7ab8208a1813e950 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_84dce90dcac2146b7ab8208a1813e950, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_84dce90dcac2146b7ab8208a1813e950->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_84dce90dcac2146b7ab8208a1813e950, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_84dce90dcac2146b7ab8208a1813e950,
        type_description_1,
        par_self
    );


    // Release cached frame.
    if ( frame_84dce90dcac2146b7ab8208a1813e950 == cache_frame_84dce90dcac2146b7ab8208a1813e950 )
    {
        Py_DECREF( frame_84dce90dcac2146b7ab8208a1813e950 );
    }
    cache_frame_84dce90dcac2146b7ab8208a1813e950 = NULL;

    assertFrameObject( frame_84dce90dcac2146b7ab8208a1813e950 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_2_is_vertical );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_2_is_vertical );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_3_set_attr( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_k = python_pars[ 1 ];
    PyObject *par_v = python_pars[ 2 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subvalue_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    static struct Nuitka_FrameObject *cache_frame_08a7366c7a58a32fd3a114d82e1cfb5f = NULL;

    struct Nuitka_FrameObject *frame_08a7366c7a58a32fd3a114d82e1cfb5f;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_08a7366c7a58a32fd3a114d82e1cfb5f, codeobj_08a7366c7a58a32fd3a114d82e1cfb5f, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_08a7366c7a58a32fd3a114d82e1cfb5f = cache_frame_08a7366c7a58a32fd3a114d82e1cfb5f;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_08a7366c7a58a32fd3a114d82e1cfb5f );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_08a7366c7a58a32fd3a114d82e1cfb5f ) == 2 ); // Frame stack

    // Framed code:
    tmp_ass_subvalue_1 = par_v;

    CHECK_OBJECT( tmp_ass_subvalue_1 );
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_attrs );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 53;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_1 = par_k;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 53;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

#if 0
    RESTORE_FRAME_EXCEPTION( frame_08a7366c7a58a32fd3a114d82e1cfb5f );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_08a7366c7a58a32fd3a114d82e1cfb5f );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_08a7366c7a58a32fd3a114d82e1cfb5f, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_08a7366c7a58a32fd3a114d82e1cfb5f->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_08a7366c7a58a32fd3a114d82e1cfb5f, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_08a7366c7a58a32fd3a114d82e1cfb5f,
        type_description_1,
        par_self,
        par_k,
        par_v
    );


    // Release cached frame.
    if ( frame_08a7366c7a58a32fd3a114d82e1cfb5f == cache_frame_08a7366c7a58a32fd3a114d82e1cfb5f )
    {
        Py_DECREF( frame_08a7366c7a58a32fd3a114d82e1cfb5f );
    }
    cache_frame_08a7366c7a58a32fd3a114d82e1cfb5f = NULL;

    assertFrameObject( frame_08a7366c7a58a32fd3a114d82e1cfb5f );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_3_set_attr );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_k );
    Py_DECREF( par_k );
    par_k = NULL;

    CHECK_OBJECT( (PyObject *)par_v );
    Py_DECREF( par_v );
    par_v = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_k );
    Py_DECREF( par_k );
    par_k = NULL;

    CHECK_OBJECT( (PyObject *)par_v );
    Py_DECREF( par_v );
    par_v = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_3_set_attr );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_4_add_code2cid( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_code = python_pars[ 1 ];
    PyObject *par_cid = python_pars[ 2 ];
    PyObject *tmp_return_value;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_4_add_code2cid );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    goto function_return_exit;
    // End of try:
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;


    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_4_add_code2cid );
    return NULL;

    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_5_add_cid2unichr( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cid = python_pars[ 1 ];
    PyObject *par_code = python_pars[ 2 ];
    PyObject *tmp_return_value;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_5_add_cid2unichr );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    goto function_return_exit;
    // End of try:
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;


    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_5_add_cid2unichr );
    return NULL;

    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_6_use_cmap( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cmap = python_pars[ 1 ];
    PyObject *tmp_return_value;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_6_use_cmap );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;

    goto function_return_exit;
    // End of try:
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;


    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_6_use_cmap );
    return NULL;

    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_7___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_kwargs = python_pars[ 1 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_dircall_arg1_1;
    PyObject *tmp_dircall_arg2_1;
    PyObject *tmp_dircall_arg3_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_322e6ebbfec7df703f1414c055282bd3 = NULL;

    struct Nuitka_FrameObject *frame_322e6ebbfec7df703f1414c055282bd3;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_322e6ebbfec7df703f1414c055282bd3, codeobj_322e6ebbfec7df703f1414c055282bd3, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *) );
    frame_322e6ebbfec7df703f1414c055282bd3 = cache_frame_322e6ebbfec7df703f1414c055282bd3;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_322e6ebbfec7df703f1414c055282bd3 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_322e6ebbfec7df703f1414c055282bd3 ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapBase );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapBase" );
        exception_tb = NULL;

        exception_lineno = 71;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }

    tmp_dircall_arg1_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain___init__ );
    if ( tmp_dircall_arg1_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 71;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_dircall_arg2_1 = PyTuple_New( 1 );
    tmp_tuple_element_1 = par_self;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_dircall_arg2_1, 0, tmp_tuple_element_1 );
    tmp_dircall_arg3_1 = par_kwargs;

    CHECK_OBJECT( tmp_dircall_arg3_1 );
    Py_INCREF( tmp_dircall_arg3_1 );

    {
        PyObject *dir_call_args[] = {tmp_dircall_arg1_1, tmp_dircall_arg2_1, tmp_dircall_arg3_1};
        tmp_unused = impl___internal__$$$function_3_complex_call_helper_pos_star_dict( dir_call_args );
    }
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 71;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_assattr_name_1 = PyDict_New();
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_code2cid, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_1 );

        exception_lineno = 72;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_1 );

#if 0
    RESTORE_FRAME_EXCEPTION( frame_322e6ebbfec7df703f1414c055282bd3 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_322e6ebbfec7df703f1414c055282bd3 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_322e6ebbfec7df703f1414c055282bd3, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_322e6ebbfec7df703f1414c055282bd3->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_322e6ebbfec7df703f1414c055282bd3, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_322e6ebbfec7df703f1414c055282bd3,
        type_description_1,
        par_self,
        par_kwargs
    );


    // Release cached frame.
    if ( frame_322e6ebbfec7df703f1414c055282bd3 == cache_frame_322e6ebbfec7df703f1414c055282bd3 )
    {
        Py_DECREF( frame_322e6ebbfec7df703f1414c055282bd3 );
    }
    cache_frame_322e6ebbfec7df703f1414c055282bd3 = NULL;

    assertFrameObject( frame_322e6ebbfec7df703f1414c055282bd3 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_7___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_7___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_8___repr__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    static struct Nuitka_FrameObject *cache_frame_e12ef1341a3f4da82b81099a3fb28678 = NULL;

    struct Nuitka_FrameObject *frame_e12ef1341a3f4da82b81099a3fb28678;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_e12ef1341a3f4da82b81099a3fb28678, codeobj_e12ef1341a3f4da82b81099a3fb28678, module_pdfminer$cmapdb, sizeof(void *) );
    frame_e12ef1341a3f4da82b81099a3fb28678 = cache_frame_e12ef1341a3f4da82b81099a3fb28678;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_e12ef1341a3f4da82b81099a3fb28678 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_e12ef1341a3f4da82b81099a3fb28678 ) == 2 ); // Frame stack

    // Framed code:
    tmp_left_name_1 = const_str_digest_5b68fb7448108f6baddc17ec34a02c5e;
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_called_instance_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_attrs );
    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 76;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    frame_e12ef1341a3f4da82b81099a3fb28678->m_frame.f_lineno = 76;
    tmp_right_name_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_1, const_str_plain_get, &PyTuple_GET_ITEM( const_tuple_str_plain_CMapName_tuple, 0 ) );

    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_right_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 76;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    tmp_return_value = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 76;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_e12ef1341a3f4da82b81099a3fb28678 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_e12ef1341a3f4da82b81099a3fb28678 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_e12ef1341a3f4da82b81099a3fb28678 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_e12ef1341a3f4da82b81099a3fb28678, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_e12ef1341a3f4da82b81099a3fb28678->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_e12ef1341a3f4da82b81099a3fb28678, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_e12ef1341a3f4da82b81099a3fb28678,
        type_description_1,
        par_self
    );


    // Release cached frame.
    if ( frame_e12ef1341a3f4da82b81099a3fb28678 == cache_frame_e12ef1341a3f4da82b81099a3fb28678 )
    {
        Py_DECREF( frame_e12ef1341a3f4da82b81099a3fb28678 );
    }
    cache_frame_e12ef1341a3f4da82b81099a3fb28678 = NULL;

    assertFrameObject( frame_e12ef1341a3f4da82b81099a3fb28678 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_8___repr__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_8___repr__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_9_use_cmap( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cmap = python_pars[ 1 ];
    struct Nuitka_CellObject *var_copy = PyCell_EMPTY();
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_called_name_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_raise_type_1;
    int tmp_res;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_cd9a0c5cca920731f1f4435051040467 = NULL;

    struct Nuitka_FrameObject *frame_cd9a0c5cca920731f1f4435051040467;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_cd9a0c5cca920731f1f4435051040467, codeobj_cd9a0c5cca920731f1f4435051040467, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_cd9a0c5cca920731f1f4435051040467 = cache_frame_cd9a0c5cca920731f1f4435051040467;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_cd9a0c5cca920731f1f4435051040467 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_cd9a0c5cca920731f1f4435051040467 ) == 2 ); // Frame stack

    // Framed code:
    tmp_isinstance_inst_1 = par_cmap;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMap );

    if (unlikely( tmp_isinstance_cls_1 == NULL ))
    {
        tmp_isinstance_cls_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMap );
    }

    if ( tmp_isinstance_cls_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMap" );
        exception_tb = NULL;

        exception_lineno = 79;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }

    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 79;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }
    if ( tmp_res == 1 )
    {
        goto branch_no_1;
    }
    else
    {
        goto branch_yes_1;
    }
    branch_yes_1:;
    tmp_raise_type_1 = PyExc_AssertionError;
    exception_type = tmp_raise_type_1;
    Py_INCREF( tmp_raise_type_1 );
    exception_lineno = 79;
    RAISE_EXCEPTION_WITH_TYPE( &exception_type, &exception_value, &exception_tb );
    type_description_1 = "ooc";
    goto frame_exception_exit_1;
    branch_no_1:;
    tmp_assign_source_1 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy( var_copy );
    {
        PyObject *old = PyCell_GET( var_copy );
        PyCell_SET( var_copy, tmp_assign_source_1 );
        Py_XDECREF( old );
    }

    if ( var_copy == NULL )
    {
        tmp_called_name_1 = NULL;
    }
    else
    {
        tmp_called_name_1 = PyCell_GET( var_copy );
    }

    if ( tmp_called_name_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "copy" );
        exception_tb = NULL;

        exception_lineno = 89;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }

    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_args_element_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_code2cid );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 89;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }
    tmp_source_name_2 = par_cmap;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_args_element_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_code2cid );
    if ( tmp_args_element_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_args_element_name_1 );

        exception_lineno = 89;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }
    frame_cd9a0c5cca920731f1f4435051040467->m_frame.f_lineno = 89;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_args_element_name_1 );
    Py_DECREF( tmp_args_element_name_2 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 89;
        type_description_1 = "ooc";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );

#if 0
    RESTORE_FRAME_EXCEPTION( frame_cd9a0c5cca920731f1f4435051040467 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_cd9a0c5cca920731f1f4435051040467 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_cd9a0c5cca920731f1f4435051040467, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_cd9a0c5cca920731f1f4435051040467->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_cd9a0c5cca920731f1f4435051040467, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_cd9a0c5cca920731f1f4435051040467,
        type_description_1,
        par_self,
        par_cmap,
        var_copy
    );


    // Release cached frame.
    if ( frame_cd9a0c5cca920731f1f4435051040467 == cache_frame_cd9a0c5cca920731f1f4435051040467 )
    {
        Py_DECREF( frame_cd9a0c5cca920731f1f4435051040467 );
    }
    cache_frame_cd9a0c5cca920731f1f4435051040467 = NULL;

    assertFrameObject( frame_cd9a0c5cca920731f1f4435051040467 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_9_use_cmap );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;

    CHECK_OBJECT( (PyObject *)var_copy );
    Py_DECREF( var_copy );
    var_copy = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;

    CHECK_OBJECT( (PyObject *)var_copy );
    Py_DECREF( var_copy );
    var_copy = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_9_use_cmap );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_dst = python_pars[ 0 ];
    PyObject *par_src = python_pars[ 1 ];
    PyObject *var_k = NULL;
    PyObject *var_v = NULL;
    PyObject *var_d = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *tmp_tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_tuple_unpack_1__source_iter = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscribed_2;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subscript_2;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_ass_subvalue_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_name_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_iter_arg_2;
    PyObject *tmp_iterator_attempt;
    PyObject *tmp_iterator_name_1;
    PyObject *tmp_next_source_1;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_unpack_1;
    PyObject *tmp_unpack_2;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_51ae9cf5786f0e86ed5f528254011a18 = NULL;

    struct Nuitka_FrameObject *frame_51ae9cf5786f0e86ed5f528254011a18;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_51ae9cf5786f0e86ed5f528254011a18, codeobj_51ae9cf5786f0e86ed5f528254011a18, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_51ae9cf5786f0e86ed5f528254011a18 = cache_frame_51ae9cf5786f0e86ed5f528254011a18;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_51ae9cf5786f0e86ed5f528254011a18 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_51ae9cf5786f0e86ed5f528254011a18 ) == 2 ); // Frame stack

    // Framed code:
    tmp_called_instance_1 = par_src;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_51ae9cf5786f0e86ed5f528254011a18->m_frame.f_lineno = 82;
    tmp_iter_arg_1 = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_iteritems );
    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 82;
        type_description_1 = "oooooc";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_1 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 82;
        type_description_1 = "oooooc";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_1;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_2 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_2 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooc";
            exception_lineno = 82;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_2;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_2 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_iter_arg_2 );
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_2 );
    if ( tmp_assign_source_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 82;
        type_description_1 = "oooooc";
        goto try_except_handler_3;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__source_iter;
        tmp_tuple_unpack_1__source_iter = tmp_assign_source_3;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_1 );
    tmp_assign_source_4 = UNPACK_NEXT( tmp_unpack_1, 0 );
    if ( tmp_assign_source_4 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooc";
        exception_lineno = 82;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_1;
        tmp_tuple_unpack_1__element_1 = tmp_assign_source_4;
        Py_XDECREF( old );
    }

    tmp_unpack_2 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_2 );
    tmp_assign_source_5 = UNPACK_NEXT( tmp_unpack_2, 1 );
    if ( tmp_assign_source_5 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooc";
        exception_lineno = 82;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_2;
        tmp_tuple_unpack_1__element_2 = tmp_assign_source_5;
        Py_XDECREF( old );
    }

    tmp_iterator_name_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_1 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_1 ); assert( HAS_ITERNEXT( tmp_iterator_name_1 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_1 )->tp_iternext)( tmp_iterator_name_1 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooc";
                exception_lineno = 82;
                goto try_except_handler_4;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooc";
        exception_lineno = 82;
        goto try_except_handler_4;
    }
    goto try_end_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    try_end_1:;
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_2;
    // End of try:
    try_end_2:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    tmp_assign_source_6 = tmp_tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_assign_source_6 );
    {
        PyObject *old = var_k;
        var_k = tmp_assign_source_6;
        Py_INCREF( var_k );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    tmp_assign_source_7 = tmp_tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_assign_source_7 );
    {
        PyObject *old = var_v;
        var_v = tmp_assign_source_7;
        Py_INCREF( var_v );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    tmp_isinstance_inst_1 = var_v;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyDict_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 83;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_assign_source_8 = PyDict_New();
    {
        PyObject *old = var_d;
        var_d = tmp_assign_source_8;
        Py_XDECREF( old );
    }

    tmp_ass_subvalue_1 = var_d;

    CHECK_OBJECT( tmp_ass_subvalue_1 );
    tmp_ass_subscribed_1 = par_dst;

    CHECK_OBJECT( tmp_ass_subscribed_1 );
    tmp_ass_subscript_1 = var_k;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 85;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }
    if ( self->m_closure[0] == NULL )
    {
        tmp_called_name_1 = NULL;
    }
    else
    {
        tmp_called_name_1 = PyCell_GET( self->m_closure[0] );
    }

    if ( tmp_called_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "copy" );
        exception_tb = NULL;

        exception_lineno = 86;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }

    tmp_args_element_name_1 = var_d;

    CHECK_OBJECT( tmp_args_element_name_1 );
    tmp_args_element_name_2 = var_v;

    CHECK_OBJECT( tmp_args_element_name_2 );
    frame_51ae9cf5786f0e86ed5f528254011a18->m_frame.f_lineno = 86;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 86;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    goto branch_end_1;
    branch_no_1:;
    tmp_ass_subvalue_2 = var_v;

    CHECK_OBJECT( tmp_ass_subvalue_2 );
    tmp_ass_subscribed_2 = par_dst;

    CHECK_OBJECT( tmp_ass_subscribed_2 );
    tmp_ass_subscript_2 = var_k;

    CHECK_OBJECT( tmp_ass_subscript_2 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_2, tmp_ass_subscript_2, tmp_ass_subvalue_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 88;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }
    branch_end_1:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 82;
        type_description_1 = "oooooc";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_3;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_3:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_51ae9cf5786f0e86ed5f528254011a18 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_51ae9cf5786f0e86ed5f528254011a18 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_51ae9cf5786f0e86ed5f528254011a18, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_51ae9cf5786f0e86ed5f528254011a18->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_51ae9cf5786f0e86ed5f528254011a18, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_51ae9cf5786f0e86ed5f528254011a18,
        type_description_1,
        par_dst,
        par_src,
        var_k,
        var_v,
        var_d,
        self->m_closure[0]
    );


    // Release cached frame.
    if ( frame_51ae9cf5786f0e86ed5f528254011a18 == cache_frame_51ae9cf5786f0e86ed5f528254011a18 )
    {
        Py_DECREF( frame_51ae9cf5786f0e86ed5f528254011a18 );
    }
    cache_frame_51ae9cf5786f0e86ed5f528254011a18 = NULL;

    assertFrameObject( frame_51ae9cf5786f0e86ed5f528254011a18 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_dst );
    Py_DECREF( par_dst );
    par_dst = NULL;

    CHECK_OBJECT( (PyObject *)par_src );
    Py_DECREF( par_src );
    par_src = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_d );
    var_d = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_dst );
    Py_DECREF( par_dst );
    par_dst = NULL;

    CHECK_OBJECT( (PyObject *)par_src );
    Py_DECREF( par_src );
    par_src = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_d );
    var_d = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_10_decode( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    struct Nuitka_CellObject *par_self = PyCell_NEW1( python_pars[ 0 ] );
    struct Nuitka_CellObject *par_code = PyCell_NEW1( python_pars[ 1 ] );
    PyObject *tmp_return_value;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    tmp_return_value = Nuitka_Generator_New(
        pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_context,
        module_pdfminer$cmapdb,
        const_str_plain_decode,
#if PYTHON_VERSION >= 350
        NULL,
#endif
        codeobj_6c9e14d04177bd2655d3c3028f48ff92,
        2
    );

    ((struct Nuitka_GeneratorObject *)tmp_return_value)->m_closure[0] = par_code;
    Py_INCREF( ((struct Nuitka_GeneratorObject *)tmp_return_value)->m_closure[0] );
    ((struct Nuitka_GeneratorObject *)tmp_return_value)->m_closure[1] = par_self;
    Py_INCREF( ((struct Nuitka_GeneratorObject *)tmp_return_value)->m_closure[1] );
    assert( Py_SIZE( tmp_return_value ) >= 2 ); 


    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_10_decode );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    goto function_return_exit;
    // End of try:
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;


    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_10_decode );
    return NULL;

    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}



#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
struct pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_locals {
    PyObject *var_d
    PyObject *var_c
    PyObject *tmp_for_loop_1__for_iterator
    PyObject *tmp_for_loop_1__iter_value
    PyObject *exception_type
    PyObject *exception_value
    PyTracebackObject *exception_tb
    int exception_lineno
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    int exception_keeper_lineno_2;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_called_name_1;
    int tmp_cmp_In_1;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_expression_name_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_ord_arg_1;
    int tmp_res;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_tuple_element_1;
    char const *type_description_1
};
#endif

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
static PyObject *pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_context( struct Nuitka_GeneratorObject *generator, PyObject *yield_return_value )
#else
static void pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode_context( struct Nuitka_GeneratorObject *generator )
#endif
{
    CHECK_OBJECT( (PyObject *)generator );
    assert( Nuitka_Generator_Check( (PyObject *)generator ) );

    // Local variable initialization
    PyObject *var_d = NULL;
    PyObject *var_c = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_called_name_1;
    int tmp_cmp_In_1;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_expression_name_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_ord_arg_1;
    int tmp_res;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_generator = NULL;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;

    // Dispatch to yield based on return label index:


    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_generator, codeobj_6c9e14d04177bd2655d3c3028f48ff92, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    generator->m_frame = cache_frame_generator;

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    Py_INCREF( generator->m_frame );
    assert( Py_REFCNT( generator->m_frame ) == 2 ); // Frame stack

#if PYTHON_VERSION >= 340
    generator->m_frame->m_frame.f_gen = (PyObject *)generator;
#endif

    Py_CLEAR( generator->m_frame->m_frame.f_back );

    generator->m_frame->m_frame.f_back = PyThreadState_GET()->frame;
    Py_INCREF( generator->m_frame->m_frame.f_back );

    PyThreadState_GET()->frame = &generator->m_frame->m_frame;
    Py_INCREF( generator->m_frame );

    Nuitka_Frame_MarkAsExecuting( generator->m_frame );

#if PYTHON_VERSION >= 300
    // Accept currently existing exception as the one to publish again when we
    // yield or yield from.

    PyThreadState *thread_state = PyThreadState_GET();

    generator->m_frame->m_frame.f_exc_type = thread_state->exc_type;
    if ( generator->m_frame->m_frame.f_exc_type == Py_None ) generator->m_frame->m_frame.f_exc_type = NULL;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_type );
    generator->m_frame->m_frame.f_exc_value = thread_state->exc_value;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_value );
    generator->m_frame->m_frame.f_exc_traceback = thread_state->exc_traceback;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_traceback );
#endif

    // Framed code:
    if ( generator->m_closure[1] == NULL )
    {
        tmp_source_name_1 = NULL;
    }
    else
    {
        tmp_source_name_1 = PyCell_GET( generator->m_closure[1] );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "self" );
        exception_tb = NULL;

        exception_lineno = 93;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    tmp_cond_value_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_debug );
    if ( tmp_cond_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 93;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_1 );

        exception_lineno = 93;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_source_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_logging );

    if (unlikely( tmp_source_name_2 == NULL ))
    {
        tmp_source_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_logging );
    }

    if ( tmp_source_name_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "logging" );
        exception_tb = NULL;

        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_debug );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    tmp_left_name_1 = const_str_digest_e82b2289dd840656dde2e4ac175f6e70;
    tmp_right_name_1 = PyTuple_New( 2 );
    if ( generator->m_closure[1] == NULL )
    {
        tmp_tuple_element_1 = NULL;
    }
    else
    {
        tmp_tuple_element_1 = PyCell_GET( generator->m_closure[1] );
    }

    if ( tmp_tuple_element_1 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        Py_DECREF( tmp_right_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "self" );
        exception_tb = NULL;

        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 0, tmp_tuple_element_1 );
    if ( generator->m_closure[0] == NULL )
    {
        tmp_tuple_element_1 = NULL;
    }
    else
    {
        tmp_tuple_element_1 = PyCell_GET( generator->m_closure[0] );
    }

    if ( tmp_tuple_element_1 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        Py_DECREF( tmp_right_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "code" );
        exception_tb = NULL;

        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 1, tmp_tuple_element_1 );
    tmp_args_element_name_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    generator->m_frame->m_frame.f_lineno = 94;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 94;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    branch_no_1:;
    if ( generator->m_closure[1] == NULL )
    {
        tmp_source_name_3 = NULL;
    }
    else
    {
        tmp_source_name_3 = PyCell_GET( generator->m_closure[1] );
    }

    if ( tmp_source_name_3 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "self" );
        exception_tb = NULL;

        exception_lineno = 95;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    tmp_assign_source_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_code2cid );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 95;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    assert( var_d == NULL );
    var_d = tmp_assign_source_1;

    if ( generator->m_closure[0] == NULL )
    {
        tmp_iter_arg_1 = NULL;
    }
    else
    {
        tmp_iter_arg_1 = PyCell_GET( generator->m_closure[0] );
    }

    if ( tmp_iter_arg_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "code" );
        exception_tb = NULL;

        exception_lineno = 96;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }

    tmp_assign_source_2 = MAKE_ITERATOR( tmp_iter_arg_1 );
    if ( tmp_assign_source_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 96;
        type_description_1 = "ccoo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_2;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_3 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "ccoo";
            exception_lineno = 96;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_3;
        Py_XDECREF( old );
    }

    tmp_assign_source_4 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_assign_source_4 );
    {
        PyObject *old = var_c;
        var_c = tmp_assign_source_4;
        Py_INCREF( var_c );
        Py_XDECREF( old );
    }

    tmp_ord_arg_1 = var_c;

    CHECK_OBJECT( tmp_ord_arg_1 );
    tmp_assign_source_5 = BUILTIN_ORD( tmp_ord_arg_1 );
    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 97;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_c;
        assert( old != NULL );
        var_c = tmp_assign_source_5;
        Py_DECREF( old );
    }

    tmp_compare_left_1 = var_c;

    CHECK_OBJECT( tmp_compare_left_1 );
    tmp_compare_right_1 = var_d;

    if ( tmp_compare_right_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 98;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }

    tmp_cmp_In_1 = PySequence_Contains( tmp_compare_right_1, tmp_compare_left_1 );
    assert( !(tmp_cmp_In_1 == -1) );
    if ( tmp_cmp_In_1 == 1 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_subscribed_name_1 = var_d;

    if ( tmp_subscribed_name_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 99;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }

    tmp_subscript_name_1 = var_c;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_assign_source_6 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 99;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_d;
        var_d = tmp_assign_source_6;
        Py_XDECREF( old );
    }

    tmp_isinstance_inst_1 = var_d;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyInt_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 100;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_3;
    }
    else
    {
        goto branch_no_3;
    }
    branch_yes_3:;
    tmp_expression_name_1 = var_d;

    CHECK_OBJECT( tmp_expression_name_1 );
    Py_INCREF( tmp_expression_name_1 );
    tmp_unused = GENERATOR_YIELD( generator, tmp_expression_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 101;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    if ( generator->m_closure[1] == NULL )
    {
        tmp_source_name_4 = NULL;
    }
    else
    {
        tmp_source_name_4 = PyCell_GET( generator->m_closure[1] );
    }

    if ( tmp_source_name_4 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "self" );
        exception_tb = NULL;

        exception_lineno = 102;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }

    tmp_assign_source_7 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_code2cid );
    if ( tmp_assign_source_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 102;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_d;
        assert( old != NULL );
        var_d = tmp_assign_source_7;
        Py_DECREF( old );
    }

    branch_no_3:;
    goto branch_end_2;
    branch_no_2:;
    if ( generator->m_closure[1] == NULL )
    {
        tmp_source_name_5 = NULL;
    }
    else
    {
        tmp_source_name_5 = PyCell_GET( generator->m_closure[1] );
    }

    if ( tmp_source_name_5 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "self" );
        exception_tb = NULL;

        exception_lineno = 104;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }

    tmp_assign_source_8 = LOOKUP_ATTRIBUTE( tmp_source_name_5, const_str_plain_code2cid );
    if ( tmp_assign_source_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 104;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_d;
        var_d = tmp_assign_source_8;
        Py_XDECREF( old );
    }

    branch_end_2:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 96;
        type_description_1 = "ccoo";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;

    Nuitka_Frame_MarkAsNotExecuting( generator->m_frame );

#if PYTHON_VERSION >= 300
    Py_CLEAR( generator->m_frame->m_frame.f_exc_type );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_value );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_traceback );
#endif

    // Allow re-use of the frame again.
    Py_DECREF( generator->m_frame );
    goto frame_no_exception_1;

    frame_exception_exit_1:;

    // If it's not an exit exception, consider and create a traceback for it.
    if ( !EXCEPTION_MATCH_GENERATOR( exception_type ) )
    {
        if ( exception_tb == NULL )
        {
            exception_tb = MAKE_TRACEBACK( generator->m_frame, exception_lineno );
        }
        else if ( exception_tb->tb_frame != &generator->m_frame->m_frame )
        {
            exception_tb = ADD_TRACEBACK( exception_tb, generator->m_frame, exception_lineno );
        }

        Nuitka_Frame_AttachLocals(
            (struct Nuitka_FrameObject *)generator->m_frame,
            type_description_1,
            generator->m_closure[1],
            generator->m_closure[0],
            var_d,
            var_c
        );


        // Release cached frame.
        if ( generator->m_frame == cache_frame_generator )
        {
            Py_DECREF( generator->m_frame );
        }
        cache_frame_generator = NULL;

        assertFrameObject( generator->m_frame );
    }

#if PYTHON_VERSION >= 300
    Py_CLEAR( generator->m_frame->m_frame.f_exc_type );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_value );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_traceback );
#endif

    Py_DECREF( generator->m_frame );
    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_10_decode$$$genobj_1_decode );
    return;
    // Return handler code:
    try_return_handler_1:;
    Py_XDECREF( var_d );
    var_d = NULL;

    Py_XDECREF( var_c );
    var_c = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( var_d );
    var_d = NULL;

    Py_XDECREF( var_c );
    var_c = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto function_exception_exit;
    // End of try:

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
    return NULL;
#else
    generator->m_yielded = NULL;
    return;
#endif

    function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
    return NULL;
#else
    generator->m_yielded = NULL;
    return;
#endif
    // The above won't return, but we need to make it clear to the compiler
    // as well, or else it will complain and/or generate inferior code.
    assert(false);
    return;

    function_return_exit:
#if PYTHON_VERSION >= 330
    if ( tmp_return_value != Py_None )
    {
        PyObject *args[1] = { tmp_return_value };
        PyObject *stop_value = CALL_FUNCTION_WITH_ARGS1( PyExc_StopIteration, args );
        RESTORE_ERROR_OCCURRED( PyExc_StopIteration, stop_value, NULL );
        Py_INCREF( PyExc_StopIteration );
    }
    else
    {
        Py_DECREF( tmp_return_value );
    }
#endif

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
    return NULL;
#else
    generator->m_yielded = NULL;
    return;
#endif

}


static PyObject *impl_pdfminer$cmapdb$$$function_11_dump( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_out = python_pars[ 1 ];
    PyObject *par_code2cid = python_pars[ 2 ];
    PyObject *par_code = python_pars[ 3 ];
    PyObject *var_k = NULL;
    PyObject *var_v = NULL;
    PyObject *var_c = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *tmp_tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_tuple_unpack_1__source_iter = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    PyObject *tmp_assign_source_10;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    PyObject *tmp_dict_key_1;
    PyObject *tmp_dict_key_2;
    PyObject *tmp_dict_key_3;
    PyObject *tmp_dict_value_1;
    PyObject *tmp_dict_value_2;
    PyObject *tmp_dict_value_3;
    bool tmp_is_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_iter_arg_2;
    PyObject *tmp_iterator_attempt;
    PyObject *tmp_iterator_name_1;
    PyObject *tmp_kw_name_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_left_name_2;
    PyObject *tmp_next_source_1;
    int tmp_res;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_right_name_2;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_tuple_element_2;
    PyObject *tmp_unpack_1;
    PyObject *tmp_unpack_2;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_23065d1938672ee05fa3dd3a75f30253 = NULL;

    struct Nuitka_FrameObject *frame_23065d1938672ee05fa3dd3a75f30253;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_23065d1938672ee05fa3dd3a75f30253, codeobj_23065d1938672ee05fa3dd3a75f30253, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_23065d1938672ee05fa3dd3a75f30253 = cache_frame_23065d1938672ee05fa3dd3a75f30253;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_23065d1938672ee05fa3dd3a75f30253 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_23065d1938672ee05fa3dd3a75f30253 ) == 2 ); // Frame stack

    // Framed code:
    tmp_compare_left_1 = par_code2cid;

    CHECK_OBJECT( tmp_compare_left_1 );
    tmp_compare_right_1 = Py_None;
    tmp_is_1 = ( tmp_compare_left_1 == tmp_compare_right_1 );
    if ( tmp_is_1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_assign_source_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_code2cid );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 109;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    {
        PyObject *old = par_code2cid;
        assert( old != NULL );
        par_code2cid = tmp_assign_source_1;
        Py_DECREF( old );
    }

    tmp_assign_source_2 = const_tuple_empty;
    {
        PyObject *old = par_code;
        assert( old != NULL );
        par_code = tmp_assign_source_2;
        Py_INCREF( par_code );
        Py_DECREF( old );
    }

    branch_no_1:;
    tmp_called_name_1 = LOOKUP_BUILTIN( const_str_plain_sorted );
    assert( tmp_called_name_1 != NULL );
    tmp_called_instance_1 = par_code2cid;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_23065d1938672ee05fa3dd3a75f30253->m_frame.f_lineno = 111;
    tmp_args_element_name_1 = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_iteritems );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    frame_23065d1938672ee05fa3dd3a75f30253->m_frame.f_lineno = 111;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_iter_arg_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_3;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_4 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_4 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "ooooooo";
            exception_lineno = 111;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_4;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_2 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_iter_arg_2 );
    tmp_assign_source_5 = MAKE_ITERATOR( tmp_iter_arg_2 );
    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__source_iter;
        tmp_tuple_unpack_1__source_iter = tmp_assign_source_5;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_1 );
    tmp_assign_source_6 = UNPACK_NEXT( tmp_unpack_1, 0 );
    if ( tmp_assign_source_6 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "ooooooo";
        exception_lineno = 111;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_1;
        tmp_tuple_unpack_1__element_1 = tmp_assign_source_6;
        Py_XDECREF( old );
    }

    tmp_unpack_2 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_2 );
    tmp_assign_source_7 = UNPACK_NEXT( tmp_unpack_2, 1 );
    if ( tmp_assign_source_7 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "ooooooo";
        exception_lineno = 111;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_2;
        tmp_tuple_unpack_1__element_2 = tmp_assign_source_7;
        Py_XDECREF( old );
    }

    tmp_iterator_name_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_1 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_1 ); assert( HAS_ITERNEXT( tmp_iterator_name_1 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_1 )->tp_iternext)( tmp_iterator_name_1 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "ooooooo";
                exception_lineno = 111;
                goto try_except_handler_4;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "ooooooo";
        exception_lineno = 111;
        goto try_except_handler_4;
    }
    goto try_end_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    try_end_1:;
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_2;
    // End of try:
    try_end_2:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    tmp_assign_source_8 = tmp_tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_assign_source_8 );
    {
        PyObject *old = var_k;
        var_k = tmp_assign_source_8;
        Py_INCREF( var_k );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    tmp_assign_source_9 = tmp_tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_assign_source_9 );
    {
        PyObject *old = var_v;
        var_v = tmp_assign_source_9;
        Py_INCREF( var_v );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    tmp_left_name_1 = par_code;

    CHECK_OBJECT( tmp_left_name_1 );
    tmp_right_name_1 = PyTuple_New( 1 );
    tmp_tuple_element_1 = var_k;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 0, tmp_tuple_element_1 );
    tmp_assign_source_10 = BINARY_OPERATION_ADD( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_assign_source_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 112;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_c;
        var_c = tmp_assign_source_10;
        Py_XDECREF( old );
    }

    tmp_isinstance_inst_1 = var_v;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyInt_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 113;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_source_name_2 = par_out;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_called_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_write );
    if ( tmp_called_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 114;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    tmp_left_name_2 = const_str_digest_81ff17319213b47b3b5f1e8319d6f3bf;
    tmp_right_name_2 = PyTuple_New( 2 );
    tmp_tuple_element_2 = var_c;

    CHECK_OBJECT( tmp_tuple_element_2 );
    Py_INCREF( tmp_tuple_element_2 );
    PyTuple_SET_ITEM( tmp_right_name_2, 0, tmp_tuple_element_2 );
    tmp_tuple_element_2 = var_v;

    CHECK_OBJECT( tmp_tuple_element_2 );
    Py_INCREF( tmp_tuple_element_2 );
    PyTuple_SET_ITEM( tmp_right_name_2, 1, tmp_tuple_element_2 );
    tmp_args_element_name_2 = BINARY_OPERATION_REMAINDER( tmp_left_name_2, tmp_right_name_2 );
    Py_DECREF( tmp_right_name_2 );
    if ( tmp_args_element_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_2 );

        exception_lineno = 114;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    frame_23065d1938672ee05fa3dd3a75f30253->m_frame.f_lineno = 114;
    {
        PyObject *call_args[] = { tmp_args_element_name_2 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_2, call_args );
    }

    Py_DECREF( tmp_called_name_2 );
    Py_DECREF( tmp_args_element_name_2 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 114;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    goto branch_end_2;
    branch_no_2:;
    tmp_source_name_3 = par_self;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_called_name_3 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_dump );
    if ( tmp_called_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 116;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    tmp_kw_name_1 = _PyDict_NewPresized( 3 );
    tmp_dict_value_1 = par_out;

    CHECK_OBJECT( tmp_dict_value_1 );
    tmp_dict_key_1 = const_str_plain_out;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_1, tmp_dict_value_1 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_2 = var_v;

    CHECK_OBJECT( tmp_dict_value_2 );
    tmp_dict_key_2 = const_str_plain_code2cid;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_2, tmp_dict_value_2 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_3 = var_c;

    CHECK_OBJECT( tmp_dict_value_3 );
    tmp_dict_key_3 = const_str_plain_code;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_3, tmp_dict_value_3 );
    assert( !(tmp_res != 0) );
    frame_23065d1938672ee05fa3dd3a75f30253->m_frame.f_lineno = 116;
    tmp_unused = CALL_FUNCTION_WITH_KEYARGS( tmp_called_name_3, tmp_kw_name_1 );
    Py_DECREF( tmp_called_name_3 );
    Py_DECREF( tmp_kw_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 116;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    branch_end_2:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_3;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_3:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_23065d1938672ee05fa3dd3a75f30253 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_23065d1938672ee05fa3dd3a75f30253 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_23065d1938672ee05fa3dd3a75f30253, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_23065d1938672ee05fa3dd3a75f30253->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_23065d1938672ee05fa3dd3a75f30253, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_23065d1938672ee05fa3dd3a75f30253,
        type_description_1,
        par_self,
        par_out,
        par_code2cid,
        par_code,
        var_k,
        var_v,
        var_c
    );


    // Release cached frame.
    if ( frame_23065d1938672ee05fa3dd3a75f30253 == cache_frame_23065d1938672ee05fa3dd3a75f30253 )
    {
        Py_DECREF( frame_23065d1938672ee05fa3dd3a75f30253 );
    }
    cache_frame_23065d1938672ee05fa3dd3a75f30253 = NULL;

    assertFrameObject( frame_23065d1938672ee05fa3dd3a75f30253 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_11_dump );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_out );
    Py_DECREF( par_out );
    par_out = NULL;

    CHECK_OBJECT( (PyObject *)par_code2cid );
    Py_DECREF( par_code2cid );
    par_code2cid = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_c );
    var_c = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_out );
    Py_DECREF( par_out );
    par_out = NULL;

    Py_XDECREF( par_code2cid );
    par_code2cid = NULL;

    Py_XDECREF( par_code );
    par_code = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_c );
    var_c = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_11_dump );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_12_decode( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_code = python_pars[ 1 ];
    PyObject *var_n = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_called_name_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_left_name_2;
    PyObject *tmp_len_arg_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_right_name_2;
    PyObject *tmp_source_name_1;
    static struct Nuitka_FrameObject *cache_frame_eb5ba0b7e44a98324f539f14a326e09c = NULL;

    struct Nuitka_FrameObject *frame_eb5ba0b7e44a98324f539f14a326e09c;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_eb5ba0b7e44a98324f539f14a326e09c, codeobj_eb5ba0b7e44a98324f539f14a326e09c, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_eb5ba0b7e44a98324f539f14a326e09c = cache_frame_eb5ba0b7e44a98324f539f14a326e09c;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_eb5ba0b7e44a98324f539f14a326e09c );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_eb5ba0b7e44a98324f539f14a326e09c ) == 2 ); // Frame stack

    // Framed code:
    tmp_len_arg_1 = par_code;

    CHECK_OBJECT( tmp_len_arg_1 );
    tmp_left_name_1 = BUILTIN_LEN( tmp_len_arg_1 );
    if ( tmp_left_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 125;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_right_name_1 = const_int_pos_2;
    tmp_assign_source_1 = BINARY_OPERATION_FLOORDIV( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_left_name_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 125;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    assert( var_n == NULL );
    var_n = tmp_assign_source_1;

    tmp_cond_value_1 = var_n;

    CHECK_OBJECT( tmp_cond_value_1 );
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 126;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_struct );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_struct );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "struct" );
        exception_tb = NULL;

        exception_lineno = 127;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_unpack );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 127;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_left_name_2 = const_str_digest_6d86adbb5b668bab4cd670281ea4b3e0;
    tmp_right_name_2 = var_n;

    CHECK_OBJECT( tmp_right_name_2 );
    tmp_args_element_name_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_2, tmp_right_name_2 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 127;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_args_element_name_2 = par_code;

    CHECK_OBJECT( tmp_args_element_name_2 );
    frame_eb5ba0b7e44a98324f539f14a326e09c->m_frame.f_lineno = 127;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_return_value = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 127;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    goto branch_end_1;
    branch_no_1:;
    tmp_return_value = const_tuple_empty;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_end_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_eb5ba0b7e44a98324f539f14a326e09c );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_eb5ba0b7e44a98324f539f14a326e09c );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_eb5ba0b7e44a98324f539f14a326e09c );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_eb5ba0b7e44a98324f539f14a326e09c, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_eb5ba0b7e44a98324f539f14a326e09c->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_eb5ba0b7e44a98324f539f14a326e09c, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_eb5ba0b7e44a98324f539f14a326e09c,
        type_description_1,
        par_self,
        par_code,
        var_n
    );


    // Release cached frame.
    if ( frame_eb5ba0b7e44a98324f539f14a326e09c == cache_frame_eb5ba0b7e44a98324f539f14a326e09c )
    {
        Py_DECREF( frame_eb5ba0b7e44a98324f539f14a326e09c );
    }
    cache_frame_eb5ba0b7e44a98324f539f14a326e09c = NULL;

    assertFrameObject( frame_eb5ba0b7e44a98324f539f14a326e09c );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_12_decode );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    CHECK_OBJECT( (PyObject *)var_n );
    Py_DECREF( var_n );
    var_n = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    Py_XDECREF( var_n );
    var_n = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_12_decode );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_13___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_kwargs = python_pars[ 1 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_dircall_arg1_1;
    PyObject *tmp_dircall_arg2_1;
    PyObject *tmp_dircall_arg3_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_fd13000fe202a74bec55fd084fd66e0d = NULL;

    struct Nuitka_FrameObject *frame_fd13000fe202a74bec55fd084fd66e0d;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_fd13000fe202a74bec55fd084fd66e0d, codeobj_fd13000fe202a74bec55fd084fd66e0d, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *) );
    frame_fd13000fe202a74bec55fd084fd66e0d = cache_frame_fd13000fe202a74bec55fd084fd66e0d;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_fd13000fe202a74bec55fd084fd66e0d );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_fd13000fe202a74bec55fd084fd66e0d ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapBase );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapBase" );
        exception_tb = NULL;

        exception_lineno = 137;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }

    tmp_dircall_arg1_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain___init__ );
    if ( tmp_dircall_arg1_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 137;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_dircall_arg2_1 = PyTuple_New( 1 );
    tmp_tuple_element_1 = par_self;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_dircall_arg2_1, 0, tmp_tuple_element_1 );
    tmp_dircall_arg3_1 = par_kwargs;

    CHECK_OBJECT( tmp_dircall_arg3_1 );
    Py_INCREF( tmp_dircall_arg3_1 );

    {
        PyObject *dir_call_args[] = {tmp_dircall_arg1_1, tmp_dircall_arg2_1, tmp_dircall_arg3_1};
        tmp_unused = impl___internal__$$$function_3_complex_call_helper_pos_star_dict( dir_call_args );
    }
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 137;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_assattr_name_1 = PyDict_New();
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_cid2unichr, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_1 );

        exception_lineno = 138;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_1 );

#if 0
    RESTORE_FRAME_EXCEPTION( frame_fd13000fe202a74bec55fd084fd66e0d );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_fd13000fe202a74bec55fd084fd66e0d );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_fd13000fe202a74bec55fd084fd66e0d, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_fd13000fe202a74bec55fd084fd66e0d->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_fd13000fe202a74bec55fd084fd66e0d, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_fd13000fe202a74bec55fd084fd66e0d,
        type_description_1,
        par_self,
        par_kwargs
    );


    // Release cached frame.
    if ( frame_fd13000fe202a74bec55fd084fd66e0d == cache_frame_fd13000fe202a74bec55fd084fd66e0d )
    {
        Py_DECREF( frame_fd13000fe202a74bec55fd084fd66e0d );
    }
    cache_frame_fd13000fe202a74bec55fd084fd66e0d = NULL;

    assertFrameObject( frame_fd13000fe202a74bec55fd084fd66e0d );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_13___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_kwargs );
    Py_DECREF( par_kwargs );
    par_kwargs = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_13___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_14___repr__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    static struct Nuitka_FrameObject *cache_frame_413e0f150c7511019171d87e84c9a71e = NULL;

    struct Nuitka_FrameObject *frame_413e0f150c7511019171d87e84c9a71e;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_413e0f150c7511019171d87e84c9a71e, codeobj_413e0f150c7511019171d87e84c9a71e, module_pdfminer$cmapdb, sizeof(void *) );
    frame_413e0f150c7511019171d87e84c9a71e = cache_frame_413e0f150c7511019171d87e84c9a71e;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_413e0f150c7511019171d87e84c9a71e );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_413e0f150c7511019171d87e84c9a71e ) == 2 ); // Frame stack

    // Framed code:
    tmp_left_name_1 = const_str_digest_7630f82f72cc55e315d978a3b1f3b902;
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_called_instance_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_attrs );
    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 142;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    frame_413e0f150c7511019171d87e84c9a71e->m_frame.f_lineno = 142;
    tmp_right_name_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_1, const_str_plain_get, &PyTuple_GET_ITEM( const_tuple_str_plain_CMapName_tuple, 0 ) );

    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_right_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 142;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    tmp_return_value = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 142;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_413e0f150c7511019171d87e84c9a71e );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_413e0f150c7511019171d87e84c9a71e );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_413e0f150c7511019171d87e84c9a71e );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_413e0f150c7511019171d87e84c9a71e, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_413e0f150c7511019171d87e84c9a71e->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_413e0f150c7511019171d87e84c9a71e, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_413e0f150c7511019171d87e84c9a71e,
        type_description_1,
        par_self
    );


    // Release cached frame.
    if ( frame_413e0f150c7511019171d87e84c9a71e == cache_frame_413e0f150c7511019171d87e84c9a71e )
    {
        Py_DECREF( frame_413e0f150c7511019171d87e84c9a71e );
    }
    cache_frame_413e0f150c7511019171d87e84c9a71e = NULL;

    assertFrameObject( frame_413e0f150c7511019171d87e84c9a71e );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_14___repr__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_14___repr__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_15_get_unichr( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cid = python_pars[ 1 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_called_name_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_91864749e5c8ffe960570370a9df7181 = NULL;

    struct Nuitka_FrameObject *frame_91864749e5c8ffe960570370a9df7181;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_91864749e5c8ffe960570370a9df7181, codeobj_91864749e5c8ffe960570370a9df7181, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *) );
    frame_91864749e5c8ffe960570370a9df7181 = cache_frame_91864749e5c8ffe960570370a9df7181;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_91864749e5c8ffe960570370a9df7181 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_91864749e5c8ffe960570370a9df7181 ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_cond_value_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_debug );
    if ( tmp_cond_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 145;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_1 );

        exception_lineno = 145;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_source_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_logging );

    if (unlikely( tmp_source_name_2 == NULL ))
    {
        tmp_source_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_logging );
    }

    if ( tmp_source_name_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "logging" );
        exception_tb = NULL;

        exception_lineno = 146;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_debug );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 146;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_left_name_1 = const_str_digest_198febb53c9afa089092ea7e45bbe1fe;
    tmp_right_name_1 = PyTuple_New( 2 );
    tmp_tuple_element_1 = par_self;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 0, tmp_tuple_element_1 );
    tmp_tuple_element_1 = par_cid;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 1, tmp_tuple_element_1 );
    tmp_args_element_name_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 146;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    frame_91864749e5c8ffe960570370a9df7181->m_frame.f_lineno = 146;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 146;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    branch_no_1:;
    tmp_source_name_3 = par_self;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_subscribed_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_cid2unichr );
    if ( tmp_subscribed_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 147;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    tmp_subscript_name_1 = par_cid;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_return_value = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    Py_DECREF( tmp_subscribed_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 147;
        type_description_1 = "oo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_91864749e5c8ffe960570370a9df7181 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_91864749e5c8ffe960570370a9df7181 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_91864749e5c8ffe960570370a9df7181 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_91864749e5c8ffe960570370a9df7181, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_91864749e5c8ffe960570370a9df7181->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_91864749e5c8ffe960570370a9df7181, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_91864749e5c8ffe960570370a9df7181,
        type_description_1,
        par_self,
        par_cid
    );


    // Release cached frame.
    if ( frame_91864749e5c8ffe960570370a9df7181 == cache_frame_91864749e5c8ffe960570370a9df7181 )
    {
        Py_DECREF( frame_91864749e5c8ffe960570370a9df7181 );
    }
    cache_frame_91864749e5c8ffe960570370a9df7181 = NULL;

    assertFrameObject( frame_91864749e5c8ffe960570370a9df7181 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_15_get_unichr );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_15_get_unichr );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_16_dump( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_out = python_pars[ 1 ];
    PyObject *var_k = NULL;
    PyObject *var_v = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *tmp_tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_tuple_unpack_1__source_iter = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_iter_arg_2;
    PyObject *tmp_iterator_attempt;
    PyObject *tmp_iterator_name_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_unpack_1;
    PyObject *tmp_unpack_2;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_97fad3ef23a1d8553a58ab6f39e4d675 = NULL;

    struct Nuitka_FrameObject *frame_97fad3ef23a1d8553a58ab6f39e4d675;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_97fad3ef23a1d8553a58ab6f39e4d675, codeobj_97fad3ef23a1d8553a58ab6f39e4d675, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_97fad3ef23a1d8553a58ab6f39e4d675 = cache_frame_97fad3ef23a1d8553a58ab6f39e4d675;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_97fad3ef23a1d8553a58ab6f39e4d675 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_97fad3ef23a1d8553a58ab6f39e4d675 ) == 2 ); // Frame stack

    // Framed code:
    tmp_called_name_1 = LOOKUP_BUILTIN( const_str_plain_sorted );
    assert( tmp_called_name_1 != NULL );
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_called_instance_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_cid2unichr );
    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    frame_97fad3ef23a1d8553a58ab6f39e4d675->m_frame.f_lineno = 150;
    tmp_args_element_name_1 = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_iteritems );
    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    frame_97fad3ef23a1d8553a58ab6f39e4d675->m_frame.f_lineno = 150;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_iter_arg_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_1 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_1;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_2 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_2 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooo";
            exception_lineno = 150;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_2;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_2 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_iter_arg_2 );
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_2 );
    if ( tmp_assign_source_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto try_except_handler_3;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__source_iter;
        tmp_tuple_unpack_1__source_iter = tmp_assign_source_3;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_1 );
    tmp_assign_source_4 = UNPACK_NEXT( tmp_unpack_1, 0 );
    if ( tmp_assign_source_4 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooo";
        exception_lineno = 150;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_1;
        tmp_tuple_unpack_1__element_1 = tmp_assign_source_4;
        Py_XDECREF( old );
    }

    tmp_unpack_2 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_2 );
    tmp_assign_source_5 = UNPACK_NEXT( tmp_unpack_2, 1 );
    if ( tmp_assign_source_5 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooo";
        exception_lineno = 150;
        goto try_except_handler_4;
    }
    {
        PyObject *old = tmp_tuple_unpack_1__element_2;
        tmp_tuple_unpack_1__element_2 = tmp_assign_source_5;
        Py_XDECREF( old );
    }

    tmp_iterator_name_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_1 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_1 ); assert( HAS_ITERNEXT( tmp_iterator_name_1 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_1 )->tp_iternext)( tmp_iterator_name_1 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooo";
                exception_lineno = 150;
                goto try_except_handler_4;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooo";
        exception_lineno = 150;
        goto try_except_handler_4;
    }
    goto try_end_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    try_end_1:;
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_2;
    // End of try:
    try_end_2:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    tmp_assign_source_6 = tmp_tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_assign_source_6 );
    {
        PyObject *old = var_k;
        var_k = tmp_assign_source_6;
        Py_INCREF( var_k );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    tmp_assign_source_7 = tmp_tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_assign_source_7 );
    {
        PyObject *old = var_v;
        var_v = tmp_assign_source_7;
        Py_INCREF( var_v );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    tmp_source_name_2 = par_out;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_called_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_write );
    if ( tmp_called_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 151;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    tmp_left_name_1 = const_str_digest_b21855e094b355d16316ad6dc0425407;
    tmp_right_name_1 = PyTuple_New( 2 );
    tmp_tuple_element_1 = var_k;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 0, tmp_tuple_element_1 );
    tmp_tuple_element_1 = var_v;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_right_name_1, 1, tmp_tuple_element_1 );
    tmp_args_element_name_2 = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_args_element_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_2 );

        exception_lineno = 151;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    frame_97fad3ef23a1d8553a58ab6f39e4d675->m_frame.f_lineno = 151;
    {
        PyObject *call_args[] = { tmp_args_element_name_2 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_2, call_args );
    }

    Py_DECREF( tmp_called_name_2 );
    Py_DECREF( tmp_args_element_name_2 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 151;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 150;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_3;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_3:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_97fad3ef23a1d8553a58ab6f39e4d675 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_97fad3ef23a1d8553a58ab6f39e4d675 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_97fad3ef23a1d8553a58ab6f39e4d675, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_97fad3ef23a1d8553a58ab6f39e4d675->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_97fad3ef23a1d8553a58ab6f39e4d675, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_97fad3ef23a1d8553a58ab6f39e4d675,
        type_description_1,
        par_self,
        par_out,
        var_k,
        var_v
    );


    // Release cached frame.
    if ( frame_97fad3ef23a1d8553a58ab6f39e4d675 == cache_frame_97fad3ef23a1d8553a58ab6f39e4d675 )
    {
        Py_DECREF( frame_97fad3ef23a1d8553a58ab6f39e4d675 );
    }
    cache_frame_97fad3ef23a1d8553a58ab6f39e4d675 = NULL;

    assertFrameObject( frame_97fad3ef23a1d8553a58ab6f39e4d675 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_16_dump );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_out );
    Py_DECREF( par_out );
    par_out = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_out );
    Py_DECREF( par_out );
    par_out = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_16_dump );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_17_add_code2cid( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_code = python_pars[ 1 ];
    PyObject *par_cid = python_pars[ 2 ];
    PyObject *var_d = NULL;
    PyObject *var_c = NULL;
    PyObject *var_t = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    int tmp_and_left_truth_1;
    PyObject *tmp_and_left_value_1;
    PyObject *tmp_and_right_value_1;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscribed_2;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subscript_2;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_ass_subvalue_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    int tmp_cmp_In_1;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_cls_2;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_isinstance_inst_2;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_ord_arg_1;
    PyObject *tmp_ord_arg_2;
    PyObject *tmp_raise_type_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    Py_ssize_t tmp_slice_index_upper_1;
    PyObject *tmp_slice_source_1;
    Py_ssize_t tmp_sliceslicedel_index_lower_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscribed_name_2;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_subscript_name_2;
    static struct Nuitka_FrameObject *cache_frame_d45f9db8c770efe384eb416ddad3eb5f = NULL;

    struct Nuitka_FrameObject *frame_d45f9db8c770efe384eb416ddad3eb5f;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_d45f9db8c770efe384eb416ddad3eb5f, codeobj_d45f9db8c770efe384eb416ddad3eb5f, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_d45f9db8c770efe384eb416ddad3eb5f = cache_frame_d45f9db8c770efe384eb416ddad3eb5f;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_d45f9db8c770efe384eb416ddad3eb5f );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_d45f9db8c770efe384eb416ddad3eb5f ) == 2 ); // Frame stack

    // Framed code:
    tmp_isinstance_inst_1 = par_code;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyString_Type;
    tmp_and_left_value_1 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_and_left_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 160;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    tmp_and_left_truth_1 = CHECK_IF_TRUE( tmp_and_left_value_1 );
    if ( tmp_and_left_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 160;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_and_left_truth_1 == 1 )
    {
        goto and_right_1;
    }
    else
    {
        goto and_left_1;
    }
    and_right_1:;
    tmp_isinstance_inst_2 = par_cid;

    CHECK_OBJECT( tmp_isinstance_inst_2 );
    tmp_isinstance_cls_2 = (PyObject *)&PyInt_Type;
    tmp_and_right_value_1 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_2, tmp_isinstance_cls_2 );
    if ( tmp_and_right_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 160;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_value_1 = tmp_and_right_value_1;
    goto and_end_1;
    and_left_1:;
    tmp_cond_value_1 = tmp_and_left_value_1;
    and_end_1:;
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 160;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_no_1;
    }
    else
    {
        goto branch_yes_1;
    }
    branch_yes_1:;
    tmp_raise_type_1 = PyExc_AssertionError;
    exception_type = tmp_raise_type_1;
    Py_INCREF( tmp_raise_type_1 );
    exception_lineno = 160;
    RAISE_EXCEPTION_WITH_TYPE( &exception_type, &exception_value, &exception_tb );
    type_description_1 = "oooooo";
    goto frame_exception_exit_1;
    branch_no_1:;
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_assign_source_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_code2cid );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 161;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    assert( var_d == NULL );
    var_d = tmp_assign_source_1;

    tmp_sliceslicedel_index_lower_1 = 0;
    tmp_slice_index_upper_1 = -1;
    tmp_slice_source_1 = par_code;

    CHECK_OBJECT( tmp_slice_source_1 );
    tmp_iter_arg_1 = LOOKUP_INDEX_SLICE( tmp_slice_source_1, tmp_sliceslicedel_index_lower_1, tmp_slice_index_upper_1 );
    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 162;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_2 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 162;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_2;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_3 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooo";
            exception_lineno = 162;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_3;
        Py_XDECREF( old );
    }

    tmp_assign_source_4 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_assign_source_4 );
    {
        PyObject *old = var_c;
        var_c = tmp_assign_source_4;
        Py_INCREF( var_c );
        Py_XDECREF( old );
    }

    tmp_ord_arg_1 = var_c;

    CHECK_OBJECT( tmp_ord_arg_1 );
    tmp_assign_source_5 = BUILTIN_ORD( tmp_ord_arg_1 );
    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 163;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_c;
        assert( old != NULL );
        var_c = tmp_assign_source_5;
        Py_DECREF( old );
    }

    tmp_compare_left_1 = var_c;

    CHECK_OBJECT( tmp_compare_left_1 );
    tmp_compare_right_1 = var_d;

    if ( tmp_compare_right_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 164;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }

    tmp_cmp_In_1 = PySequence_Contains( tmp_compare_right_1, tmp_compare_left_1 );
    assert( !(tmp_cmp_In_1 == -1) );
    if ( tmp_cmp_In_1 == 1 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_subscribed_name_1 = var_d;

    if ( tmp_subscribed_name_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 165;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }

    tmp_subscript_name_1 = var_c;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_assign_source_6 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 165;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_d;
        var_d = tmp_assign_source_6;
        Py_XDECREF( old );
    }

    goto branch_end_2;
    branch_no_2:;
    tmp_assign_source_7 = PyDict_New();
    {
        PyObject *old = var_t;
        var_t = tmp_assign_source_7;
        Py_XDECREF( old );
    }

    tmp_ass_subvalue_1 = var_t;

    CHECK_OBJECT( tmp_ass_subvalue_1 );
    tmp_ass_subscribed_1 = var_d;

    if ( tmp_ass_subscribed_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 168;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }

    tmp_ass_subscript_1 = var_c;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 168;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    tmp_assign_source_8 = var_t;

    CHECK_OBJECT( tmp_assign_source_8 );
    {
        PyObject *old = var_d;
        var_d = tmp_assign_source_8;
        Py_INCREF( var_d );
        Py_XDECREF( old );
    }

    branch_end_2:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 162;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;
    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_subscribed_name_2 = par_code;

    CHECK_OBJECT( tmp_subscribed_name_2 );
    tmp_subscript_name_2 = const_int_neg_1;
    tmp_ord_arg_2 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_2, tmp_subscript_name_2 );
    if ( tmp_ord_arg_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 170;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_9 = BUILTIN_ORD( tmp_ord_arg_2 );
    Py_DECREF( tmp_ord_arg_2 );
    if ( tmp_assign_source_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 170;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    {
        PyObject *old = var_c;
        var_c = tmp_assign_source_9;
        Py_XDECREF( old );
    }

    tmp_ass_subvalue_2 = par_cid;

    CHECK_OBJECT( tmp_ass_subvalue_2 );
    tmp_ass_subscribed_2 = var_d;

    if ( tmp_ass_subscribed_2 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "d" );
        exception_tb = NULL;

        exception_lineno = 171;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }

    tmp_ass_subscript_2 = var_c;

    CHECK_OBJECT( tmp_ass_subscript_2 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_2, tmp_ass_subscript_2, tmp_ass_subvalue_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 171;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }

#if 0
    RESTORE_FRAME_EXCEPTION( frame_d45f9db8c770efe384eb416ddad3eb5f );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_d45f9db8c770efe384eb416ddad3eb5f );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_d45f9db8c770efe384eb416ddad3eb5f, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_d45f9db8c770efe384eb416ddad3eb5f->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_d45f9db8c770efe384eb416ddad3eb5f, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_d45f9db8c770efe384eb416ddad3eb5f,
        type_description_1,
        par_self,
        par_code,
        par_cid,
        var_d,
        var_c,
        var_t
    );


    // Release cached frame.
    if ( frame_d45f9db8c770efe384eb416ddad3eb5f == cache_frame_d45f9db8c770efe384eb416ddad3eb5f )
    {
        Py_DECREF( frame_d45f9db8c770efe384eb416ddad3eb5f );
    }
    cache_frame_d45f9db8c770efe384eb416ddad3eb5f = NULL;

    assertFrameObject( frame_d45f9db8c770efe384eb416ddad3eb5f );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_17_add_code2cid );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    Py_XDECREF( var_d );
    var_d = NULL;

    CHECK_OBJECT( (PyObject *)var_c );
    Py_DECREF( var_c );
    var_c = NULL;

    Py_XDECREF( var_t );
    var_t = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    Py_XDECREF( var_d );
    var_d = NULL;

    Py_XDECREF( var_c );
    var_c = NULL;

    Py_XDECREF( var_t );
    var_t = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_17_add_code2cid );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_18_add_cid2unichr( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cid = python_pars[ 1 ];
    PyObject *par_code = python_pars[ 2 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscribed_2;
    PyObject *tmp_ass_subscribed_3;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subscript_2;
    PyObject *tmp_ass_subscript_3;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_ass_subvalue_2;
    PyObject *tmp_ass_subvalue_3;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_cls_2;
    PyObject *tmp_isinstance_cls_3;
    PyObject *tmp_isinstance_cls_4;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_isinstance_inst_2;
    PyObject *tmp_isinstance_inst_3;
    PyObject *tmp_isinstance_inst_4;
    PyObject *tmp_make_exception_arg_1;
    PyObject *tmp_raise_type_1;
    PyObject *tmp_raise_type_2;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_unicode_arg_1;
    PyObject *tmp_unicode_encoding_1;
    PyObject *tmp_unicode_errors_1;
    static struct Nuitka_FrameObject *cache_frame_b8a1a2ca42dca93d288657257f607fc7 = NULL;

    struct Nuitka_FrameObject *frame_b8a1a2ca42dca93d288657257f607fc7;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_b8a1a2ca42dca93d288657257f607fc7, codeobj_b8a1a2ca42dca93d288657257f607fc7, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_b8a1a2ca42dca93d288657257f607fc7 = cache_frame_b8a1a2ca42dca93d288657257f607fc7;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_b8a1a2ca42dca93d288657257f607fc7 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_b8a1a2ca42dca93d288657257f607fc7 ) == 2 ); // Frame stack

    // Framed code:
    tmp_isinstance_inst_1 = par_cid;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyInt_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 180;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_res == 1 )
    {
        goto branch_no_1;
    }
    else
    {
        goto branch_yes_1;
    }
    branch_yes_1:;
    tmp_raise_type_1 = PyExc_AssertionError;
    exception_type = tmp_raise_type_1;
    Py_INCREF( tmp_raise_type_1 );
    exception_lineno = 180;
    RAISE_EXCEPTION_WITH_TYPE( &exception_type, &exception_value, &exception_tb );
    type_description_1 = "ooo";
    goto frame_exception_exit_1;
    branch_no_1:;
    tmp_isinstance_inst_2 = par_code;

    CHECK_OBJECT( tmp_isinstance_inst_2 );
    tmp_isinstance_cls_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSLiteral );

    if (unlikely( tmp_isinstance_cls_2 == NULL ))
    {
        tmp_isinstance_cls_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSLiteral );
    }

    if ( tmp_isinstance_cls_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PSLiteral" );
        exception_tb = NULL;

        exception_lineno = 181;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_2, tmp_isinstance_cls_2 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 181;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_called_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_name2unicode );

    if (unlikely( tmp_called_name_1 == NULL ))
    {
        tmp_called_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_name2unicode );
    }

    if ( tmp_called_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "name2unicode" );
        exception_tb = NULL;

        exception_lineno = 183;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

    tmp_source_name_1 = par_code;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_args_element_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_name );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 183;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    frame_b8a1a2ca42dca93d288657257f607fc7->m_frame.f_lineno = 183;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_ass_subvalue_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_ass_subvalue_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 183;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_source_name_2 = par_self;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_cid2unichr );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_ass_subvalue_1 );

        exception_lineno = 183;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_1 = par_cid;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    Py_DECREF( tmp_ass_subvalue_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 183;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    goto branch_end_2;
    branch_no_2:;
    tmp_isinstance_inst_3 = par_code;

    CHECK_OBJECT( tmp_isinstance_inst_3 );
    tmp_isinstance_cls_3 = (PyObject *)&PyString_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_3, tmp_isinstance_cls_3 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 184;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_3;
    }
    else
    {
        goto branch_no_3;
    }
    branch_yes_3:;
    tmp_unicode_arg_1 = par_code;

    CHECK_OBJECT( tmp_unicode_arg_1 );
    tmp_unicode_encoding_1 = const_str_digest_9be5b4e2f6d190afc27e049db170f4a2;
    tmp_unicode_errors_1 = const_str_plain_ignore;
    tmp_ass_subvalue_2 = TO_UNICODE3( tmp_unicode_arg_1, tmp_unicode_encoding_1, tmp_unicode_errors_1 );
    if ( tmp_ass_subvalue_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 186;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_source_name_3 = par_self;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_ass_subscribed_2 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_cid2unichr );
    if ( tmp_ass_subscribed_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_ass_subvalue_2 );

        exception_lineno = 186;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_2 = par_cid;

    CHECK_OBJECT( tmp_ass_subscript_2 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_2, tmp_ass_subscript_2, tmp_ass_subvalue_2 );
    Py_DECREF( tmp_ass_subscribed_2 );
    Py_DECREF( tmp_ass_subvalue_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 186;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    goto branch_end_3;
    branch_no_3:;
    tmp_isinstance_inst_4 = par_code;

    CHECK_OBJECT( tmp_isinstance_inst_4 );
    tmp_isinstance_cls_4 = (PyObject *)&PyInt_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_4, tmp_isinstance_cls_4 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 187;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_4;
    }
    else
    {
        goto branch_no_4;
    }
    branch_yes_4:;
    tmp_called_name_2 = LOOKUP_BUILTIN( const_str_plain_unichr );
    assert( tmp_called_name_2 != NULL );
    tmp_args_element_name_2 = par_code;

    CHECK_OBJECT( tmp_args_element_name_2 );
    frame_b8a1a2ca42dca93d288657257f607fc7->m_frame.f_lineno = 188;
    {
        PyObject *call_args[] = { tmp_args_element_name_2 };
        tmp_ass_subvalue_3 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_2, call_args );
    }

    if ( tmp_ass_subvalue_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 188;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_source_name_4 = par_self;

    CHECK_OBJECT( tmp_source_name_4 );
    tmp_ass_subscribed_3 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_cid2unichr );
    if ( tmp_ass_subscribed_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_ass_subvalue_3 );

        exception_lineno = 188;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_3 = par_cid;

    CHECK_OBJECT( tmp_ass_subscript_3 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_3, tmp_ass_subscript_3, tmp_ass_subvalue_3 );
    Py_DECREF( tmp_ass_subscribed_3 );
    Py_DECREF( tmp_ass_subvalue_3 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 188;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    goto branch_end_4;
    branch_no_4:;
    tmp_make_exception_arg_1 = par_code;

    CHECK_OBJECT( tmp_make_exception_arg_1 );
    frame_b8a1a2ca42dca93d288657257f607fc7->m_frame.f_lineno = 190;
    {
        PyObject *call_args[] = { tmp_make_exception_arg_1 };
        tmp_raise_type_2 = CALL_FUNCTION_WITH_ARGS1( PyExc_TypeError, call_args );
    }

    assert( tmp_raise_type_2 != NULL );
    exception_type = tmp_raise_type_2;
    exception_lineno = 190;
    RAISE_EXCEPTION_WITH_TYPE( &exception_type, &exception_value, &exception_tb );
    type_description_1 = "ooo";
    goto frame_exception_exit_1;
    branch_end_4:;
    branch_end_3:;
    branch_end_2:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_b8a1a2ca42dca93d288657257f607fc7 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_b8a1a2ca42dca93d288657257f607fc7 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_b8a1a2ca42dca93d288657257f607fc7, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_b8a1a2ca42dca93d288657257f607fc7->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_b8a1a2ca42dca93d288657257f607fc7, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_b8a1a2ca42dca93d288657257f607fc7,
        type_description_1,
        par_self,
        par_cid,
        par_code
    );


    // Release cached frame.
    if ( frame_b8a1a2ca42dca93d288657257f607fc7 == cache_frame_b8a1a2ca42dca93d288657257f607fc7 )
    {
        Py_DECREF( frame_b8a1a2ca42dca93d288657257f607fc7 );
    }
    cache_frame_b8a1a2ca42dca93d288657257f607fc7 = NULL;

    assertFrameObject( frame_b8a1a2ca42dca93d288657257f607fc7 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_18_add_cid2unichr );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cid );
    Py_DECREF( par_cid );
    par_cid = NULL;

    CHECK_OBJECT( (PyObject *)par_code );
    Py_DECREF( par_code );
    par_code = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_18_add_cid2unichr );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_19___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_name = python_pars[ 1 ];
    PyObject *par_module = python_pars[ 2 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_name_1;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_called_name_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_dict_key_1;
    PyObject *tmp_dict_value_1;
    PyObject *tmp_kw_name_1;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_a80f840bc8a1ed93b203ed21d320acaa = NULL;

    struct Nuitka_FrameObject *frame_a80f840bc8a1ed93b203ed21d320acaa;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_a80f840bc8a1ed93b203ed21d320acaa, codeobj_a80f840bc8a1ed93b203ed21d320acaa, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_a80f840bc8a1ed93b203ed21d320acaa = cache_frame_a80f840bc8a1ed93b203ed21d320acaa;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_a80f840bc8a1ed93b203ed21d320acaa );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_a80f840bc8a1ed93b203ed21d320acaa ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMap );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMap );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMap" );
        exception_tb = NULL;

        exception_lineno = 199;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain___init__ );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 199;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_args_name_1 = PyTuple_New( 1 );
    tmp_tuple_element_1 = par_self;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_name_1, 0, tmp_tuple_element_1 );
    tmp_kw_name_1 = _PyDict_NewPresized( 1 );
    tmp_dict_value_1 = par_name;

    CHECK_OBJECT( tmp_dict_value_1 );
    tmp_dict_key_1 = const_str_plain_CMapName;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_1, tmp_dict_value_1 );
    assert( !(tmp_res != 0) );
    frame_a80f840bc8a1ed93b203ed21d320acaa->m_frame.f_lineno = 199;
    tmp_unused = CALL_FUNCTION( tmp_called_name_1, tmp_args_name_1, tmp_kw_name_1 );
    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_name_1 );
    Py_DECREF( tmp_kw_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 199;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_source_name_2 = par_module;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_assattr_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_CODE2CID );
    if ( tmp_assattr_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 200;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_code2cid, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_1 );

        exception_lineno = 200;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_1 );
    tmp_source_name_3 = par_module;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_cond_value_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_IS_VERTICAL );
    if ( tmp_cond_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 201;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_1 );

        exception_lineno = 201;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_ass_subvalue_1 = const_int_pos_1;
    tmp_source_name_4 = par_self;

    CHECK_OBJECT( tmp_source_name_4 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_attrs );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 202;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_1 = const_str_plain_WMode;
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 202;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    branch_no_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_a80f840bc8a1ed93b203ed21d320acaa );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_a80f840bc8a1ed93b203ed21d320acaa );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_a80f840bc8a1ed93b203ed21d320acaa, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_a80f840bc8a1ed93b203ed21d320acaa->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_a80f840bc8a1ed93b203ed21d320acaa, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_a80f840bc8a1ed93b203ed21d320acaa,
        type_description_1,
        par_self,
        par_name,
        par_module
    );


    // Release cached frame.
    if ( frame_a80f840bc8a1ed93b203ed21d320acaa == cache_frame_a80f840bc8a1ed93b203ed21d320acaa )
    {
        Py_DECREF( frame_a80f840bc8a1ed93b203ed21d320acaa );
    }
    cache_frame_a80f840bc8a1ed93b203ed21d320acaa = NULL;

    assertFrameObject( frame_a80f840bc8a1ed93b203ed21d320acaa );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_19___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_module );
    Py_DECREF( par_module );
    par_module = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_module );
    Py_DECREF( par_module );
    par_module = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_19___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_20___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_name = python_pars[ 1 ];
    PyObject *par_module = python_pars[ 2 ];
    PyObject *par_vertical = python_pars[ 3 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_name_1;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_name_2;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_assattr_target_2;
    PyObject *tmp_called_name_1;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_dict_key_1;
    PyObject *tmp_dict_value_1;
    PyObject *tmp_kw_name_1;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_tuple_element_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_393bff62988f703c8ec9fb622290849f = NULL;

    struct Nuitka_FrameObject *frame_393bff62988f703c8ec9fb622290849f;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_393bff62988f703c8ec9fb622290849f, codeobj_393bff62988f703c8ec9fb622290849f, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_393bff62988f703c8ec9fb622290849f = cache_frame_393bff62988f703c8ec9fb622290849f;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_393bff62988f703c8ec9fb622290849f );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_393bff62988f703c8ec9fb622290849f ) == 2 ); // Frame stack

    // Framed code:
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_UnicodeMap );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_UnicodeMap );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "UnicodeMap" );
        exception_tb = NULL;

        exception_lineno = 211;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain___init__ );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 211;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    tmp_args_name_1 = PyTuple_New( 1 );
    tmp_tuple_element_1 = par_self;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_name_1, 0, tmp_tuple_element_1 );
    tmp_kw_name_1 = _PyDict_NewPresized( 1 );
    tmp_dict_value_1 = par_name;

    CHECK_OBJECT( tmp_dict_value_1 );
    tmp_dict_key_1 = const_str_plain_CMapName;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_1, tmp_dict_value_1 );
    assert( !(tmp_res != 0) );
    frame_393bff62988f703c8ec9fb622290849f->m_frame.f_lineno = 211;
    tmp_unused = CALL_FUNCTION( tmp_called_name_1, tmp_args_name_1, tmp_kw_name_1 );
    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_name_1 );
    Py_DECREF( tmp_kw_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 211;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_cond_value_1 = par_vertical;

    CHECK_OBJECT( tmp_cond_value_1 );
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 212;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_source_name_2 = par_module;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_assattr_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_CID2UNICHR_V );
    if ( tmp_assattr_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 213;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_cid2unichr, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_1 );

        exception_lineno = 213;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_1 );
    tmp_ass_subvalue_1 = const_int_pos_1;
    tmp_source_name_3 = par_self;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_attrs );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 214;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    tmp_ass_subscript_1 = const_str_plain_WMode;
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 214;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    goto branch_end_1;
    branch_no_1:;
    tmp_source_name_4 = par_module;

    CHECK_OBJECT( tmp_source_name_4 );
    tmp_assattr_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_CID2UNICHR_H );
    if ( tmp_assattr_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 216;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_target_2 = par_self;

    CHECK_OBJECT( tmp_assattr_target_2 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_2, const_str_plain_cid2unichr, tmp_assattr_name_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_2 );

        exception_lineno = 216;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_assattr_name_2 );
    branch_end_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_393bff62988f703c8ec9fb622290849f );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_393bff62988f703c8ec9fb622290849f );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_393bff62988f703c8ec9fb622290849f, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_393bff62988f703c8ec9fb622290849f->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_393bff62988f703c8ec9fb622290849f, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_393bff62988f703c8ec9fb622290849f,
        type_description_1,
        par_self,
        par_name,
        par_module,
        par_vertical
    );


    // Release cached frame.
    if ( frame_393bff62988f703c8ec9fb622290849f == cache_frame_393bff62988f703c8ec9fb622290849f )
    {
        Py_DECREF( frame_393bff62988f703c8ec9fb622290849f );
    }
    cache_frame_393bff62988f703c8ec9fb622290849f = NULL;

    assertFrameObject( frame_393bff62988f703c8ec9fb622290849f );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_20___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_module );
    Py_DECREF( par_module );
    par_module = NULL;

    CHECK_OBJECT( (PyObject *)par_vertical );
    Py_DECREF( par_vertical );
    par_vertical = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_module );
    Py_DECREF( par_module );
    par_module = NULL;

    CHECK_OBJECT( (PyObject *)par_vertical );
    Py_DECREF( par_vertical );
    par_vertical = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_20___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_21__load_data( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_klass = python_pars[ 0 ];
    PyObject *par_name = python_pars[ 1 ];
    PyObject *var_filename = NULL;
    PyObject *var_cmap_paths = NULL;
    PyObject *var_directory = NULL;
    PyObject *var_path = NULL;
    PyObject *var_gzfile = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_args_element_name_5;
    PyObject *tmp_args_element_name_6;
    PyObject *tmp_args_element_name_7;
    PyObject *tmp_args_element_name_8;
    PyObject *tmp_args_element_name_9;
    PyObject *tmp_args_element_name_10;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_bases_name_1;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_instance_2;
    PyObject *tmp_called_instance_3;
    PyObject *tmp_called_instance_4;
    PyObject *tmp_called_instance_5;
    PyObject *tmp_called_instance_6;
    PyObject *tmp_called_instance_7;
    PyObject *tmp_called_instance_8;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_called_name_4;
    int tmp_cond_truth_1;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_dict_name_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_left_name_2;
    PyObject *tmp_next_source_1;
    PyObject *tmp_raise_type_1;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_right_name_2;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_source_name_6;
    PyObject *tmp_source_name_7;
    PyObject *tmp_source_name_8;
    PyObject *tmp_source_name_9;
    PyObject *tmp_str_arg_1;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_type_name_name_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_e5e7e55f392592a385ee5efc197a73a2 = NULL;

    struct Nuitka_FrameObject *frame_e5e7e55f392592a385ee5efc197a73a2;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_e5e7e55f392592a385ee5efc197a73a2, codeobj_e5e7e55f392592a385ee5efc197a73a2, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_e5e7e55f392592a385ee5efc197a73a2 = cache_frame_e5e7e55f392592a385ee5efc197a73a2;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_e5e7e55f392592a385ee5efc197a73a2 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_e5e7e55f392592a385ee5efc197a73a2 ) == 2 ); // Frame stack

    // Framed code:
    tmp_left_name_1 = const_str_digest_578f15b8391035c916b128eb320b5c58;
    tmp_right_name_1 = par_name;

    CHECK_OBJECT( tmp_right_name_1 );
    tmp_assign_source_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 232;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_filename == NULL );
    var_filename = tmp_assign_source_1;

    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_logging );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_logging );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "logging" );
        exception_tb = NULL;

        exception_lineno = 233;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_info );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 233;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_left_name_2 = const_str_digest_91bdb4bec0f6193ff3c892ab9c238e14;
    tmp_right_name_2 = par_name;

    CHECK_OBJECT( tmp_right_name_2 );
    tmp_args_element_name_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_2, tmp_right_name_2 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 233;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 233;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 233;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_assign_source_2 = PyTuple_New( 2 );
    tmp_source_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os );

    if (unlikely( tmp_source_name_2 == NULL ))
    {
        tmp_source_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_os );
    }

    if ( tmp_source_name_2 == NULL )
    {
        Py_DECREF( tmp_assign_source_2 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "os" );
        exception_tb = NULL;

        exception_lineno = 234;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }

    tmp_called_instance_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_environ );
    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );

        exception_lineno = 234;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 234;
    tmp_tuple_element_1 = CALL_METHOD_WITH_ARGS2( tmp_called_instance_1, const_str_plain_get, &PyTuple_GET_ITEM( const_tuple_adb7e9cb592accf77f5da4f40375750f_tuple, 0 ) );

    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_tuple_element_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );

        exception_lineno = 234;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    PyTuple_SET_ITEM( tmp_assign_source_2, 0, tmp_tuple_element_1 );
    tmp_source_name_4 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os );

    if (unlikely( tmp_source_name_4 == NULL ))
    {
        tmp_source_name_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_os );
    }

    if ( tmp_source_name_4 == NULL )
    {
        Py_DECREF( tmp_assign_source_2 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "os" );
        exception_tb = NULL;

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }

    tmp_source_name_3 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_path );
    if ( tmp_source_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_called_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_join );
    Py_DECREF( tmp_source_name_3 );
    if ( tmp_called_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_source_name_6 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os );

    if (unlikely( tmp_source_name_6 == NULL ))
    {
        tmp_source_name_6 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_os );
    }

    if ( tmp_source_name_6 == NULL )
    {
        Py_DECREF( tmp_assign_source_2 );
        Py_DECREF( tmp_called_name_2 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "os" );
        exception_tb = NULL;

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }

    tmp_source_name_5 = LOOKUP_ATTRIBUTE( tmp_source_name_6, const_str_plain_path );
    if ( tmp_source_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );
        Py_DECREF( tmp_called_name_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_called_name_3 = LOOKUP_ATTRIBUTE( tmp_source_name_5, const_str_plain_dirname );
    Py_DECREF( tmp_source_name_5 );
    if ( tmp_called_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );
        Py_DECREF( tmp_called_name_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_args_element_name_3 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___file__ );

    if (unlikely( tmp_args_element_name_3 == NULL ))
    {
        tmp_args_element_name_3 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain___file__ );
    }

    if ( tmp_args_element_name_3 == NULL )
    {
        Py_DECREF( tmp_assign_source_2 );
        Py_DECREF( tmp_called_name_2 );
        Py_DECREF( tmp_called_name_3 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "__file__" );
        exception_tb = NULL;

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }

    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 235;
    {
        PyObject *call_args[] = { tmp_args_element_name_3 };
        tmp_args_element_name_2 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_3, call_args );
    }

    Py_DECREF( tmp_called_name_3 );
    if ( tmp_args_element_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );
        Py_DECREF( tmp_called_name_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    tmp_args_element_name_4 = const_str_plain_cmap;
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 235;
    {
        PyObject *call_args[] = { tmp_args_element_name_2, tmp_args_element_name_4 };
        tmp_tuple_element_1 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_2, call_args );
    }

    Py_DECREF( tmp_called_name_2 );
    Py_DECREF( tmp_args_element_name_2 );
    if ( tmp_tuple_element_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assign_source_2 );

        exception_lineno = 235;
        type_description_1 = "ooooooo";
        goto frame_exception_exit_1;
    }
    PyTuple_SET_ITEM( tmp_assign_source_2, 1, tmp_tuple_element_1 );
    assert( var_cmap_paths == NULL );
    var_cmap_paths = tmp_assign_source_2;

    // Tried code:
    tmp_iter_arg_1 = var_cmap_paths;

    CHECK_OBJECT( tmp_iter_arg_1 );
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 236;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_3;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_4 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_4 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "ooooooo";
            exception_lineno = 236;
            goto try_except_handler_3;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_4;
        Py_XDECREF( old );
    }

    tmp_assign_source_5 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_assign_source_5 );
    {
        PyObject *old = var_directory;
        var_directory = tmp_assign_source_5;
        Py_INCREF( var_directory );
        Py_XDECREF( old );
    }

    tmp_source_name_7 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os );

    if (unlikely( tmp_source_name_7 == NULL ))
    {
        tmp_source_name_7 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_os );
    }

    if ( tmp_source_name_7 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "os" );
        exception_tb = NULL;

        exception_lineno = 237;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }

    tmp_called_instance_2 = LOOKUP_ATTRIBUTE( tmp_source_name_7, const_str_plain_path );
    if ( tmp_called_instance_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 237;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    tmp_args_element_name_5 = var_directory;

    CHECK_OBJECT( tmp_args_element_name_5 );
    tmp_args_element_name_6 = var_filename;

    CHECK_OBJECT( tmp_args_element_name_6 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 237;
    {
        PyObject *call_args[] = { tmp_args_element_name_5, tmp_args_element_name_6 };
        tmp_assign_source_6 = CALL_METHOD_WITH_ARGS2( tmp_called_instance_2, const_str_plain_join, call_args );
    }

    Py_DECREF( tmp_called_instance_2 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 237;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    {
        PyObject *old = var_path;
        var_path = tmp_assign_source_6;
        Py_XDECREF( old );
    }

    tmp_source_name_8 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os );

    if (unlikely( tmp_source_name_8 == NULL ))
    {
        tmp_source_name_8 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_os );
    }

    if ( tmp_source_name_8 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "os" );
        exception_tb = NULL;

        exception_lineno = 238;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }

    tmp_called_instance_3 = LOOKUP_ATTRIBUTE( tmp_source_name_8, const_str_plain_path );
    if ( tmp_called_instance_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 238;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    tmp_args_element_name_7 = var_path;

    CHECK_OBJECT( tmp_args_element_name_7 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 238;
    {
        PyObject *call_args[] = { tmp_args_element_name_7 };
        tmp_cond_value_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_3, const_str_plain_exists, call_args );
    }

    Py_DECREF( tmp_called_instance_3 );
    if ( tmp_cond_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 238;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_1 );

        exception_lineno = 238;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    Py_DECREF( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_called_instance_4 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_gzip );

    if (unlikely( tmp_called_instance_4 == NULL ))
    {
        tmp_called_instance_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_gzip );
    }

    if ( tmp_called_instance_4 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "gzip" );
        exception_tb = NULL;

        exception_lineno = 239;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }

    tmp_args_element_name_8 = var_path;

    CHECK_OBJECT( tmp_args_element_name_8 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 239;
    {
        PyObject *call_args[] = { tmp_args_element_name_8 };
        tmp_assign_source_7 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_4, const_str_plain_open, call_args );
    }

    if ( tmp_assign_source_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 239;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    assert( var_gzfile == NULL );
    var_gzfile = tmp_assign_source_7;

    // Tried code:
    tmp_str_arg_1 = par_name;

    CHECK_OBJECT( tmp_str_arg_1 );
    tmp_type_name_name_1 = PyObject_Str( tmp_str_arg_1 );
    if ( tmp_type_name_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }
    tmp_bases_name_1 = const_tuple_empty;
    tmp_source_name_9 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_pickle );

    if (unlikely( tmp_source_name_9 == NULL ))
    {
        tmp_source_name_9 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_pickle );
    }

    if ( tmp_source_name_9 == NULL )
    {
        Py_DECREF( tmp_type_name_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "pickle" );
        exception_tb = NULL;

        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }

    tmp_called_name_4 = LOOKUP_ATTRIBUTE( tmp_source_name_9, const_str_plain_loads );
    if ( tmp_called_name_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_type_name_name_1 );

        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }
    tmp_called_instance_5 = var_gzfile;

    CHECK_OBJECT( tmp_called_instance_5 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 241;
    tmp_args_element_name_9 = CALL_METHOD_NO_ARGS( tmp_called_instance_5, const_str_plain_read );
    if ( tmp_args_element_name_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_type_name_name_1 );
        Py_DECREF( tmp_called_name_4 );

        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 241;
    {
        PyObject *call_args[] = { tmp_args_element_name_9 };
        tmp_dict_name_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_4, call_args );
    }

    Py_DECREF( tmp_called_name_4 );
    Py_DECREF( tmp_args_element_name_9 );
    if ( tmp_dict_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_type_name_name_1 );

        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }
    tmp_return_value = BUILTIN_TYPE3( const_str_digest_a5f56e291553139a63a10626179e7804, tmp_type_name_name_1, tmp_bases_name_1, tmp_dict_name_1 );
    Py_DECREF( tmp_type_name_name_1 );
    Py_DECREF( tmp_dict_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 241;
        type_description_1 = "ooooooo";
        goto try_except_handler_4;
    }
    goto try_return_handler_4;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_21__load_data );
    return NULL;
    // Return handler code:
    try_return_handler_4:;
    tmp_called_instance_6 = var_gzfile;

    CHECK_OBJECT( tmp_called_instance_6 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 243;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_6, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 243;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    Py_DECREF( tmp_unused );
    goto try_return_handler_3;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    tmp_called_instance_7 = var_gzfile;

    CHECK_OBJECT( tmp_called_instance_7 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 243;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_7, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        Py_DECREF( exception_keeper_type_1 );
        Py_XDECREF( exception_keeper_value_1 );
        Py_XDECREF( exception_keeper_tb_1 );

        exception_lineno = 243;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    Py_DECREF( tmp_unused );
    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    branch_no_1:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 236;
        type_description_1 = "ooooooo";
        goto try_except_handler_3;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_1;
    // Return handler code:
    try_return_handler_3:;
    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__iter_value );
    Py_DECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    goto frame_return_exit_1;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_2;
    // End of try:
    try_end_1:;
    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_called_instance_8 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapDB );

    if (unlikely( tmp_called_instance_8 == NULL ))
    {
        tmp_called_instance_8 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapDB );
    }

    if ( tmp_called_instance_8 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapDB" );
        exception_tb = NULL;

        exception_lineno = 245;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }

    tmp_args_element_name_10 = par_name;

    CHECK_OBJECT( tmp_args_element_name_10 );
    frame_e5e7e55f392592a385ee5efc197a73a2->m_frame.f_lineno = 245;
    {
        PyObject *call_args[] = { tmp_args_element_name_10 };
        tmp_raise_type_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_8, const_str_plain_CMapNotFound, call_args );
    }

    if ( tmp_raise_type_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 245;
        type_description_1 = "ooooooo";
        goto try_except_handler_2;
    }
    exception_type = tmp_raise_type_1;
    exception_lineno = 245;
    RAISE_EXCEPTION_WITH_TYPE( &exception_type, &exception_value, &exception_tb );
    type_description_1 = "ooooooo";
    goto try_except_handler_2;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_21__load_data );
    return NULL;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:

#if 0
    RESTORE_FRAME_EXCEPTION( frame_e5e7e55f392592a385ee5efc197a73a2 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_e5e7e55f392592a385ee5efc197a73a2 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_e5e7e55f392592a385ee5efc197a73a2 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_e5e7e55f392592a385ee5efc197a73a2, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_e5e7e55f392592a385ee5efc197a73a2->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_e5e7e55f392592a385ee5efc197a73a2, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_e5e7e55f392592a385ee5efc197a73a2,
        type_description_1,
        par_klass,
        par_name,
        var_filename,
        var_cmap_paths,
        var_directory,
        var_path,
        var_gzfile
    );


    // Release cached frame.
    if ( frame_e5e7e55f392592a385ee5efc197a73a2 == cache_frame_e5e7e55f392592a385ee5efc197a73a2 )
    {
        Py_DECREF( frame_e5e7e55f392592a385ee5efc197a73a2 );
    }
    cache_frame_e5e7e55f392592a385ee5efc197a73a2 = NULL;

    assertFrameObject( frame_e5e7e55f392592a385ee5efc197a73a2 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_21__load_data );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)var_filename );
    Py_DECREF( var_filename );
    var_filename = NULL;

    CHECK_OBJECT( (PyObject *)var_cmap_paths );
    Py_DECREF( var_cmap_paths );
    var_cmap_paths = NULL;

    CHECK_OBJECT( (PyObject *)var_directory );
    Py_DECREF( var_directory );
    var_directory = NULL;

    CHECK_OBJECT( (PyObject *)var_path );
    Py_DECREF( var_path );
    var_path = NULL;

    CHECK_OBJECT( (PyObject *)var_gzfile );
    Py_DECREF( var_gzfile );
    var_gzfile = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    Py_XDECREF( var_filename );
    var_filename = NULL;

    Py_XDECREF( var_cmap_paths );
    var_cmap_paths = NULL;

    Py_XDECREF( var_directory );
    var_directory = NULL;

    Py_XDECREF( var_path );
    var_path = NULL;

    Py_XDECREF( var_gzfile );
    var_gzfile = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_21__load_data );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_22_get_cmap( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_klass = python_pars[ 0 ];
    PyObject *par_name = python_pars[ 1 ];
    PyObject *var_data = NULL;
    PyObject *var_cmap = NULL;
    PyObject *tmp_assign_unpack_1__assign_source = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    int tmp_cmp_Eq_1;
    int tmp_cmp_Eq_2;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_left_2;
    PyObject *tmp_compare_left_3;
    PyObject *tmp_compare_right_1;
    PyObject *tmp_compare_right_2;
    PyObject *tmp_compare_right_3;
    int tmp_exc_match_exception_match_1;
    PyObject *tmp_kw_name_1;
    PyObject *tmp_kw_name_2;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    static struct Nuitka_FrameObject *cache_frame_3689aab6f2005e7d6d6cba5bd05af69a = NULL;

    struct Nuitka_FrameObject *frame_3689aab6f2005e7d6d6cba5bd05af69a;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_3689aab6f2005e7d6d6cba5bd05af69a, codeobj_3689aab6f2005e7d6d6cba5bd05af69a, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_3689aab6f2005e7d6d6cba5bd05af69a = cache_frame_3689aab6f2005e7d6d6cba5bd05af69a;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_3689aab6f2005e7d6d6cba5bd05af69a );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_3689aab6f2005e7d6d6cba5bd05af69a ) == 2 ); // Frame stack

    // Framed code:
    tmp_compare_left_1 = par_name;

    CHECK_OBJECT( tmp_compare_left_1 );
    tmp_compare_right_1 = const_str_digest_e7502d95d9606e3e619198e28527b862;
    tmp_cmp_Eq_1 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_1, tmp_compare_right_1 );
    if ( tmp_cmp_Eq_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 249;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_called_name_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_IdentityCMap );

    if (unlikely( tmp_called_name_1 == NULL ))
    {
        tmp_called_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_IdentityCMap );
    }

    if ( tmp_called_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "IdentityCMap" );
        exception_tb = NULL;

        exception_lineno = 250;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }

    tmp_kw_name_1 = PyDict_Copy( const_dict_47564eeef2ec8d21619ac66253a5cc5e );
    frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame.f_lineno = 250;
    tmp_return_value = CALL_FUNCTION_WITH_KEYARGS( tmp_called_name_1, tmp_kw_name_1 );
    Py_DECREF( tmp_kw_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 250;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    goto branch_end_1;
    branch_no_1:;
    tmp_compare_left_2 = par_name;

    CHECK_OBJECT( tmp_compare_left_2 );
    tmp_compare_right_2 = const_str_digest_b59ff24f0306e1d3fc9e440d70c22e7b;
    tmp_cmp_Eq_2 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_2, tmp_compare_right_2 );
    if ( tmp_cmp_Eq_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 251;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_2 == 1 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_called_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_IdentityCMap );

    if (unlikely( tmp_called_name_2 == NULL ))
    {
        tmp_called_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_IdentityCMap );
    }

    if ( tmp_called_name_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "IdentityCMap" );
        exception_tb = NULL;

        exception_lineno = 252;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }

    tmp_kw_name_2 = PyDict_Copy( const_dict_ce3809eb77b4cef6dc68a812b608cc09 );
    frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame.f_lineno = 252;
    tmp_return_value = CALL_FUNCTION_WITH_KEYARGS( tmp_called_name_2, tmp_kw_name_2 );
    Py_DECREF( tmp_kw_name_2 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 252;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    branch_no_2:;
    branch_end_1:;
    // Tried code:
    tmp_source_name_1 = par_klass;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_subscribed_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain__cmap_cache );
    if ( tmp_subscribed_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 254;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    tmp_subscript_name_1 = par_name;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_return_value = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    Py_DECREF( tmp_subscribed_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 254;
        type_description_1 = "oooo";
        goto try_except_handler_2;
    }
    goto frame_return_exit_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_22_get_cmap );
    return NULL;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_3689aab6f2005e7d6d6cba5bd05af69a );
    if ( exception_keeper_tb_1 == NULL )
    {
        exception_keeper_tb_1 = MAKE_TRACEBACK( frame_3689aab6f2005e7d6d6cba5bd05af69a, exception_keeper_lineno_1 );
    }
    else if ( exception_keeper_lineno_1 != 0 )
    {
        exception_keeper_tb_1 = ADD_TRACEBACK( exception_keeper_tb_1, frame_3689aab6f2005e7d6d6cba5bd05af69a, exception_keeper_lineno_1 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    PUBLISH_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    tmp_compare_left_3 = PyThreadState_GET()->exc_type;
    tmp_compare_right_3 = PyExc_KeyError;
    tmp_exc_match_exception_match_1 = EXCEPTION_MATCH_BOOL( tmp_compare_left_3, tmp_compare_right_3 );
    if ( tmp_exc_match_exception_match_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 255;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_exc_match_exception_match_1 == 1 )
    {
        goto branch_no_3;
    }
    else
    {
        goto branch_yes_3;
    }
    branch_yes_3:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 253;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame) frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "oooo";
    goto frame_exception_exit_1;
    branch_no_3:;
    goto try_end_1;
    // exception handler codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_22_get_cmap );
    return NULL;
    // End of try:
    try_end_1:;
    tmp_called_instance_1 = par_klass;

    CHECK_OBJECT( tmp_called_instance_1 );
    tmp_args_element_name_1 = par_name;

    CHECK_OBJECT( tmp_args_element_name_1 );
    frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame.f_lineno = 257;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_assign_source_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_1, const_str_plain__load_data, call_args );
    }

    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 257;
        type_description_1 = "oooo";
        goto frame_exception_exit_1;
    }
    assert( var_data == NULL );
    var_data = tmp_assign_source_1;

    // Tried code:
    tmp_called_name_3 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PyCMap );

    if (unlikely( tmp_called_name_3 == NULL ))
    {
        tmp_called_name_3 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PyCMap );
    }

    if ( tmp_called_name_3 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PyCMap" );
        exception_tb = NULL;

        exception_lineno = 258;
        type_description_1 = "oooo";
        goto try_except_handler_3;
    }

    tmp_args_element_name_2 = par_name;

    CHECK_OBJECT( tmp_args_element_name_2 );
    tmp_args_element_name_3 = var_data;

    CHECK_OBJECT( tmp_args_element_name_3 );
    frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame.f_lineno = 258;
    {
        PyObject *call_args[] = { tmp_args_element_name_2, tmp_args_element_name_3 };
        tmp_assign_source_2 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_3, call_args );
    }

    if ( tmp_assign_source_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 258;
        type_description_1 = "oooo";
        goto try_except_handler_3;
    }
    assert( tmp_assign_unpack_1__assign_source == NULL );
    tmp_assign_unpack_1__assign_source = tmp_assign_source_2;

    tmp_ass_subvalue_1 = tmp_assign_unpack_1__assign_source;

    CHECK_OBJECT( tmp_ass_subvalue_1 );
    tmp_source_name_2 = par_klass;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain__cmap_cache );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 258;
        type_description_1 = "oooo";
        goto try_except_handler_3;
    }
    tmp_ass_subscript_1 = par_name;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 258;
        type_description_1 = "oooo";
        goto try_except_handler_3;
    }
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_assign_unpack_1__assign_source );
    tmp_assign_unpack_1__assign_source = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto frame_exception_exit_1;
    // End of try:
    try_end_2:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_3689aab6f2005e7d6d6cba5bd05af69a );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 1
    RESTORE_FRAME_EXCEPTION( frame_3689aab6f2005e7d6d6cba5bd05af69a );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_3689aab6f2005e7d6d6cba5bd05af69a );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_3689aab6f2005e7d6d6cba5bd05af69a, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_3689aab6f2005e7d6d6cba5bd05af69a->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_3689aab6f2005e7d6d6cba5bd05af69a, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_3689aab6f2005e7d6d6cba5bd05af69a,
        type_description_1,
        par_klass,
        par_name,
        var_data,
        var_cmap
    );


    // Release cached frame.
    if ( frame_3689aab6f2005e7d6d6cba5bd05af69a == cache_frame_3689aab6f2005e7d6d6cba5bd05af69a )
    {
        Py_DECREF( frame_3689aab6f2005e7d6d6cba5bd05af69a );
    }
    cache_frame_3689aab6f2005e7d6d6cba5bd05af69a = NULL;

    assertFrameObject( frame_3689aab6f2005e7d6d6cba5bd05af69a );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_assign_source_3 = tmp_assign_unpack_1__assign_source;

    CHECK_OBJECT( tmp_assign_source_3 );
    assert( var_cmap == NULL );
    Py_INCREF( tmp_assign_source_3 );
    var_cmap = tmp_assign_source_3;

    CHECK_OBJECT( (PyObject *)tmp_assign_unpack_1__assign_source );
    Py_DECREF( tmp_assign_unpack_1__assign_source );
    tmp_assign_unpack_1__assign_source = NULL;

    tmp_return_value = var_cmap;

    CHECK_OBJECT( tmp_return_value );
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_22_get_cmap );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    Py_XDECREF( var_data );
    var_data = NULL;

    Py_XDECREF( var_cmap );
    var_cmap = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    Py_XDECREF( var_data );
    var_data = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_22_get_cmap );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_23_get_unicode_map( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_klass = python_pars[ 0 ];
    PyObject *par_name = python_pars[ 1 ];
    PyObject *par_vertical = python_pars[ 2 ];
    PyObject *var_data = NULL;
    PyObject *var_v = NULL;
    PyObject *var_umaps = NULL;
    PyObject *tmp_assign_unpack_1__assign_source = NULL;
    PyObject *tmp_list_contraction_1__$0 = NULL;
    PyObject *tmp_list_contraction_1__contraction_result = NULL;
    PyObject *tmp_list_contraction_1__iter_value_0 = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *tmp_append_list_1;
    PyObject *tmp_append_value_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_ass_subscribed_1;
    PyObject *tmp_ass_subscript_1;
    PyObject *tmp_ass_subvalue_1;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    int tmp_exc_match_exception_match_1;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_outline_return_value_1;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscribed_name_2;
    PyObject *tmp_subscribed_name_3;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_subscript_name_2;
    PyObject *tmp_subscript_name_3;
    static struct Nuitka_FrameObject *cache_frame_af28b21103770807e407a40fb3bd2b78 = NULL;

    struct Nuitka_FrameObject *frame_af28b21103770807e407a40fb3bd2b78;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;
    tmp_outline_return_value_1 = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_af28b21103770807e407a40fb3bd2b78, codeobj_af28b21103770807e407a40fb3bd2b78, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_af28b21103770807e407a40fb3bd2b78 = cache_frame_af28b21103770807e407a40fb3bd2b78;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_af28b21103770807e407a40fb3bd2b78 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_af28b21103770807e407a40fb3bd2b78 ) == 2 ); // Frame stack

    // Framed code:
    // Tried code:
    tmp_source_name_1 = par_klass;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_subscribed_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain__umap_cache );
    if ( tmp_subscribed_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 264;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    tmp_subscript_name_1 = par_name;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_subscribed_name_1 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_2, tmp_subscript_name_1 );
    Py_DECREF( tmp_subscribed_name_2 );
    if ( tmp_subscribed_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 264;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    tmp_subscript_name_2 = par_vertical;

    CHECK_OBJECT( tmp_subscript_name_2 );
    tmp_return_value = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_2 );
    Py_DECREF( tmp_subscribed_name_1 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 264;
        type_description_1 = "oooooo";
        goto try_except_handler_2;
    }
    goto frame_return_exit_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_af28b21103770807e407a40fb3bd2b78 );
    if ( exception_keeper_tb_1 == NULL )
    {
        exception_keeper_tb_1 = MAKE_TRACEBACK( frame_af28b21103770807e407a40fb3bd2b78, exception_keeper_lineno_1 );
    }
    else if ( exception_keeper_lineno_1 != 0 )
    {
        exception_keeper_tb_1 = ADD_TRACEBACK( exception_keeper_tb_1, frame_af28b21103770807e407a40fb3bd2b78, exception_keeper_lineno_1 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    PUBLISH_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    tmp_compare_left_1 = PyThreadState_GET()->exc_type;
    tmp_compare_right_1 = PyExc_KeyError;
    tmp_exc_match_exception_match_1 = EXCEPTION_MATCH_BOOL( tmp_compare_left_1, tmp_compare_right_1 );
    if ( tmp_exc_match_exception_match_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 265;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_exc_match_exception_match_1 == 1 )
    {
        goto branch_no_1;
    }
    else
    {
        goto branch_yes_1;
    }
    branch_yes_1:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 263;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_af28b21103770807e407a40fb3bd2b78->m_frame) frame_af28b21103770807e407a40fb3bd2b78->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "oooooo";
    goto frame_exception_exit_1;
    branch_no_1:;
    goto try_end_1;
    // exception handler codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;
    // End of try:
    try_end_1:;
    tmp_source_name_2 = par_klass;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain__load_data );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 267;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    tmp_left_name_1 = const_str_digest_744fab9097f9fc4d67e451ba8fa53651;
    tmp_right_name_1 = par_name;

    CHECK_OBJECT( tmp_right_name_1 );
    tmp_args_element_name_1 = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 267;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    frame_af28b21103770807e407a40fb3bd2b78->m_frame.f_lineno = 267;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_assign_source_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 267;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    assert( var_data == NULL );
    var_data = tmp_assign_source_1;

    // Tried code:
    tmp_iter_arg_1 = const_tuple_false_true_tuple;
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_1 );
    assert( tmp_assign_source_3 != NULL );
    assert( tmp_list_contraction_1__$0 == NULL );
    tmp_list_contraction_1__$0 = tmp_assign_source_3;

    tmp_assign_source_4 = PyList_New( 0 );
    assert( tmp_list_contraction_1__contraction_result == NULL );
    tmp_list_contraction_1__contraction_result = tmp_assign_source_4;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_list_contraction_1__$0;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_5 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_5 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooo";
            exception_lineno = 268;
            goto try_except_handler_4;
        }
    }

    {
        PyObject *old = tmp_list_contraction_1__iter_value_0;
        tmp_list_contraction_1__iter_value_0 = tmp_assign_source_5;
        Py_XDECREF( old );
    }

    tmp_assign_source_6 = tmp_list_contraction_1__iter_value_0;

    CHECK_OBJECT( tmp_assign_source_6 );
    {
        PyObject *old = var_v;
        var_v = tmp_assign_source_6;
        Py_INCREF( var_v );
        Py_XDECREF( old );
    }

    tmp_append_list_1 = tmp_list_contraction_1__contraction_result;

    CHECK_OBJECT( tmp_append_list_1 );
    tmp_called_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PyUnicodeMap );

    if (unlikely( tmp_called_name_2 == NULL ))
    {
        tmp_called_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PyUnicodeMap );
    }

    if ( tmp_called_name_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PyUnicodeMap" );
        exception_tb = NULL;

        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_4;
    }

    tmp_args_element_name_2 = par_name;

    CHECK_OBJECT( tmp_args_element_name_2 );
    tmp_args_element_name_3 = var_data;

    CHECK_OBJECT( tmp_args_element_name_3 );
    tmp_args_element_name_4 = var_v;

    CHECK_OBJECT( tmp_args_element_name_4 );
    frame_af28b21103770807e407a40fb3bd2b78->m_frame.f_lineno = 268;
    {
        PyObject *call_args[] = { tmp_args_element_name_2, tmp_args_element_name_3, tmp_args_element_name_4 };
        tmp_append_value_1 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_2, call_args );
    }

    if ( tmp_append_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_4;
    }
    assert( PyList_Check( tmp_append_list_1 ) );
    tmp_res = PyList_Append( tmp_append_list_1, tmp_append_value_1 );
    Py_DECREF( tmp_append_value_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_4;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_4;
    }
    goto loop_start_1;
    loop_end_1:;
    tmp_outline_return_value_1 = tmp_list_contraction_1__contraction_result;

    CHECK_OBJECT( tmp_outline_return_value_1 );
    Py_INCREF( tmp_outline_return_value_1 );
    goto try_return_handler_4;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;
    // Return handler code:
    try_return_handler_4:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__$0 );
    Py_DECREF( tmp_list_contraction_1__$0 );
    tmp_list_contraction_1__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__contraction_result );
    Py_DECREF( tmp_list_contraction_1__contraction_result );
    tmp_list_contraction_1__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_1__iter_value_0 );
    tmp_list_contraction_1__iter_value_0 = NULL;

    goto outline_result_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__$0 );
    Py_DECREF( tmp_list_contraction_1__$0 );
    tmp_list_contraction_1__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__contraction_result );
    Py_DECREF( tmp_list_contraction_1__contraction_result );
    tmp_list_contraction_1__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_1__iter_value_0 );
    tmp_list_contraction_1__iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_3;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;
    outline_result_1:;
    tmp_assign_source_2 = tmp_outline_return_value_1;
    assert( tmp_assign_unpack_1__assign_source == NULL );
    tmp_assign_unpack_1__assign_source = tmp_assign_source_2;

    tmp_ass_subvalue_1 = tmp_assign_unpack_1__assign_source;

    CHECK_OBJECT( tmp_ass_subvalue_1 );
    tmp_source_name_3 = par_klass;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_ass_subscribed_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain__umap_cache );
    if ( tmp_ass_subscribed_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_3;
    }
    tmp_ass_subscript_1 = par_name;

    CHECK_OBJECT( tmp_ass_subscript_1 );
    tmp_result = SET_SUBSCRIPT( tmp_ass_subscribed_1, tmp_ass_subscript_1, tmp_ass_subvalue_1 );
    Py_DECREF( tmp_ass_subscribed_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 268;
        type_description_1 = "oooooo";
        goto try_except_handler_3;
    }
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_assign_unpack_1__assign_source );
    tmp_assign_unpack_1__assign_source = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_2:;
    tmp_assign_source_7 = tmp_assign_unpack_1__assign_source;

    CHECK_OBJECT( tmp_assign_source_7 );
    assert( var_umaps == NULL );
    Py_INCREF( tmp_assign_source_7 );
    var_umaps = tmp_assign_source_7;

    CHECK_OBJECT( (PyObject *)tmp_assign_unpack_1__assign_source );
    Py_DECREF( tmp_assign_unpack_1__assign_source );
    tmp_assign_unpack_1__assign_source = NULL;

    tmp_subscribed_name_3 = var_umaps;

    CHECK_OBJECT( tmp_subscribed_name_3 );
    tmp_subscript_name_3 = par_vertical;

    CHECK_OBJECT( tmp_subscript_name_3 );
    tmp_return_value = LOOKUP_SUBSCRIPT( tmp_subscribed_name_3, tmp_subscript_name_3 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 269;
        type_description_1 = "oooooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_af28b21103770807e407a40fb3bd2b78 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 1
    RESTORE_FRAME_EXCEPTION( frame_af28b21103770807e407a40fb3bd2b78 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_af28b21103770807e407a40fb3bd2b78 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_af28b21103770807e407a40fb3bd2b78, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_af28b21103770807e407a40fb3bd2b78->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_af28b21103770807e407a40fb3bd2b78, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_af28b21103770807e407a40fb3bd2b78,
        type_description_1,
        par_klass,
        par_name,
        par_vertical,
        var_data,
        var_v,
        var_umaps
    );


    // Release cached frame.
    if ( frame_af28b21103770807e407a40fb3bd2b78 == cache_frame_af28b21103770807e407a40fb3bd2b78 )
    {
        Py_DECREF( frame_af28b21103770807e407a40fb3bd2b78 );
    }
    cache_frame_af28b21103770807e407a40fb3bd2b78 = NULL;

    assertFrameObject( frame_af28b21103770807e407a40fb3bd2b78 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_vertical );
    Py_DECREF( par_vertical );
    par_vertical = NULL;

    Py_XDECREF( var_data );
    var_data = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_umaps );
    var_umaps = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_klass );
    Py_DECREF( par_klass );
    par_klass = NULL;

    CHECK_OBJECT( (PyObject *)par_name );
    Py_DECREF( par_name );
    par_name = NULL;

    CHECK_OBJECT( (PyObject *)par_vertical );
    Py_DECREF( par_vertical );
    par_vertical = NULL;

    Py_XDECREF( var_data );
    var_data = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_umaps );
    var_umaps = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_23_get_unicode_map );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_24___init__( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_cmap = python_pars[ 1 ];
    PyObject *par_fp = python_pars[ 2 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_name_2;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_assattr_target_2;
    PyObject *tmp_called_instance_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_eda9792646615076f73a487c13258da9 = NULL;

    struct Nuitka_FrameObject *frame_eda9792646615076f73a487c13258da9;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_eda9792646615076f73a487c13258da9, codeobj_eda9792646615076f73a487c13258da9, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_eda9792646615076f73a487c13258da9 = cache_frame_eda9792646615076f73a487c13258da9;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_eda9792646615076f73a487c13258da9 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_eda9792646615076f73a487c13258da9 ) == 2 ); // Frame stack

    // Framed code:
    tmp_called_instance_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSStackParser );

    if (unlikely( tmp_called_instance_1 == NULL ))
    {
        tmp_called_instance_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSStackParser );
    }

    if ( tmp_called_instance_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PSStackParser" );
        exception_tb = NULL;

        exception_lineno = 277;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_1 = par_self;

    CHECK_OBJECT( tmp_args_element_name_1 );
    tmp_args_element_name_2 = par_fp;

    CHECK_OBJECT( tmp_args_element_name_2 );
    frame_eda9792646615076f73a487c13258da9->m_frame.f_lineno = 277;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_unused = CALL_METHOD_WITH_ARGS2( tmp_called_instance_1, const_str_plain___init__, call_args );
    }

    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 277;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_assattr_name_1 = par_cmap;

    CHECK_OBJECT( tmp_assattr_name_1 );
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_cmap, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 278;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_name_2 = Py_True;
    tmp_assattr_target_2 = par_self;

    CHECK_OBJECT( tmp_assattr_target_2 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_2, const_str_plain__in_cmap, tmp_assattr_name_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 280;
        type_description_1 = "ooo";
        goto frame_exception_exit_1;
    }

#if 0
    RESTORE_FRAME_EXCEPTION( frame_eda9792646615076f73a487c13258da9 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_eda9792646615076f73a487c13258da9 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_eda9792646615076f73a487c13258da9, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_eda9792646615076f73a487c13258da9->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_eda9792646615076f73a487c13258da9, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_eda9792646615076f73a487c13258da9,
        type_description_1,
        par_self,
        par_cmap,
        par_fp
    );


    // Release cached frame.
    if ( frame_eda9792646615076f73a487c13258da9 == cache_frame_eda9792646615076f73a487c13258da9 )
    {
        Py_DECREF( frame_eda9792646615076f73a487c13258da9 );
    }
    cache_frame_eda9792646615076f73a487c13258da9 = NULL;

    assertFrameObject( frame_eda9792646615076f73a487c13258da9 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_24___init__ );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;

    CHECK_OBJECT( (PyObject *)par_fp );
    Py_DECREF( par_fp );
    par_fp = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_cmap );
    Py_DECREF( par_cmap );
    par_cmap = NULL;

    CHECK_OBJECT( (PyObject *)par_fp );
    Py_DECREF( par_fp );
    par_fp = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_24___init__ );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_25_run( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_right_1;
    int tmp_exc_match_exception_match_1;
    bool tmp_result;
    PyObject *tmp_return_value;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_96b1bf7efd688a60a724ef5995c02a1a = NULL;

    struct Nuitka_FrameObject *frame_96b1bf7efd688a60a724ef5995c02a1a;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_96b1bf7efd688a60a724ef5995c02a1a, codeobj_96b1bf7efd688a60a724ef5995c02a1a, module_pdfminer$cmapdb, sizeof(void *) );
    frame_96b1bf7efd688a60a724ef5995c02a1a = cache_frame_96b1bf7efd688a60a724ef5995c02a1a;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_96b1bf7efd688a60a724ef5995c02a1a );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_96b1bf7efd688a60a724ef5995c02a1a ) == 2 ); // Frame stack

    // Framed code:
    // Tried code:
    tmp_called_instance_1 = par_self;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_96b1bf7efd688a60a724ef5995c02a1a->m_frame.f_lineno = 285;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_nextobject );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 285;
        type_description_1 = "o";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_96b1bf7efd688a60a724ef5995c02a1a );
    if ( exception_keeper_tb_1 == NULL )
    {
        exception_keeper_tb_1 = MAKE_TRACEBACK( frame_96b1bf7efd688a60a724ef5995c02a1a, exception_keeper_lineno_1 );
    }
    else if ( exception_keeper_lineno_1 != 0 )
    {
        exception_keeper_tb_1 = ADD_TRACEBACK( exception_keeper_tb_1, frame_96b1bf7efd688a60a724ef5995c02a1a, exception_keeper_lineno_1 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    PUBLISH_EXCEPTION( &exception_keeper_type_1, &exception_keeper_value_1, &exception_keeper_tb_1 );
    tmp_compare_left_1 = PyThreadState_GET()->exc_type;
    tmp_compare_right_1 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSEOF );

    if (unlikely( tmp_compare_right_1 == NULL ))
    {
        tmp_compare_right_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSEOF );
    }

    if ( tmp_compare_right_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PSEOF" );
        exception_tb = NULL;

        exception_lineno = 286;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }

    tmp_exc_match_exception_match_1 = EXCEPTION_MATCH_BOOL( tmp_compare_left_1, tmp_compare_right_1 );
    if ( tmp_exc_match_exception_match_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 286;
        type_description_1 = "o";
        goto frame_exception_exit_1;
    }
    if ( tmp_exc_match_exception_match_1 == 1 )
    {
        goto branch_no_1;
    }
    else
    {
        goto branch_yes_1;
    }
    branch_yes_1:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 284;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_96b1bf7efd688a60a724ef5995c02a1a->m_frame) frame_96b1bf7efd688a60a724ef5995c02a1a->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "o";
    goto frame_exception_exit_1;
    branch_no_1:;
    goto try_end_1;
    // exception handler codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_25_run );
    return NULL;
    // End of try:
    try_end_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_96b1bf7efd688a60a724ef5995c02a1a );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_96b1bf7efd688a60a724ef5995c02a1a );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_96b1bf7efd688a60a724ef5995c02a1a, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_96b1bf7efd688a60a724ef5995c02a1a->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_96b1bf7efd688a60a724ef5995c02a1a, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_96b1bf7efd688a60a724ef5995c02a1a,
        type_description_1,
        par_self
    );


    // Release cached frame.
    if ( frame_96b1bf7efd688a60a724ef5995c02a1a == cache_frame_96b1bf7efd688a60a724ef5995c02a1a )
    {
        Py_DECREF( frame_96b1bf7efd688a60a724ef5995c02a1a );
    }
    cache_frame_96b1bf7efd688a60a724ef5995c02a1a = NULL;

    assertFrameObject( frame_96b1bf7efd688a60a724ef5995c02a1a );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_25_run );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_25_run );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_26_do_keyword( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_self = python_pars[ 0 ];
    PyObject *par_pos = python_pars[ 1 ];
    PyObject *par_token = python_pars[ 2 ];
    PyObject *var__ = NULL;
    PyObject *var_k = NULL;
    PyObject *var_v = NULL;
    PyObject *var_cmapname = NULL;
    PyObject *var___ = NULL;
    PyObject *var_obj = NULL;
    PyObject *var_objs = NULL;
    PyObject *var_s = NULL;
    PyObject *var_e = NULL;
    PyObject *var_cid = NULL;
    PyObject *var_sprefix = NULL;
    PyObject *var_eprefix = NULL;
    PyObject *var_svar = NULL;
    PyObject *var_evar = NULL;
    PyObject *var_s1 = NULL;
    PyObject *var_e1 = NULL;
    PyObject *var_vlen = NULL;
    PyObject *var_i = NULL;
    PyObject *var_x = NULL;
    PyObject *var_code = NULL;
    PyObject *var_var = NULL;
    PyObject *var_base = NULL;
    PyObject *var_prefix = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *tmp_for_loop_2__for_iterator = NULL;
    PyObject *tmp_for_loop_2__iter_value = NULL;
    PyObject *tmp_for_loop_3__for_iterator = NULL;
    PyObject *tmp_for_loop_3__iter_value = NULL;
    PyObject *tmp_for_loop_4__for_iterator = NULL;
    PyObject *tmp_for_loop_4__iter_value = NULL;
    PyObject *tmp_for_loop_5__for_iterator = NULL;
    PyObject *tmp_for_loop_5__iter_value = NULL;
    PyObject *tmp_for_loop_6__for_iterator = NULL;
    PyObject *tmp_for_loop_6__iter_value = NULL;
    PyObject *tmp_for_loop_7__for_iterator = NULL;
    PyObject *tmp_for_loop_7__iter_value = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_1__source_iter = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_2__element_1 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_2__element_2 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_2__source_iter = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_3__element_1 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_3__element_2 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_3__source_iter = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_4__element_1 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_4__element_2 = NULL;
    PyObject *tmp_list_contraction$tuple_unpack_4__source_iter = NULL;
    PyObject *tmp_list_contraction_1__$0 = NULL;
    PyObject *tmp_list_contraction_1__contraction_result = NULL;
    PyObject *tmp_list_contraction_1__iter_value_0 = NULL;
    PyObject *tmp_list_contraction_2__$0 = NULL;
    PyObject *tmp_list_contraction_2__contraction_result = NULL;
    PyObject *tmp_list_contraction_2__iter_value_0 = NULL;
    PyObject *tmp_list_contraction_3__$0 = NULL;
    PyObject *tmp_list_contraction_3__contraction_result = NULL;
    PyObject *tmp_list_contraction_3__iter_value_0 = NULL;
    PyObject *tmp_list_contraction_4__$0 = NULL;
    PyObject *tmp_list_contraction_4__contraction_result = NULL;
    PyObject *tmp_list_contraction_4__iter_value_0 = NULL;
    PyObject *tmp_tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_tuple_unpack_1__source_iter = NULL;
    PyObject *tmp_tuple_unpack_2__element_1 = NULL;
    PyObject *tmp_tuple_unpack_2__element_2 = NULL;
    PyObject *tmp_tuple_unpack_2__source_iter = NULL;
    PyObject *tmp_tuple_unpack_3__element_1 = NULL;
    PyObject *tmp_tuple_unpack_3__element_2 = NULL;
    PyObject *tmp_tuple_unpack_3__source_iter = NULL;
    PyObject *tmp_tuple_unpack_4__element_1 = NULL;
    PyObject *tmp_tuple_unpack_4__source_iter = NULL;
    PyObject *tmp_tuple_unpack_5__element_1 = NULL;
    PyObject *tmp_tuple_unpack_5__element_2 = NULL;
    PyObject *tmp_tuple_unpack_5__source_iter = NULL;
    PyObject *tmp_tuple_unpack_6__element_1 = NULL;
    PyObject *tmp_tuple_unpack_6__element_2 = NULL;
    PyObject *tmp_tuple_unpack_6__element_3 = NULL;
    PyObject *tmp_tuple_unpack_6__source_iter = NULL;
    PyObject *tmp_tuple_unpack_7__element_1 = NULL;
    PyObject *tmp_tuple_unpack_7__element_2 = NULL;
    PyObject *tmp_tuple_unpack_7__source_iter = NULL;
    PyObject *tmp_tuple_unpack_8__element_1 = NULL;
    PyObject *tmp_tuple_unpack_8__element_2 = NULL;
    PyObject *tmp_tuple_unpack_8__element_3 = NULL;
    PyObject *tmp_tuple_unpack_8__source_iter = NULL;
    PyObject *tmp_tuple_unpack_9__element_1 = NULL;
    PyObject *tmp_tuple_unpack_9__element_2 = NULL;
    PyObject *tmp_tuple_unpack_9__source_iter = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *exception_keeper_type_5;
    PyObject *exception_keeper_value_5;
    PyTracebackObject *exception_keeper_tb_5;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_5;
    PyObject *exception_keeper_type_6;
    PyObject *exception_keeper_value_6;
    PyTracebackObject *exception_keeper_tb_6;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_6;
    PyObject *exception_keeper_type_7;
    PyObject *exception_keeper_value_7;
    PyTracebackObject *exception_keeper_tb_7;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_7;
    PyObject *exception_keeper_type_8;
    PyObject *exception_keeper_value_8;
    PyTracebackObject *exception_keeper_tb_8;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_8;
    PyObject *exception_keeper_type_9;
    PyObject *exception_keeper_value_9;
    PyTracebackObject *exception_keeper_tb_9;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_9;
    PyObject *exception_keeper_type_10;
    PyObject *exception_keeper_value_10;
    PyTracebackObject *exception_keeper_tb_10;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_10;
    PyObject *exception_keeper_type_11;
    PyObject *exception_keeper_value_11;
    PyTracebackObject *exception_keeper_tb_11;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_11;
    PyObject *exception_keeper_type_12;
    PyObject *exception_keeper_value_12;
    PyTracebackObject *exception_keeper_tb_12;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_12;
    PyObject *exception_keeper_type_13;
    PyObject *exception_keeper_value_13;
    PyTracebackObject *exception_keeper_tb_13;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_13;
    PyObject *exception_keeper_type_14;
    PyObject *exception_keeper_value_14;
    PyTracebackObject *exception_keeper_tb_14;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_14;
    PyObject *exception_keeper_type_15;
    PyObject *exception_keeper_value_15;
    PyTracebackObject *exception_keeper_tb_15;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_15;
    PyObject *exception_keeper_type_16;
    PyObject *exception_keeper_value_16;
    PyTracebackObject *exception_keeper_tb_16;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_16;
    PyObject *exception_keeper_type_17;
    PyObject *exception_keeper_value_17;
    PyTracebackObject *exception_keeper_tb_17;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_17;
    PyObject *exception_keeper_type_18;
    PyObject *exception_keeper_value_18;
    PyTracebackObject *exception_keeper_tb_18;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_18;
    PyObject *exception_keeper_type_19;
    PyObject *exception_keeper_value_19;
    PyTracebackObject *exception_keeper_tb_19;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_19;
    PyObject *exception_keeper_type_20;
    PyObject *exception_keeper_value_20;
    PyTracebackObject *exception_keeper_tb_20;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_20;
    PyObject *exception_keeper_type_21;
    PyObject *exception_keeper_value_21;
    PyTracebackObject *exception_keeper_tb_21;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_21;
    PyObject *exception_keeper_type_22;
    PyObject *exception_keeper_value_22;
    PyTracebackObject *exception_keeper_tb_22;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_22;
    PyObject *exception_keeper_type_23;
    PyObject *exception_keeper_value_23;
    PyTracebackObject *exception_keeper_tb_23;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_23;
    PyObject *exception_keeper_type_24;
    PyObject *exception_keeper_value_24;
    PyTracebackObject *exception_keeper_tb_24;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_24;
    PyObject *exception_keeper_type_25;
    PyObject *exception_keeper_value_25;
    PyTracebackObject *exception_keeper_tb_25;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_25;
    PyObject *exception_keeper_type_26;
    PyObject *exception_keeper_value_26;
    PyTracebackObject *exception_keeper_tb_26;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_26;
    PyObject *exception_keeper_type_27;
    PyObject *exception_keeper_value_27;
    PyTracebackObject *exception_keeper_tb_27;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_27;
    PyObject *exception_keeper_type_28;
    PyObject *exception_keeper_value_28;
    PyTracebackObject *exception_keeper_tb_28;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_28;
    PyObject *exception_keeper_type_29;
    PyObject *exception_keeper_value_29;
    PyTracebackObject *exception_keeper_tb_29;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_29;
    PyObject *exception_keeper_type_30;
    PyObject *exception_keeper_value_30;
    PyTracebackObject *exception_keeper_tb_30;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_30;
    PyObject *exception_keeper_type_31;
    PyObject *exception_keeper_value_31;
    PyTracebackObject *exception_keeper_tb_31;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_31;
    PyObject *exception_keeper_type_32;
    PyObject *exception_keeper_value_32;
    PyTracebackObject *exception_keeper_tb_32;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_32;
    PyObject *exception_keeper_type_33;
    PyObject *exception_keeper_value_33;
    PyTracebackObject *exception_keeper_tb_33;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_33;
    PyObject *exception_keeper_type_34;
    PyObject *exception_keeper_value_34;
    PyTracebackObject *exception_keeper_tb_34;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_34;
    PyObject *exception_keeper_type_35;
    PyObject *exception_keeper_value_35;
    PyTracebackObject *exception_keeper_tb_35;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_35;
    PyObject *exception_keeper_type_36;
    PyObject *exception_keeper_value_36;
    PyTracebackObject *exception_keeper_tb_36;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_36;
    PyObject *exception_keeper_type_37;
    PyObject *exception_keeper_value_37;
    PyTracebackObject *exception_keeper_tb_37;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_37;
    PyObject *exception_keeper_type_38;
    PyObject *exception_keeper_value_38;
    PyTracebackObject *exception_keeper_tb_38;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_38;
    PyObject *exception_keeper_type_39;
    PyObject *exception_keeper_value_39;
    PyTracebackObject *exception_keeper_tb_39;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_39;
    PyObject *exception_keeper_type_40;
    PyObject *exception_keeper_value_40;
    PyTracebackObject *exception_keeper_tb_40;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_40;
    int tmp_and_left_truth_1;
    int tmp_and_left_truth_2;
    PyObject *tmp_and_left_value_1;
    PyObject *tmp_and_left_value_2;
    PyObject *tmp_and_right_value_1;
    PyObject *tmp_and_right_value_2;
    PyObject *tmp_append_list_1;
    PyObject *tmp_append_list_2;
    PyObject *tmp_append_list_3;
    PyObject *tmp_append_list_4;
    PyObject *tmp_append_value_1;
    PyObject *tmp_append_value_2;
    PyObject *tmp_append_value_3;
    PyObject *tmp_append_value_4;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_args_element_name_5;
    PyObject *tmp_args_element_name_6;
    PyObject *tmp_args_element_name_7;
    PyObject *tmp_args_element_name_8;
    PyObject *tmp_args_element_name_9;
    PyObject *tmp_args_element_name_10;
    PyObject *tmp_args_element_name_11;
    PyObject *tmp_args_element_name_12;
    PyObject *tmp_args_element_name_13;
    PyObject *tmp_args_element_name_14;
    PyObject *tmp_args_element_name_15;
    PyObject *tmp_args_element_name_16;
    PyObject *tmp_args_element_name_17;
    PyObject *tmp_args_element_name_18;
    PyObject *tmp_args_element_name_19;
    PyObject *tmp_args_element_name_20;
    PyObject *tmp_args_element_name_21;
    PyObject *tmp_args_element_name_22;
    PyObject *tmp_args_element_name_23;
    PyObject *tmp_args_element_name_24;
    PyObject *tmp_args_element_name_25;
    PyObject *tmp_args_element_name_26;
    PyObject *tmp_args_element_name_27;
    PyObject *tmp_args_element_name_28;
    PyObject *tmp_args_element_name_29;
    PyObject *tmp_args_element_name_30;
    PyObject *tmp_args_element_name_31;
    PyObject *tmp_args_element_name_32;
    PyObject *tmp_args_element_name_33;
    PyObject *tmp_args_element_name_34;
    PyObject *tmp_args_element_name_35;
    PyObject *tmp_args_element_name_36;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_name_2;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_assattr_target_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    PyObject *tmp_assign_source_10;
    PyObject *tmp_assign_source_11;
    PyObject *tmp_assign_source_12;
    PyObject *tmp_assign_source_13;
    PyObject *tmp_assign_source_14;
    PyObject *tmp_assign_source_15;
    PyObject *tmp_assign_source_16;
    PyObject *tmp_assign_source_17;
    PyObject *tmp_assign_source_18;
    PyObject *tmp_assign_source_19;
    PyObject *tmp_assign_source_20;
    PyObject *tmp_assign_source_21;
    PyObject *tmp_assign_source_22;
    PyObject *tmp_assign_source_23;
    PyObject *tmp_assign_source_24;
    PyObject *tmp_assign_source_25;
    PyObject *tmp_assign_source_26;
    PyObject *tmp_assign_source_27;
    PyObject *tmp_assign_source_28;
    PyObject *tmp_assign_source_29;
    PyObject *tmp_assign_source_30;
    PyObject *tmp_assign_source_31;
    PyObject *tmp_assign_source_32;
    PyObject *tmp_assign_source_33;
    PyObject *tmp_assign_source_34;
    PyObject *tmp_assign_source_35;
    PyObject *tmp_assign_source_36;
    PyObject *tmp_assign_source_37;
    PyObject *tmp_assign_source_38;
    PyObject *tmp_assign_source_39;
    PyObject *tmp_assign_source_40;
    PyObject *tmp_assign_source_41;
    PyObject *tmp_assign_source_42;
    PyObject *tmp_assign_source_43;
    PyObject *tmp_assign_source_44;
    PyObject *tmp_assign_source_45;
    PyObject *tmp_assign_source_46;
    PyObject *tmp_assign_source_47;
    PyObject *tmp_assign_source_48;
    PyObject *tmp_assign_source_49;
    PyObject *tmp_assign_source_50;
    PyObject *tmp_assign_source_51;
    PyObject *tmp_assign_source_52;
    PyObject *tmp_assign_source_53;
    PyObject *tmp_assign_source_54;
    PyObject *tmp_assign_source_55;
    PyObject *tmp_assign_source_56;
    PyObject *tmp_assign_source_57;
    PyObject *tmp_assign_source_58;
    PyObject *tmp_assign_source_59;
    PyObject *tmp_assign_source_60;
    PyObject *tmp_assign_source_61;
    PyObject *tmp_assign_source_62;
    PyObject *tmp_assign_source_63;
    PyObject *tmp_assign_source_64;
    PyObject *tmp_assign_source_65;
    PyObject *tmp_assign_source_66;
    PyObject *tmp_assign_source_67;
    PyObject *tmp_assign_source_68;
    PyObject *tmp_assign_source_69;
    PyObject *tmp_assign_source_70;
    PyObject *tmp_assign_source_71;
    PyObject *tmp_assign_source_72;
    PyObject *tmp_assign_source_73;
    PyObject *tmp_assign_source_74;
    PyObject *tmp_assign_source_75;
    PyObject *tmp_assign_source_76;
    PyObject *tmp_assign_source_77;
    PyObject *tmp_assign_source_78;
    PyObject *tmp_assign_source_79;
    PyObject *tmp_assign_source_80;
    PyObject *tmp_assign_source_81;
    PyObject *tmp_assign_source_82;
    PyObject *tmp_assign_source_83;
    PyObject *tmp_assign_source_84;
    PyObject *tmp_assign_source_85;
    PyObject *tmp_assign_source_86;
    PyObject *tmp_assign_source_87;
    PyObject *tmp_assign_source_88;
    PyObject *tmp_assign_source_89;
    PyObject *tmp_assign_source_90;
    PyObject *tmp_assign_source_91;
    PyObject *tmp_assign_source_92;
    PyObject *tmp_assign_source_93;
    PyObject *tmp_assign_source_94;
    PyObject *tmp_assign_source_95;
    PyObject *tmp_assign_source_96;
    PyObject *tmp_assign_source_97;
    PyObject *tmp_assign_source_98;
    PyObject *tmp_assign_source_99;
    PyObject *tmp_assign_source_100;
    PyObject *tmp_assign_source_101;
    PyObject *tmp_assign_source_102;
    PyObject *tmp_assign_source_103;
    PyObject *tmp_assign_source_104;
    PyObject *tmp_assign_source_105;
    PyObject *tmp_assign_source_106;
    PyObject *tmp_assign_source_107;
    PyObject *tmp_assign_source_108;
    PyObject *tmp_assign_source_109;
    PyObject *tmp_assign_source_110;
    PyObject *tmp_assign_source_111;
    PyObject *tmp_assign_source_112;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_instance_2;
    PyObject *tmp_called_instance_3;
    PyObject *tmp_called_instance_4;
    PyObject *tmp_called_instance_5;
    PyObject *tmp_called_instance_6;
    PyObject *tmp_called_instance_7;
    PyObject *tmp_called_instance_8;
    PyObject *tmp_called_instance_9;
    PyObject *tmp_called_instance_10;
    PyObject *tmp_called_instance_11;
    PyObject *tmp_called_instance_12;
    PyObject *tmp_called_instance_13;
    PyObject *tmp_called_instance_14;
    PyObject *tmp_called_instance_15;
    PyObject *tmp_called_instance_16;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_called_name_4;
    PyObject *tmp_called_name_5;
    PyObject *tmp_called_name_6;
    PyObject *tmp_called_name_7;
    PyObject *tmp_called_name_8;
    PyObject *tmp_called_name_9;
    PyObject *tmp_called_name_10;
    PyObject *tmp_called_name_11;
    PyObject *tmp_called_name_12;
    PyObject *tmp_called_name_13;
    PyObject *tmp_called_name_14;
    PyObject *tmp_called_name_15;
    PyObject *tmp_called_name_16;
    PyObject *tmp_called_name_17;
    PyObject *tmp_called_name_18;
    PyObject *tmp_called_name_19;
    PyObject *tmp_called_name_20;
    PyObject *tmp_called_name_21;
    PyObject *tmp_called_name_22;
    PyObject *tmp_called_name_23;
    int tmp_cmp_NotEq_1;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_left_2;
    PyObject *tmp_compare_left_3;
    PyObject *tmp_compare_left_4;
    PyObject *tmp_compare_left_5;
    PyObject *tmp_compare_left_6;
    PyObject *tmp_compare_left_7;
    PyObject *tmp_compare_left_8;
    PyObject *tmp_compare_left_9;
    PyObject *tmp_compare_left_10;
    PyObject *tmp_compare_left_11;
    PyObject *tmp_compare_left_12;
    PyObject *tmp_compare_left_13;
    PyObject *tmp_compare_left_14;
    PyObject *tmp_compare_left_15;
    PyObject *tmp_compare_left_16;
    PyObject *tmp_compare_left_17;
    PyObject *tmp_compare_left_18;
    PyObject *tmp_compare_left_19;
    PyObject *tmp_compare_left_20;
    PyObject *tmp_compare_right_1;
    PyObject *tmp_compare_right_2;
    PyObject *tmp_compare_right_3;
    PyObject *tmp_compare_right_4;
    PyObject *tmp_compare_right_5;
    PyObject *tmp_compare_right_6;
    PyObject *tmp_compare_right_7;
    PyObject *tmp_compare_right_8;
    PyObject *tmp_compare_right_9;
    PyObject *tmp_compare_right_10;
    PyObject *tmp_compare_right_11;
    PyObject *tmp_compare_right_12;
    PyObject *tmp_compare_right_13;
    PyObject *tmp_compare_right_14;
    PyObject *tmp_compare_right_15;
    PyObject *tmp_compare_right_16;
    PyObject *tmp_compare_right_17;
    PyObject *tmp_compare_right_18;
    PyObject *tmp_compare_right_19;
    PyObject *tmp_compare_right_20;
    PyObject *tmp_compexpr_left_1;
    PyObject *tmp_compexpr_left_2;
    PyObject *tmp_compexpr_right_1;
    PyObject *tmp_compexpr_right_2;
    int tmp_cond_truth_1;
    int tmp_cond_truth_2;
    int tmp_cond_truth_3;
    int tmp_cond_truth_4;
    int tmp_cond_truth_5;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_cond_value_2;
    PyObject *tmp_cond_value_3;
    PyObject *tmp_cond_value_4;
    PyObject *tmp_cond_value_5;
    int tmp_exc_match_exception_match_1;
    int tmp_exc_match_exception_match_2;
    int tmp_exc_match_exception_match_3;
    bool tmp_is_1;
    bool tmp_is_2;
    bool tmp_is_3;
    bool tmp_is_4;
    bool tmp_is_5;
    bool tmp_is_6;
    bool tmp_is_7;
    bool tmp_is_8;
    bool tmp_is_9;
    bool tmp_is_10;
    bool tmp_is_11;
    bool tmp_is_12;
    bool tmp_is_13;
    bool tmp_is_14;
    bool tmp_is_15;
    bool tmp_is_16;
    PyObject *tmp_isinstance_cls_1;
    PyObject *tmp_isinstance_cls_2;
    PyObject *tmp_isinstance_cls_3;
    PyObject *tmp_isinstance_cls_4;
    PyObject *tmp_isinstance_cls_5;
    PyObject *tmp_isinstance_cls_6;
    PyObject *tmp_isinstance_cls_7;
    PyObject *tmp_isinstance_cls_8;
    PyObject *tmp_isinstance_cls_9;
    PyObject *tmp_isinstance_cls_10;
    PyObject *tmp_isinstance_inst_1;
    PyObject *tmp_isinstance_inst_2;
    PyObject *tmp_isinstance_inst_3;
    PyObject *tmp_isinstance_inst_4;
    PyObject *tmp_isinstance_inst_5;
    PyObject *tmp_isinstance_inst_6;
    PyObject *tmp_isinstance_inst_7;
    PyObject *tmp_isinstance_inst_8;
    PyObject *tmp_isinstance_inst_9;
    PyObject *tmp_isinstance_inst_10;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_iter_arg_2;
    PyObject *tmp_iter_arg_3;
    PyObject *tmp_iter_arg_4;
    PyObject *tmp_iter_arg_5;
    PyObject *tmp_iter_arg_6;
    PyObject *tmp_iter_arg_7;
    PyObject *tmp_iter_arg_8;
    PyObject *tmp_iter_arg_9;
    PyObject *tmp_iter_arg_10;
    PyObject *tmp_iter_arg_11;
    PyObject *tmp_iter_arg_12;
    PyObject *tmp_iter_arg_13;
    PyObject *tmp_iter_arg_14;
    PyObject *tmp_iter_arg_15;
    PyObject *tmp_iter_arg_16;
    PyObject *tmp_iter_arg_17;
    PyObject *tmp_iter_arg_18;
    PyObject *tmp_iter_arg_19;
    PyObject *tmp_iter_arg_20;
    PyObject *tmp_iter_arg_21;
    PyObject *tmp_iter_arg_22;
    PyObject *tmp_iter_arg_23;
    PyObject *tmp_iter_arg_24;
    PyObject *tmp_iterator_attempt;
    PyObject *tmp_iterator_name_1;
    PyObject *tmp_iterator_name_2;
    PyObject *tmp_iterator_name_3;
    PyObject *tmp_iterator_name_4;
    PyObject *tmp_iterator_name_5;
    PyObject *tmp_iterator_name_6;
    PyObject *tmp_iterator_name_7;
    PyObject *tmp_iterator_name_8;
    PyObject *tmp_iterator_name_9;
    PyObject *tmp_iterator_name_10;
    PyObject *tmp_iterator_name_11;
    PyObject *tmp_iterator_name_12;
    PyObject *tmp_iterator_name_13;
    PyObject *tmp_left_name_1;
    PyObject *tmp_left_name_2;
    PyObject *tmp_left_name_3;
    PyObject *tmp_left_name_4;
    PyObject *tmp_left_name_5;
    PyObject *tmp_left_name_6;
    PyObject *tmp_left_name_7;
    PyObject *tmp_left_name_8;
    PyObject *tmp_left_name_9;
    PyObject *tmp_left_name_10;
    PyObject *tmp_left_name_11;
    PyObject *tmp_left_name_12;
    PyObject *tmp_left_name_13;
    PyObject *tmp_len_arg_1;
    PyObject *tmp_len_arg_2;
    PyObject *tmp_len_arg_3;
    PyObject *tmp_len_arg_4;
    PyObject *tmp_len_arg_5;
    PyObject *tmp_len_arg_6;
    PyObject *tmp_next_source_1;
    PyObject *tmp_next_source_2;
    PyObject *tmp_next_source_3;
    PyObject *tmp_next_source_4;
    PyObject *tmp_next_source_5;
    PyObject *tmp_next_source_6;
    PyObject *tmp_next_source_7;
    PyObject *tmp_next_source_8;
    PyObject *tmp_next_source_9;
    PyObject *tmp_next_source_10;
    PyObject *tmp_next_source_11;
    PyObject *tmp_operand_name_1;
    PyObject *tmp_operand_name_2;
    PyObject *tmp_operand_name_3;
    PyObject *tmp_operand_name_4;
    PyObject *tmp_operand_name_5;
    PyObject *tmp_operand_name_6;
    PyObject *tmp_operand_name_7;
    int tmp_or_left_truth_1;
    int tmp_or_left_truth_2;
    int tmp_or_left_truth_3;
    int tmp_or_left_truth_4;
    int tmp_or_left_truth_5;
    PyObject *tmp_or_left_value_1;
    PyObject *tmp_or_left_value_2;
    PyObject *tmp_or_left_value_3;
    PyObject *tmp_or_left_value_4;
    PyObject *tmp_or_left_value_5;
    PyObject *tmp_or_right_value_1;
    PyObject *tmp_or_right_value_2;
    PyObject *tmp_or_right_value_3;
    PyObject *tmp_or_right_value_4;
    PyObject *tmp_or_right_value_5;
    PyObject *tmp_outline_return_value_1;
    PyObject *tmp_outline_return_value_2;
    PyObject *tmp_outline_return_value_3;
    PyObject *tmp_outline_return_value_4;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_right_name_2;
    PyObject *tmp_right_name_3;
    PyObject *tmp_right_name_4;
    PyObject *tmp_right_name_5;
    PyObject *tmp_right_name_6;
    PyObject *tmp_right_name_7;
    PyObject *tmp_right_name_8;
    PyObject *tmp_right_name_9;
    PyObject *tmp_right_name_10;
    PyObject *tmp_right_name_11;
    PyObject *tmp_right_name_12;
    PyObject *tmp_right_name_13;
    Py_ssize_t tmp_slice_index_upper_1;
    Py_ssize_t tmp_slice_index_upper_2;
    Py_ssize_t tmp_slice_index_upper_3;
    Py_ssize_t tmp_slice_index_upper_4;
    Py_ssize_t tmp_slice_index_upper_5;
    Py_ssize_t tmp_slice_index_upper_6;
    PyObject *tmp_slice_lower_1;
    PyObject *tmp_slice_lower_2;
    PyObject *tmp_slice_source_1;
    PyObject *tmp_slice_source_2;
    PyObject *tmp_slice_source_3;
    PyObject *tmp_slice_source_4;
    PyObject *tmp_slice_source_5;
    PyObject *tmp_slice_source_6;
    PyObject *tmp_slice_source_7;
    PyObject *tmp_slice_source_8;
    Py_ssize_t tmp_sliceslicedel_index_lower_1;
    Py_ssize_t tmp_sliceslicedel_index_lower_2;
    Py_ssize_t tmp_sliceslicedel_index_lower_3;
    Py_ssize_t tmp_sliceslicedel_index_lower_4;
    Py_ssize_t tmp_sliceslicedel_index_lower_5;
    Py_ssize_t tmp_sliceslicedel_index_lower_6;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_source_name_6;
    PyObject *tmp_source_name_7;
    PyObject *tmp_source_name_8;
    PyObject *tmp_source_name_9;
    PyObject *tmp_source_name_10;
    PyObject *tmp_source_name_11;
    PyObject *tmp_source_name_12;
    PyObject *tmp_source_name_13;
    PyObject *tmp_source_name_14;
    PyObject *tmp_source_name_15;
    PyObject *tmp_source_name_16;
    PyObject *tmp_source_name_17;
    PyObject *tmp_source_name_18;
    PyObject *tmp_source_name_19;
    PyObject *tmp_source_name_20;
    PyObject *tmp_source_name_21;
    PyObject *tmp_source_name_22;
    PyObject *tmp_source_name_23;
    PyObject *tmp_source_name_24;
    PyObject *tmp_source_name_25;
    PyObject *tmp_source_name_26;
    PyObject *tmp_source_name_27;
    PyObject *tmp_source_name_28;
    PyObject *tmp_source_name_29;
    PyObject *tmp_source_name_30;
    PyObject *tmp_source_name_31;
    PyObject *tmp_source_name_32;
    PyObject *tmp_source_name_33;
    PyObject *tmp_source_name_34;
    PyObject *tmp_source_name_35;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_unpack_1;
    PyObject *tmp_unpack_2;
    PyObject *tmp_unpack_3;
    PyObject *tmp_unpack_4;
    PyObject *tmp_unpack_5;
    PyObject *tmp_unpack_6;
    PyObject *tmp_unpack_7;
    PyObject *tmp_unpack_8;
    PyObject *tmp_unpack_9;
    PyObject *tmp_unpack_10;
    PyObject *tmp_unpack_11;
    PyObject *tmp_unpack_12;
    PyObject *tmp_unpack_13;
    PyObject *tmp_unpack_14;
    PyObject *tmp_unpack_15;
    PyObject *tmp_unpack_16;
    PyObject *tmp_unpack_17;
    PyObject *tmp_unpack_18;
    PyObject *tmp_unpack_19;
    PyObject *tmp_unpack_20;
    PyObject *tmp_unpack_21;
    PyObject *tmp_unpack_22;
    PyObject *tmp_unpack_23;
    PyObject *tmp_unpack_24;
    PyObject *tmp_unpack_25;
    PyObject *tmp_unpack_26;
    PyObject *tmp_unpack_27;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    PyObject *tmp_xrange_low_1;
    PyObject *tmp_xrange_low_2;
    PyObject *tmp_xrange_low_3;
    static struct Nuitka_FrameObject *cache_frame_dde973ae2c181782bcfe319ce801f19b = NULL;

    struct Nuitka_FrameObject *frame_dde973ae2c181782bcfe319ce801f19b;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;
    tmp_outline_return_value_1 = NULL;
    tmp_outline_return_value_2 = NULL;
    tmp_outline_return_value_3 = NULL;
    tmp_outline_return_value_4 = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_dde973ae2c181782bcfe319ce801f19b, codeobj_dde973ae2c181782bcfe319ce801f19b, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_dde973ae2c181782bcfe319ce801f19b = cache_frame_dde973ae2c181782bcfe319ce801f19b;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_dde973ae2c181782bcfe319ce801f19b );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_dde973ae2c181782bcfe319ce801f19b ) == 2 ); // Frame stack

    // Framed code:
    tmp_compare_left_1 = par_token;

    CHECK_OBJECT( tmp_compare_left_1 );
    tmp_source_name_1 = par_self;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_compare_right_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_KEYWORD_BEGINCMAP );
    if ( tmp_compare_right_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 308;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_1 = ( tmp_compare_left_1 == tmp_compare_right_1 );
    Py_DECREF( tmp_compare_right_1 );
    if ( tmp_is_1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_assattr_name_1 = Py_True;
    tmp_assattr_target_1 = par_self;

    CHECK_OBJECT( tmp_assattr_target_1 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain__in_cmap, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 309;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_called_instance_1 = par_self;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 310;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 310;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    goto branch_end_1;
    branch_no_1:;
    tmp_compare_left_2 = par_token;

    CHECK_OBJECT( tmp_compare_left_2 );
    tmp_source_name_2 = par_self;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_compare_right_2 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_KEYWORD_ENDCMAP );
    if ( tmp_compare_right_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 312;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_2 = ( tmp_compare_left_2 == tmp_compare_right_2 );
    Py_DECREF( tmp_compare_right_2 );
    if ( tmp_is_2 )
    {
        goto branch_yes_2;
    }
    else
    {
        goto branch_no_2;
    }
    branch_yes_2:;
    tmp_assattr_name_2 = Py_False;
    tmp_assattr_target_2 = par_self;

    CHECK_OBJECT( tmp_assattr_target_2 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_2, const_str_plain__in_cmap, tmp_assattr_name_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 313;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_2:;
    branch_end_1:;
    tmp_source_name_3 = par_self;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_cond_value_1 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain__in_cmap );
    if ( tmp_cond_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 315;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_1 );

        exception_lineno = 315;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_no_3;
    }
    else
    {
        goto branch_yes_3;
    }
    branch_yes_3:;
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_3:;
    tmp_compare_left_3 = par_token;

    CHECK_OBJECT( tmp_compare_left_3 );
    tmp_source_name_4 = par_self;

    CHECK_OBJECT( tmp_source_name_4 );
    tmp_compare_right_3 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_KEYWORD_DEF );
    if ( tmp_compare_right_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 318;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_3 = ( tmp_compare_left_3 == tmp_compare_right_3 );
    Py_DECREF( tmp_compare_right_3 );
    if ( tmp_is_3 )
    {
        goto branch_yes_4;
    }
    else
    {
        goto branch_no_4;
    }
    branch_yes_4:;
    // Tried code:
    // Tried code:
    tmp_called_instance_2 = par_self;

    CHECK_OBJECT( tmp_called_instance_2 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 320;
    tmp_iter_arg_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_2, const_str_plain_pop, &PyTuple_GET_ITEM( const_tuple_int_pos_2_tuple, 0 ) );

    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 320;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_3;
    }
    tmp_assign_source_1 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 320;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_3;
    }
    assert( tmp_tuple_unpack_1__source_iter == NULL );
    tmp_tuple_unpack_1__source_iter = tmp_assign_source_1;

    // Tried code:
    tmp_unpack_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_1 );
    tmp_assign_source_2 = UNPACK_NEXT( tmp_unpack_1, 0 );
    if ( tmp_assign_source_2 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_4;
    }
    assert( tmp_tuple_unpack_1__element_1 == NULL );
    tmp_tuple_unpack_1__element_1 = tmp_assign_source_2;

    tmp_unpack_2 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_2 );
    tmp_assign_source_3 = UNPACK_NEXT( tmp_unpack_2, 1 );
    if ( tmp_assign_source_3 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_4;
    }
    assert( tmp_tuple_unpack_1__element_2 == NULL );
    tmp_tuple_unpack_1__element_2 = tmp_assign_source_3;

    tmp_iterator_name_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_1 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_1 ); assert( HAS_ITERNEXT( tmp_iterator_name_1 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_1 )->tp_iternext)( tmp_iterator_name_1 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 320;
                goto try_except_handler_4;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_4;
    }
    goto try_end_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    try_end_1:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Tried code:
    tmp_iter_arg_2 = tmp_tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_iter_arg_2 );
    tmp_assign_source_4 = MAKE_ITERATOR( tmp_iter_arg_2 );
    if ( tmp_assign_source_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 320;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_5;
    }
    assert( tmp_tuple_unpack_2__source_iter == NULL );
    tmp_tuple_unpack_2__source_iter = tmp_assign_source_4;

    // Tried code:
    tmp_unpack_3 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_3 );
    tmp_assign_source_5 = UNPACK_NEXT( tmp_unpack_3, 0 );
    if ( tmp_assign_source_5 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_6;
    }
    assert( tmp_tuple_unpack_2__element_1 == NULL );
    tmp_tuple_unpack_2__element_1 = tmp_assign_source_5;

    tmp_unpack_4 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_4 );
    tmp_assign_source_6 = UNPACK_NEXT( tmp_unpack_4, 1 );
    if ( tmp_assign_source_6 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_6;
    }
    assert( tmp_tuple_unpack_2__element_2 == NULL );
    tmp_tuple_unpack_2__element_2 = tmp_assign_source_6;

    tmp_iterator_name_2 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_iterator_name_2 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_2 ); assert( HAS_ITERNEXT( tmp_iterator_name_2 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_2 )->tp_iternext)( tmp_iterator_name_2 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 320;
                goto try_except_handler_6;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_6;
    }
    goto try_end_2;
    // Exception handler code:
    try_except_handler_6:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_2__source_iter );
    Py_DECREF( tmp_tuple_unpack_2__source_iter );
    tmp_tuple_unpack_2__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_5;
    // End of try:
    try_end_2:;
    goto try_end_3;
    // Exception handler code:
    try_except_handler_5:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_2__element_1 );
    tmp_tuple_unpack_2__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_2__element_2 );
    tmp_tuple_unpack_2__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto try_except_handler_3;
    // End of try:
    try_end_3:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_2__source_iter );
    Py_DECREF( tmp_tuple_unpack_2__source_iter );
    tmp_tuple_unpack_2__source_iter = NULL;

    tmp_assign_source_7 = tmp_tuple_unpack_2__element_1;

    CHECK_OBJECT( tmp_assign_source_7 );
    assert( var__ == NULL );
    Py_INCREF( tmp_assign_source_7 );
    var__ = tmp_assign_source_7;

    Py_XDECREF( tmp_tuple_unpack_2__element_1 );
    tmp_tuple_unpack_2__element_1 = NULL;

    tmp_assign_source_8 = tmp_tuple_unpack_2__element_2;

    CHECK_OBJECT( tmp_assign_source_8 );
    assert( var_k == NULL );
    Py_INCREF( tmp_assign_source_8 );
    var_k = tmp_assign_source_8;

    Py_XDECREF( tmp_tuple_unpack_2__element_2 );
    tmp_tuple_unpack_2__element_2 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    // Tried code:
    tmp_iter_arg_3 = tmp_tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_iter_arg_3 );
    tmp_assign_source_9 = MAKE_ITERATOR( tmp_iter_arg_3 );
    if ( tmp_assign_source_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 320;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_7;
    }
    assert( tmp_tuple_unpack_3__source_iter == NULL );
    tmp_tuple_unpack_3__source_iter = tmp_assign_source_9;

    // Tried code:
    tmp_unpack_5 = tmp_tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_unpack_5 );
    tmp_assign_source_10 = UNPACK_NEXT( tmp_unpack_5, 0 );
    if ( tmp_assign_source_10 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_8;
    }
    assert( tmp_tuple_unpack_3__element_1 == NULL );
    tmp_tuple_unpack_3__element_1 = tmp_assign_source_10;

    tmp_unpack_6 = tmp_tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_unpack_6 );
    tmp_assign_source_11 = UNPACK_NEXT( tmp_unpack_6, 1 );
    if ( tmp_assign_source_11 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_8;
    }
    assert( tmp_tuple_unpack_3__element_2 == NULL );
    tmp_tuple_unpack_3__element_2 = tmp_assign_source_11;

    tmp_iterator_name_3 = tmp_tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_iterator_name_3 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_3 ); assert( HAS_ITERNEXT( tmp_iterator_name_3 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_3 )->tp_iternext)( tmp_iterator_name_3 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 320;
                goto try_except_handler_8;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 320;
        goto try_except_handler_8;
    }
    goto try_end_4;
    // Exception handler code:
    try_except_handler_8:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_3__source_iter );
    Py_DECREF( tmp_tuple_unpack_3__source_iter );
    tmp_tuple_unpack_3__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto try_except_handler_7;
    // End of try:
    try_end_4:;
    goto try_end_5;
    // Exception handler code:
    try_except_handler_7:;
    exception_keeper_type_5 = exception_type;
    exception_keeper_value_5 = exception_value;
    exception_keeper_tb_5 = exception_tb;
    exception_keeper_lineno_5 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_3__element_1 );
    tmp_tuple_unpack_3__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_3__element_2 );
    tmp_tuple_unpack_3__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_5;
    exception_value = exception_keeper_value_5;
    exception_tb = exception_keeper_tb_5;
    exception_lineno = exception_keeper_lineno_5;

    goto try_except_handler_3;
    // End of try:
    try_end_5:;
    goto try_end_6;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_6 = exception_type;
    exception_keeper_value_6 = exception_value;
    exception_keeper_tb_6 = exception_tb;
    exception_keeper_lineno_6 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_6;
    exception_value = exception_keeper_value_6;
    exception_tb = exception_keeper_tb_6;
    exception_lineno = exception_keeper_lineno_6;

    goto try_except_handler_2;
    // End of try:
    try_end_6:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_3__source_iter );
    Py_DECREF( tmp_tuple_unpack_3__source_iter );
    tmp_tuple_unpack_3__source_iter = NULL;

    tmp_assign_source_12 = tmp_tuple_unpack_3__element_1;

    CHECK_OBJECT( tmp_assign_source_12 );
    {
        PyObject *old = var__;
        assert( old != NULL );
        var__ = tmp_assign_source_12;
        Py_INCREF( var__ );
        Py_DECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_3__element_1 );
    tmp_tuple_unpack_3__element_1 = NULL;

    tmp_assign_source_13 = tmp_tuple_unpack_3__element_2;

    CHECK_OBJECT( tmp_assign_source_13 );
    assert( var_v == NULL );
    Py_INCREF( tmp_assign_source_13 );
    var_v = tmp_assign_source_13;

    Py_XDECREF( tmp_tuple_unpack_3__element_2 );
    tmp_tuple_unpack_3__element_2 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    tmp_source_name_6 = par_self;

    CHECK_OBJECT( tmp_source_name_6 );
    tmp_source_name_5 = LOOKUP_ATTRIBUTE( tmp_source_name_6, const_str_plain_cmap );
    if ( tmp_source_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 321;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_2;
    }
    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_5, const_str_plain_set_attr );
    Py_DECREF( tmp_source_name_5 );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 321;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_2;
    }
    tmp_called_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_literal_name );

    if (unlikely( tmp_called_name_2 == NULL ))
    {
        tmp_called_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_literal_name );
    }

    if ( tmp_called_name_2 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "literal_name" );
        exception_tb = NULL;

        exception_lineno = 321;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_2;
    }

    tmp_args_element_name_2 = var_k;

    CHECK_OBJECT( tmp_args_element_name_2 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 321;
    {
        PyObject *call_args[] = { tmp_args_element_name_2 };
        tmp_args_element_name_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_2, call_args );
    }

    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 321;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_2;
    }
    tmp_args_element_name_3 = var_v;

    CHECK_OBJECT( tmp_args_element_name_3 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 321;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_3 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 321;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    goto try_end_7;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_7 = exception_type;
    exception_keeper_value_7 = exception_value;
    exception_keeper_tb_7 = exception_tb;
    exception_keeper_lineno_7 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_dde973ae2c181782bcfe319ce801f19b );
    if ( exception_keeper_tb_7 == NULL )
    {
        exception_keeper_tb_7 = MAKE_TRACEBACK( frame_dde973ae2c181782bcfe319ce801f19b, exception_keeper_lineno_7 );
    }
    else if ( exception_keeper_lineno_7 != 0 )
    {
        exception_keeper_tb_7 = ADD_TRACEBACK( exception_keeper_tb_7, frame_dde973ae2c181782bcfe319ce801f19b, exception_keeper_lineno_7 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_7, &exception_keeper_value_7, &exception_keeper_tb_7 );
    PUBLISH_EXCEPTION( &exception_keeper_type_7, &exception_keeper_value_7, &exception_keeper_tb_7 );
    tmp_compare_left_4 = PyThreadState_GET()->exc_type;
    tmp_compare_right_4 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSSyntaxError );

    if (unlikely( tmp_compare_right_4 == NULL ))
    {
        tmp_compare_right_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSSyntaxError );
    }

    if ( tmp_compare_right_4 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PSSyntaxError" );
        exception_tb = NULL;

        exception_lineno = 322;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_exc_match_exception_match_1 = EXCEPTION_MATCH_BOOL( tmp_compare_left_4, tmp_compare_right_4 );
    if ( tmp_exc_match_exception_match_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 322;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_exc_match_exception_match_1 == 1 )
    {
        goto branch_no_5;
    }
    else
    {
        goto branch_yes_5;
    }
    branch_yes_5:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 319;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_dde973ae2c181782bcfe319ce801f19b->m_frame) frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "oooooooooooooooooooooooooo";
    goto frame_exception_exit_1;
    branch_no_5:;
    goto try_end_7;
    // exception handler codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // End of try:
    try_end_7:;
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_4:;
    tmp_compare_left_5 = par_token;

    CHECK_OBJECT( tmp_compare_left_5 );
    tmp_source_name_7 = par_self;

    CHECK_OBJECT( tmp_source_name_7 );
    tmp_compare_right_5 = LOOKUP_ATTRIBUTE( tmp_source_name_7, const_str_plain_KEYWORD_USECMAP );
    if ( tmp_compare_right_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 326;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_4 = ( tmp_compare_left_5 == tmp_compare_right_5 );
    Py_DECREF( tmp_compare_right_5 );
    if ( tmp_is_4 )
    {
        goto branch_yes_6;
    }
    else
    {
        goto branch_no_6;
    }
    branch_yes_6:;
    // Tried code:
    // Tried code:
    tmp_called_instance_3 = par_self;

    CHECK_OBJECT( tmp_called_instance_3 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 328;
    tmp_iter_arg_4 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_3, const_str_plain_pop, &PyTuple_GET_ITEM( const_tuple_int_pos_1_tuple, 0 ) );

    if ( tmp_iter_arg_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 328;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_10;
    }
    tmp_assign_source_14 = MAKE_ITERATOR( tmp_iter_arg_4 );
    Py_DECREF( tmp_iter_arg_4 );
    if ( tmp_assign_source_14 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 328;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_10;
    }
    assert( tmp_tuple_unpack_4__source_iter == NULL );
    tmp_tuple_unpack_4__source_iter = tmp_assign_source_14;

    // Tried code:
    tmp_unpack_7 = tmp_tuple_unpack_4__source_iter;

    CHECK_OBJECT( tmp_unpack_7 );
    tmp_assign_source_15 = UNPACK_NEXT( tmp_unpack_7, 0 );
    if ( tmp_assign_source_15 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 328;
        goto try_except_handler_11;
    }
    assert( tmp_tuple_unpack_4__element_1 == NULL );
    tmp_tuple_unpack_4__element_1 = tmp_assign_source_15;

    tmp_iterator_name_4 = tmp_tuple_unpack_4__source_iter;

    CHECK_OBJECT( tmp_iterator_name_4 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_4 ); assert( HAS_ITERNEXT( tmp_iterator_name_4 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_4 )->tp_iternext)( tmp_iterator_name_4 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 328;
                goto try_except_handler_11;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 1)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 328;
        goto try_except_handler_11;
    }
    goto try_end_8;
    // Exception handler code:
    try_except_handler_11:;
    exception_keeper_type_8 = exception_type;
    exception_keeper_value_8 = exception_value;
    exception_keeper_tb_8 = exception_tb;
    exception_keeper_lineno_8 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_4__source_iter );
    Py_DECREF( tmp_tuple_unpack_4__source_iter );
    tmp_tuple_unpack_4__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_8;
    exception_value = exception_keeper_value_8;
    exception_tb = exception_keeper_tb_8;
    exception_lineno = exception_keeper_lineno_8;

    goto try_except_handler_10;
    // End of try:
    try_end_8:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_4__source_iter );
    Py_DECREF( tmp_tuple_unpack_4__source_iter );
    tmp_tuple_unpack_4__source_iter = NULL;

    // Tried code:
    tmp_iter_arg_5 = tmp_tuple_unpack_4__element_1;

    CHECK_OBJECT( tmp_iter_arg_5 );
    tmp_assign_source_16 = MAKE_ITERATOR( tmp_iter_arg_5 );
    if ( tmp_assign_source_16 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 328;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_12;
    }
    assert( tmp_tuple_unpack_5__source_iter == NULL );
    tmp_tuple_unpack_5__source_iter = tmp_assign_source_16;

    // Tried code:
    tmp_unpack_8 = tmp_tuple_unpack_5__source_iter;

    CHECK_OBJECT( tmp_unpack_8 );
    tmp_assign_source_17 = UNPACK_NEXT( tmp_unpack_8, 0 );
    if ( tmp_assign_source_17 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 328;
        goto try_except_handler_13;
    }
    assert( tmp_tuple_unpack_5__element_1 == NULL );
    tmp_tuple_unpack_5__element_1 = tmp_assign_source_17;

    tmp_unpack_9 = tmp_tuple_unpack_5__source_iter;

    CHECK_OBJECT( tmp_unpack_9 );
    tmp_assign_source_18 = UNPACK_NEXT( tmp_unpack_9, 1 );
    if ( tmp_assign_source_18 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 328;
        goto try_except_handler_13;
    }
    assert( tmp_tuple_unpack_5__element_2 == NULL );
    tmp_tuple_unpack_5__element_2 = tmp_assign_source_18;

    tmp_iterator_name_5 = tmp_tuple_unpack_5__source_iter;

    CHECK_OBJECT( tmp_iterator_name_5 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_5 ); assert( HAS_ITERNEXT( tmp_iterator_name_5 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_5 )->tp_iternext)( tmp_iterator_name_5 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 328;
                goto try_except_handler_13;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 328;
        goto try_except_handler_13;
    }
    goto try_end_9;
    // Exception handler code:
    try_except_handler_13:;
    exception_keeper_type_9 = exception_type;
    exception_keeper_value_9 = exception_value;
    exception_keeper_tb_9 = exception_tb;
    exception_keeper_lineno_9 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_5__source_iter );
    Py_DECREF( tmp_tuple_unpack_5__source_iter );
    tmp_tuple_unpack_5__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_9;
    exception_value = exception_keeper_value_9;
    exception_tb = exception_keeper_tb_9;
    exception_lineno = exception_keeper_lineno_9;

    goto try_except_handler_12;
    // End of try:
    try_end_9:;
    goto try_end_10;
    // Exception handler code:
    try_except_handler_12:;
    exception_keeper_type_10 = exception_type;
    exception_keeper_value_10 = exception_value;
    exception_keeper_tb_10 = exception_tb;
    exception_keeper_lineno_10 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_5__element_1 );
    tmp_tuple_unpack_5__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_5__element_2 );
    tmp_tuple_unpack_5__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_10;
    exception_value = exception_keeper_value_10;
    exception_tb = exception_keeper_tb_10;
    exception_lineno = exception_keeper_lineno_10;

    goto try_except_handler_10;
    // End of try:
    try_end_10:;
    goto try_end_11;
    // Exception handler code:
    try_except_handler_10:;
    exception_keeper_type_11 = exception_type;
    exception_keeper_value_11 = exception_value;
    exception_keeper_tb_11 = exception_tb;
    exception_keeper_lineno_11 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_4__element_1 );
    tmp_tuple_unpack_4__element_1 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_11;
    exception_value = exception_keeper_value_11;
    exception_tb = exception_keeper_tb_11;
    exception_lineno = exception_keeper_lineno_11;

    goto try_except_handler_9;
    // End of try:
    try_end_11:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_5__source_iter );
    Py_DECREF( tmp_tuple_unpack_5__source_iter );
    tmp_tuple_unpack_5__source_iter = NULL;

    tmp_assign_source_19 = tmp_tuple_unpack_5__element_1;

    CHECK_OBJECT( tmp_assign_source_19 );
    assert( var__ == NULL );
    Py_INCREF( tmp_assign_source_19 );
    var__ = tmp_assign_source_19;

    Py_XDECREF( tmp_tuple_unpack_5__element_1 );
    tmp_tuple_unpack_5__element_1 = NULL;

    tmp_assign_source_20 = tmp_tuple_unpack_5__element_2;

    CHECK_OBJECT( tmp_assign_source_20 );
    assert( var_cmapname == NULL );
    Py_INCREF( tmp_assign_source_20 );
    var_cmapname = tmp_assign_source_20;

    Py_XDECREF( tmp_tuple_unpack_5__element_2 );
    tmp_tuple_unpack_5__element_2 = NULL;

    Py_XDECREF( tmp_tuple_unpack_4__element_1 );
    tmp_tuple_unpack_4__element_1 = NULL;

    tmp_source_name_9 = par_self;

    CHECK_OBJECT( tmp_source_name_9 );
    tmp_source_name_8 = LOOKUP_ATTRIBUTE( tmp_source_name_9, const_str_plain_cmap );
    if ( tmp_source_name_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    tmp_called_name_3 = LOOKUP_ATTRIBUTE( tmp_source_name_8, const_str_plain_use_cmap );
    Py_DECREF( tmp_source_name_8 );
    if ( tmp_called_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    tmp_source_name_10 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapDB );

    if (unlikely( tmp_source_name_10 == NULL ))
    {
        tmp_source_name_10 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapDB );
    }

    if ( tmp_source_name_10 == NULL )
    {
        Py_DECREF( tmp_called_name_3 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapDB" );
        exception_tb = NULL;

        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }

    tmp_called_name_4 = LOOKUP_ATTRIBUTE( tmp_source_name_10, const_str_plain_get_cmap );
    if ( tmp_called_name_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_3 );

        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    tmp_called_name_5 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_literal_name );

    if (unlikely( tmp_called_name_5 == NULL ))
    {
        tmp_called_name_5 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_literal_name );
    }

    if ( tmp_called_name_5 == NULL )
    {
        Py_DECREF( tmp_called_name_3 );
        Py_DECREF( tmp_called_name_4 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "literal_name" );
        exception_tb = NULL;

        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }

    tmp_args_element_name_6 = var_cmapname;

    CHECK_OBJECT( tmp_args_element_name_6 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 329;
    {
        PyObject *call_args[] = { tmp_args_element_name_6 };
        tmp_args_element_name_5 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_5, call_args );
    }

    if ( tmp_args_element_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_3 );
        Py_DECREF( tmp_called_name_4 );

        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 329;
    {
        PyObject *call_args[] = { tmp_args_element_name_5 };
        tmp_args_element_name_4 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_4, call_args );
    }

    Py_DECREF( tmp_called_name_4 );
    Py_DECREF( tmp_args_element_name_5 );
    if ( tmp_args_element_name_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_3 );

        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 329;
    {
        PyObject *call_args[] = { tmp_args_element_name_4 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_3, call_args );
    }

    Py_DECREF( tmp_called_name_3 );
    Py_DECREF( tmp_args_element_name_4 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 329;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_9;
    }
    Py_DECREF( tmp_unused );
    goto try_end_12;
    // Exception handler code:
    try_except_handler_9:;
    exception_keeper_type_12 = exception_type;
    exception_keeper_value_12 = exception_value;
    exception_keeper_tb_12 = exception_tb;
    exception_keeper_lineno_12 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_dde973ae2c181782bcfe319ce801f19b );
    if ( exception_keeper_tb_12 == NULL )
    {
        exception_keeper_tb_12 = MAKE_TRACEBACK( frame_dde973ae2c181782bcfe319ce801f19b, exception_keeper_lineno_12 );
    }
    else if ( exception_keeper_lineno_12 != 0 )
    {
        exception_keeper_tb_12 = ADD_TRACEBACK( exception_keeper_tb_12, frame_dde973ae2c181782bcfe319ce801f19b, exception_keeper_lineno_12 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_12, &exception_keeper_value_12, &exception_keeper_tb_12 );
    PUBLISH_EXCEPTION( &exception_keeper_type_12, &exception_keeper_value_12, &exception_keeper_tb_12 );
    tmp_compare_left_6 = PyThreadState_GET()->exc_type;
    tmp_compare_right_6 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSSyntaxError );

    if (unlikely( tmp_compare_right_6 == NULL ))
    {
        tmp_compare_right_6 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSSyntaxError );
    }

    if ( tmp_compare_right_6 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PSSyntaxError" );
        exception_tb = NULL;

        exception_lineno = 330;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_exc_match_exception_match_2 = EXCEPTION_MATCH_BOOL( tmp_compare_left_6, tmp_compare_right_6 );
    if ( tmp_exc_match_exception_match_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 330;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_exc_match_exception_match_2 == 1 )
    {
        goto branch_no_7;
    }
    else
    {
        goto branch_yes_7;
    }
    branch_yes_7:;
    tmp_compare_left_7 = PyThreadState_GET()->exc_type;
    tmp_source_name_11 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapDB );

    if (unlikely( tmp_source_name_11 == NULL ))
    {
        tmp_source_name_11 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapDB );
    }

    if ( tmp_source_name_11 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapDB" );
        exception_tb = NULL;

        exception_lineno = 332;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_compare_right_7 = LOOKUP_ATTRIBUTE( tmp_source_name_11, const_str_plain_CMapNotFound );
    if ( tmp_compare_right_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 332;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_exc_match_exception_match_3 = EXCEPTION_MATCH_BOOL( tmp_compare_left_7, tmp_compare_right_7 );
    if ( tmp_exc_match_exception_match_3 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_compare_right_7 );

        exception_lineno = 332;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_compare_right_7 );
    if ( tmp_exc_match_exception_match_3 == 1 )
    {
        goto branch_no_8;
    }
    else
    {
        goto branch_yes_8;
    }
    branch_yes_8:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 327;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_dde973ae2c181782bcfe319ce801f19b->m_frame) frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "oooooooooooooooooooooooooo";
    goto frame_exception_exit_1;
    branch_no_8:;
    branch_no_7:;
    goto try_end_12;
    // exception handler codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // End of try:
    try_end_12:;
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_6:;
    tmp_compare_left_8 = par_token;

    CHECK_OBJECT( tmp_compare_left_8 );
    tmp_source_name_12 = par_self;

    CHECK_OBJECT( tmp_source_name_12 );
    tmp_compare_right_8 = LOOKUP_ATTRIBUTE( tmp_source_name_12, const_str_plain_KEYWORD_BEGINCODESPACERANGE );
    if ( tmp_compare_right_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 336;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_5 = ( tmp_compare_left_8 == tmp_compare_right_8 );
    Py_DECREF( tmp_compare_right_8 );
    if ( tmp_is_5 )
    {
        goto branch_yes_9;
    }
    else
    {
        goto branch_no_9;
    }
    branch_yes_9:;
    tmp_called_instance_4 = par_self;

    CHECK_OBJECT( tmp_called_instance_4 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 337;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_4, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 337;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_9:;
    tmp_compare_left_9 = par_token;

    CHECK_OBJECT( tmp_compare_left_9 );
    tmp_source_name_13 = par_self;

    CHECK_OBJECT( tmp_source_name_13 );
    tmp_compare_right_9 = LOOKUP_ATTRIBUTE( tmp_source_name_13, const_str_plain_KEYWORD_ENDCODESPACERANGE );
    if ( tmp_compare_right_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 339;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_6 = ( tmp_compare_left_9 == tmp_compare_right_9 );
    Py_DECREF( tmp_compare_right_9 );
    if ( tmp_is_6 )
    {
        goto branch_yes_10;
    }
    else
    {
        goto branch_no_10;
    }
    branch_yes_10:;
    tmp_called_instance_5 = par_self;

    CHECK_OBJECT( tmp_called_instance_5 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 340;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_5, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 340;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_10:;
    tmp_compare_left_10 = par_token;

    CHECK_OBJECT( tmp_compare_left_10 );
    tmp_source_name_14 = par_self;

    CHECK_OBJECT( tmp_source_name_14 );
    tmp_compare_right_10 = LOOKUP_ATTRIBUTE( tmp_source_name_14, const_str_plain_KEYWORD_BEGINCIDRANGE );
    if ( tmp_compare_right_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 343;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_7 = ( tmp_compare_left_10 == tmp_compare_right_10 );
    Py_DECREF( tmp_compare_right_10 );
    if ( tmp_is_7 )
    {
        goto branch_yes_11;
    }
    else
    {
        goto branch_no_11;
    }
    branch_yes_11:;
    tmp_called_instance_6 = par_self;

    CHECK_OBJECT( tmp_called_instance_6 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 344;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_6, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 344;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_11:;
    tmp_compare_left_11 = par_token;

    CHECK_OBJECT( tmp_compare_left_11 );
    tmp_source_name_15 = par_self;

    CHECK_OBJECT( tmp_source_name_15 );
    tmp_compare_right_11 = LOOKUP_ATTRIBUTE( tmp_source_name_15, const_str_plain_KEYWORD_ENDCIDRANGE );
    if ( tmp_compare_right_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 346;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_8 = ( tmp_compare_left_11 == tmp_compare_right_11 );
    Py_DECREF( tmp_compare_right_11 );
    if ( tmp_is_8 )
    {
        goto branch_yes_12;
    }
    else
    {
        goto branch_no_12;
    }
    branch_yes_12:;
    // Tried code:
    tmp_called_instance_7 = par_self;

    CHECK_OBJECT( tmp_called_instance_7 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 347;
    tmp_iter_arg_6 = CALL_METHOD_NO_ARGS( tmp_called_instance_7, const_str_plain_popall );
    if ( tmp_iter_arg_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 347;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_14;
    }
    tmp_assign_source_22 = MAKE_ITERATOR( tmp_iter_arg_6 );
    Py_DECREF( tmp_iter_arg_6 );
    if ( tmp_assign_source_22 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 347;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_14;
    }
    assert( tmp_list_contraction_1__$0 == NULL );
    tmp_list_contraction_1__$0 = tmp_assign_source_22;

    tmp_assign_source_23 = PyList_New( 0 );
    assert( tmp_list_contraction_1__contraction_result == NULL );
    tmp_list_contraction_1__contraction_result = tmp_assign_source_23;

    loop_start_1:;
    tmp_next_source_1 = tmp_list_contraction_1__$0;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_24 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_24 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 347;
            goto try_except_handler_14;
        }
    }

    {
        PyObject *old = tmp_list_contraction_1__iter_value_0;
        tmp_list_contraction_1__iter_value_0 = tmp_assign_source_24;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_7 = tmp_list_contraction_1__iter_value_0;

    CHECK_OBJECT( tmp_iter_arg_7 );
    tmp_assign_source_25 = MAKE_ITERATOR( tmp_iter_arg_7 );
    if ( tmp_assign_source_25 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 347;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_15;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_1__source_iter;
        tmp_list_contraction$tuple_unpack_1__source_iter = tmp_assign_source_25;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_10 = tmp_list_contraction$tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_10 );
    tmp_assign_source_26 = UNPACK_NEXT( tmp_unpack_10, 0 );
    if ( tmp_assign_source_26 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 347;
        goto try_except_handler_16;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_1__element_1;
        tmp_list_contraction$tuple_unpack_1__element_1 = tmp_assign_source_26;
        Py_XDECREF( old );
    }

    tmp_unpack_11 = tmp_list_contraction$tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_11 );
    tmp_assign_source_27 = UNPACK_NEXT( tmp_unpack_11, 1 );
    if ( tmp_assign_source_27 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 347;
        goto try_except_handler_16;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_1__element_2;
        tmp_list_contraction$tuple_unpack_1__element_2 = tmp_assign_source_27;
        Py_XDECREF( old );
    }

    tmp_iterator_name_6 = tmp_list_contraction$tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_6 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_6 ); assert( HAS_ITERNEXT( tmp_iterator_name_6 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_6 )->tp_iternext)( tmp_iterator_name_6 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 347;
                goto try_except_handler_16;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 347;
        goto try_except_handler_16;
    }
    goto try_end_13;
    // Exception handler code:
    try_except_handler_16:;
    exception_keeper_type_13 = exception_type;
    exception_keeper_value_13 = exception_value;
    exception_keeper_tb_13 = exception_tb;
    exception_keeper_lineno_13 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_1__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_1__source_iter );
    tmp_list_contraction$tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_13;
    exception_value = exception_keeper_value_13;
    exception_tb = exception_keeper_tb_13;
    exception_lineno = exception_keeper_lineno_13;

    goto try_except_handler_15;
    // End of try:
    try_end_13:;
    goto try_end_14;
    // Exception handler code:
    try_except_handler_15:;
    exception_keeper_type_14 = exception_type;
    exception_keeper_value_14 = exception_value;
    exception_keeper_tb_14 = exception_tb;
    exception_keeper_lineno_14 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_1__element_1 );
    tmp_list_contraction$tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_1__element_2 );
    tmp_list_contraction$tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_14;
    exception_value = exception_keeper_value_14;
    exception_tb = exception_keeper_tb_14;
    exception_lineno = exception_keeper_lineno_14;

    goto try_except_handler_14;
    // End of try:
    try_end_14:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_1__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_1__source_iter );
    tmp_list_contraction$tuple_unpack_1__source_iter = NULL;

    tmp_assign_source_28 = tmp_list_contraction$tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_assign_source_28 );
    {
        PyObject *old = var___;
        var___ = tmp_assign_source_28;
        Py_INCREF( var___ );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_1__element_1 );
    tmp_list_contraction$tuple_unpack_1__element_1 = NULL;

    tmp_assign_source_29 = tmp_list_contraction$tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_assign_source_29 );
    {
        PyObject *old = var_obj;
        var_obj = tmp_assign_source_29;
        Py_INCREF( var_obj );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_1__element_2 );
    tmp_list_contraction$tuple_unpack_1__element_2 = NULL;

    tmp_append_list_1 = tmp_list_contraction_1__contraction_result;

    CHECK_OBJECT( tmp_append_list_1 );
    tmp_append_value_1 = var_obj;

    CHECK_OBJECT( tmp_append_value_1 );
    assert( PyList_Check( tmp_append_list_1 ) );
    tmp_res = PyList_Append( tmp_append_list_1, tmp_append_value_1 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 347;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_14;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 347;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_14;
    }
    goto loop_start_1;
    loop_end_1:;
    tmp_outline_return_value_1 = tmp_list_contraction_1__contraction_result;

    CHECK_OBJECT( tmp_outline_return_value_1 );
    Py_INCREF( tmp_outline_return_value_1 );
    goto try_return_handler_14;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // Return handler code:
    try_return_handler_14:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__$0 );
    Py_DECREF( tmp_list_contraction_1__$0 );
    tmp_list_contraction_1__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_1__contraction_result );
    Py_DECREF( tmp_list_contraction_1__contraction_result );
    tmp_list_contraction_1__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_1__iter_value_0 );
    tmp_list_contraction_1__iter_value_0 = NULL;

    goto outline_result_1;
    // Exception handler code:
    try_except_handler_14:;
    exception_keeper_type_15 = exception_type;
    exception_keeper_value_15 = exception_value;
    exception_keeper_tb_15 = exception_tb;
    exception_keeper_lineno_15 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction_1__$0 );
    tmp_list_contraction_1__$0 = NULL;

    Py_XDECREF( tmp_list_contraction_1__contraction_result );
    tmp_list_contraction_1__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_1__iter_value_0 );
    tmp_list_contraction_1__iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_15;
    exception_value = exception_keeper_value_15;
    exception_tb = exception_keeper_tb_15;
    exception_lineno = exception_keeper_lineno_15;

    goto frame_exception_exit_1;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    outline_result_1:;
    tmp_assign_source_21 = tmp_outline_return_value_1;
    assert( var_objs == NULL );
    var_objs = tmp_assign_source_21;

    tmp_called_name_6 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_choplist );

    if (unlikely( tmp_called_name_6 == NULL ))
    {
        tmp_called_name_6 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_choplist );
    }

    if ( tmp_called_name_6 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "choplist" );
        exception_tb = NULL;

        exception_lineno = 348;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_7 = const_int_pos_3;
    tmp_args_element_name_8 = var_objs;

    CHECK_OBJECT( tmp_args_element_name_8 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 348;
    {
        PyObject *call_args[] = { tmp_args_element_name_7, tmp_args_element_name_8 };
        tmp_iter_arg_8 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_6, call_args );
    }

    if ( tmp_iter_arg_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 348;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_30 = MAKE_ITERATOR( tmp_iter_arg_8 );
    Py_DECREF( tmp_iter_arg_8 );
    if ( tmp_assign_source_30 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 348;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_30;

    // Tried code:
    loop_start_2:;
    tmp_next_source_2 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_2 );
    tmp_assign_source_31 = ITERATOR_NEXT( tmp_next_source_2 );
    if ( tmp_assign_source_31 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_2;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 348;
            goto try_except_handler_17;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_31;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_9 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_iter_arg_9 );
    tmp_assign_source_32 = MAKE_ITERATOR( tmp_iter_arg_9 );
    if ( tmp_assign_source_32 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 348;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_18;
    }
    {
        PyObject *old = tmp_tuple_unpack_6__source_iter;
        tmp_tuple_unpack_6__source_iter = tmp_assign_source_32;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_12 = tmp_tuple_unpack_6__source_iter;

    CHECK_OBJECT( tmp_unpack_12 );
    tmp_assign_source_33 = UNPACK_NEXT( tmp_unpack_12, 0 );
    if ( tmp_assign_source_33 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 348;
        goto try_except_handler_19;
    }
    {
        PyObject *old = tmp_tuple_unpack_6__element_1;
        tmp_tuple_unpack_6__element_1 = tmp_assign_source_33;
        Py_XDECREF( old );
    }

    tmp_unpack_13 = tmp_tuple_unpack_6__source_iter;

    CHECK_OBJECT( tmp_unpack_13 );
    tmp_assign_source_34 = UNPACK_NEXT( tmp_unpack_13, 1 );
    if ( tmp_assign_source_34 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 348;
        goto try_except_handler_19;
    }
    {
        PyObject *old = tmp_tuple_unpack_6__element_2;
        tmp_tuple_unpack_6__element_2 = tmp_assign_source_34;
        Py_XDECREF( old );
    }

    tmp_unpack_14 = tmp_tuple_unpack_6__source_iter;

    CHECK_OBJECT( tmp_unpack_14 );
    tmp_assign_source_35 = UNPACK_NEXT( tmp_unpack_14, 2 );
    if ( tmp_assign_source_35 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 348;
        goto try_except_handler_19;
    }
    {
        PyObject *old = tmp_tuple_unpack_6__element_3;
        tmp_tuple_unpack_6__element_3 = tmp_assign_source_35;
        Py_XDECREF( old );
    }

    tmp_iterator_name_7 = tmp_tuple_unpack_6__source_iter;

    CHECK_OBJECT( tmp_iterator_name_7 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_7 ); assert( HAS_ITERNEXT( tmp_iterator_name_7 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_7 )->tp_iternext)( tmp_iterator_name_7 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 348;
                goto try_except_handler_19;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 3)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 348;
        goto try_except_handler_19;
    }
    goto try_end_15;
    // Exception handler code:
    try_except_handler_19:;
    exception_keeper_type_16 = exception_type;
    exception_keeper_value_16 = exception_value;
    exception_keeper_tb_16 = exception_tb;
    exception_keeper_lineno_16 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_6__source_iter );
    Py_DECREF( tmp_tuple_unpack_6__source_iter );
    tmp_tuple_unpack_6__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_16;
    exception_value = exception_keeper_value_16;
    exception_tb = exception_keeper_tb_16;
    exception_lineno = exception_keeper_lineno_16;

    goto try_except_handler_18;
    // End of try:
    try_end_15:;
    goto try_end_16;
    // Exception handler code:
    try_except_handler_18:;
    exception_keeper_type_17 = exception_type;
    exception_keeper_value_17 = exception_value;
    exception_keeper_tb_17 = exception_tb;
    exception_keeper_lineno_17 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_6__element_1 );
    tmp_tuple_unpack_6__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_6__element_2 );
    tmp_tuple_unpack_6__element_2 = NULL;

    Py_XDECREF( tmp_tuple_unpack_6__element_3 );
    tmp_tuple_unpack_6__element_3 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_17;
    exception_value = exception_keeper_value_17;
    exception_tb = exception_keeper_tb_17;
    exception_lineno = exception_keeper_lineno_17;

    goto try_except_handler_17;
    // End of try:
    try_end_16:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_6__source_iter );
    Py_DECREF( tmp_tuple_unpack_6__source_iter );
    tmp_tuple_unpack_6__source_iter = NULL;

    tmp_assign_source_36 = tmp_tuple_unpack_6__element_1;

    CHECK_OBJECT( tmp_assign_source_36 );
    {
        PyObject *old = var_s;
        var_s = tmp_assign_source_36;
        Py_INCREF( var_s );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_6__element_1 );
    tmp_tuple_unpack_6__element_1 = NULL;

    tmp_assign_source_37 = tmp_tuple_unpack_6__element_2;

    CHECK_OBJECT( tmp_assign_source_37 );
    {
        PyObject *old = var_e;
        var_e = tmp_assign_source_37;
        Py_INCREF( var_e );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_6__element_2 );
    tmp_tuple_unpack_6__element_2 = NULL;

    tmp_assign_source_38 = tmp_tuple_unpack_6__element_3;

    CHECK_OBJECT( tmp_assign_source_38 );
    {
        PyObject *old = var_cid;
        var_cid = tmp_assign_source_38;
        Py_INCREF( var_cid );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_6__element_3 );
    tmp_tuple_unpack_6__element_3 = NULL;

    tmp_isinstance_inst_1 = var_s;

    CHECK_OBJECT( tmp_isinstance_inst_1 );
    tmp_isinstance_cls_1 = (PyObject *)&PyString_Type;
    tmp_operand_name_1 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_1, tmp_isinstance_cls_1 );
    if ( tmp_operand_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 349;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_value_1 = UNARY_OPERATION( UNARY_NOT, tmp_operand_name_1 );
    if ( tmp_or_left_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 349;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_truth_1 = CHECK_IF_TRUE( tmp_or_left_value_1 );
    if ( tmp_or_left_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    if ( tmp_or_left_truth_1 == 1 )
    {
        goto or_left_1;
    }
    else
    {
        goto or_right_1;
    }
    or_right_1:;
    tmp_isinstance_inst_2 = var_e;

    CHECK_OBJECT( tmp_isinstance_inst_2 );
    tmp_isinstance_cls_2 = (PyObject *)&PyString_Type;
    tmp_operand_name_2 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_2, tmp_isinstance_cls_2 );
    if ( tmp_operand_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 349;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_value_2 = UNARY_OPERATION( UNARY_NOT, tmp_operand_name_2 );
    if ( tmp_or_left_value_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 349;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_truth_2 = CHECK_IF_TRUE( tmp_or_left_value_2 );
    if ( tmp_or_left_truth_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    if ( tmp_or_left_truth_2 == 1 )
    {
        goto or_left_2;
    }
    else
    {
        goto or_right_2;
    }
    or_right_2:;
    tmp_isinstance_inst_3 = var_cid;

    CHECK_OBJECT( tmp_isinstance_inst_3 );
    tmp_isinstance_cls_3 = (PyObject *)&PyInt_Type;
    tmp_operand_name_3 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_3, tmp_isinstance_cls_3 );
    if ( tmp_operand_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_value_3 = UNARY_OPERATION( UNARY_NOT, tmp_operand_name_3 );
    if ( tmp_or_left_value_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_left_truth_3 = CHECK_IF_TRUE( tmp_or_left_value_3 );
    if ( tmp_or_left_truth_3 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    if ( tmp_or_left_truth_3 == 1 )
    {
        goto or_left_3;
    }
    else
    {
        goto or_right_3;
    }
    or_right_3:;
    tmp_len_arg_1 = var_s;

    CHECK_OBJECT( tmp_len_arg_1 );
    tmp_compexpr_left_1 = BUILTIN_LEN( tmp_len_arg_1 );
    if ( tmp_compexpr_left_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_len_arg_2 = var_e;

    CHECK_OBJECT( tmp_len_arg_2 );
    tmp_compexpr_right_1 = BUILTIN_LEN( tmp_len_arg_2 );
    if ( tmp_compexpr_right_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_compexpr_left_1 );

        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_right_value_3 = RICH_COMPARE_NE( tmp_compexpr_left_1, tmp_compexpr_right_1 );
    Py_DECREF( tmp_compexpr_left_1 );
    Py_DECREF( tmp_compexpr_right_1 );
    if ( tmp_or_right_value_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_or_right_value_2 = tmp_or_right_value_3;
    goto or_end_3;
    or_left_3:;
    Py_INCREF( tmp_or_left_value_3 );
    tmp_or_right_value_2 = tmp_or_left_value_3;
    or_end_3:;
    tmp_or_right_value_1 = tmp_or_right_value_2;
    goto or_end_2;
    or_left_2:;
    Py_INCREF( tmp_or_left_value_2 );
    tmp_or_right_value_1 = tmp_or_left_value_2;
    or_end_2:;
    tmp_cond_value_2 = tmp_or_right_value_1;
    goto or_end_1;
    or_left_1:;
    Py_INCREF( tmp_or_left_value_1 );
    tmp_cond_value_2 = tmp_or_left_value_1;
    or_end_1:;
    tmp_cond_truth_2 = CHECK_IF_TRUE( tmp_cond_value_2 );
    if ( tmp_cond_truth_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_2 );

        exception_lineno = 350;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    Py_DECREF( tmp_cond_value_2 );
    if ( tmp_cond_truth_2 == 1 )
    {
        goto branch_yes_13;
    }
    else
    {
        goto branch_no_13;
    }
    branch_yes_13:;
    goto loop_start_2;
    branch_no_13:;
    tmp_sliceslicedel_index_lower_1 = 0;
    tmp_slice_index_upper_1 = -4;
    tmp_slice_source_1 = var_s;

    CHECK_OBJECT( tmp_slice_source_1 );
    tmp_assign_source_39 = LOOKUP_INDEX_SLICE( tmp_slice_source_1, tmp_sliceslicedel_index_lower_1, tmp_slice_index_upper_1 );
    if ( tmp_assign_source_39 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 352;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_sprefix;
        var_sprefix = tmp_assign_source_39;
        Py_XDECREF( old );
    }

    tmp_sliceslicedel_index_lower_2 = 0;
    tmp_slice_index_upper_2 = -4;
    tmp_slice_source_2 = var_e;

    CHECK_OBJECT( tmp_slice_source_2 );
    tmp_assign_source_40 = LOOKUP_INDEX_SLICE( tmp_slice_source_2, tmp_sliceslicedel_index_lower_2, tmp_slice_index_upper_2 );
    if ( tmp_assign_source_40 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 353;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_eprefix;
        var_eprefix = tmp_assign_source_40;
        Py_XDECREF( old );
    }

    tmp_compare_left_12 = var_sprefix;

    CHECK_OBJECT( tmp_compare_left_12 );
    tmp_compare_right_12 = var_eprefix;

    CHECK_OBJECT( tmp_compare_right_12 );
    tmp_cmp_NotEq_1 = RICH_COMPARE_BOOL_NE( tmp_compare_left_12, tmp_compare_right_12 );
    if ( tmp_cmp_NotEq_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 354;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    if ( tmp_cmp_NotEq_1 == 1 )
    {
        goto branch_yes_14;
    }
    else
    {
        goto branch_no_14;
    }
    branch_yes_14:;
    goto loop_start_2;
    branch_no_14:;
    tmp_sliceslicedel_index_lower_3 = -4;
    tmp_slice_index_upper_3 = PY_SSIZE_T_MAX;
    tmp_slice_source_3 = var_s;

    CHECK_OBJECT( tmp_slice_source_3 );
    tmp_assign_source_41 = LOOKUP_INDEX_SLICE( tmp_slice_source_3, tmp_sliceslicedel_index_lower_3, tmp_slice_index_upper_3 );
    if ( tmp_assign_source_41 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 356;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_svar;
        var_svar = tmp_assign_source_41;
        Py_XDECREF( old );
    }

    tmp_sliceslicedel_index_lower_4 = -4;
    tmp_slice_index_upper_4 = PY_SSIZE_T_MAX;
    tmp_slice_source_4 = var_e;

    CHECK_OBJECT( tmp_slice_source_4 );
    tmp_assign_source_42 = LOOKUP_INDEX_SLICE( tmp_slice_source_4, tmp_sliceslicedel_index_lower_4, tmp_slice_index_upper_4 );
    if ( tmp_assign_source_42 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 357;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_evar;
        var_evar = tmp_assign_source_42;
        Py_XDECREF( old );
    }

    tmp_called_name_7 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_7 == NULL ))
    {
        tmp_called_name_7 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_7 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 358;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }

    tmp_args_element_name_9 = var_svar;

    CHECK_OBJECT( tmp_args_element_name_9 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 358;
    {
        PyObject *call_args[] = { tmp_args_element_name_9 };
        tmp_assign_source_43 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_7, call_args );
    }

    if ( tmp_assign_source_43 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 358;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_s1;
        var_s1 = tmp_assign_source_43;
        Py_XDECREF( old );
    }

    tmp_called_name_8 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_8 == NULL ))
    {
        tmp_called_name_8 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_8 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 359;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }

    tmp_args_element_name_10 = var_evar;

    CHECK_OBJECT( tmp_args_element_name_10 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 359;
    {
        PyObject *call_args[] = { tmp_args_element_name_10 };
        tmp_assign_source_44 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_8, call_args );
    }

    if ( tmp_assign_source_44 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 359;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_e1;
        var_e1 = tmp_assign_source_44;
        Py_XDECREF( old );
    }

    tmp_len_arg_3 = var_svar;

    CHECK_OBJECT( tmp_len_arg_3 );
    tmp_assign_source_45 = BUILTIN_LEN( tmp_len_arg_3 );
    if ( tmp_assign_source_45 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 360;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = var_vlen;
        var_vlen = tmp_assign_source_45;
        Py_XDECREF( old );
    }

    tmp_left_name_2 = var_e1;

    CHECK_OBJECT( tmp_left_name_2 );
    tmp_right_name_1 = var_s1;

    CHECK_OBJECT( tmp_right_name_1 );
    tmp_left_name_1 = BINARY_OPERATION_SUB( tmp_left_name_2, tmp_right_name_1 );
    if ( tmp_left_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 362;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_right_name_2 = const_int_pos_1;
    tmp_xrange_low_1 = BINARY_OPERATION_ADD( tmp_left_name_1, tmp_right_name_2 );
    Py_DECREF( tmp_left_name_1 );
    if ( tmp_xrange_low_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 362;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_iter_arg_10 = BUILTIN_XRANGE1( tmp_xrange_low_1 );
    Py_DECREF( tmp_xrange_low_1 );
    if ( tmp_iter_arg_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 362;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    tmp_assign_source_46 = MAKE_ITERATOR( tmp_iter_arg_10 );
    Py_DECREF( tmp_iter_arg_10 );
    if ( tmp_assign_source_46 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 362;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    {
        PyObject *old = tmp_for_loop_2__for_iterator;
        tmp_for_loop_2__for_iterator = tmp_assign_source_46;
        Py_XDECREF( old );
    }

    // Tried code:
    loop_start_3:;
    tmp_next_source_3 = tmp_for_loop_2__for_iterator;

    CHECK_OBJECT( tmp_next_source_3 );
    tmp_assign_source_47 = ITERATOR_NEXT( tmp_next_source_3 );
    if ( tmp_assign_source_47 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_3;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 362;
            goto try_except_handler_20;
        }
    }

    {
        PyObject *old = tmp_for_loop_2__iter_value;
        tmp_for_loop_2__iter_value = tmp_assign_source_47;
        Py_XDECREF( old );
    }

    tmp_assign_source_48 = tmp_for_loop_2__iter_value;

    CHECK_OBJECT( tmp_assign_source_48 );
    {
        PyObject *old = var_i;
        var_i = tmp_assign_source_48;
        Py_INCREF( var_i );
        Py_XDECREF( old );
    }

    tmp_left_name_3 = var_sprefix;

    CHECK_OBJECT( tmp_left_name_3 );
    tmp_source_name_16 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_struct );

    if (unlikely( tmp_source_name_16 == NULL ))
    {
        tmp_source_name_16 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_struct );
    }

    if ( tmp_source_name_16 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "struct" );
        exception_tb = NULL;

        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }

    tmp_called_name_9 = LOOKUP_ATTRIBUTE( tmp_source_name_16, const_str_plain_pack );
    if ( tmp_called_name_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_args_element_name_11 = const_str_digest_7532b9d7f11d8fedcf0f9e47d9f9d1da;
    tmp_left_name_4 = var_s1;

    CHECK_OBJECT( tmp_left_name_4 );
    tmp_right_name_4 = var_i;

    CHECK_OBJECT( tmp_right_name_4 );
    tmp_args_element_name_12 = BINARY_OPERATION_ADD( tmp_left_name_4, tmp_right_name_4 );
    if ( tmp_args_element_name_12 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_9 );

        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 363;
    {
        PyObject *call_args[] = { tmp_args_element_name_11, tmp_args_element_name_12 };
        tmp_slice_source_5 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_9, call_args );
    }

    Py_DECREF( tmp_called_name_9 );
    Py_DECREF( tmp_args_element_name_12 );
    if ( tmp_slice_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_operand_name_4 = var_vlen;

    CHECK_OBJECT( tmp_operand_name_4 );
    tmp_slice_lower_1 = UNARY_OPERATION( PyNumber_Negative, tmp_operand_name_4 );
    if ( tmp_slice_lower_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_slice_source_5 );

        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_right_name_3 = LOOKUP_SLICE( tmp_slice_source_5, tmp_slice_lower_1, Py_None );
    Py_DECREF( tmp_slice_source_5 );
    Py_DECREF( tmp_slice_lower_1 );
    if ( tmp_right_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_assign_source_49 = BINARY_OPERATION_ADD( tmp_left_name_3, tmp_right_name_3 );
    Py_DECREF( tmp_right_name_3 );
    if ( tmp_assign_source_49 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 363;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    {
        PyObject *old = var_x;
        var_x = tmp_assign_source_49;
        Py_XDECREF( old );
    }

    tmp_source_name_18 = par_self;

    CHECK_OBJECT( tmp_source_name_18 );
    tmp_source_name_17 = LOOKUP_ATTRIBUTE( tmp_source_name_18, const_str_plain_cmap );
    if ( tmp_source_name_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 364;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_called_name_10 = LOOKUP_ATTRIBUTE( tmp_source_name_17, const_str_plain_add_code2cid );
    Py_DECREF( tmp_source_name_17 );
    if ( tmp_called_name_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 364;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    tmp_args_element_name_13 = var_x;

    CHECK_OBJECT( tmp_args_element_name_13 );
    tmp_left_name_5 = var_cid;

    CHECK_OBJECT( tmp_left_name_5 );
    tmp_right_name_5 = var_i;

    CHECK_OBJECT( tmp_right_name_5 );
    tmp_args_element_name_14 = BINARY_OPERATION_ADD( tmp_left_name_5, tmp_right_name_5 );
    if ( tmp_args_element_name_14 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_10 );

        exception_lineno = 364;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 364;
    {
        PyObject *call_args[] = { tmp_args_element_name_13, tmp_args_element_name_14 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_10, call_args );
    }

    Py_DECREF( tmp_called_name_10 );
    Py_DECREF( tmp_args_element_name_14 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 364;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 362;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_20;
    }
    goto loop_start_3;
    loop_end_3:;
    goto try_end_17;
    // Exception handler code:
    try_except_handler_20:;
    exception_keeper_type_18 = exception_type;
    exception_keeper_value_18 = exception_value;
    exception_keeper_tb_18 = exception_tb;
    exception_keeper_lineno_18 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_2__iter_value );
    tmp_for_loop_2__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_2__for_iterator );
    Py_DECREF( tmp_for_loop_2__for_iterator );
    tmp_for_loop_2__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_18;
    exception_value = exception_keeper_value_18;
    exception_tb = exception_keeper_tb_18;
    exception_lineno = exception_keeper_lineno_18;

    goto try_except_handler_17;
    // End of try:
    try_end_17:;
    Py_XDECREF( tmp_for_loop_2__iter_value );
    tmp_for_loop_2__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_2__for_iterator );
    Py_DECREF( tmp_for_loop_2__for_iterator );
    tmp_for_loop_2__for_iterator = NULL;

    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 348;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_17;
    }
    goto loop_start_2;
    loop_end_2:;
    goto try_end_18;
    // Exception handler code:
    try_except_handler_17:;
    exception_keeper_type_19 = exception_type;
    exception_keeper_value_19 = exception_value;
    exception_keeper_tb_19 = exception_tb;
    exception_keeper_lineno_19 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_19;
    exception_value = exception_keeper_value_19;
    exception_tb = exception_keeper_tb_19;
    exception_lineno = exception_keeper_lineno_19;

    goto frame_exception_exit_1;
    // End of try:
    try_end_18:;
    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_12:;
    tmp_compare_left_13 = par_token;

    CHECK_OBJECT( tmp_compare_left_13 );
    tmp_source_name_19 = par_self;

    CHECK_OBJECT( tmp_source_name_19 );
    tmp_compare_right_13 = LOOKUP_ATTRIBUTE( tmp_source_name_19, const_str_plain_KEYWORD_BEGINCIDCHAR );
    if ( tmp_compare_right_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 367;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_9 = ( tmp_compare_left_13 == tmp_compare_right_13 );
    Py_DECREF( tmp_compare_right_13 );
    if ( tmp_is_9 )
    {
        goto branch_yes_15;
    }
    else
    {
        goto branch_no_15;
    }
    branch_yes_15:;
    tmp_called_instance_8 = par_self;

    CHECK_OBJECT( tmp_called_instance_8 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 368;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_8, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 368;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_15:;
    tmp_compare_left_14 = par_token;

    CHECK_OBJECT( tmp_compare_left_14 );
    tmp_source_name_20 = par_self;

    CHECK_OBJECT( tmp_source_name_20 );
    tmp_compare_right_14 = LOOKUP_ATTRIBUTE( tmp_source_name_20, const_str_plain_KEYWORD_ENDCIDCHAR );
    if ( tmp_compare_right_14 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 370;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_10 = ( tmp_compare_left_14 == tmp_compare_right_14 );
    Py_DECREF( tmp_compare_right_14 );
    if ( tmp_is_10 )
    {
        goto branch_yes_16;
    }
    else
    {
        goto branch_no_16;
    }
    branch_yes_16:;
    // Tried code:
    tmp_called_instance_9 = par_self;

    CHECK_OBJECT( tmp_called_instance_9 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 371;
    tmp_iter_arg_11 = CALL_METHOD_NO_ARGS( tmp_called_instance_9, const_str_plain_popall );
    if ( tmp_iter_arg_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 371;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_21;
    }
    tmp_assign_source_51 = MAKE_ITERATOR( tmp_iter_arg_11 );
    Py_DECREF( tmp_iter_arg_11 );
    if ( tmp_assign_source_51 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 371;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_21;
    }
    assert( tmp_list_contraction_2__$0 == NULL );
    tmp_list_contraction_2__$0 = tmp_assign_source_51;

    tmp_assign_source_52 = PyList_New( 0 );
    assert( tmp_list_contraction_2__contraction_result == NULL );
    tmp_list_contraction_2__contraction_result = tmp_assign_source_52;

    loop_start_4:;
    tmp_next_source_4 = tmp_list_contraction_2__$0;

    CHECK_OBJECT( tmp_next_source_4 );
    tmp_assign_source_53 = ITERATOR_NEXT( tmp_next_source_4 );
    if ( tmp_assign_source_53 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_4;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 371;
            goto try_except_handler_21;
        }
    }

    {
        PyObject *old = tmp_list_contraction_2__iter_value_0;
        tmp_list_contraction_2__iter_value_0 = tmp_assign_source_53;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_12 = tmp_list_contraction_2__iter_value_0;

    CHECK_OBJECT( tmp_iter_arg_12 );
    tmp_assign_source_54 = MAKE_ITERATOR( tmp_iter_arg_12 );
    if ( tmp_assign_source_54 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 371;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_22;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_2__source_iter;
        tmp_list_contraction$tuple_unpack_2__source_iter = tmp_assign_source_54;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_15 = tmp_list_contraction$tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_15 );
    tmp_assign_source_55 = UNPACK_NEXT( tmp_unpack_15, 0 );
    if ( tmp_assign_source_55 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 371;
        goto try_except_handler_23;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_2__element_1;
        tmp_list_contraction$tuple_unpack_2__element_1 = tmp_assign_source_55;
        Py_XDECREF( old );
    }

    tmp_unpack_16 = tmp_list_contraction$tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_16 );
    tmp_assign_source_56 = UNPACK_NEXT( tmp_unpack_16, 1 );
    if ( tmp_assign_source_56 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 371;
        goto try_except_handler_23;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_2__element_2;
        tmp_list_contraction$tuple_unpack_2__element_2 = tmp_assign_source_56;
        Py_XDECREF( old );
    }

    tmp_iterator_name_8 = tmp_list_contraction$tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_iterator_name_8 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_8 ); assert( HAS_ITERNEXT( tmp_iterator_name_8 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_8 )->tp_iternext)( tmp_iterator_name_8 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 371;
                goto try_except_handler_23;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 371;
        goto try_except_handler_23;
    }
    goto try_end_19;
    // Exception handler code:
    try_except_handler_23:;
    exception_keeper_type_20 = exception_type;
    exception_keeper_value_20 = exception_value;
    exception_keeper_tb_20 = exception_tb;
    exception_keeper_lineno_20 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_2__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_2__source_iter );
    tmp_list_contraction$tuple_unpack_2__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_20;
    exception_value = exception_keeper_value_20;
    exception_tb = exception_keeper_tb_20;
    exception_lineno = exception_keeper_lineno_20;

    goto try_except_handler_22;
    // End of try:
    try_end_19:;
    goto try_end_20;
    // Exception handler code:
    try_except_handler_22:;
    exception_keeper_type_21 = exception_type;
    exception_keeper_value_21 = exception_value;
    exception_keeper_tb_21 = exception_tb;
    exception_keeper_lineno_21 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_2__element_1 );
    tmp_list_contraction$tuple_unpack_2__element_1 = NULL;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_2__element_2 );
    tmp_list_contraction$tuple_unpack_2__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_21;
    exception_value = exception_keeper_value_21;
    exception_tb = exception_keeper_tb_21;
    exception_lineno = exception_keeper_lineno_21;

    goto try_except_handler_21;
    // End of try:
    try_end_20:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_2__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_2__source_iter );
    tmp_list_contraction$tuple_unpack_2__source_iter = NULL;

    tmp_assign_source_57 = tmp_list_contraction$tuple_unpack_2__element_1;

    CHECK_OBJECT( tmp_assign_source_57 );
    {
        PyObject *old = var___;
        var___ = tmp_assign_source_57;
        Py_INCREF( var___ );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_2__element_1 );
    tmp_list_contraction$tuple_unpack_2__element_1 = NULL;

    tmp_assign_source_58 = tmp_list_contraction$tuple_unpack_2__element_2;

    CHECK_OBJECT( tmp_assign_source_58 );
    {
        PyObject *old = var_obj;
        var_obj = tmp_assign_source_58;
        Py_INCREF( var_obj );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_2__element_2 );
    tmp_list_contraction$tuple_unpack_2__element_2 = NULL;

    tmp_append_list_2 = tmp_list_contraction_2__contraction_result;

    CHECK_OBJECT( tmp_append_list_2 );
    tmp_append_value_2 = var_obj;

    CHECK_OBJECT( tmp_append_value_2 );
    assert( PyList_Check( tmp_append_list_2 ) );
    tmp_res = PyList_Append( tmp_append_list_2, tmp_append_value_2 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 371;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_21;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 371;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_21;
    }
    goto loop_start_4;
    loop_end_4:;
    tmp_outline_return_value_2 = tmp_list_contraction_2__contraction_result;

    CHECK_OBJECT( tmp_outline_return_value_2 );
    Py_INCREF( tmp_outline_return_value_2 );
    goto try_return_handler_21;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // Return handler code:
    try_return_handler_21:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction_2__$0 );
    Py_DECREF( tmp_list_contraction_2__$0 );
    tmp_list_contraction_2__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_2__contraction_result );
    Py_DECREF( tmp_list_contraction_2__contraction_result );
    tmp_list_contraction_2__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_2__iter_value_0 );
    tmp_list_contraction_2__iter_value_0 = NULL;

    goto outline_result_2;
    // Exception handler code:
    try_except_handler_21:;
    exception_keeper_type_22 = exception_type;
    exception_keeper_value_22 = exception_value;
    exception_keeper_tb_22 = exception_tb;
    exception_keeper_lineno_22 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction_2__$0 );
    tmp_list_contraction_2__$0 = NULL;

    Py_XDECREF( tmp_list_contraction_2__contraction_result );
    tmp_list_contraction_2__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_2__iter_value_0 );
    tmp_list_contraction_2__iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_22;
    exception_value = exception_keeper_value_22;
    exception_tb = exception_keeper_tb_22;
    exception_lineno = exception_keeper_lineno_22;

    goto frame_exception_exit_1;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    outline_result_2:;
    tmp_assign_source_50 = tmp_outline_return_value_2;
    assert( var_objs == NULL );
    var_objs = tmp_assign_source_50;

    tmp_called_name_11 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_choplist );

    if (unlikely( tmp_called_name_11 == NULL ))
    {
        tmp_called_name_11 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_choplist );
    }

    if ( tmp_called_name_11 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "choplist" );
        exception_tb = NULL;

        exception_lineno = 372;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_15 = const_int_pos_2;
    tmp_args_element_name_16 = var_objs;

    CHECK_OBJECT( tmp_args_element_name_16 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 372;
    {
        PyObject *call_args[] = { tmp_args_element_name_15, tmp_args_element_name_16 };
        tmp_iter_arg_13 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_11, call_args );
    }

    if ( tmp_iter_arg_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 372;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_59 = MAKE_ITERATOR( tmp_iter_arg_13 );
    Py_DECREF( tmp_iter_arg_13 );
    if ( tmp_assign_source_59 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 372;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_3__for_iterator == NULL );
    tmp_for_loop_3__for_iterator = tmp_assign_source_59;

    // Tried code:
    loop_start_5:;
    tmp_next_source_5 = tmp_for_loop_3__for_iterator;

    CHECK_OBJECT( tmp_next_source_5 );
    tmp_assign_source_60 = ITERATOR_NEXT( tmp_next_source_5 );
    if ( tmp_assign_source_60 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_5;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 372;
            goto try_except_handler_24;
        }
    }

    {
        PyObject *old = tmp_for_loop_3__iter_value;
        tmp_for_loop_3__iter_value = tmp_assign_source_60;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_14 = tmp_for_loop_3__iter_value;

    CHECK_OBJECT( tmp_iter_arg_14 );
    tmp_assign_source_61 = MAKE_ITERATOR( tmp_iter_arg_14 );
    if ( tmp_assign_source_61 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 372;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_25;
    }
    {
        PyObject *old = tmp_tuple_unpack_7__source_iter;
        tmp_tuple_unpack_7__source_iter = tmp_assign_source_61;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_17 = tmp_tuple_unpack_7__source_iter;

    CHECK_OBJECT( tmp_unpack_17 );
    tmp_assign_source_62 = UNPACK_NEXT( tmp_unpack_17, 0 );
    if ( tmp_assign_source_62 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 372;
        goto try_except_handler_26;
    }
    {
        PyObject *old = tmp_tuple_unpack_7__element_1;
        tmp_tuple_unpack_7__element_1 = tmp_assign_source_62;
        Py_XDECREF( old );
    }

    tmp_unpack_18 = tmp_tuple_unpack_7__source_iter;

    CHECK_OBJECT( tmp_unpack_18 );
    tmp_assign_source_63 = UNPACK_NEXT( tmp_unpack_18, 1 );
    if ( tmp_assign_source_63 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 372;
        goto try_except_handler_26;
    }
    {
        PyObject *old = tmp_tuple_unpack_7__element_2;
        tmp_tuple_unpack_7__element_2 = tmp_assign_source_63;
        Py_XDECREF( old );
    }

    tmp_iterator_name_9 = tmp_tuple_unpack_7__source_iter;

    CHECK_OBJECT( tmp_iterator_name_9 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_9 ); assert( HAS_ITERNEXT( tmp_iterator_name_9 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_9 )->tp_iternext)( tmp_iterator_name_9 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 372;
                goto try_except_handler_26;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 372;
        goto try_except_handler_26;
    }
    goto try_end_21;
    // Exception handler code:
    try_except_handler_26:;
    exception_keeper_type_23 = exception_type;
    exception_keeper_value_23 = exception_value;
    exception_keeper_tb_23 = exception_tb;
    exception_keeper_lineno_23 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_7__source_iter );
    Py_DECREF( tmp_tuple_unpack_7__source_iter );
    tmp_tuple_unpack_7__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_23;
    exception_value = exception_keeper_value_23;
    exception_tb = exception_keeper_tb_23;
    exception_lineno = exception_keeper_lineno_23;

    goto try_except_handler_25;
    // End of try:
    try_end_21:;
    goto try_end_22;
    // Exception handler code:
    try_except_handler_25:;
    exception_keeper_type_24 = exception_type;
    exception_keeper_value_24 = exception_value;
    exception_keeper_tb_24 = exception_tb;
    exception_keeper_lineno_24 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_7__element_1 );
    tmp_tuple_unpack_7__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_7__element_2 );
    tmp_tuple_unpack_7__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_24;
    exception_value = exception_keeper_value_24;
    exception_tb = exception_keeper_tb_24;
    exception_lineno = exception_keeper_lineno_24;

    goto try_except_handler_24;
    // End of try:
    try_end_22:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_7__source_iter );
    Py_DECREF( tmp_tuple_unpack_7__source_iter );
    tmp_tuple_unpack_7__source_iter = NULL;

    tmp_assign_source_64 = tmp_tuple_unpack_7__element_1;

    CHECK_OBJECT( tmp_assign_source_64 );
    {
        PyObject *old = var_cid;
        var_cid = tmp_assign_source_64;
        Py_INCREF( var_cid );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_7__element_1 );
    tmp_tuple_unpack_7__element_1 = NULL;

    tmp_assign_source_65 = tmp_tuple_unpack_7__element_2;

    CHECK_OBJECT( tmp_assign_source_65 );
    {
        PyObject *old = var_code;
        var_code = tmp_assign_source_65;
        Py_INCREF( var_code );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_7__element_2 );
    tmp_tuple_unpack_7__element_2 = NULL;

    tmp_isinstance_inst_4 = var_code;

    CHECK_OBJECT( tmp_isinstance_inst_4 );
    tmp_isinstance_cls_4 = (PyObject *)&PyString_Type;
    tmp_and_left_value_1 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_4, tmp_isinstance_cls_4 );
    if ( tmp_and_left_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 373;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    tmp_and_left_truth_1 = CHECK_IF_TRUE( tmp_and_left_value_1 );
    if ( tmp_and_left_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 373;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    if ( tmp_and_left_truth_1 == 1 )
    {
        goto and_right_1;
    }
    else
    {
        goto and_left_1;
    }
    and_right_1:;
    tmp_isinstance_inst_5 = var_cid;

    CHECK_OBJECT( tmp_isinstance_inst_5 );
    tmp_isinstance_cls_5 = (PyObject *)&PyString_Type;
    tmp_and_right_value_1 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_5, tmp_isinstance_cls_5 );
    if ( tmp_and_right_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 373;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    tmp_cond_value_3 = tmp_and_right_value_1;
    goto and_end_1;
    and_left_1:;
    tmp_cond_value_3 = tmp_and_left_value_1;
    and_end_1:;
    tmp_cond_truth_3 = CHECK_IF_TRUE( tmp_cond_value_3 );
    if ( tmp_cond_truth_3 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 373;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    if ( tmp_cond_truth_3 == 1 )
    {
        goto branch_yes_17;
    }
    else
    {
        goto branch_no_17;
    }
    branch_yes_17:;
    tmp_source_name_22 = par_self;

    CHECK_OBJECT( tmp_source_name_22 );
    tmp_source_name_21 = LOOKUP_ATTRIBUTE( tmp_source_name_22, const_str_plain_cmap );
    if ( tmp_source_name_21 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 374;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    tmp_called_name_12 = LOOKUP_ATTRIBUTE( tmp_source_name_21, const_str_plain_add_code2cid );
    Py_DECREF( tmp_source_name_21 );
    if ( tmp_called_name_12 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 374;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    tmp_args_element_name_17 = var_code;

    CHECK_OBJECT( tmp_args_element_name_17 );
    tmp_called_name_13 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_13 == NULL ))
    {
        tmp_called_name_13 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_13 == NULL )
    {
        Py_DECREF( tmp_called_name_12 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 374;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }

    tmp_args_element_name_19 = var_cid;

    CHECK_OBJECT( tmp_args_element_name_19 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 374;
    {
        PyObject *call_args[] = { tmp_args_element_name_19 };
        tmp_args_element_name_18 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_13, call_args );
    }

    if ( tmp_args_element_name_18 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_12 );

        exception_lineno = 374;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 374;
    {
        PyObject *call_args[] = { tmp_args_element_name_17, tmp_args_element_name_18 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_12, call_args );
    }

    Py_DECREF( tmp_called_name_12 );
    Py_DECREF( tmp_args_element_name_18 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 374;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    Py_DECREF( tmp_unused );
    branch_no_17:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 372;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_24;
    }
    goto loop_start_5;
    loop_end_5:;
    goto try_end_23;
    // Exception handler code:
    try_except_handler_24:;
    exception_keeper_type_25 = exception_type;
    exception_keeper_value_25 = exception_value;
    exception_keeper_tb_25 = exception_tb;
    exception_keeper_lineno_25 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_3__iter_value );
    tmp_for_loop_3__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_3__for_iterator );
    Py_DECREF( tmp_for_loop_3__for_iterator );
    tmp_for_loop_3__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_25;
    exception_value = exception_keeper_value_25;
    exception_tb = exception_keeper_tb_25;
    exception_lineno = exception_keeper_lineno_25;

    goto frame_exception_exit_1;
    // End of try:
    try_end_23:;
    Py_XDECREF( tmp_for_loop_3__iter_value );
    tmp_for_loop_3__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_3__for_iterator );
    Py_DECREF( tmp_for_loop_3__for_iterator );
    tmp_for_loop_3__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_16:;
    tmp_compare_left_15 = par_token;

    CHECK_OBJECT( tmp_compare_left_15 );
    tmp_source_name_23 = par_self;

    CHECK_OBJECT( tmp_source_name_23 );
    tmp_compare_right_15 = LOOKUP_ATTRIBUTE( tmp_source_name_23, const_str_plain_KEYWORD_BEGINBFRANGE );
    if ( tmp_compare_right_15 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 377;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_11 = ( tmp_compare_left_15 == tmp_compare_right_15 );
    Py_DECREF( tmp_compare_right_15 );
    if ( tmp_is_11 )
    {
        goto branch_yes_18;
    }
    else
    {
        goto branch_no_18;
    }
    branch_yes_18:;
    tmp_called_instance_10 = par_self;

    CHECK_OBJECT( tmp_called_instance_10 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 378;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_10, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 378;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_18:;
    tmp_compare_left_16 = par_token;

    CHECK_OBJECT( tmp_compare_left_16 );
    tmp_source_name_24 = par_self;

    CHECK_OBJECT( tmp_source_name_24 );
    tmp_compare_right_16 = LOOKUP_ATTRIBUTE( tmp_source_name_24, const_str_plain_KEYWORD_ENDBFRANGE );
    if ( tmp_compare_right_16 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 380;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_12 = ( tmp_compare_left_16 == tmp_compare_right_16 );
    Py_DECREF( tmp_compare_right_16 );
    if ( tmp_is_12 )
    {
        goto branch_yes_19;
    }
    else
    {
        goto branch_no_19;
    }
    branch_yes_19:;
    // Tried code:
    tmp_called_instance_11 = par_self;

    CHECK_OBJECT( tmp_called_instance_11 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 381;
    tmp_iter_arg_15 = CALL_METHOD_NO_ARGS( tmp_called_instance_11, const_str_plain_popall );
    if ( tmp_iter_arg_15 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 381;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_27;
    }
    tmp_assign_source_67 = MAKE_ITERATOR( tmp_iter_arg_15 );
    Py_DECREF( tmp_iter_arg_15 );
    if ( tmp_assign_source_67 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 381;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_27;
    }
    assert( tmp_list_contraction_3__$0 == NULL );
    tmp_list_contraction_3__$0 = tmp_assign_source_67;

    tmp_assign_source_68 = PyList_New( 0 );
    assert( tmp_list_contraction_3__contraction_result == NULL );
    tmp_list_contraction_3__contraction_result = tmp_assign_source_68;

    loop_start_6:;
    tmp_next_source_6 = tmp_list_contraction_3__$0;

    CHECK_OBJECT( tmp_next_source_6 );
    tmp_assign_source_69 = ITERATOR_NEXT( tmp_next_source_6 );
    if ( tmp_assign_source_69 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_6;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 381;
            goto try_except_handler_27;
        }
    }

    {
        PyObject *old = tmp_list_contraction_3__iter_value_0;
        tmp_list_contraction_3__iter_value_0 = tmp_assign_source_69;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_16 = tmp_list_contraction_3__iter_value_0;

    CHECK_OBJECT( tmp_iter_arg_16 );
    tmp_assign_source_70 = MAKE_ITERATOR( tmp_iter_arg_16 );
    if ( tmp_assign_source_70 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 381;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_28;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_3__source_iter;
        tmp_list_contraction$tuple_unpack_3__source_iter = tmp_assign_source_70;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_19 = tmp_list_contraction$tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_unpack_19 );
    tmp_assign_source_71 = UNPACK_NEXT( tmp_unpack_19, 0 );
    if ( tmp_assign_source_71 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 381;
        goto try_except_handler_29;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_3__element_1;
        tmp_list_contraction$tuple_unpack_3__element_1 = tmp_assign_source_71;
        Py_XDECREF( old );
    }

    tmp_unpack_20 = tmp_list_contraction$tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_unpack_20 );
    tmp_assign_source_72 = UNPACK_NEXT( tmp_unpack_20, 1 );
    if ( tmp_assign_source_72 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 381;
        goto try_except_handler_29;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_3__element_2;
        tmp_list_contraction$tuple_unpack_3__element_2 = tmp_assign_source_72;
        Py_XDECREF( old );
    }

    tmp_iterator_name_10 = tmp_list_contraction$tuple_unpack_3__source_iter;

    CHECK_OBJECT( tmp_iterator_name_10 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_10 ); assert( HAS_ITERNEXT( tmp_iterator_name_10 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_10 )->tp_iternext)( tmp_iterator_name_10 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 381;
                goto try_except_handler_29;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 381;
        goto try_except_handler_29;
    }
    goto try_end_24;
    // Exception handler code:
    try_except_handler_29:;
    exception_keeper_type_26 = exception_type;
    exception_keeper_value_26 = exception_value;
    exception_keeper_tb_26 = exception_tb;
    exception_keeper_lineno_26 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_3__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_3__source_iter );
    tmp_list_contraction$tuple_unpack_3__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_26;
    exception_value = exception_keeper_value_26;
    exception_tb = exception_keeper_tb_26;
    exception_lineno = exception_keeper_lineno_26;

    goto try_except_handler_28;
    // End of try:
    try_end_24:;
    goto try_end_25;
    // Exception handler code:
    try_except_handler_28:;
    exception_keeper_type_27 = exception_type;
    exception_keeper_value_27 = exception_value;
    exception_keeper_tb_27 = exception_tb;
    exception_keeper_lineno_27 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_3__element_1 );
    tmp_list_contraction$tuple_unpack_3__element_1 = NULL;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_3__element_2 );
    tmp_list_contraction$tuple_unpack_3__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_27;
    exception_value = exception_keeper_value_27;
    exception_tb = exception_keeper_tb_27;
    exception_lineno = exception_keeper_lineno_27;

    goto try_except_handler_27;
    // End of try:
    try_end_25:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_3__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_3__source_iter );
    tmp_list_contraction$tuple_unpack_3__source_iter = NULL;

    tmp_assign_source_73 = tmp_list_contraction$tuple_unpack_3__element_1;

    CHECK_OBJECT( tmp_assign_source_73 );
    {
        PyObject *old = var___;
        var___ = tmp_assign_source_73;
        Py_INCREF( var___ );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_3__element_1 );
    tmp_list_contraction$tuple_unpack_3__element_1 = NULL;

    tmp_assign_source_74 = tmp_list_contraction$tuple_unpack_3__element_2;

    CHECK_OBJECT( tmp_assign_source_74 );
    {
        PyObject *old = var_obj;
        var_obj = tmp_assign_source_74;
        Py_INCREF( var_obj );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_3__element_2 );
    tmp_list_contraction$tuple_unpack_3__element_2 = NULL;

    tmp_append_list_3 = tmp_list_contraction_3__contraction_result;

    CHECK_OBJECT( tmp_append_list_3 );
    tmp_append_value_3 = var_obj;

    CHECK_OBJECT( tmp_append_value_3 );
    assert( PyList_Check( tmp_append_list_3 ) );
    tmp_res = PyList_Append( tmp_append_list_3, tmp_append_value_3 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 381;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_27;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 381;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_27;
    }
    goto loop_start_6;
    loop_end_6:;
    tmp_outline_return_value_3 = tmp_list_contraction_3__contraction_result;

    CHECK_OBJECT( tmp_outline_return_value_3 );
    Py_INCREF( tmp_outline_return_value_3 );
    goto try_return_handler_27;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // Return handler code:
    try_return_handler_27:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction_3__$0 );
    Py_DECREF( tmp_list_contraction_3__$0 );
    tmp_list_contraction_3__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_3__contraction_result );
    Py_DECREF( tmp_list_contraction_3__contraction_result );
    tmp_list_contraction_3__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_3__iter_value_0 );
    tmp_list_contraction_3__iter_value_0 = NULL;

    goto outline_result_3;
    // Exception handler code:
    try_except_handler_27:;
    exception_keeper_type_28 = exception_type;
    exception_keeper_value_28 = exception_value;
    exception_keeper_tb_28 = exception_tb;
    exception_keeper_lineno_28 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction_3__$0 );
    tmp_list_contraction_3__$0 = NULL;

    Py_XDECREF( tmp_list_contraction_3__contraction_result );
    tmp_list_contraction_3__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_3__iter_value_0 );
    tmp_list_contraction_3__iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_28;
    exception_value = exception_keeper_value_28;
    exception_tb = exception_keeper_tb_28;
    exception_lineno = exception_keeper_lineno_28;

    goto frame_exception_exit_1;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    outline_result_3:;
    tmp_assign_source_66 = tmp_outline_return_value_3;
    assert( var_objs == NULL );
    var_objs = tmp_assign_source_66;

    tmp_called_name_14 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_choplist );

    if (unlikely( tmp_called_name_14 == NULL ))
    {
        tmp_called_name_14 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_choplist );
    }

    if ( tmp_called_name_14 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "choplist" );
        exception_tb = NULL;

        exception_lineno = 382;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_20 = const_int_pos_3;
    tmp_args_element_name_21 = var_objs;

    CHECK_OBJECT( tmp_args_element_name_21 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 382;
    {
        PyObject *call_args[] = { tmp_args_element_name_20, tmp_args_element_name_21 };
        tmp_iter_arg_17 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_14, call_args );
    }

    if ( tmp_iter_arg_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 382;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_75 = MAKE_ITERATOR( tmp_iter_arg_17 );
    Py_DECREF( tmp_iter_arg_17 );
    if ( tmp_assign_source_75 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 382;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_4__for_iterator == NULL );
    tmp_for_loop_4__for_iterator = tmp_assign_source_75;

    // Tried code:
    loop_start_7:;
    tmp_next_source_7 = tmp_for_loop_4__for_iterator;

    CHECK_OBJECT( tmp_next_source_7 );
    tmp_assign_source_76 = ITERATOR_NEXT( tmp_next_source_7 );
    if ( tmp_assign_source_76 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_7;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 382;
            goto try_except_handler_30;
        }
    }

    {
        PyObject *old = tmp_for_loop_4__iter_value;
        tmp_for_loop_4__iter_value = tmp_assign_source_76;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_18 = tmp_for_loop_4__iter_value;

    CHECK_OBJECT( tmp_iter_arg_18 );
    tmp_assign_source_77 = MAKE_ITERATOR( tmp_iter_arg_18 );
    if ( tmp_assign_source_77 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 382;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_31;
    }
    {
        PyObject *old = tmp_tuple_unpack_8__source_iter;
        tmp_tuple_unpack_8__source_iter = tmp_assign_source_77;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_21 = tmp_tuple_unpack_8__source_iter;

    CHECK_OBJECT( tmp_unpack_21 );
    tmp_assign_source_78 = UNPACK_NEXT( tmp_unpack_21, 0 );
    if ( tmp_assign_source_78 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 382;
        goto try_except_handler_32;
    }
    {
        PyObject *old = tmp_tuple_unpack_8__element_1;
        tmp_tuple_unpack_8__element_1 = tmp_assign_source_78;
        Py_XDECREF( old );
    }

    tmp_unpack_22 = tmp_tuple_unpack_8__source_iter;

    CHECK_OBJECT( tmp_unpack_22 );
    tmp_assign_source_79 = UNPACK_NEXT( tmp_unpack_22, 1 );
    if ( tmp_assign_source_79 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 382;
        goto try_except_handler_32;
    }
    {
        PyObject *old = tmp_tuple_unpack_8__element_2;
        tmp_tuple_unpack_8__element_2 = tmp_assign_source_79;
        Py_XDECREF( old );
    }

    tmp_unpack_23 = tmp_tuple_unpack_8__source_iter;

    CHECK_OBJECT( tmp_unpack_23 );
    tmp_assign_source_80 = UNPACK_NEXT( tmp_unpack_23, 2 );
    if ( tmp_assign_source_80 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 382;
        goto try_except_handler_32;
    }
    {
        PyObject *old = tmp_tuple_unpack_8__element_3;
        tmp_tuple_unpack_8__element_3 = tmp_assign_source_80;
        Py_XDECREF( old );
    }

    tmp_iterator_name_11 = tmp_tuple_unpack_8__source_iter;

    CHECK_OBJECT( tmp_iterator_name_11 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_11 ); assert( HAS_ITERNEXT( tmp_iterator_name_11 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_11 )->tp_iternext)( tmp_iterator_name_11 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 382;
                goto try_except_handler_32;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 3)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 382;
        goto try_except_handler_32;
    }
    goto try_end_26;
    // Exception handler code:
    try_except_handler_32:;
    exception_keeper_type_29 = exception_type;
    exception_keeper_value_29 = exception_value;
    exception_keeper_tb_29 = exception_tb;
    exception_keeper_lineno_29 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_8__source_iter );
    Py_DECREF( tmp_tuple_unpack_8__source_iter );
    tmp_tuple_unpack_8__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_29;
    exception_value = exception_keeper_value_29;
    exception_tb = exception_keeper_tb_29;
    exception_lineno = exception_keeper_lineno_29;

    goto try_except_handler_31;
    // End of try:
    try_end_26:;
    goto try_end_27;
    // Exception handler code:
    try_except_handler_31:;
    exception_keeper_type_30 = exception_type;
    exception_keeper_value_30 = exception_value;
    exception_keeper_tb_30 = exception_tb;
    exception_keeper_lineno_30 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_8__element_1 );
    tmp_tuple_unpack_8__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_8__element_2 );
    tmp_tuple_unpack_8__element_2 = NULL;

    Py_XDECREF( tmp_tuple_unpack_8__element_3 );
    tmp_tuple_unpack_8__element_3 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_30;
    exception_value = exception_keeper_value_30;
    exception_tb = exception_keeper_tb_30;
    exception_lineno = exception_keeper_lineno_30;

    goto try_except_handler_30;
    // End of try:
    try_end_27:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_8__source_iter );
    Py_DECREF( tmp_tuple_unpack_8__source_iter );
    tmp_tuple_unpack_8__source_iter = NULL;

    tmp_assign_source_81 = tmp_tuple_unpack_8__element_1;

    CHECK_OBJECT( tmp_assign_source_81 );
    {
        PyObject *old = var_s;
        var_s = tmp_assign_source_81;
        Py_INCREF( var_s );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_8__element_1 );
    tmp_tuple_unpack_8__element_1 = NULL;

    tmp_assign_source_82 = tmp_tuple_unpack_8__element_2;

    CHECK_OBJECT( tmp_assign_source_82 );
    {
        PyObject *old = var_e;
        var_e = tmp_assign_source_82;
        Py_INCREF( var_e );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_8__element_2 );
    tmp_tuple_unpack_8__element_2 = NULL;

    tmp_assign_source_83 = tmp_tuple_unpack_8__element_3;

    CHECK_OBJECT( tmp_assign_source_83 );
    {
        PyObject *old = var_code;
        var_code = tmp_assign_source_83;
        Py_INCREF( var_code );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_8__element_3 );
    tmp_tuple_unpack_8__element_3 = NULL;

    tmp_isinstance_inst_6 = var_s;

    CHECK_OBJECT( tmp_isinstance_inst_6 );
    tmp_isinstance_cls_6 = (PyObject *)&PyString_Type;
    tmp_operand_name_5 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_6, tmp_isinstance_cls_6 );
    if ( tmp_operand_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 383;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_left_value_4 = UNARY_OPERATION( UNARY_NOT, tmp_operand_name_5 );
    if ( tmp_or_left_value_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 383;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_left_truth_4 = CHECK_IF_TRUE( tmp_or_left_value_4 );
    if ( tmp_or_left_truth_4 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    if ( tmp_or_left_truth_4 == 1 )
    {
        goto or_left_4;
    }
    else
    {
        goto or_right_4;
    }
    or_right_4:;
    tmp_isinstance_inst_7 = var_e;

    CHECK_OBJECT( tmp_isinstance_inst_7 );
    tmp_isinstance_cls_7 = (PyObject *)&PyString_Type;
    tmp_operand_name_6 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_7, tmp_isinstance_cls_7 );
    if ( tmp_operand_name_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 383;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_left_value_5 = UNARY_OPERATION( UNARY_NOT, tmp_operand_name_6 );
    if ( tmp_or_left_value_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 383;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_left_truth_5 = CHECK_IF_TRUE( tmp_or_left_value_5 );
    if ( tmp_or_left_truth_5 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    if ( tmp_or_left_truth_5 == 1 )
    {
        goto or_left_5;
    }
    else
    {
        goto or_right_5;
    }
    or_right_5:;
    tmp_len_arg_4 = var_s;

    CHECK_OBJECT( tmp_len_arg_4 );
    tmp_compexpr_left_2 = BUILTIN_LEN( tmp_len_arg_4 );
    if ( tmp_compexpr_left_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_len_arg_5 = var_e;

    CHECK_OBJECT( tmp_len_arg_5 );
    tmp_compexpr_right_2 = BUILTIN_LEN( tmp_len_arg_5 );
    if ( tmp_compexpr_right_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_compexpr_left_2 );

        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_right_value_5 = RICH_COMPARE_NE( tmp_compexpr_left_2, tmp_compexpr_right_2 );
    Py_DECREF( tmp_compexpr_left_2 );
    Py_DECREF( tmp_compexpr_right_2 );
    if ( tmp_or_right_value_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_or_right_value_4 = tmp_or_right_value_5;
    goto or_end_5;
    or_left_5:;
    Py_INCREF( tmp_or_left_value_5 );
    tmp_or_right_value_4 = tmp_or_left_value_5;
    or_end_5:;
    tmp_cond_value_4 = tmp_or_right_value_4;
    goto or_end_4;
    or_left_4:;
    Py_INCREF( tmp_or_left_value_4 );
    tmp_cond_value_4 = tmp_or_left_value_4;
    or_end_4:;
    tmp_cond_truth_4 = CHECK_IF_TRUE( tmp_cond_value_4 );
    if ( tmp_cond_truth_4 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_4 );

        exception_lineno = 384;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    Py_DECREF( tmp_cond_value_4 );
    if ( tmp_cond_truth_4 == 1 )
    {
        goto branch_yes_20;
    }
    else
    {
        goto branch_no_20;
    }
    branch_yes_20:;
    goto loop_start_7;
    branch_no_20:;
    tmp_called_name_15 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_15 == NULL ))
    {
        tmp_called_name_15 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_15 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 386;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }

    tmp_args_element_name_22 = var_s;

    CHECK_OBJECT( tmp_args_element_name_22 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 386;
    {
        PyObject *call_args[] = { tmp_args_element_name_22 };
        tmp_assign_source_84 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_15, call_args );
    }

    if ( tmp_assign_source_84 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 386;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_s1;
        var_s1 = tmp_assign_source_84;
        Py_XDECREF( old );
    }

    tmp_called_name_16 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_16 == NULL ))
    {
        tmp_called_name_16 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_16 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 387;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }

    tmp_args_element_name_23 = var_e;

    CHECK_OBJECT( tmp_args_element_name_23 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 387;
    {
        PyObject *call_args[] = { tmp_args_element_name_23 };
        tmp_assign_source_85 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_16, call_args );
    }

    if ( tmp_assign_source_85 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 387;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_e1;
        var_e1 = tmp_assign_source_85;
        Py_XDECREF( old );
    }

    tmp_isinstance_inst_8 = var_code;

    CHECK_OBJECT( tmp_isinstance_inst_8 );
    tmp_isinstance_cls_8 = (PyObject *)&PyList_Type;
    tmp_res = Nuitka_IsInstance( tmp_isinstance_inst_8, tmp_isinstance_cls_8 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 389;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    if ( tmp_res == 1 )
    {
        goto branch_yes_21;
    }
    else
    {
        goto branch_no_21;
    }
    branch_yes_21:;
    tmp_left_name_7 = var_e1;

    CHECK_OBJECT( tmp_left_name_7 );
    tmp_right_name_6 = var_s1;

    CHECK_OBJECT( tmp_right_name_6 );
    tmp_left_name_6 = BINARY_OPERATION_SUB( tmp_left_name_7, tmp_right_name_6 );
    if ( tmp_left_name_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 390;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_right_name_7 = const_int_pos_1;
    tmp_xrange_low_2 = BINARY_OPERATION_ADD( tmp_left_name_6, tmp_right_name_7 );
    Py_DECREF( tmp_left_name_6 );
    if ( tmp_xrange_low_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 390;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_iter_arg_19 = BUILTIN_XRANGE1( tmp_xrange_low_2 );
    Py_DECREF( tmp_xrange_low_2 );
    if ( tmp_iter_arg_19 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 390;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_assign_source_86 = MAKE_ITERATOR( tmp_iter_arg_19 );
    Py_DECREF( tmp_iter_arg_19 );
    if ( tmp_assign_source_86 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 390;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = tmp_for_loop_5__for_iterator;
        tmp_for_loop_5__for_iterator = tmp_assign_source_86;
        Py_XDECREF( old );
    }

    // Tried code:
    loop_start_8:;
    tmp_next_source_8 = tmp_for_loop_5__for_iterator;

    CHECK_OBJECT( tmp_next_source_8 );
    tmp_assign_source_87 = ITERATOR_NEXT( tmp_next_source_8 );
    if ( tmp_assign_source_87 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_8;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 390;
            goto try_except_handler_33;
        }
    }

    {
        PyObject *old = tmp_for_loop_5__iter_value;
        tmp_for_loop_5__iter_value = tmp_assign_source_87;
        Py_XDECREF( old );
    }

    tmp_assign_source_88 = tmp_for_loop_5__iter_value;

    CHECK_OBJECT( tmp_assign_source_88 );
    {
        PyObject *old = var_i;
        var_i = tmp_assign_source_88;
        Py_INCREF( var_i );
        Py_XDECREF( old );
    }

    tmp_source_name_26 = par_self;

    CHECK_OBJECT( tmp_source_name_26 );
    tmp_source_name_25 = LOOKUP_ATTRIBUTE( tmp_source_name_26, const_str_plain_cmap );
    if ( tmp_source_name_25 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 391;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    tmp_called_name_17 = LOOKUP_ATTRIBUTE( tmp_source_name_25, const_str_plain_add_cid2unichr );
    Py_DECREF( tmp_source_name_25 );
    if ( tmp_called_name_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 391;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    tmp_left_name_8 = var_s1;

    CHECK_OBJECT( tmp_left_name_8 );
    tmp_right_name_8 = var_i;

    CHECK_OBJECT( tmp_right_name_8 );
    tmp_args_element_name_24 = BINARY_OPERATION_ADD( tmp_left_name_8, tmp_right_name_8 );
    if ( tmp_args_element_name_24 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_17 );

        exception_lineno = 391;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    tmp_subscribed_name_1 = var_code;

    CHECK_OBJECT( tmp_subscribed_name_1 );
    tmp_subscript_name_1 = var_i;

    CHECK_OBJECT( tmp_subscript_name_1 );
    tmp_args_element_name_25 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    if ( tmp_args_element_name_25 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_17 );
        Py_DECREF( tmp_args_element_name_24 );

        exception_lineno = 391;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 391;
    {
        PyObject *call_args[] = { tmp_args_element_name_24, tmp_args_element_name_25 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_17, call_args );
    }

    Py_DECREF( tmp_called_name_17 );
    Py_DECREF( tmp_args_element_name_24 );
    Py_DECREF( tmp_args_element_name_25 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 391;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 390;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_33;
    }
    goto loop_start_8;
    loop_end_8:;
    goto try_end_28;
    // Exception handler code:
    try_except_handler_33:;
    exception_keeper_type_31 = exception_type;
    exception_keeper_value_31 = exception_value;
    exception_keeper_tb_31 = exception_tb;
    exception_keeper_lineno_31 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_5__iter_value );
    tmp_for_loop_5__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_5__for_iterator );
    Py_DECREF( tmp_for_loop_5__for_iterator );
    tmp_for_loop_5__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_31;
    exception_value = exception_keeper_value_31;
    exception_tb = exception_keeper_tb_31;
    exception_lineno = exception_keeper_lineno_31;

    goto try_except_handler_30;
    // End of try:
    try_end_28:;
    Py_XDECREF( tmp_for_loop_5__iter_value );
    tmp_for_loop_5__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_5__for_iterator );
    Py_DECREF( tmp_for_loop_5__for_iterator );
    tmp_for_loop_5__for_iterator = NULL;

    goto branch_end_21;
    branch_no_21:;
    tmp_sliceslicedel_index_lower_5 = -4;
    tmp_slice_index_upper_5 = PY_SSIZE_T_MAX;
    tmp_slice_source_6 = var_code;

    CHECK_OBJECT( tmp_slice_source_6 );
    tmp_assign_source_89 = LOOKUP_INDEX_SLICE( tmp_slice_source_6, tmp_sliceslicedel_index_lower_5, tmp_slice_index_upper_5 );
    if ( tmp_assign_source_89 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 393;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_var;
        var_var = tmp_assign_source_89;
        Py_XDECREF( old );
    }

    tmp_called_name_18 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_18 == NULL ))
    {
        tmp_called_name_18 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_18 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 394;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }

    tmp_args_element_name_26 = var_var;

    CHECK_OBJECT( tmp_args_element_name_26 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 394;
    {
        PyObject *call_args[] = { tmp_args_element_name_26 };
        tmp_assign_source_90 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_18, call_args );
    }

    if ( tmp_assign_source_90 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 394;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_base;
        var_base = tmp_assign_source_90;
        Py_XDECREF( old );
    }

    tmp_sliceslicedel_index_lower_6 = 0;
    tmp_slice_index_upper_6 = -4;
    tmp_slice_source_7 = var_code;

    CHECK_OBJECT( tmp_slice_source_7 );
    tmp_assign_source_91 = LOOKUP_INDEX_SLICE( tmp_slice_source_7, tmp_sliceslicedel_index_lower_6, tmp_slice_index_upper_6 );
    if ( tmp_assign_source_91 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 395;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_prefix;
        var_prefix = tmp_assign_source_91;
        Py_XDECREF( old );
    }

    tmp_len_arg_6 = var_var;

    CHECK_OBJECT( tmp_len_arg_6 );
    tmp_assign_source_92 = BUILTIN_LEN( tmp_len_arg_6 );
    if ( tmp_assign_source_92 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 396;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = var_vlen;
        var_vlen = tmp_assign_source_92;
        Py_XDECREF( old );
    }

    tmp_left_name_10 = var_e1;

    CHECK_OBJECT( tmp_left_name_10 );
    tmp_right_name_9 = var_s1;

    CHECK_OBJECT( tmp_right_name_9 );
    tmp_left_name_9 = BINARY_OPERATION_SUB( tmp_left_name_10, tmp_right_name_9 );
    if ( tmp_left_name_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 397;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_right_name_10 = const_int_pos_1;
    tmp_xrange_low_3 = BINARY_OPERATION_ADD( tmp_left_name_9, tmp_right_name_10 );
    Py_DECREF( tmp_left_name_9 );
    if ( tmp_xrange_low_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 397;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_iter_arg_20 = BUILTIN_XRANGE1( tmp_xrange_low_3 );
    Py_DECREF( tmp_xrange_low_3 );
    if ( tmp_iter_arg_20 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 397;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    tmp_assign_source_93 = MAKE_ITERATOR( tmp_iter_arg_20 );
    Py_DECREF( tmp_iter_arg_20 );
    if ( tmp_assign_source_93 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 397;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    {
        PyObject *old = tmp_for_loop_6__for_iterator;
        tmp_for_loop_6__for_iterator = tmp_assign_source_93;
        Py_XDECREF( old );
    }

    // Tried code:
    loop_start_9:;
    tmp_next_source_9 = tmp_for_loop_6__for_iterator;

    CHECK_OBJECT( tmp_next_source_9 );
    tmp_assign_source_94 = ITERATOR_NEXT( tmp_next_source_9 );
    if ( tmp_assign_source_94 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_9;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 397;
            goto try_except_handler_34;
        }
    }

    {
        PyObject *old = tmp_for_loop_6__iter_value;
        tmp_for_loop_6__iter_value = tmp_assign_source_94;
        Py_XDECREF( old );
    }

    tmp_assign_source_95 = tmp_for_loop_6__iter_value;

    CHECK_OBJECT( tmp_assign_source_95 );
    {
        PyObject *old = var_i;
        var_i = tmp_assign_source_95;
        Py_INCREF( var_i );
        Py_XDECREF( old );
    }

    tmp_left_name_11 = var_prefix;

    CHECK_OBJECT( tmp_left_name_11 );
    tmp_source_name_27 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_struct );

    if (unlikely( tmp_source_name_27 == NULL ))
    {
        tmp_source_name_27 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_struct );
    }

    if ( tmp_source_name_27 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "struct" );
        exception_tb = NULL;

        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }

    tmp_called_name_19 = LOOKUP_ATTRIBUTE( tmp_source_name_27, const_str_plain_pack );
    if ( tmp_called_name_19 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_args_element_name_27 = const_str_digest_7532b9d7f11d8fedcf0f9e47d9f9d1da;
    tmp_left_name_12 = var_base;

    CHECK_OBJECT( tmp_left_name_12 );
    tmp_right_name_12 = var_i;

    CHECK_OBJECT( tmp_right_name_12 );
    tmp_args_element_name_28 = BINARY_OPERATION_ADD( tmp_left_name_12, tmp_right_name_12 );
    if ( tmp_args_element_name_28 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_19 );

        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 398;
    {
        PyObject *call_args[] = { tmp_args_element_name_27, tmp_args_element_name_28 };
        tmp_slice_source_8 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_19, call_args );
    }

    Py_DECREF( tmp_called_name_19 );
    Py_DECREF( tmp_args_element_name_28 );
    if ( tmp_slice_source_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_operand_name_7 = var_vlen;

    CHECK_OBJECT( tmp_operand_name_7 );
    tmp_slice_lower_2 = UNARY_OPERATION( PyNumber_Negative, tmp_operand_name_7 );
    if ( tmp_slice_lower_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_slice_source_8 );

        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_right_name_11 = LOOKUP_SLICE( tmp_slice_source_8, tmp_slice_lower_2, Py_None );
    Py_DECREF( tmp_slice_source_8 );
    Py_DECREF( tmp_slice_lower_2 );
    if ( tmp_right_name_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_assign_source_96 = BINARY_OPERATION_ADD( tmp_left_name_11, tmp_right_name_11 );
    Py_DECREF( tmp_right_name_11 );
    if ( tmp_assign_source_96 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 398;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    {
        PyObject *old = var_x;
        var_x = tmp_assign_source_96;
        Py_XDECREF( old );
    }

    tmp_source_name_29 = par_self;

    CHECK_OBJECT( tmp_source_name_29 );
    tmp_source_name_28 = LOOKUP_ATTRIBUTE( tmp_source_name_29, const_str_plain_cmap );
    if ( tmp_source_name_28 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 399;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_called_name_20 = LOOKUP_ATTRIBUTE( tmp_source_name_28, const_str_plain_add_cid2unichr );
    Py_DECREF( tmp_source_name_28 );
    if ( tmp_called_name_20 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 399;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_left_name_13 = var_s1;

    CHECK_OBJECT( tmp_left_name_13 );
    tmp_right_name_13 = var_i;

    CHECK_OBJECT( tmp_right_name_13 );
    tmp_args_element_name_29 = BINARY_OPERATION_ADD( tmp_left_name_13, tmp_right_name_13 );
    if ( tmp_args_element_name_29 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_20 );

        exception_lineno = 399;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    tmp_args_element_name_30 = var_x;

    CHECK_OBJECT( tmp_args_element_name_30 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 399;
    {
        PyObject *call_args[] = { tmp_args_element_name_29, tmp_args_element_name_30 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_20, call_args );
    }

    Py_DECREF( tmp_called_name_20 );
    Py_DECREF( tmp_args_element_name_29 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 399;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 397;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_34;
    }
    goto loop_start_9;
    loop_end_9:;
    goto try_end_29;
    // Exception handler code:
    try_except_handler_34:;
    exception_keeper_type_32 = exception_type;
    exception_keeper_value_32 = exception_value;
    exception_keeper_tb_32 = exception_tb;
    exception_keeper_lineno_32 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_6__iter_value );
    tmp_for_loop_6__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_6__for_iterator );
    Py_DECREF( tmp_for_loop_6__for_iterator );
    tmp_for_loop_6__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_32;
    exception_value = exception_keeper_value_32;
    exception_tb = exception_keeper_tb_32;
    exception_lineno = exception_keeper_lineno_32;

    goto try_except_handler_30;
    // End of try:
    try_end_29:;
    Py_XDECREF( tmp_for_loop_6__iter_value );
    tmp_for_loop_6__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_6__for_iterator );
    Py_DECREF( tmp_for_loop_6__for_iterator );
    tmp_for_loop_6__for_iterator = NULL;

    branch_end_21:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 382;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_30;
    }
    goto loop_start_7;
    loop_end_7:;
    goto try_end_30;
    // Exception handler code:
    try_except_handler_30:;
    exception_keeper_type_33 = exception_type;
    exception_keeper_value_33 = exception_value;
    exception_keeper_tb_33 = exception_tb;
    exception_keeper_lineno_33 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_4__iter_value );
    tmp_for_loop_4__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_4__for_iterator );
    Py_DECREF( tmp_for_loop_4__for_iterator );
    tmp_for_loop_4__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_33;
    exception_value = exception_keeper_value_33;
    exception_tb = exception_keeper_tb_33;
    exception_lineno = exception_keeper_lineno_33;

    goto frame_exception_exit_1;
    // End of try:
    try_end_30:;
    Py_XDECREF( tmp_for_loop_4__iter_value );
    tmp_for_loop_4__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_4__for_iterator );
    Py_DECREF( tmp_for_loop_4__for_iterator );
    tmp_for_loop_4__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_19:;
    tmp_compare_left_17 = par_token;

    CHECK_OBJECT( tmp_compare_left_17 );
    tmp_source_name_30 = par_self;

    CHECK_OBJECT( tmp_source_name_30 );
    tmp_compare_right_17 = LOOKUP_ATTRIBUTE( tmp_source_name_30, const_str_plain_KEYWORD_BEGINBFCHAR );
    if ( tmp_compare_right_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 402;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_13 = ( tmp_compare_left_17 == tmp_compare_right_17 );
    Py_DECREF( tmp_compare_right_17 );
    if ( tmp_is_13 )
    {
        goto branch_yes_22;
    }
    else
    {
        goto branch_no_22;
    }
    branch_yes_22:;
    tmp_called_instance_12 = par_self;

    CHECK_OBJECT( tmp_called_instance_12 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 403;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_12, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 403;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_22:;
    tmp_compare_left_18 = par_token;

    CHECK_OBJECT( tmp_compare_left_18 );
    tmp_source_name_31 = par_self;

    CHECK_OBJECT( tmp_source_name_31 );
    tmp_compare_right_18 = LOOKUP_ATTRIBUTE( tmp_source_name_31, const_str_plain_KEYWORD_ENDBFCHAR );
    if ( tmp_compare_right_18 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 405;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_14 = ( tmp_compare_left_18 == tmp_compare_right_18 );
    Py_DECREF( tmp_compare_right_18 );
    if ( tmp_is_14 )
    {
        goto branch_yes_23;
    }
    else
    {
        goto branch_no_23;
    }
    branch_yes_23:;
    // Tried code:
    tmp_called_instance_13 = par_self;

    CHECK_OBJECT( tmp_called_instance_13 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 406;
    tmp_iter_arg_21 = CALL_METHOD_NO_ARGS( tmp_called_instance_13, const_str_plain_popall );
    if ( tmp_iter_arg_21 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 406;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_35;
    }
    tmp_assign_source_98 = MAKE_ITERATOR( tmp_iter_arg_21 );
    Py_DECREF( tmp_iter_arg_21 );
    if ( tmp_assign_source_98 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 406;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_35;
    }
    assert( tmp_list_contraction_4__$0 == NULL );
    tmp_list_contraction_4__$0 = tmp_assign_source_98;

    tmp_assign_source_99 = PyList_New( 0 );
    assert( tmp_list_contraction_4__contraction_result == NULL );
    tmp_list_contraction_4__contraction_result = tmp_assign_source_99;

    loop_start_10:;
    tmp_next_source_10 = tmp_list_contraction_4__$0;

    CHECK_OBJECT( tmp_next_source_10 );
    tmp_assign_source_100 = ITERATOR_NEXT( tmp_next_source_10 );
    if ( tmp_assign_source_100 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_10;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 406;
            goto try_except_handler_35;
        }
    }

    {
        PyObject *old = tmp_list_contraction_4__iter_value_0;
        tmp_list_contraction_4__iter_value_0 = tmp_assign_source_100;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_22 = tmp_list_contraction_4__iter_value_0;

    CHECK_OBJECT( tmp_iter_arg_22 );
    tmp_assign_source_101 = MAKE_ITERATOR( tmp_iter_arg_22 );
    if ( tmp_assign_source_101 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 406;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_36;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_4__source_iter;
        tmp_list_contraction$tuple_unpack_4__source_iter = tmp_assign_source_101;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_24 = tmp_list_contraction$tuple_unpack_4__source_iter;

    CHECK_OBJECT( tmp_unpack_24 );
    tmp_assign_source_102 = UNPACK_NEXT( tmp_unpack_24, 0 );
    if ( tmp_assign_source_102 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 406;
        goto try_except_handler_37;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_4__element_1;
        tmp_list_contraction$tuple_unpack_4__element_1 = tmp_assign_source_102;
        Py_XDECREF( old );
    }

    tmp_unpack_25 = tmp_list_contraction$tuple_unpack_4__source_iter;

    CHECK_OBJECT( tmp_unpack_25 );
    tmp_assign_source_103 = UNPACK_NEXT( tmp_unpack_25, 1 );
    if ( tmp_assign_source_103 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 406;
        goto try_except_handler_37;
    }
    {
        PyObject *old = tmp_list_contraction$tuple_unpack_4__element_2;
        tmp_list_contraction$tuple_unpack_4__element_2 = tmp_assign_source_103;
        Py_XDECREF( old );
    }

    tmp_iterator_name_12 = tmp_list_contraction$tuple_unpack_4__source_iter;

    CHECK_OBJECT( tmp_iterator_name_12 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_12 ); assert( HAS_ITERNEXT( tmp_iterator_name_12 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_12 )->tp_iternext)( tmp_iterator_name_12 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 406;
                goto try_except_handler_37;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 406;
        goto try_except_handler_37;
    }
    goto try_end_31;
    // Exception handler code:
    try_except_handler_37:;
    exception_keeper_type_34 = exception_type;
    exception_keeper_value_34 = exception_value;
    exception_keeper_tb_34 = exception_tb;
    exception_keeper_lineno_34 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_4__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_4__source_iter );
    tmp_list_contraction$tuple_unpack_4__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_34;
    exception_value = exception_keeper_value_34;
    exception_tb = exception_keeper_tb_34;
    exception_lineno = exception_keeper_lineno_34;

    goto try_except_handler_36;
    // End of try:
    try_end_31:;
    goto try_end_32;
    // Exception handler code:
    try_except_handler_36:;
    exception_keeper_type_35 = exception_type;
    exception_keeper_value_35 = exception_value;
    exception_keeper_tb_35 = exception_tb;
    exception_keeper_lineno_35 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_4__element_1 );
    tmp_list_contraction$tuple_unpack_4__element_1 = NULL;

    Py_XDECREF( tmp_list_contraction$tuple_unpack_4__element_2 );
    tmp_list_contraction$tuple_unpack_4__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_35;
    exception_value = exception_keeper_value_35;
    exception_tb = exception_keeper_tb_35;
    exception_lineno = exception_keeper_lineno_35;

    goto try_except_handler_35;
    // End of try:
    try_end_32:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction$tuple_unpack_4__source_iter );
    Py_DECREF( tmp_list_contraction$tuple_unpack_4__source_iter );
    tmp_list_contraction$tuple_unpack_4__source_iter = NULL;

    tmp_assign_source_104 = tmp_list_contraction$tuple_unpack_4__element_1;

    CHECK_OBJECT( tmp_assign_source_104 );
    {
        PyObject *old = var___;
        var___ = tmp_assign_source_104;
        Py_INCREF( var___ );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_4__element_1 );
    tmp_list_contraction$tuple_unpack_4__element_1 = NULL;

    tmp_assign_source_105 = tmp_list_contraction$tuple_unpack_4__element_2;

    CHECK_OBJECT( tmp_assign_source_105 );
    {
        PyObject *old = var_obj;
        var_obj = tmp_assign_source_105;
        Py_INCREF( var_obj );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_list_contraction$tuple_unpack_4__element_2 );
    tmp_list_contraction$tuple_unpack_4__element_2 = NULL;

    tmp_append_list_4 = tmp_list_contraction_4__contraction_result;

    CHECK_OBJECT( tmp_append_list_4 );
    tmp_append_value_4 = var_obj;

    CHECK_OBJECT( tmp_append_value_4 );
    assert( PyList_Check( tmp_append_list_4 ) );
    tmp_res = PyList_Append( tmp_append_list_4, tmp_append_value_4 );
    if ( tmp_res == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 406;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_35;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 406;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_35;
    }
    goto loop_start_10;
    loop_end_10:;
    tmp_outline_return_value_4 = tmp_list_contraction_4__contraction_result;

    CHECK_OBJECT( tmp_outline_return_value_4 );
    Py_INCREF( tmp_outline_return_value_4 );
    goto try_return_handler_35;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // Return handler code:
    try_return_handler_35:;
    CHECK_OBJECT( (PyObject *)tmp_list_contraction_4__$0 );
    Py_DECREF( tmp_list_contraction_4__$0 );
    tmp_list_contraction_4__$0 = NULL;

    CHECK_OBJECT( (PyObject *)tmp_list_contraction_4__contraction_result );
    Py_DECREF( tmp_list_contraction_4__contraction_result );
    tmp_list_contraction_4__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_4__iter_value_0 );
    tmp_list_contraction_4__iter_value_0 = NULL;

    goto outline_result_4;
    // Exception handler code:
    try_except_handler_35:;
    exception_keeper_type_36 = exception_type;
    exception_keeper_value_36 = exception_value;
    exception_keeper_tb_36 = exception_tb;
    exception_keeper_lineno_36 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_list_contraction_4__$0 );
    tmp_list_contraction_4__$0 = NULL;

    Py_XDECREF( tmp_list_contraction_4__contraction_result );
    tmp_list_contraction_4__contraction_result = NULL;

    Py_XDECREF( tmp_list_contraction_4__iter_value_0 );
    tmp_list_contraction_4__iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_36;
    exception_value = exception_keeper_value_36;
    exception_tb = exception_keeper_tb_36;
    exception_lineno = exception_keeper_lineno_36;

    goto frame_exception_exit_1;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    outline_result_4:;
    tmp_assign_source_97 = tmp_outline_return_value_4;
    assert( var_objs == NULL );
    var_objs = tmp_assign_source_97;

    tmp_called_name_21 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_choplist );

    if (unlikely( tmp_called_name_21 == NULL ))
    {
        tmp_called_name_21 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_choplist );
    }

    if ( tmp_called_name_21 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "choplist" );
        exception_tb = NULL;

        exception_lineno = 407;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_31 = const_int_pos_2;
    tmp_args_element_name_32 = var_objs;

    CHECK_OBJECT( tmp_args_element_name_32 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 407;
    {
        PyObject *call_args[] = { tmp_args_element_name_31, tmp_args_element_name_32 };
        tmp_iter_arg_23 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_21, call_args );
    }

    if ( tmp_iter_arg_23 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 407;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assign_source_106 = MAKE_ITERATOR( tmp_iter_arg_23 );
    Py_DECREF( tmp_iter_arg_23 );
    if ( tmp_assign_source_106 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 407;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_7__for_iterator == NULL );
    tmp_for_loop_7__for_iterator = tmp_assign_source_106;

    // Tried code:
    loop_start_11:;
    tmp_next_source_11 = tmp_for_loop_7__for_iterator;

    CHECK_OBJECT( tmp_next_source_11 );
    tmp_assign_source_107 = ITERATOR_NEXT( tmp_next_source_11 );
    if ( tmp_assign_source_107 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_11;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "oooooooooooooooooooooooooo";
            exception_lineno = 407;
            goto try_except_handler_38;
        }
    }

    {
        PyObject *old = tmp_for_loop_7__iter_value;
        tmp_for_loop_7__iter_value = tmp_assign_source_107;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_24 = tmp_for_loop_7__iter_value;

    CHECK_OBJECT( tmp_iter_arg_24 );
    tmp_assign_source_108 = MAKE_ITERATOR( tmp_iter_arg_24 );
    if ( tmp_assign_source_108 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 407;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_39;
    }
    {
        PyObject *old = tmp_tuple_unpack_9__source_iter;
        tmp_tuple_unpack_9__source_iter = tmp_assign_source_108;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_26 = tmp_tuple_unpack_9__source_iter;

    CHECK_OBJECT( tmp_unpack_26 );
    tmp_assign_source_109 = UNPACK_NEXT( tmp_unpack_26, 0 );
    if ( tmp_assign_source_109 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 407;
        goto try_except_handler_40;
    }
    {
        PyObject *old = tmp_tuple_unpack_9__element_1;
        tmp_tuple_unpack_9__element_1 = tmp_assign_source_109;
        Py_XDECREF( old );
    }

    tmp_unpack_27 = tmp_tuple_unpack_9__source_iter;

    CHECK_OBJECT( tmp_unpack_27 );
    tmp_assign_source_110 = UNPACK_NEXT( tmp_unpack_27, 1 );
    if ( tmp_assign_source_110 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 407;
        goto try_except_handler_40;
    }
    {
        PyObject *old = tmp_tuple_unpack_9__element_2;
        tmp_tuple_unpack_9__element_2 = tmp_assign_source_110;
        Py_XDECREF( old );
    }

    tmp_iterator_name_13 = tmp_tuple_unpack_9__source_iter;

    CHECK_OBJECT( tmp_iterator_name_13 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_13 ); assert( HAS_ITERNEXT( tmp_iterator_name_13 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_13 )->tp_iternext)( tmp_iterator_name_13 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "oooooooooooooooooooooooooo";
                exception_lineno = 407;
                goto try_except_handler_40;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "oooooooooooooooooooooooooo";
        exception_lineno = 407;
        goto try_except_handler_40;
    }
    goto try_end_33;
    // Exception handler code:
    try_except_handler_40:;
    exception_keeper_type_37 = exception_type;
    exception_keeper_value_37 = exception_value;
    exception_keeper_tb_37 = exception_tb;
    exception_keeper_lineno_37 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_9__source_iter );
    Py_DECREF( tmp_tuple_unpack_9__source_iter );
    tmp_tuple_unpack_9__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_37;
    exception_value = exception_keeper_value_37;
    exception_tb = exception_keeper_tb_37;
    exception_lineno = exception_keeper_lineno_37;

    goto try_except_handler_39;
    // End of try:
    try_end_33:;
    goto try_end_34;
    // Exception handler code:
    try_except_handler_39:;
    exception_keeper_type_38 = exception_type;
    exception_keeper_value_38 = exception_value;
    exception_keeper_tb_38 = exception_tb;
    exception_keeper_lineno_38 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_9__element_1 );
    tmp_tuple_unpack_9__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_9__element_2 );
    tmp_tuple_unpack_9__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_38;
    exception_value = exception_keeper_value_38;
    exception_tb = exception_keeper_tb_38;
    exception_lineno = exception_keeper_lineno_38;

    goto try_except_handler_38;
    // End of try:
    try_end_34:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_9__source_iter );
    Py_DECREF( tmp_tuple_unpack_9__source_iter );
    tmp_tuple_unpack_9__source_iter = NULL;

    tmp_assign_source_111 = tmp_tuple_unpack_9__element_1;

    CHECK_OBJECT( tmp_assign_source_111 );
    {
        PyObject *old = var_cid;
        var_cid = tmp_assign_source_111;
        Py_INCREF( var_cid );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_9__element_1 );
    tmp_tuple_unpack_9__element_1 = NULL;

    tmp_assign_source_112 = tmp_tuple_unpack_9__element_2;

    CHECK_OBJECT( tmp_assign_source_112 );
    {
        PyObject *old = var_code;
        var_code = tmp_assign_source_112;
        Py_INCREF( var_code );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_9__element_2 );
    tmp_tuple_unpack_9__element_2 = NULL;

    tmp_isinstance_inst_9 = var_cid;

    CHECK_OBJECT( tmp_isinstance_inst_9 );
    tmp_isinstance_cls_9 = (PyObject *)&PyString_Type;
    tmp_and_left_value_2 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_9, tmp_isinstance_cls_9 );
    if ( tmp_and_left_value_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 408;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    tmp_and_left_truth_2 = CHECK_IF_TRUE( tmp_and_left_value_2 );
    if ( tmp_and_left_truth_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 408;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    if ( tmp_and_left_truth_2 == 1 )
    {
        goto and_right_2;
    }
    else
    {
        goto and_left_2;
    }
    and_right_2:;
    tmp_isinstance_inst_10 = var_code;

    CHECK_OBJECT( tmp_isinstance_inst_10 );
    tmp_isinstance_cls_10 = (PyObject *)&PyString_Type;
    tmp_and_right_value_2 = BUILTIN_ISINSTANCE( tmp_isinstance_inst_10, tmp_isinstance_cls_10 );
    if ( tmp_and_right_value_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 408;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    tmp_cond_value_5 = tmp_and_right_value_2;
    goto and_end_2;
    and_left_2:;
    tmp_cond_value_5 = tmp_and_left_value_2;
    and_end_2:;
    tmp_cond_truth_5 = CHECK_IF_TRUE( tmp_cond_value_5 );
    if ( tmp_cond_truth_5 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 408;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    if ( tmp_cond_truth_5 == 1 )
    {
        goto branch_yes_24;
    }
    else
    {
        goto branch_no_24;
    }
    branch_yes_24:;
    tmp_source_name_33 = par_self;

    CHECK_OBJECT( tmp_source_name_33 );
    tmp_source_name_32 = LOOKUP_ATTRIBUTE( tmp_source_name_33, const_str_plain_cmap );
    if ( tmp_source_name_32 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 409;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    tmp_called_name_22 = LOOKUP_ATTRIBUTE( tmp_source_name_32, const_str_plain_add_cid2unichr );
    Py_DECREF( tmp_source_name_32 );
    if ( tmp_called_name_22 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 409;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    tmp_called_name_23 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack );

    if (unlikely( tmp_called_name_23 == NULL ))
    {
        tmp_called_name_23 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_nunpack );
    }

    if ( tmp_called_name_23 == NULL )
    {
        Py_DECREF( tmp_called_name_22 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "nunpack" );
        exception_tb = NULL;

        exception_lineno = 409;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }

    tmp_args_element_name_34 = var_cid;

    CHECK_OBJECT( tmp_args_element_name_34 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 409;
    {
        PyObject *call_args[] = { tmp_args_element_name_34 };
        tmp_args_element_name_33 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_23, call_args );
    }

    if ( tmp_args_element_name_33 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_22 );

        exception_lineno = 409;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    tmp_args_element_name_35 = var_code;

    CHECK_OBJECT( tmp_args_element_name_35 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 409;
    {
        PyObject *call_args[] = { tmp_args_element_name_33, tmp_args_element_name_35 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_22, call_args );
    }

    Py_DECREF( tmp_called_name_22 );
    Py_DECREF( tmp_args_element_name_33 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 409;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    Py_DECREF( tmp_unused );
    branch_no_24:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 407;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto try_except_handler_38;
    }
    goto loop_start_11;
    loop_end_11:;
    goto try_end_35;
    // Exception handler code:
    try_except_handler_38:;
    exception_keeper_type_39 = exception_type;
    exception_keeper_value_39 = exception_value;
    exception_keeper_tb_39 = exception_tb;
    exception_keeper_lineno_39 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_7__iter_value );
    tmp_for_loop_7__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_7__for_iterator );
    Py_DECREF( tmp_for_loop_7__for_iterator );
    tmp_for_loop_7__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_39;
    exception_value = exception_keeper_value_39;
    exception_tb = exception_keeper_tb_39;
    exception_lineno = exception_keeper_lineno_39;

    goto frame_exception_exit_1;
    // End of try:
    try_end_35:;
    Py_XDECREF( tmp_for_loop_7__iter_value );
    tmp_for_loop_7__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_7__for_iterator );
    Py_DECREF( tmp_for_loop_7__for_iterator );
    tmp_for_loop_7__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_23:;
    tmp_compare_left_19 = par_token;

    CHECK_OBJECT( tmp_compare_left_19 );
    tmp_source_name_34 = par_self;

    CHECK_OBJECT( tmp_source_name_34 );
    tmp_compare_right_19 = LOOKUP_ATTRIBUTE( tmp_source_name_34, const_str_plain_KEYWORD_BEGINNOTDEFRANGE );
    if ( tmp_compare_right_19 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 412;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_15 = ( tmp_compare_left_19 == tmp_compare_right_19 );
    Py_DECREF( tmp_compare_right_19 );
    if ( tmp_is_15 )
    {
        goto branch_yes_25;
    }
    else
    {
        goto branch_no_25;
    }
    branch_yes_25:;
    tmp_called_instance_14 = par_self;

    CHECK_OBJECT( tmp_called_instance_14 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 413;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_14, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 413;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_25:;
    tmp_compare_left_20 = par_token;

    CHECK_OBJECT( tmp_compare_left_20 );
    tmp_source_name_35 = par_self;

    CHECK_OBJECT( tmp_source_name_35 );
    tmp_compare_right_20 = LOOKUP_ATTRIBUTE( tmp_source_name_35, const_str_plain_KEYWORD_ENDNOTDEFRANGE );
    if ( tmp_compare_right_20 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 415;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_is_16 = ( tmp_compare_left_20 == tmp_compare_right_20 );
    Py_DECREF( tmp_compare_right_20 );
    if ( tmp_is_16 )
    {
        goto branch_yes_26;
    }
    else
    {
        goto branch_no_26;
    }
    branch_yes_26:;
    tmp_called_instance_15 = par_self;

    CHECK_OBJECT( tmp_called_instance_15 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 416;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_15, const_str_plain_popall );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 416;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto frame_return_exit_1;
    branch_no_26:;
    tmp_called_instance_16 = par_self;

    CHECK_OBJECT( tmp_called_instance_16 );
    tmp_args_element_name_36 = PyTuple_New( 2 );
    tmp_tuple_element_1 = par_pos;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_element_name_36, 0, tmp_tuple_element_1 );
    tmp_tuple_element_1 = par_token;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_element_name_36, 1, tmp_tuple_element_1 );
    frame_dde973ae2c181782bcfe319ce801f19b->m_frame.f_lineno = 419;
    {
        PyObject *call_args[] = { tmp_args_element_name_36 };
        tmp_unused = CALL_METHOD_WITH_ARGS1( tmp_called_instance_16, const_str_plain_push, call_args );
    }

    Py_DECREF( tmp_args_element_name_36 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 419;
        type_description_1 = "oooooooooooooooooooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );

#if 1
    RESTORE_FRAME_EXCEPTION( frame_dde973ae2c181782bcfe319ce801f19b );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 1
    RESTORE_FRAME_EXCEPTION( frame_dde973ae2c181782bcfe319ce801f19b );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_dde973ae2c181782bcfe319ce801f19b );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_dde973ae2c181782bcfe319ce801f19b, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_dde973ae2c181782bcfe319ce801f19b->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_dde973ae2c181782bcfe319ce801f19b, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_dde973ae2c181782bcfe319ce801f19b,
        type_description_1,
        par_self,
        par_pos,
        par_token,
        var__,
        var_k,
        var_v,
        var_cmapname,
        var___,
        var_obj,
        var_objs,
        var_s,
        var_e,
        var_cid,
        var_sprefix,
        var_eprefix,
        var_svar,
        var_evar,
        var_s1,
        var_e1,
        var_vlen,
        var_i,
        var_x,
        var_code,
        var_var,
        var_base,
        var_prefix
    );


    // Release cached frame.
    if ( frame_dde973ae2c181782bcfe319ce801f19b == cache_frame_dde973ae2c181782bcfe319ce801f19b )
    {
        Py_DECREF( frame_dde973ae2c181782bcfe319ce801f19b );
    }
    cache_frame_dde973ae2c181782bcfe319ce801f19b = NULL;

    assertFrameObject( frame_dde973ae2c181782bcfe319ce801f19b );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_pos );
    Py_DECREF( par_pos );
    par_pos = NULL;

    CHECK_OBJECT( (PyObject *)par_token );
    Py_DECREF( par_token );
    par_token = NULL;

    Py_XDECREF( var__ );
    var__ = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_cmapname );
    var_cmapname = NULL;

    Py_XDECREF( var___ );
    var___ = NULL;

    Py_XDECREF( var_obj );
    var_obj = NULL;

    Py_XDECREF( var_objs );
    var_objs = NULL;

    Py_XDECREF( var_s );
    var_s = NULL;

    Py_XDECREF( var_e );
    var_e = NULL;

    Py_XDECREF( var_cid );
    var_cid = NULL;

    Py_XDECREF( var_sprefix );
    var_sprefix = NULL;

    Py_XDECREF( var_eprefix );
    var_eprefix = NULL;

    Py_XDECREF( var_svar );
    var_svar = NULL;

    Py_XDECREF( var_evar );
    var_evar = NULL;

    Py_XDECREF( var_s1 );
    var_s1 = NULL;

    Py_XDECREF( var_e1 );
    var_e1 = NULL;

    Py_XDECREF( var_vlen );
    var_vlen = NULL;

    Py_XDECREF( var_i );
    var_i = NULL;

    Py_XDECREF( var_x );
    var_x = NULL;

    Py_XDECREF( var_code );
    var_code = NULL;

    Py_XDECREF( var_var );
    var_var = NULL;

    Py_XDECREF( var_base );
    var_base = NULL;

    Py_XDECREF( var_prefix );
    var_prefix = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_40 = exception_type;
    exception_keeper_value_40 = exception_value;
    exception_keeper_tb_40 = exception_tb;
    exception_keeper_lineno_40 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_self );
    Py_DECREF( par_self );
    par_self = NULL;

    CHECK_OBJECT( (PyObject *)par_pos );
    Py_DECREF( par_pos );
    par_pos = NULL;

    CHECK_OBJECT( (PyObject *)par_token );
    Py_DECREF( par_token );
    par_token = NULL;

    Py_XDECREF( var__ );
    var__ = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_cmapname );
    var_cmapname = NULL;

    Py_XDECREF( var___ );
    var___ = NULL;

    Py_XDECREF( var_obj );
    var_obj = NULL;

    Py_XDECREF( var_objs );
    var_objs = NULL;

    Py_XDECREF( var_s );
    var_s = NULL;

    Py_XDECREF( var_e );
    var_e = NULL;

    Py_XDECREF( var_cid );
    var_cid = NULL;

    Py_XDECREF( var_sprefix );
    var_sprefix = NULL;

    Py_XDECREF( var_eprefix );
    var_eprefix = NULL;

    Py_XDECREF( var_svar );
    var_svar = NULL;

    Py_XDECREF( var_evar );
    var_evar = NULL;

    Py_XDECREF( var_s1 );
    var_s1 = NULL;

    Py_XDECREF( var_e1 );
    var_e1 = NULL;

    Py_XDECREF( var_vlen );
    var_vlen = NULL;

    Py_XDECREF( var_i );
    var_i = NULL;

    Py_XDECREF( var_x );
    var_x = NULL;

    Py_XDECREF( var_code );
    var_code = NULL;

    Py_XDECREF( var_var );
    var_var = NULL;

    Py_XDECREF( var_base );
    var_base = NULL;

    Py_XDECREF( var_prefix );
    var_prefix = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_40;
    exception_value = exception_keeper_value_40;
    exception_tb = exception_keeper_tb_40;
    exception_lineno = exception_keeper_lineno_40;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_26_do_keyword );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl_pdfminer$cmapdb$$$function_27_main( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *par_argv = python_pars[ 0 ];
    PyObject *var_args = NULL;
    PyObject *var_fname = NULL;
    PyObject *var_fp = NULL;
    PyObject *var_cmap = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_instance_2;
    PyObject *tmp_called_instance_3;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_return_value;
    Py_ssize_t tmp_slice_index_upper_1;
    PyObject *tmp_slice_source_1;
    Py_ssize_t tmp_sliceslicedel_index_lower_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_4470f8f74fc84dbe3ef6af9cb8351243 = NULL;

    struct Nuitka_FrameObject *frame_4470f8f74fc84dbe3ef6af9cb8351243;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_4470f8f74fc84dbe3ef6af9cb8351243, codeobj_4470f8f74fc84dbe3ef6af9cb8351243, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_4470f8f74fc84dbe3ef6af9cb8351243 = cache_frame_4470f8f74fc84dbe3ef6af9cb8351243;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_4470f8f74fc84dbe3ef6af9cb8351243 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_4470f8f74fc84dbe3ef6af9cb8351243 ) == 2 ); // Frame stack

    // Framed code:
    tmp_sliceslicedel_index_lower_1 = 1;
    tmp_slice_index_upper_1 = PY_SSIZE_T_MAX;
    tmp_slice_source_1 = par_argv;

    CHECK_OBJECT( tmp_slice_source_1 );
    tmp_assign_source_1 = LOOKUP_INDEX_SLICE( tmp_slice_source_1, tmp_sliceslicedel_index_lower_1, tmp_slice_index_upper_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 425;
        type_description_1 = "ooooo";
        goto frame_exception_exit_1;
    }
    assert( var_args == NULL );
    var_args = tmp_assign_source_1;

    tmp_iter_arg_1 = var_args;

    CHECK_OBJECT( tmp_iter_arg_1 );
    tmp_assign_source_2 = MAKE_ITERATOR( tmp_iter_arg_1 );
    if ( tmp_assign_source_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 426;
        type_description_1 = "ooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_2;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_3 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "ooooo";
            exception_lineno = 426;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_3;
        Py_XDECREF( old );
    }

    tmp_assign_source_4 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_assign_source_4 );
    {
        PyObject *old = var_fname;
        var_fname = tmp_assign_source_4;
        Py_INCREF( var_fname );
        Py_XDECREF( old );
    }

    tmp_called_name_1 = (PyObject *)&PyFile_Type;
    tmp_args_element_name_1 = var_fname;

    CHECK_OBJECT( tmp_args_element_name_1 );
    tmp_args_element_name_2 = const_str_plain_rb;
    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 427;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_assign_source_5 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 427;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_fp;
        var_fp = tmp_assign_source_5;
        Py_XDECREF( old );
    }

    tmp_called_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_FileUnicodeMap );

    if (unlikely( tmp_called_name_2 == NULL ))
    {
        tmp_called_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_FileUnicodeMap );
    }

    if ( tmp_called_name_2 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "FileUnicodeMap" );
        exception_tb = NULL;

        exception_lineno = 428;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }

    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 428;
    tmp_assign_source_6 = CALL_FUNCTION_NO_ARGS( tmp_called_name_2 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 428;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    {
        PyObject *old = var_cmap;
        var_cmap = tmp_assign_source_6;
        Py_XDECREF( old );
    }

    tmp_called_name_3 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapParser );

    if (unlikely( tmp_called_name_3 == NULL ))
    {
        tmp_called_name_3 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapParser );
    }

    if ( tmp_called_name_3 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapParser" );
        exception_tb = NULL;

        exception_lineno = 430;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }

    tmp_args_element_name_3 = var_cmap;

    CHECK_OBJECT( tmp_args_element_name_3 );
    tmp_args_element_name_4 = var_fp;

    CHECK_OBJECT( tmp_args_element_name_4 );
    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 430;
    {
        PyObject *call_args[] = { tmp_args_element_name_3, tmp_args_element_name_4 };
        tmp_called_instance_1 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_3, call_args );
    }

    if ( tmp_called_instance_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 430;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 430;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_1, const_str_plain_run );
    Py_DECREF( tmp_called_instance_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 430;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    tmp_called_instance_2 = var_fp;

    CHECK_OBJECT( tmp_called_instance_2 );
    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 431;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_2, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 431;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    tmp_called_instance_3 = var_cmap;

    CHECK_OBJECT( tmp_called_instance_3 );
    frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame.f_lineno = 432;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_3, const_str_plain_dump );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 432;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 426;
        type_description_1 = "ooooo";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_4470f8f74fc84dbe3ef6af9cb8351243 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_4470f8f74fc84dbe3ef6af9cb8351243 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_4470f8f74fc84dbe3ef6af9cb8351243, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_4470f8f74fc84dbe3ef6af9cb8351243->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_4470f8f74fc84dbe3ef6af9cb8351243, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_4470f8f74fc84dbe3ef6af9cb8351243,
        type_description_1,
        par_argv,
        var_args,
        var_fname,
        var_fp,
        var_cmap
    );


    // Release cached frame.
    if ( frame_4470f8f74fc84dbe3ef6af9cb8351243 == cache_frame_4470f8f74fc84dbe3ef6af9cb8351243 )
    {
        Py_DECREF( frame_4470f8f74fc84dbe3ef6af9cb8351243 );
    }
    cache_frame_4470f8f74fc84dbe3ef6af9cb8351243 = NULL;

    assertFrameObject( frame_4470f8f74fc84dbe3ef6af9cb8351243 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_27_main );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_argv );
    Py_DECREF( par_argv );
    par_argv = NULL;

    CHECK_OBJECT( (PyObject *)var_args );
    Py_DECREF( var_args );
    var_args = NULL;

    Py_XDECREF( var_fname );
    var_fname = NULL;

    Py_XDECREF( var_fp );
    var_fp = NULL;

    Py_XDECREF( var_cmap );
    var_cmap = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_argv );
    Py_DECREF( par_argv );
    par_argv = NULL;

    Py_XDECREF( var_args );
    var_args = NULL;

    Py_XDECREF( var_fname );
    var_fname = NULL;

    Py_XDECREF( var_fp );
    var_fp = NULL;

    Py_XDECREF( var_cmap );
    var_cmap = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb$$$function_27_main );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_10_decode(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_10_decode,
        const_str_plain_decode,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_6c9e14d04177bd2655d3c3028f48ff92,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_11_dump( PyObject *defaults )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_11_dump,
        const_str_plain_dump,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_23065d1938672ee05fa3dd3a75f30253,
        defaults,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_12_decode(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_12_decode,
        const_str_plain_decode,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_eb5ba0b7e44a98324f539f14a326e09c,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_13___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_13___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_fd13000fe202a74bec55fd084fd66e0d,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_14___repr__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_14___repr__,
        const_str_plain___repr__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_413e0f150c7511019171d87e84c9a71e,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_15_get_unichr(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_15_get_unichr,
        const_str_plain_get_unichr,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_91864749e5c8ffe960570370a9df7181,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_16_dump( PyObject *defaults )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_16_dump,
        const_str_plain_dump,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_97fad3ef23a1d8553a58ab6f39e4d675,
        defaults,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_17_add_code2cid(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_17_add_code2cid,
        const_str_plain_add_code2cid,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_d45f9db8c770efe384eb416ddad3eb5f,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_18_add_cid2unichr(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_18_add_cid2unichr,
        const_str_plain_add_cid2unichr,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_b8a1a2ca42dca93d288657257f607fc7,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_19___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_19___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_a80f840bc8a1ed93b203ed21d320acaa,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_1___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_1___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_4241055d5ae190a4b1b81c41bc26fa03,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_20___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_20___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_393bff62988f703c8ec9fb622290849f,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_21__load_data(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_21__load_data,
        const_str_plain__load_data,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_e5e7e55f392592a385ee5efc197a73a2,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_22_get_cmap(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_22_get_cmap,
        const_str_plain_get_cmap,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_3689aab6f2005e7d6d6cba5bd05af69a,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_23_get_unicode_map( PyObject *defaults )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_23_get_unicode_map,
        const_str_plain_get_unicode_map,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_af28b21103770807e407a40fb3bd2b78,
        defaults,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_24___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_24___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_eda9792646615076f73a487c13258da9,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_25_run(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_25_run,
        const_str_plain_run,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_96b1bf7efd688a60a724ef5995c02a1a,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_26_do_keyword(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_26_do_keyword,
        const_str_plain_do_keyword,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_dde973ae2c181782bcfe319ce801f19b,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_27_main(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_27_main,
        const_str_plain_main,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_4470f8f74fc84dbe3ef6af9cb8351243,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_2_is_vertical(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_2_is_vertical,
        const_str_plain_is_vertical,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_84dce90dcac2146b7ab8208a1813e950,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_3_set_attr(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_3_set_attr,
        const_str_plain_set_attr,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_08a7366c7a58a32fd3a114d82e1cfb5f,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_4_add_code2cid(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_4_add_code2cid,
        const_str_plain_add_code2cid,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_39f92db23036c369bf860621db522420,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_5_add_cid2unichr(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_5_add_cid2unichr,
        const_str_plain_add_cid2unichr,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_448023be2082b765d13e992240c4a9c8,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_6_use_cmap(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_6_use_cmap,
        const_str_plain_use_cmap,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_36d9bc168446ebd066abe05baa90edb4,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_7___init__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_7___init__,
        const_str_plain___init__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_322e6ebbfec7df703f1414c055282bd3,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_8___repr__(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_8___repr__,
        const_str_plain___repr__,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_e12ef1341a3f4da82b81099a3fb28678,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_9_use_cmap,
        const_str_plain_use_cmap,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_cd9a0c5cca920731f1f4435051040467,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy( struct Nuitka_CellObject *closure_copy )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl_pdfminer$cmapdb$$$function_9_use_cmap$$$function_1_copy,
        const_str_plain_copy,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_51ae9cf5786f0e86ed5f528254011a18,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module_pdfminer$cmapdb,
        Py_None,
        1
    );

result->m_closure[0] = closure_copy;
Py_INCREF( result->m_closure[0] );

    return (PyObject *)result;
}



#if PYTHON_VERSION >= 300
static struct PyModuleDef mdef_pdfminer$cmapdb =
{
    PyModuleDef_HEAD_INIT,
    "pdfminer.cmapdb",   /* m_name */
    NULL,                /* m_doc */
    -1,                  /* m_size */
    NULL,                /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
  };
#endif

#if PYTHON_VERSION >= 300
extern PyObject *metapath_based_loader;
#endif
#if PYTHON_VERSION >= 330
extern PyObject *const_str_plain___loader__;
#endif

extern void _initCompiledCellType();
extern void _initCompiledGeneratorType();
extern void _initCompiledFunctionType();
extern void _initCompiledMethodType();
extern void _initCompiledFrameType();
#if PYTHON_VERSION >= 350
extern void _initCompiledCoroutineTypes();
#endif
#if PYTHON_VERSION >= 360
extern void _initCompiledAsyncgenTypes();
#endif

// The exported interface to CPython. On import of the module, this function
// gets called. It has to have an exact function name, in cases it's a shared
// library export. This is hidden behind the MOD_INIT_DECL.

MOD_INIT_DECL( pdfminer$cmapdb )
{
#if defined(_NUITKA_EXE) || PYTHON_VERSION >= 300
    static bool _init_done = false;

    // Modules might be imported repeatedly, which is to be ignored.
    if ( _init_done )
    {
        return MOD_RETURN_VALUE( module_pdfminer$cmapdb );
    }
    else
    {
        _init_done = true;
    }
#endif

#ifdef _NUITKA_MODULE
    // In case of a stand alone extension module, need to call initialization
    // the init here because that's the first and only time we are going to get
    // called here.

    // Initialize the constant values used.
    _initBuiltinModule();
    createGlobalConstants();

    /* Initialize the compiled types of Nuitka. */
    _initCompiledCellType();
    _initCompiledGeneratorType();
    _initCompiledFunctionType();
    _initCompiledMethodType();
    _initCompiledFrameType();
#if PYTHON_VERSION >= 350
    _initCompiledCoroutineTypes();
#endif
#if PYTHON_VERSION >= 360
    _initCompiledAsyncgenTypes();
#endif

#if PYTHON_VERSION < 300
    _initSlotCompare();
#endif
#if PYTHON_VERSION >= 270
    _initSlotIternext();
#endif

    patchBuiltinModule();
    patchTypeComparison();

    // Enable meta path based loader if not already done.
    setupMetaPathBasedLoader();

#if PYTHON_VERSION >= 300
    patchInspectModule();
#endif

#endif

    /* The constants only used by this module are created now. */
#ifdef _NUITKA_TRACE
    puts("pdfminer.cmapdb: Calling createModuleConstants().");
#endif
    createModuleConstants();

    /* The code objects used by this module are created now. */
#ifdef _NUITKA_TRACE
    puts("pdfminer.cmapdb: Calling createModuleCodeObjects().");
#endif
    createModuleCodeObjects();

    // puts( "in initpdfminer$cmapdb" );

    // Create the module object first. There are no methods initially, all are
    // added dynamically in actual code only.  Also no "__doc__" is initially
    // set at this time, as it could not contain NUL characters this way, they
    // are instead set in early module code.  No "self" for modules, we have no
    // use for it.
#if PYTHON_VERSION < 300
    module_pdfminer$cmapdb = Py_InitModule4(
        "pdfminer.cmapdb",       // Module Name
        NULL,                    // No methods initially, all are added
                                 // dynamically in actual module code only.
        NULL,                    // No __doc__ is initially set, as it could
                                 // not contain NUL this way, added early in
                                 // actual code.
        NULL,                    // No self for modules, we don't use it.
        PYTHON_API_VERSION
    );
#else
    module_pdfminer$cmapdb = PyModule_Create( &mdef_pdfminer$cmapdb );
#endif

    moduledict_pdfminer$cmapdb = MODULE_DICT( module_pdfminer$cmapdb );

    CHECK_OBJECT( module_pdfminer$cmapdb );

// Seems to work for Python2.7 out of the box, but for Python3, the module
// doesn't automatically enter "sys.modules", so do it manually.
#if PYTHON_VERSION >= 300
    {
        int r = PyObject_SetItem( PySys_GetObject( (char *)"modules" ), const_str_digest_a5f56e291553139a63a10626179e7804, module_pdfminer$cmapdb );

        assert( r != -1 );
    }
#endif

    // For deep importing of a module we need to have "__builtins__", so we set
    // it ourselves in the same way than CPython does. Note: This must be done
    // before the frame object is allocated, or else it may fail.

    if ( GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___builtins__ ) == NULL )
    {
        PyObject *value = (PyObject *)builtin_module;

        // Check if main module, not a dict then but the module itself.
#if !defined(_NUITKA_EXE) || !0
        value = PyModule_GetDict( value );
#endif

        UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___builtins__, value );
    }

#if PYTHON_VERSION >= 330
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___loader__, metapath_based_loader );
#endif

    // Temp variables if any
    PyObject *outline_0_var___module__ = NULL;
    PyObject *outline_1_var___module__ = NULL;
    PyObject *outline_1_var_debug = NULL;
    PyObject *outline_1_var___init__ = NULL;
    PyObject *outline_1_var_is_vertical = NULL;
    PyObject *outline_1_var_set_attr = NULL;
    PyObject *outline_1_var_add_code2cid = NULL;
    PyObject *outline_1_var_add_cid2unichr = NULL;
    PyObject *outline_1_var_use_cmap = NULL;
    PyObject *outline_2_var___module__ = NULL;
    PyObject *outline_2_var___init__ = NULL;
    PyObject *outline_2_var___repr__ = NULL;
    PyObject *outline_2_var_use_cmap = NULL;
    PyObject *outline_2_var_decode = NULL;
    PyObject *outline_2_var_dump = NULL;
    PyObject *outline_3_var___module__ = NULL;
    PyObject *outline_3_var_decode = NULL;
    PyObject *outline_4_var___module__ = NULL;
    PyObject *outline_4_var___init__ = NULL;
    PyObject *outline_4_var___repr__ = NULL;
    PyObject *outline_4_var_get_unichr = NULL;
    PyObject *outline_4_var_dump = NULL;
    PyObject *outline_5_var___module__ = NULL;
    PyObject *outline_5_var_add_code2cid = NULL;
    PyObject *outline_6_var___module__ = NULL;
    PyObject *outline_6_var_add_cid2unichr = NULL;
    PyObject *outline_7_var___module__ = NULL;
    PyObject *outline_7_var___init__ = NULL;
    PyObject *outline_8_var___module__ = NULL;
    PyObject *outline_8_var___init__ = NULL;
    PyObject *outline_9_var___module__ = NULL;
    PyObject *outline_9_var__cmap_cache = NULL;
    PyObject *outline_9_var__umap_cache = NULL;
    PyObject *outline_9_var_CMapNotFound = NULL;
    PyObject *outline_9_var__load_data = NULL;
    PyObject *outline_9_var_get_cmap = NULL;
    PyObject *outline_9_var_get_unicode_map = NULL;
    PyObject *outline_10_var___module__ = NULL;
    PyObject *outline_11_var___module__ = NULL;
    PyObject *outline_11_var___init__ = NULL;
    PyObject *outline_11_var_run = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINCMAP = NULL;
    PyObject *outline_11_var_KEYWORD_ENDCMAP = NULL;
    PyObject *outline_11_var_KEYWORD_USECMAP = NULL;
    PyObject *outline_11_var_KEYWORD_DEF = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINCODESPACERANGE = NULL;
    PyObject *outline_11_var_KEYWORD_ENDCODESPACERANGE = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINCIDRANGE = NULL;
    PyObject *outline_11_var_KEYWORD_ENDCIDRANGE = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINCIDCHAR = NULL;
    PyObject *outline_11_var_KEYWORD_ENDCIDCHAR = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINBFRANGE = NULL;
    PyObject *outline_11_var_KEYWORD_ENDBFRANGE = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINBFCHAR = NULL;
    PyObject *outline_11_var_KEYWORD_ENDBFCHAR = NULL;
    PyObject *outline_11_var_KEYWORD_BEGINNOTDEFRANGE = NULL;
    PyObject *outline_11_var_KEYWORD_ENDNOTDEFRANGE = NULL;
    PyObject *outline_11_var_do_keyword = NULL;
    PyObject *tmp_CMapDB$class_creation_1__bases = NULL;
    PyObject *tmp_CMapDB$class_creation_1__class = NULL;
    PyObject *tmp_CMapDB$class_creation_1__class_dict = NULL;
    PyObject *tmp_CMapDB$class_creation_1__metaclass = NULL;
    PyObject *tmp_CMapDB$select_metaclass_1__base = NULL;
    PyObject *tmp_class_creation_10__class = NULL;
    PyObject *tmp_class_creation_10__class_dict = NULL;
    PyObject *tmp_class_creation_10__metaclass = NULL;
    PyObject *tmp_class_creation_11__bases = NULL;
    PyObject *tmp_class_creation_11__class = NULL;
    PyObject *tmp_class_creation_11__class_dict = NULL;
    PyObject *tmp_class_creation_11__metaclass = NULL;
    PyObject *tmp_class_creation_1__bases = NULL;
    PyObject *tmp_class_creation_1__class = NULL;
    PyObject *tmp_class_creation_1__class_dict = NULL;
    PyObject *tmp_class_creation_1__metaclass = NULL;
    PyObject *tmp_class_creation_2__class = NULL;
    PyObject *tmp_class_creation_2__class_dict = NULL;
    PyObject *tmp_class_creation_2__metaclass = NULL;
    PyObject *tmp_class_creation_3__bases = NULL;
    PyObject *tmp_class_creation_3__class = NULL;
    PyObject *tmp_class_creation_3__class_dict = NULL;
    PyObject *tmp_class_creation_3__metaclass = NULL;
    PyObject *tmp_class_creation_4__bases = NULL;
    PyObject *tmp_class_creation_4__class = NULL;
    PyObject *tmp_class_creation_4__class_dict = NULL;
    PyObject *tmp_class_creation_4__metaclass = NULL;
    PyObject *tmp_class_creation_5__bases = NULL;
    PyObject *tmp_class_creation_5__class = NULL;
    PyObject *tmp_class_creation_5__class_dict = NULL;
    PyObject *tmp_class_creation_5__metaclass = NULL;
    PyObject *tmp_class_creation_6__bases = NULL;
    PyObject *tmp_class_creation_6__class = NULL;
    PyObject *tmp_class_creation_6__class_dict = NULL;
    PyObject *tmp_class_creation_6__metaclass = NULL;
    PyObject *tmp_class_creation_7__bases = NULL;
    PyObject *tmp_class_creation_7__class = NULL;
    PyObject *tmp_class_creation_7__class_dict = NULL;
    PyObject *tmp_class_creation_7__metaclass = NULL;
    PyObject *tmp_class_creation_8__bases = NULL;
    PyObject *tmp_class_creation_8__class = NULL;
    PyObject *tmp_class_creation_8__class_dict = NULL;
    PyObject *tmp_class_creation_8__metaclass = NULL;
    PyObject *tmp_class_creation_9__bases = NULL;
    PyObject *tmp_class_creation_9__class = NULL;
    PyObject *tmp_class_creation_9__class_dict = NULL;
    PyObject *tmp_class_creation_9__metaclass = NULL;
    PyObject *tmp_select_metaclass_11__base = NULL;
    PyObject *tmp_select_metaclass_1__base = NULL;
    PyObject *tmp_select_metaclass_3__base = NULL;
    PyObject *tmp_select_metaclass_4__base = NULL;
    PyObject *tmp_select_metaclass_5__base = NULL;
    PyObject *tmp_select_metaclass_6__base = NULL;
    PyObject *tmp_select_metaclass_7__base = NULL;
    PyObject *tmp_select_metaclass_8__base = NULL;
    PyObject *tmp_select_metaclass_9__base = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *exception_keeper_type_5;
    PyObject *exception_keeper_value_5;
    PyTracebackObject *exception_keeper_tb_5;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_5;
    PyObject *exception_keeper_type_6;
    PyObject *exception_keeper_value_6;
    PyTracebackObject *exception_keeper_tb_6;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_6;
    PyObject *exception_keeper_type_7;
    PyObject *exception_keeper_value_7;
    PyTracebackObject *exception_keeper_tb_7;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_7;
    PyObject *exception_keeper_type_8;
    PyObject *exception_keeper_value_8;
    PyTracebackObject *exception_keeper_tb_8;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_8;
    PyObject *exception_keeper_type_9;
    PyObject *exception_keeper_value_9;
    PyTracebackObject *exception_keeper_tb_9;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_9;
    PyObject *exception_keeper_type_10;
    PyObject *exception_keeper_value_10;
    PyTracebackObject *exception_keeper_tb_10;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_10;
    PyObject *exception_keeper_type_11;
    PyObject *exception_keeper_value_11;
    PyTracebackObject *exception_keeper_tb_11;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_11;
    PyObject *exception_keeper_type_12;
    PyObject *exception_keeper_value_12;
    PyTracebackObject *exception_keeper_tb_12;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_12;
    PyObject *exception_keeper_type_13;
    PyObject *exception_keeper_value_13;
    PyTracebackObject *exception_keeper_tb_13;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_13;
    PyObject *exception_keeper_type_14;
    PyObject *exception_keeper_value_14;
    PyTracebackObject *exception_keeper_tb_14;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_14;
    PyObject *exception_keeper_type_15;
    PyObject *exception_keeper_value_15;
    PyTracebackObject *exception_keeper_tb_15;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_15;
    PyObject *exception_keeper_type_16;
    PyObject *exception_keeper_value_16;
    PyTracebackObject *exception_keeper_tb_16;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_16;
    PyObject *exception_keeper_type_17;
    PyObject *exception_keeper_value_17;
    PyTracebackObject *exception_keeper_tb_17;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_17;
    PyObject *exception_keeper_type_18;
    PyObject *exception_keeper_value_18;
    PyTracebackObject *exception_keeper_tb_18;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_18;
    PyObject *exception_keeper_type_19;
    PyObject *exception_keeper_value_19;
    PyTracebackObject *exception_keeper_tb_19;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_19;
    PyObject *exception_keeper_type_20;
    PyObject *exception_keeper_value_20;
    PyTracebackObject *exception_keeper_tb_20;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_20;
    PyObject *exception_keeper_type_21;
    PyObject *exception_keeper_value_21;
    PyTracebackObject *exception_keeper_tb_21;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_21;
    PyObject *exception_keeper_type_22;
    PyObject *exception_keeper_value_22;
    PyTracebackObject *exception_keeper_tb_22;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_22;
    PyObject *exception_keeper_type_23;
    PyObject *exception_keeper_value_23;
    PyTracebackObject *exception_keeper_tb_23;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_23;
    PyObject *exception_keeper_type_24;
    PyObject *exception_keeper_value_24;
    PyTracebackObject *exception_keeper_tb_24;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_24;
    PyObject *exception_keeper_type_25;
    PyObject *exception_keeper_value_25;
    PyTracebackObject *exception_keeper_tb_25;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_25;
    PyObject *exception_keeper_type_26;
    PyObject *exception_keeper_value_26;
    PyTracebackObject *exception_keeper_tb_26;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_26;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_args_element_name_5;
    PyObject *tmp_args_element_name_6;
    PyObject *tmp_args_element_name_7;
    PyObject *tmp_args_element_name_8;
    PyObject *tmp_args_element_name_9;
    PyObject *tmp_args_element_name_10;
    PyObject *tmp_args_element_name_11;
    PyObject *tmp_args_element_name_12;
    PyObject *tmp_args_element_name_13;
    PyObject *tmp_args_element_name_14;
    PyObject *tmp_args_element_name_15;
    PyObject *tmp_args_element_name_16;
    PyObject *tmp_args_element_name_17;
    PyObject *tmp_args_element_name_18;
    PyObject *tmp_args_element_name_19;
    PyObject *tmp_args_element_name_20;
    PyObject *tmp_args_element_name_21;
    PyObject *tmp_args_element_name_22;
    PyObject *tmp_args_element_name_23;
    PyObject *tmp_args_element_name_24;
    PyObject *tmp_args_element_name_25;
    PyObject *tmp_args_element_name_26;
    PyObject *tmp_args_element_name_27;
    PyObject *tmp_args_element_name_28;
    PyObject *tmp_args_element_name_29;
    PyObject *tmp_args_element_name_30;
    PyObject *tmp_args_element_name_31;
    PyObject *tmp_args_element_name_32;
    PyObject *tmp_args_element_name_33;
    PyObject *tmp_args_element_name_34;
    PyObject *tmp_args_element_name_35;
    PyObject *tmp_args_element_name_36;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    PyObject *tmp_assign_source_10;
    PyObject *tmp_assign_source_11;
    PyObject *tmp_assign_source_12;
    PyObject *tmp_assign_source_13;
    PyObject *tmp_assign_source_14;
    PyObject *tmp_assign_source_15;
    PyObject *tmp_assign_source_16;
    PyObject *tmp_assign_source_17;
    PyObject *tmp_assign_source_18;
    PyObject *tmp_assign_source_19;
    PyObject *tmp_assign_source_20;
    PyObject *tmp_assign_source_21;
    PyObject *tmp_assign_source_22;
    PyObject *tmp_assign_source_23;
    PyObject *tmp_assign_source_24;
    PyObject *tmp_assign_source_25;
    PyObject *tmp_assign_source_26;
    PyObject *tmp_assign_source_27;
    PyObject *tmp_assign_source_28;
    PyObject *tmp_assign_source_29;
    PyObject *tmp_assign_source_30;
    PyObject *tmp_assign_source_31;
    PyObject *tmp_assign_source_32;
    PyObject *tmp_assign_source_33;
    PyObject *tmp_assign_source_34;
    PyObject *tmp_assign_source_35;
    PyObject *tmp_assign_source_36;
    PyObject *tmp_assign_source_37;
    PyObject *tmp_assign_source_38;
    PyObject *tmp_assign_source_39;
    PyObject *tmp_assign_source_40;
    PyObject *tmp_assign_source_41;
    PyObject *tmp_assign_source_42;
    PyObject *tmp_assign_source_43;
    PyObject *tmp_assign_source_44;
    PyObject *tmp_assign_source_45;
    PyObject *tmp_assign_source_46;
    PyObject *tmp_assign_source_47;
    PyObject *tmp_assign_source_48;
    PyObject *tmp_assign_source_49;
    PyObject *tmp_assign_source_50;
    PyObject *tmp_assign_source_51;
    PyObject *tmp_assign_source_52;
    PyObject *tmp_assign_source_53;
    PyObject *tmp_assign_source_54;
    PyObject *tmp_assign_source_55;
    PyObject *tmp_assign_source_56;
    PyObject *tmp_assign_source_57;
    PyObject *tmp_assign_source_58;
    PyObject *tmp_assign_source_59;
    PyObject *tmp_assign_source_60;
    PyObject *tmp_assign_source_61;
    PyObject *tmp_assign_source_62;
    PyObject *tmp_assign_source_63;
    PyObject *tmp_assign_source_64;
    PyObject *tmp_assign_source_65;
    PyObject *tmp_assign_source_66;
    PyObject *tmp_assign_source_67;
    PyObject *tmp_assign_source_68;
    PyObject *tmp_assign_source_69;
    PyObject *tmp_assign_source_70;
    PyObject *tmp_assign_source_71;
    PyObject *tmp_assign_source_72;
    PyObject *tmp_assign_source_73;
    PyObject *tmp_assign_source_74;
    PyObject *tmp_assign_source_75;
    PyObject *tmp_assign_source_76;
    PyObject *tmp_assign_source_77;
    PyObject *tmp_assign_source_78;
    PyObject *tmp_assign_source_79;
    PyObject *tmp_assign_source_80;
    PyObject *tmp_assign_source_81;
    PyObject *tmp_assign_source_82;
    PyObject *tmp_assign_source_83;
    PyObject *tmp_assign_source_84;
    PyObject *tmp_assign_source_85;
    PyObject *tmp_assign_source_86;
    PyObject *tmp_assign_source_87;
    PyObject *tmp_assign_source_88;
    PyObject *tmp_assign_source_89;
    PyObject *tmp_assign_source_90;
    PyObject *tmp_assign_source_91;
    PyObject *tmp_assign_source_92;
    PyObject *tmp_assign_source_93;
    PyObject *tmp_assign_source_94;
    PyObject *tmp_assign_source_95;
    PyObject *tmp_assign_source_96;
    PyObject *tmp_assign_source_97;
    PyObject *tmp_assign_source_98;
    PyObject *tmp_assign_source_99;
    PyObject *tmp_assign_source_100;
    PyObject *tmp_assign_source_101;
    PyObject *tmp_assign_source_102;
    PyObject *tmp_assign_source_103;
    PyObject *tmp_assign_source_104;
    PyObject *tmp_assign_source_105;
    PyObject *tmp_assign_source_106;
    PyObject *tmp_assign_source_107;
    PyObject *tmp_assign_source_108;
    PyObject *tmp_assign_source_109;
    PyObject *tmp_assign_source_110;
    PyObject *tmp_assign_source_111;
    PyObject *tmp_assign_source_112;
    PyObject *tmp_assign_source_113;
    PyObject *tmp_assign_source_114;
    PyObject *tmp_assign_source_115;
    PyObject *tmp_assign_source_116;
    PyObject *tmp_assign_source_117;
    PyObject *tmp_assign_source_118;
    PyObject *tmp_assign_source_119;
    PyObject *tmp_assign_source_120;
    PyObject *tmp_assign_source_121;
    PyObject *tmp_assign_source_122;
    PyObject *tmp_assign_source_123;
    PyObject *tmp_assign_source_124;
    PyObject *tmp_assign_source_125;
    PyObject *tmp_assign_source_126;
    PyObject *tmp_assign_source_127;
    PyObject *tmp_assign_source_128;
    PyObject *tmp_assign_source_129;
    PyObject *tmp_assign_source_130;
    PyObject *tmp_assign_source_131;
    PyObject *tmp_assign_source_132;
    PyObject *tmp_assign_source_133;
    PyObject *tmp_assign_source_134;
    PyObject *tmp_assign_source_135;
    PyObject *tmp_assign_source_136;
    PyObject *tmp_assign_source_137;
    PyObject *tmp_assign_source_138;
    PyObject *tmp_assign_source_139;
    PyObject *tmp_assign_source_140;
    PyObject *tmp_assign_source_141;
    PyObject *tmp_assign_source_142;
    PyObject *tmp_assign_source_143;
    PyObject *tmp_assign_source_144;
    PyObject *tmp_assign_source_145;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_called_name_4;
    PyObject *tmp_called_name_5;
    PyObject *tmp_called_name_6;
    PyObject *tmp_called_name_7;
    PyObject *tmp_called_name_8;
    PyObject *tmp_called_name_9;
    PyObject *tmp_called_name_10;
    PyObject *tmp_called_name_11;
    PyObject *tmp_called_name_12;
    PyObject *tmp_called_name_13;
    PyObject *tmp_called_name_14;
    PyObject *tmp_called_name_15;
    PyObject *tmp_called_name_16;
    PyObject *tmp_called_name_17;
    PyObject *tmp_called_name_18;
    PyObject *tmp_called_name_19;
    PyObject *tmp_called_name_20;
    PyObject *tmp_called_name_21;
    PyObject *tmp_called_name_22;
    PyObject *tmp_called_name_23;
    PyObject *tmp_called_name_24;
    PyObject *tmp_called_name_25;
    PyObject *tmp_called_name_26;
    PyObject *tmp_called_name_27;
    PyObject *tmp_called_name_28;
    PyObject *tmp_classmethod_arg_1;
    PyObject *tmp_classmethod_arg_2;
    PyObject *tmp_classmethod_arg_3;
    int tmp_cmp_In_1;
    int tmp_cmp_In_2;
    int tmp_cmp_In_3;
    int tmp_cmp_In_4;
    int tmp_cmp_In_5;
    int tmp_cmp_In_6;
    int tmp_cmp_In_7;
    int tmp_cmp_In_8;
    int tmp_cmp_In_9;
    int tmp_cmp_In_10;
    int tmp_cmp_In_11;
    int tmp_cmp_In_12;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_left_2;
    PyObject *tmp_compare_left_3;
    PyObject *tmp_compare_left_4;
    PyObject *tmp_compare_left_5;
    PyObject *tmp_compare_left_6;
    PyObject *tmp_compare_left_7;
    PyObject *tmp_compare_left_8;
    PyObject *tmp_compare_left_9;
    PyObject *tmp_compare_left_10;
    PyObject *tmp_compare_left_11;
    PyObject *tmp_compare_left_12;
    PyObject *tmp_compare_right_1;
    PyObject *tmp_compare_right_2;
    PyObject *tmp_compare_right_3;
    PyObject *tmp_compare_right_4;
    PyObject *tmp_compare_right_5;
    PyObject *tmp_compare_right_6;
    PyObject *tmp_compare_right_7;
    PyObject *tmp_compare_right_8;
    PyObject *tmp_compare_right_9;
    PyObject *tmp_compare_right_10;
    PyObject *tmp_compare_right_11;
    PyObject *tmp_compare_right_12;
    PyObject *tmp_defaults_1;
    PyObject *tmp_defaults_2;
    PyObject *tmp_defaults_3;
    PyObject *tmp_dict_key_1;
    PyObject *tmp_dict_key_2;
    PyObject *tmp_dict_key_3;
    PyObject *tmp_dict_key_4;
    PyObject *tmp_dict_key_5;
    PyObject *tmp_dict_key_6;
    PyObject *tmp_dict_key_7;
    PyObject *tmp_dict_key_8;
    PyObject *tmp_dict_key_9;
    PyObject *tmp_dict_key_10;
    PyObject *tmp_dict_key_11;
    PyObject *tmp_dict_key_12;
    PyObject *tmp_dict_key_13;
    PyObject *tmp_dict_key_14;
    PyObject *tmp_dict_key_15;
    PyObject *tmp_dict_key_16;
    PyObject *tmp_dict_key_17;
    PyObject *tmp_dict_key_18;
    PyObject *tmp_dict_key_19;
    PyObject *tmp_dict_key_20;
    PyObject *tmp_dict_key_21;
    PyObject *tmp_dict_key_22;
    PyObject *tmp_dict_key_23;
    PyObject *tmp_dict_key_24;
    PyObject *tmp_dict_key_25;
    PyObject *tmp_dict_key_26;
    PyObject *tmp_dict_key_27;
    PyObject *tmp_dict_key_28;
    PyObject *tmp_dict_key_29;
    PyObject *tmp_dict_key_30;
    PyObject *tmp_dict_key_31;
    PyObject *tmp_dict_key_32;
    PyObject *tmp_dict_key_33;
    PyObject *tmp_dict_key_34;
    PyObject *tmp_dict_key_35;
    PyObject *tmp_dict_key_36;
    PyObject *tmp_dict_key_37;
    PyObject *tmp_dict_key_38;
    PyObject *tmp_dict_key_39;
    PyObject *tmp_dict_key_40;
    PyObject *tmp_dict_key_41;
    PyObject *tmp_dict_key_42;
    PyObject *tmp_dict_key_43;
    PyObject *tmp_dict_key_44;
    PyObject *tmp_dict_key_45;
    PyObject *tmp_dict_key_46;
    PyObject *tmp_dict_key_47;
    PyObject *tmp_dict_key_48;
    PyObject *tmp_dict_key_49;
    PyObject *tmp_dict_key_50;
    PyObject *tmp_dict_key_51;
    PyObject *tmp_dict_key_52;
    PyObject *tmp_dict_key_53;
    PyObject *tmp_dict_key_54;
    PyObject *tmp_dict_key_55;
    PyObject *tmp_dict_key_56;
    PyObject *tmp_dict_key_57;
    PyObject *tmp_dict_key_58;
    PyObject *tmp_dict_name_1;
    PyObject *tmp_dict_name_2;
    PyObject *tmp_dict_name_3;
    PyObject *tmp_dict_name_4;
    PyObject *tmp_dict_name_5;
    PyObject *tmp_dict_name_6;
    PyObject *tmp_dict_name_7;
    PyObject *tmp_dict_name_8;
    PyObject *tmp_dict_name_9;
    PyObject *tmp_dict_name_10;
    PyObject *tmp_dict_name_11;
    PyObject *tmp_dict_name_12;
    PyObject *tmp_dict_value_1;
    PyObject *tmp_dict_value_2;
    PyObject *tmp_dict_value_3;
    PyObject *tmp_dict_value_4;
    PyObject *tmp_dict_value_5;
    PyObject *tmp_dict_value_6;
    PyObject *tmp_dict_value_7;
    PyObject *tmp_dict_value_8;
    PyObject *tmp_dict_value_9;
    PyObject *tmp_dict_value_10;
    PyObject *tmp_dict_value_11;
    PyObject *tmp_dict_value_12;
    PyObject *tmp_dict_value_13;
    PyObject *tmp_dict_value_14;
    PyObject *tmp_dict_value_15;
    PyObject *tmp_dict_value_16;
    PyObject *tmp_dict_value_17;
    PyObject *tmp_dict_value_18;
    PyObject *tmp_dict_value_19;
    PyObject *tmp_dict_value_20;
    PyObject *tmp_dict_value_21;
    PyObject *tmp_dict_value_22;
    PyObject *tmp_dict_value_23;
    PyObject *tmp_dict_value_24;
    PyObject *tmp_dict_value_25;
    PyObject *tmp_dict_value_26;
    PyObject *tmp_dict_value_27;
    PyObject *tmp_dict_value_28;
    PyObject *tmp_dict_value_29;
    PyObject *tmp_dict_value_30;
    PyObject *tmp_dict_value_31;
    PyObject *tmp_dict_value_32;
    PyObject *tmp_dict_value_33;
    PyObject *tmp_dict_value_34;
    PyObject *tmp_dict_value_35;
    PyObject *tmp_dict_value_36;
    PyObject *tmp_dict_value_37;
    PyObject *tmp_dict_value_38;
    PyObject *tmp_dict_value_39;
    PyObject *tmp_dict_value_40;
    PyObject *tmp_dict_value_41;
    PyObject *tmp_dict_value_42;
    PyObject *tmp_dict_value_43;
    PyObject *tmp_dict_value_44;
    PyObject *tmp_dict_value_45;
    PyObject *tmp_dict_value_46;
    PyObject *tmp_dict_value_47;
    PyObject *tmp_dict_value_48;
    PyObject *tmp_dict_value_49;
    PyObject *tmp_dict_value_50;
    PyObject *tmp_dict_value_51;
    PyObject *tmp_dict_value_52;
    PyObject *tmp_dict_value_53;
    PyObject *tmp_dict_value_54;
    PyObject *tmp_dict_value_55;
    PyObject *tmp_dict_value_56;
    PyObject *tmp_dict_value_57;
    PyObject *tmp_dict_value_58;
    PyObject *tmp_fromlist_name_1;
    PyObject *tmp_fromlist_name_2;
    PyObject *tmp_fromlist_name_3;
    PyObject *tmp_fromlist_name_4;
    PyObject *tmp_fromlist_name_5;
    PyObject *tmp_fromlist_name_6;
    PyObject *tmp_fromlist_name_7;
    PyObject *tmp_fromlist_name_8;
    PyObject *tmp_fromlist_name_9;
    PyObject *tmp_fromlist_name_10;
    PyObject *tmp_fromlist_name_11;
    PyObject *tmp_fromlist_name_12;
    PyObject *tmp_fromlist_name_13;
    PyObject *tmp_fromlist_name_14;
    PyObject *tmp_fromlist_name_15;
    PyObject *tmp_fromlist_name_16;
    PyObject *tmp_globals_name_1;
    PyObject *tmp_globals_name_2;
    PyObject *tmp_globals_name_3;
    PyObject *tmp_globals_name_4;
    PyObject *tmp_globals_name_5;
    PyObject *tmp_globals_name_6;
    PyObject *tmp_globals_name_7;
    PyObject *tmp_globals_name_8;
    PyObject *tmp_globals_name_9;
    PyObject *tmp_globals_name_10;
    PyObject *tmp_globals_name_11;
    PyObject *tmp_globals_name_12;
    PyObject *tmp_globals_name_13;
    PyObject *tmp_globals_name_14;
    PyObject *tmp_globals_name_15;
    PyObject *tmp_globals_name_16;
    PyObject *tmp_import_name_from_1;
    PyObject *tmp_import_name_from_2;
    PyObject *tmp_import_name_from_3;
    PyObject *tmp_import_name_from_4;
    PyObject *tmp_import_name_from_5;
    PyObject *tmp_import_name_from_6;
    PyObject *tmp_import_name_from_7;
    PyObject *tmp_import_name_from_8;
    PyObject *tmp_import_name_from_9;
    PyObject *tmp_key_name_1;
    PyObject *tmp_key_name_2;
    PyObject *tmp_key_name_3;
    PyObject *tmp_key_name_4;
    PyObject *tmp_key_name_5;
    PyObject *tmp_key_name_6;
    PyObject *tmp_key_name_7;
    PyObject *tmp_key_name_8;
    PyObject *tmp_key_name_9;
    PyObject *tmp_key_name_10;
    PyObject *tmp_key_name_11;
    PyObject *tmp_key_name_12;
    PyObject *tmp_level_name_8;
    PyObject *tmp_level_name_9;
    PyObject *tmp_level_name_10;
    PyObject *tmp_level_name_11;
    PyObject *tmp_level_name_12;
    PyObject *tmp_level_name_13;
    PyObject *tmp_level_name_14;
    PyObject *tmp_level_name_15;
    PyObject *tmp_level_name_16;
    PyObject *tmp_locals_name_1;
    PyObject *tmp_locals_name_2;
    PyObject *tmp_locals_name_3;
    PyObject *tmp_locals_name_4;
    PyObject *tmp_locals_name_5;
    PyObject *tmp_locals_name_6;
    PyObject *tmp_locals_name_7;
    PyObject *tmp_locals_name_8;
    PyObject *tmp_locals_name_9;
    PyObject *tmp_locals_name_10;
    PyObject *tmp_locals_name_11;
    PyObject *tmp_locals_name_12;
    PyObject *tmp_locals_name_13;
    PyObject *tmp_locals_name_14;
    PyObject *tmp_locals_name_15;
    PyObject *tmp_locals_name_16;
    PyObject *tmp_name_name_1;
    PyObject *tmp_name_name_2;
    PyObject *tmp_name_name_3;
    PyObject *tmp_name_name_4;
    PyObject *tmp_name_name_5;
    PyObject *tmp_name_name_6;
    PyObject *tmp_name_name_7;
    PyObject *tmp_name_name_8;
    PyObject *tmp_name_name_9;
    PyObject *tmp_name_name_10;
    PyObject *tmp_name_name_11;
    PyObject *tmp_name_name_12;
    PyObject *tmp_name_name_13;
    PyObject *tmp_name_name_14;
    PyObject *tmp_name_name_15;
    PyObject *tmp_name_name_16;
    PyObject *tmp_outline_return_value_1;
    PyObject *tmp_outline_return_value_2;
    PyObject *tmp_outline_return_value_3;
    PyObject *tmp_outline_return_value_4;
    PyObject *tmp_outline_return_value_5;
    PyObject *tmp_outline_return_value_6;
    PyObject *tmp_outline_return_value_7;
    PyObject *tmp_outline_return_value_8;
    PyObject *tmp_outline_return_value_9;
    PyObject *tmp_outline_return_value_10;
    PyObject *tmp_outline_return_value_11;
    PyObject *tmp_outline_return_value_12;
    PyObject *tmp_outline_return_value_13;
    PyObject *tmp_outline_return_value_14;
    PyObject *tmp_outline_return_value_15;
    PyObject *tmp_outline_return_value_16;
    PyObject *tmp_outline_return_value_17;
    PyObject *tmp_outline_return_value_18;
    PyObject *tmp_outline_return_value_19;
    PyObject *tmp_outline_return_value_20;
    PyObject *tmp_outline_return_value_21;
    PyObject *tmp_outline_return_value_22;
    int tmp_res;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_source_name_6;
    PyObject *tmp_source_name_7;
    PyObject *tmp_source_name_8;
    PyObject *tmp_source_name_9;
    PyObject *tmp_source_name_10;
    PyObject *tmp_source_name_11;
    PyObject *tmp_source_name_12;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscribed_name_2;
    PyObject *tmp_subscribed_name_3;
    PyObject *tmp_subscribed_name_4;
    PyObject *tmp_subscribed_name_5;
    PyObject *tmp_subscribed_name_6;
    PyObject *tmp_subscribed_name_7;
    PyObject *tmp_subscribed_name_8;
    PyObject *tmp_subscribed_name_9;
    PyObject *tmp_subscribed_name_10;
    PyObject *tmp_subscript_name_1;
    PyObject *tmp_subscript_name_2;
    PyObject *tmp_subscript_name_3;
    PyObject *tmp_subscript_name_4;
    PyObject *tmp_subscript_name_5;
    PyObject *tmp_subscript_name_6;
    PyObject *tmp_subscript_name_7;
    PyObject *tmp_subscript_name_8;
    PyObject *tmp_subscript_name_9;
    PyObject *tmp_subscript_name_10;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_tuple_element_2;
    PyObject *tmp_tuple_element_3;
    PyObject *tmp_tuple_element_4;
    PyObject *tmp_tuple_element_5;
    PyObject *tmp_tuple_element_6;
    PyObject *tmp_tuple_element_7;
    PyObject *tmp_tuple_element_8;
    PyObject *tmp_tuple_element_9;
    PyObject *tmp_tuple_element_10;
    PyObject *tmp_tuple_element_11;
    PyObject *tmp_tuple_element_12;
    PyObject *tmp_type_arg_1;
    PyObject *tmp_type_arg_2;
    PyObject *tmp_type_arg_3;
    PyObject *tmp_type_arg_4;
    PyObject *tmp_type_arg_5;
    PyObject *tmp_type_arg_6;
    PyObject *tmp_type_arg_7;
    PyObject *tmp_type_arg_8;
    PyObject *tmp_type_arg_9;
    PyObject *tmp_type_arg_10;
    static struct Nuitka_FrameObject *cache_frame_1bcd1bf519e2b38557d857744ff7938c_2 = NULL;

    struct Nuitka_FrameObject *frame_1bcd1bf519e2b38557d857744ff7938c_2;

    static struct Nuitka_FrameObject *cache_frame_6e3884fccc459a164677932fec301eae_3 = NULL;

    struct Nuitka_FrameObject *frame_6e3884fccc459a164677932fec301eae_3;

    static struct Nuitka_FrameObject *cache_frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 = NULL;

    struct Nuitka_FrameObject *frame_e27dfacafd4f0c6cafc37ccc00e56d00_4;

    static struct Nuitka_FrameObject *cache_frame_70c765a79ededee6fac819da4b485742_5 = NULL;

    struct Nuitka_FrameObject *frame_70c765a79ededee6fac819da4b485742_5;

    struct Nuitka_FrameObject *frame_453c250602a3594a72d093020d99368b;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    NUITKA_MAY_BE_UNUSED char const *type_description_2 = NULL;
    NUITKA_MAY_BE_UNUSED char const *type_description_3 = NULL;
    NUITKA_MAY_BE_UNUSED char const *type_description_4 = NULL;
    NUITKA_MAY_BE_UNUSED char const *type_description_5 = NULL;
    tmp_outline_return_value_1 = NULL;
    tmp_outline_return_value_2 = NULL;
    tmp_outline_return_value_3 = NULL;
    tmp_outline_return_value_4 = NULL;
    tmp_outline_return_value_5 = NULL;
    tmp_outline_return_value_6 = NULL;
    tmp_outline_return_value_7 = NULL;
    tmp_outline_return_value_8 = NULL;
    tmp_outline_return_value_9 = NULL;
    tmp_outline_return_value_10 = NULL;
    tmp_outline_return_value_11 = NULL;
    tmp_outline_return_value_12 = NULL;
    tmp_outline_return_value_13 = NULL;
    tmp_outline_return_value_14 = NULL;
    tmp_outline_return_value_15 = NULL;
    tmp_outline_return_value_16 = NULL;
    tmp_outline_return_value_17 = NULL;
    tmp_outline_return_value_18 = NULL;
    tmp_outline_return_value_19 = NULL;
    tmp_outline_return_value_20 = NULL;
    tmp_outline_return_value_21 = NULL;
    tmp_outline_return_value_22 = NULL;

    // Module code.
    tmp_assign_source_1 = const_str_digest_eeb22152564a9374d5ef8cadef0c46d0;
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___doc__, tmp_assign_source_1 );
    tmp_assign_source_2 = const_str_digest_9320efa7add6853c7ceff8f829714204;
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___file__, tmp_assign_source_2 );
    tmp_assign_source_3 = Py_None;
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain___package__, tmp_assign_source_3 );
    tmp_name_name_1 = const_str_plain_sys;
    tmp_globals_name_1 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_1 = Py_None;
    tmp_fromlist_name_1 = Py_None;
    tmp_assign_source_4 = IMPORT_MODULE4( tmp_name_name_1, tmp_globals_name_1, tmp_locals_name_1, tmp_fromlist_name_1 );
    assert( tmp_assign_source_4 != NULL );
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_sys, tmp_assign_source_4 );
    // Frame without reuse.
    frame_453c250602a3594a72d093020d99368b = MAKE_MODULE_FRAME( codeobj_453c250602a3594a72d093020d99368b, module_pdfminer$cmapdb );

    // Push the new frame as the currently active one, and we should be exclusively
    // owning it.
    pushFrameStack( frame_453c250602a3594a72d093020d99368b );
    assert( Py_REFCNT( frame_453c250602a3594a72d093020d99368b ) == 2 );

    // Framed code:
    tmp_name_name_2 = const_str_plain_os;
    tmp_globals_name_2 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_2 = Py_None;
    tmp_fromlist_name_2 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 15;
    tmp_assign_source_5 = IMPORT_MODULE4( tmp_name_name_2, tmp_globals_name_2, tmp_locals_name_2, tmp_fromlist_name_2 );
    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 15;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os, tmp_assign_source_5 );
    tmp_name_name_3 = const_str_digest_e399ba4554180f37de594a6743234f17;
    tmp_globals_name_3 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_3 = Py_None;
    tmp_fromlist_name_3 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 16;
    tmp_assign_source_6 = IMPORT_MODULE4( tmp_name_name_3, tmp_globals_name_3, tmp_locals_name_3, tmp_fromlist_name_3 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 16;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_os, tmp_assign_source_6 );
    tmp_name_name_4 = const_str_plain_gzip;
    tmp_globals_name_4 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_4 = Py_None;
    tmp_fromlist_name_4 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 17;
    tmp_assign_source_7 = IMPORT_MODULE4( tmp_name_name_4, tmp_globals_name_4, tmp_locals_name_4, tmp_fromlist_name_4 );
    if ( tmp_assign_source_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 17;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_gzip, tmp_assign_source_7 );
    tmp_name_name_5 = const_str_plain_cPickle;
    tmp_globals_name_5 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_5 = Py_None;
    tmp_fromlist_name_5 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 19;
    tmp_assign_source_8 = IMPORT_MODULE4( tmp_name_name_5, tmp_globals_name_5, tmp_locals_name_5, tmp_fromlist_name_5 );
    assert( tmp_assign_source_8 != NULL );
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_pickle, tmp_assign_source_8 );
    tmp_name_name_6 = const_str_plain_struct;
    tmp_globals_name_6 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_6 = Py_None;
    tmp_fromlist_name_6 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 22;
    tmp_assign_source_9 = IMPORT_MODULE4( tmp_name_name_6, tmp_globals_name_6, tmp_locals_name_6, tmp_fromlist_name_6 );
    if ( tmp_assign_source_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 22;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_struct, tmp_assign_source_9 );
    tmp_name_name_7 = const_str_plain_logging;
    tmp_globals_name_7 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_7 = Py_None;
    tmp_fromlist_name_7 = Py_None;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 23;
    tmp_assign_source_10 = IMPORT_MODULE4( tmp_name_name_7, tmp_globals_name_7, tmp_locals_name_7, tmp_fromlist_name_7 );
    if ( tmp_assign_source_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 23;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_logging, tmp_assign_source_10 );
    tmp_name_name_8 = const_str_plain_psparser;
    tmp_globals_name_8 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_8 = Py_None;
    tmp_fromlist_name_8 = const_tuple_str_plain_PSStackParser_tuple;
    tmp_level_name_8 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 24;
    tmp_import_name_from_1 = IMPORT_MODULE5( tmp_name_name_8, tmp_globals_name_8, tmp_locals_name_8, tmp_fromlist_name_8, tmp_level_name_8 );
    if ( tmp_import_name_from_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 24;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_11 = IMPORT_NAME( tmp_import_name_from_1, const_str_plain_PSStackParser );
    Py_DECREF( tmp_import_name_from_1 );
    if ( tmp_assign_source_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 24;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSStackParser, tmp_assign_source_11 );
    tmp_name_name_9 = const_str_plain_psparser;
    tmp_globals_name_9 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_9 = Py_None;
    tmp_fromlist_name_9 = const_tuple_str_plain_PSSyntaxError_tuple;
    tmp_level_name_9 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 25;
    tmp_import_name_from_2 = IMPORT_MODULE5( tmp_name_name_9, tmp_globals_name_9, tmp_locals_name_9, tmp_fromlist_name_9, tmp_level_name_9 );
    if ( tmp_import_name_from_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 25;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_12 = IMPORT_NAME( tmp_import_name_from_2, const_str_plain_PSSyntaxError );
    Py_DECREF( tmp_import_name_from_2 );
    if ( tmp_assign_source_12 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 25;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSSyntaxError, tmp_assign_source_12 );
    tmp_name_name_10 = const_str_plain_psparser;
    tmp_globals_name_10 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_10 = Py_None;
    tmp_fromlist_name_10 = const_tuple_str_plain_PSEOF_tuple;
    tmp_level_name_10 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 26;
    tmp_import_name_from_3 = IMPORT_MODULE5( tmp_name_name_10, tmp_globals_name_10, tmp_locals_name_10, tmp_fromlist_name_10, tmp_level_name_10 );
    if ( tmp_import_name_from_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 26;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_13 = IMPORT_NAME( tmp_import_name_from_3, const_str_plain_PSEOF );
    Py_DECREF( tmp_import_name_from_3 );
    if ( tmp_assign_source_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 26;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSEOF, tmp_assign_source_13 );
    tmp_name_name_11 = const_str_plain_psparser;
    tmp_globals_name_11 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_11 = Py_None;
    tmp_fromlist_name_11 = const_tuple_str_plain_PSLiteral_tuple;
    tmp_level_name_11 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 27;
    tmp_import_name_from_4 = IMPORT_MODULE5( tmp_name_name_11, tmp_globals_name_11, tmp_locals_name_11, tmp_fromlist_name_11, tmp_level_name_11 );
    if ( tmp_import_name_from_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 27;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_14 = IMPORT_NAME( tmp_import_name_from_4, const_str_plain_PSLiteral );
    Py_DECREF( tmp_import_name_from_4 );
    if ( tmp_assign_source_14 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 27;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSLiteral, tmp_assign_source_14 );
    tmp_name_name_12 = const_str_plain_psparser;
    tmp_globals_name_12 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_12 = Py_None;
    tmp_fromlist_name_12 = const_tuple_str_plain_literal_name_tuple;
    tmp_level_name_12 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 28;
    tmp_import_name_from_5 = IMPORT_MODULE5( tmp_name_name_12, tmp_globals_name_12, tmp_locals_name_12, tmp_fromlist_name_12, tmp_level_name_12 );
    if ( tmp_import_name_from_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 28;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_15 = IMPORT_NAME( tmp_import_name_from_5, const_str_plain_literal_name );
    Py_DECREF( tmp_import_name_from_5 );
    if ( tmp_assign_source_15 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 28;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_literal_name, tmp_assign_source_15 );
    tmp_name_name_13 = const_str_plain_psparser;
    tmp_globals_name_13 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_13 = Py_None;
    tmp_fromlist_name_13 = const_tuple_str_plain_KWD_tuple;
    tmp_level_name_13 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 29;
    tmp_import_name_from_6 = IMPORT_MODULE5( tmp_name_name_13, tmp_globals_name_13, tmp_locals_name_13, tmp_fromlist_name_13, tmp_level_name_13 );
    if ( tmp_import_name_from_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 29;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_16 = IMPORT_NAME( tmp_import_name_from_6, const_str_plain_KWD );
    Py_DECREF( tmp_import_name_from_6 );
    if ( tmp_assign_source_16 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 29;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD, tmp_assign_source_16 );
    tmp_name_name_14 = const_str_plain_encodingdb;
    tmp_globals_name_14 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_14 = Py_None;
    tmp_fromlist_name_14 = const_tuple_str_plain_name2unicode_tuple;
    tmp_level_name_14 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 30;
    tmp_import_name_from_7 = IMPORT_MODULE5( tmp_name_name_14, tmp_globals_name_14, tmp_locals_name_14, tmp_fromlist_name_14, tmp_level_name_14 );
    if ( tmp_import_name_from_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 30;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_17 = IMPORT_NAME( tmp_import_name_from_7, const_str_plain_name2unicode );
    Py_DECREF( tmp_import_name_from_7 );
    if ( tmp_assign_source_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 30;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_name2unicode, tmp_assign_source_17 );
    tmp_name_name_15 = const_str_plain_utils;
    tmp_globals_name_15 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_15 = Py_None;
    tmp_fromlist_name_15 = const_tuple_str_plain_choplist_tuple;
    tmp_level_name_15 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 31;
    tmp_import_name_from_8 = IMPORT_MODULE5( tmp_name_name_15, tmp_globals_name_15, tmp_locals_name_15, tmp_fromlist_name_15, tmp_level_name_15 );
    if ( tmp_import_name_from_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 31;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_18 = IMPORT_NAME( tmp_import_name_from_8, const_str_plain_choplist );
    Py_DECREF( tmp_import_name_from_8 );
    if ( tmp_assign_source_18 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 31;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_choplist, tmp_assign_source_18 );
    tmp_name_name_16 = const_str_plain_utils;
    tmp_globals_name_16 = (PyObject *)moduledict_pdfminer$cmapdb;
    tmp_locals_name_16 = Py_None;
    tmp_fromlist_name_16 = const_tuple_str_plain_nunpack_tuple;
    tmp_level_name_16 = const_int_pos_1;
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 32;
    tmp_import_name_from_9 = IMPORT_MODULE5( tmp_name_name_16, tmp_globals_name_16, tmp_locals_name_16, tmp_fromlist_name_16, tmp_level_name_16 );
    if ( tmp_import_name_from_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 32;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_19 = IMPORT_NAME( tmp_import_name_from_9, const_str_plain_nunpack );
    Py_DECREF( tmp_import_name_from_9 );
    if ( tmp_assign_source_19 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 32;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_nunpack, tmp_assign_source_19 );
    tmp_assign_source_20 = PyTuple_New( 1 );
    tmp_tuple_element_1 = PyExc_Exception;
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_assign_source_20, 0, tmp_tuple_element_1 );
    assert( tmp_class_creation_1__bases == NULL );
    tmp_class_creation_1__bases = tmp_assign_source_20;

    tmp_assign_source_22 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_0_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_22 );
    outline_0_var___module__ = tmp_assign_source_22;

    // Tried code:
    tmp_outline_return_value_1 = _PyDict_NewPresized( 1 );
    tmp_dict_value_1 = outline_0_var___module__;

    CHECK_OBJECT( tmp_dict_value_1 );
    tmp_dict_key_1 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_1, tmp_dict_key_1, tmp_dict_value_1 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)outline_0_var___module__ );
    Py_DECREF( outline_0_var___module__ );
    outline_0_var___module__ = NULL;

    goto outline_result_1;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_0_var___module__ );
    Py_DECREF( outline_0_var___module__ );
    outline_0_var___module__ = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_1:;
    tmp_assign_source_21 = tmp_outline_return_value_1;
    assert( tmp_class_creation_1__class_dict == NULL );
    tmp_class_creation_1__class_dict = tmp_assign_source_21;

    // Tried code:
    tmp_compare_left_1 = const_str_plain___metaclass__;
    tmp_compare_right_1 = tmp_class_creation_1__class_dict;

    CHECK_OBJECT( tmp_compare_right_1 );
    tmp_cmp_In_1 = PySequence_Contains( tmp_compare_right_1, tmp_compare_left_1 );
    assert( !(tmp_cmp_In_1 == -1) );
    if ( tmp_cmp_In_1 == 1 )
    {
        goto condexpr_true_1;
    }
    else
    {
        goto condexpr_false_1;
    }
    condexpr_true_1:;
    tmp_dict_name_1 = tmp_class_creation_1__class_dict;

    CHECK_OBJECT( tmp_dict_name_1 );
    tmp_key_name_1 = const_str_plain___metaclass__;
    tmp_assign_source_23 = DICT_GET_ITEM( tmp_dict_name_1, tmp_key_name_1 );
    if ( tmp_assign_source_23 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 35;

        goto try_except_handler_2;
    }
    goto condexpr_end_1;
    condexpr_false_1:;
    tmp_subscribed_name_1 = tmp_class_creation_1__bases;

    CHECK_OBJECT( tmp_subscribed_name_1 );
    tmp_subscript_name_1 = const_int_0;
    tmp_assign_source_24 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    if ( tmp_assign_source_24 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 35;

        goto try_except_handler_2;
    }
    assert( tmp_select_metaclass_1__base == NULL );
    tmp_select_metaclass_1__base = tmp_assign_source_24;

    // Tried code:
    // Tried code:
    tmp_source_name_1 = tmp_select_metaclass_1__base;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_outline_return_value_2 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_1 );
    if ( tmp_outline_return_value_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 35;

        goto try_except_handler_4;
    }
    goto try_return_handler_3;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_1 );
    Py_XDECREF( exception_keeper_value_1 );
    Py_XDECREF( exception_keeper_tb_1 );
    tmp_type_arg_1 = tmp_select_metaclass_1__base;

    CHECK_OBJECT( tmp_type_arg_1 );
    tmp_outline_return_value_2 = BUILTIN_TYPE1( tmp_type_arg_1 );
    assert( tmp_outline_return_value_2 != NULL );
    goto try_return_handler_3;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_3:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_1__base );
    Py_DECREF( tmp_select_metaclass_1__base );
    tmp_select_metaclass_1__base = NULL;

    goto outline_result_2;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_1__base );
    Py_DECREF( tmp_select_metaclass_1__base );
    tmp_select_metaclass_1__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_2:;
    tmp_assign_source_23 = tmp_outline_return_value_2;
    condexpr_end_1:;
    assert( tmp_class_creation_1__metaclass == NULL );
    tmp_class_creation_1__metaclass = tmp_assign_source_23;

    tmp_called_name_1 = tmp_class_creation_1__metaclass;

    CHECK_OBJECT( tmp_called_name_1 );
    tmp_args_element_name_1 = const_str_plain_CMapError;
    tmp_args_element_name_2 = tmp_class_creation_1__bases;

    CHECK_OBJECT( tmp_args_element_name_2 );
    tmp_args_element_name_3 = tmp_class_creation_1__class_dict;

    CHECK_OBJECT( tmp_args_element_name_3 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 35;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2, tmp_args_element_name_3 };
        tmp_assign_source_25 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_1, call_args );
    }

    if ( tmp_assign_source_25 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 35;

        goto try_except_handler_2;
    }
    assert( tmp_class_creation_1__class == NULL );
    tmp_class_creation_1__class = tmp_assign_source_25;

    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__bases );
    Py_DECREF( tmp_class_creation_1__bases );
    tmp_class_creation_1__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__class_dict );
    Py_DECREF( tmp_class_creation_1__class_dict );
    tmp_class_creation_1__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_1__metaclass );
    tmp_class_creation_1__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;
    tmp_assign_source_26 = tmp_class_creation_1__class;

    CHECK_OBJECT( tmp_assign_source_26 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapError, tmp_assign_source_26 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__class );
    Py_DECREF( tmp_class_creation_1__class );
    tmp_class_creation_1__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__bases );
    Py_DECREF( tmp_class_creation_1__bases );
    tmp_class_creation_1__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__class_dict );
    Py_DECREF( tmp_class_creation_1__class_dict );
    tmp_class_creation_1__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_1__metaclass );
    Py_DECREF( tmp_class_creation_1__metaclass );
    tmp_class_creation_1__metaclass = NULL;

    tmp_assign_source_28 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_1_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_28 );
    outline_1_var___module__ = tmp_assign_source_28;

    tmp_assign_source_29 = const_int_0;
    assert( outline_1_var_debug == NULL );
    Py_INCREF( tmp_assign_source_29 );
    outline_1_var_debug = tmp_assign_source_29;

    tmp_assign_source_30 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_1___init__(  );
    assert( outline_1_var___init__ == NULL );
    outline_1_var___init__ = tmp_assign_source_30;

    tmp_assign_source_31 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_2_is_vertical(  );
    assert( outline_1_var_is_vertical == NULL );
    outline_1_var_is_vertical = tmp_assign_source_31;

    tmp_assign_source_32 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_3_set_attr(  );
    assert( outline_1_var_set_attr == NULL );
    outline_1_var_set_attr = tmp_assign_source_32;

    tmp_assign_source_33 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_4_add_code2cid(  );
    assert( outline_1_var_add_code2cid == NULL );
    outline_1_var_add_code2cid = tmp_assign_source_33;

    tmp_assign_source_34 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_5_add_cid2unichr(  );
    assert( outline_1_var_add_cid2unichr == NULL );
    outline_1_var_add_cid2unichr = tmp_assign_source_34;

    tmp_assign_source_35 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_6_use_cmap(  );
    assert( outline_1_var_use_cmap == NULL );
    outline_1_var_use_cmap = tmp_assign_source_35;

    // Tried code:
    tmp_outline_return_value_3 = _PyDict_NewPresized( 8 );
    tmp_dict_value_2 = outline_1_var___module__;

    CHECK_OBJECT( tmp_dict_value_2 );
    tmp_dict_key_2 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_2, tmp_dict_value_2 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_3 = outline_1_var_debug;

    CHECK_OBJECT( tmp_dict_value_3 );
    tmp_dict_key_3 = const_str_plain_debug;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_3, tmp_dict_value_3 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_4 = outline_1_var___init__;

    CHECK_OBJECT( tmp_dict_value_4 );
    tmp_dict_key_4 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_4, tmp_dict_value_4 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_5 = outline_1_var_is_vertical;

    CHECK_OBJECT( tmp_dict_value_5 );
    tmp_dict_key_5 = const_str_plain_is_vertical;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_5, tmp_dict_value_5 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_6 = outline_1_var_set_attr;

    CHECK_OBJECT( tmp_dict_value_6 );
    tmp_dict_key_6 = const_str_plain_set_attr;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_6, tmp_dict_value_6 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_7 = outline_1_var_add_code2cid;

    CHECK_OBJECT( tmp_dict_value_7 );
    tmp_dict_key_7 = const_str_plain_add_code2cid;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_7, tmp_dict_value_7 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_8 = outline_1_var_add_cid2unichr;

    CHECK_OBJECT( tmp_dict_value_8 );
    tmp_dict_key_8 = const_str_plain_add_cid2unichr;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_8, tmp_dict_value_8 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_9 = outline_1_var_use_cmap;

    CHECK_OBJECT( tmp_dict_value_9 );
    tmp_dict_key_9 = const_str_plain_use_cmap;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_3, tmp_dict_key_9, tmp_dict_value_9 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_5;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_5:;
    CHECK_OBJECT( (PyObject *)outline_1_var___module__ );
    Py_DECREF( outline_1_var___module__ );
    outline_1_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_debug );
    Py_DECREF( outline_1_var_debug );
    outline_1_var_debug = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var___init__ );
    Py_DECREF( outline_1_var___init__ );
    outline_1_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_is_vertical );
    Py_DECREF( outline_1_var_is_vertical );
    outline_1_var_is_vertical = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_set_attr );
    Py_DECREF( outline_1_var_set_attr );
    outline_1_var_set_attr = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_add_code2cid );
    Py_DECREF( outline_1_var_add_code2cid );
    outline_1_var_add_code2cid = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_add_cid2unichr );
    Py_DECREF( outline_1_var_add_cid2unichr );
    outline_1_var_add_cid2unichr = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_use_cmap );
    Py_DECREF( outline_1_var_use_cmap );
    outline_1_var_use_cmap = NULL;

    goto outline_result_3;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_1_var___module__ );
    Py_DECREF( outline_1_var___module__ );
    outline_1_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_debug );
    Py_DECREF( outline_1_var_debug );
    outline_1_var_debug = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var___init__ );
    Py_DECREF( outline_1_var___init__ );
    outline_1_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_is_vertical );
    Py_DECREF( outline_1_var_is_vertical );
    outline_1_var_is_vertical = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_set_attr );
    Py_DECREF( outline_1_var_set_attr );
    outline_1_var_set_attr = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_add_code2cid );
    Py_DECREF( outline_1_var_add_code2cid );
    outline_1_var_add_code2cid = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_add_cid2unichr );
    Py_DECREF( outline_1_var_add_cid2unichr );
    outline_1_var_add_cid2unichr = NULL;

    CHECK_OBJECT( (PyObject *)outline_1_var_use_cmap );
    Py_DECREF( outline_1_var_use_cmap );
    outline_1_var_use_cmap = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_3:;
    tmp_assign_source_27 = tmp_outline_return_value_3;
    assert( tmp_class_creation_2__class_dict == NULL );
    tmp_class_creation_2__class_dict = tmp_assign_source_27;

    // Tried code:
    tmp_compare_left_2 = const_str_plain___metaclass__;
    tmp_compare_right_2 = tmp_class_creation_2__class_dict;

    CHECK_OBJECT( tmp_compare_right_2 );
    tmp_cmp_In_2 = PySequence_Contains( tmp_compare_right_2, tmp_compare_left_2 );
    assert( !(tmp_cmp_In_2 == -1) );
    if ( tmp_cmp_In_2 == 1 )
    {
        goto condexpr_true_2;
    }
    else
    {
        goto condexpr_false_2;
    }
    condexpr_true_2:;
    tmp_dict_name_2 = tmp_class_creation_2__class_dict;

    CHECK_OBJECT( tmp_dict_name_2 );
    tmp_key_name_2 = const_str_plain___metaclass__;
    tmp_assign_source_36 = DICT_GET_ITEM( tmp_dict_name_2, tmp_key_name_2 );
    if ( tmp_assign_source_36 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 41;

        goto try_except_handler_6;
    }
    goto condexpr_end_2;
    condexpr_false_2:;
    tmp_assign_source_36 = (PyObject *)&PyType_Type;
    Py_INCREF( tmp_assign_source_36 );
    condexpr_end_2:;
    assert( tmp_class_creation_2__metaclass == NULL );
    tmp_class_creation_2__metaclass = tmp_assign_source_36;

    tmp_called_name_2 = tmp_class_creation_2__metaclass;

    CHECK_OBJECT( tmp_called_name_2 );
    tmp_args_element_name_4 = const_str_plain_CMapBase;
    tmp_args_element_name_5 = const_tuple_type_object_tuple;
    tmp_args_element_name_6 = tmp_class_creation_2__class_dict;

    CHECK_OBJECT( tmp_args_element_name_6 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 41;
    {
        PyObject *call_args[] = { tmp_args_element_name_4, tmp_args_element_name_5, tmp_args_element_name_6 };
        tmp_assign_source_37 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_2, call_args );
    }

    if ( tmp_assign_source_37 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 41;

        goto try_except_handler_6;
    }
    assert( tmp_class_creation_2__class == NULL );
    tmp_class_creation_2__class = tmp_assign_source_37;

    goto try_end_2;
    // Exception handler code:
    try_except_handler_6:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_2__class_dict );
    Py_DECREF( tmp_class_creation_2__class_dict );
    tmp_class_creation_2__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_2__metaclass );
    tmp_class_creation_2__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_2:;
    tmp_assign_source_38 = tmp_class_creation_2__class;

    CHECK_OBJECT( tmp_assign_source_38 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase, tmp_assign_source_38 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_2__class );
    Py_DECREF( tmp_class_creation_2__class );
    tmp_class_creation_2__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_2__class_dict );
    Py_DECREF( tmp_class_creation_2__class_dict );
    tmp_class_creation_2__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_2__metaclass );
    Py_DECREF( tmp_class_creation_2__metaclass );
    tmp_class_creation_2__metaclass = NULL;

    // Tried code:
    tmp_assign_source_39 = PyTuple_New( 1 );
    tmp_tuple_element_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase );

    if (unlikely( tmp_tuple_element_2 == NULL ))
    {
        tmp_tuple_element_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapBase );
    }

    if ( tmp_tuple_element_2 == NULL )
    {
        Py_DECREF( tmp_assign_source_39 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMapBase" );
        exception_tb = NULL;

        exception_lineno = 68;

        goto try_except_handler_7;
    }

    Py_INCREF( tmp_tuple_element_2 );
    PyTuple_SET_ITEM( tmp_assign_source_39, 0, tmp_tuple_element_2 );
    assert( tmp_class_creation_3__bases == NULL );
    tmp_class_creation_3__bases = tmp_assign_source_39;

    tmp_assign_source_41 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_2_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_41 );
    outline_2_var___module__ = tmp_assign_source_41;

    tmp_assign_source_42 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_7___init__(  );
    assert( outline_2_var___init__ == NULL );
    outline_2_var___init__ = tmp_assign_source_42;

    tmp_assign_source_43 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_8___repr__(  );
    assert( outline_2_var___repr__ == NULL );
    outline_2_var___repr__ = tmp_assign_source_43;

    tmp_assign_source_44 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_9_use_cmap(  );
    assert( outline_2_var_use_cmap == NULL );
    outline_2_var_use_cmap = tmp_assign_source_44;

    tmp_assign_source_45 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_10_decode(  );
    assert( outline_2_var_decode == NULL );
    outline_2_var_decode = tmp_assign_source_45;

    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_1bcd1bf519e2b38557d857744ff7938c_2, codeobj_1bcd1bf519e2b38557d857744ff7938c, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_1bcd1bf519e2b38557d857744ff7938c_2 = cache_frame_1bcd1bf519e2b38557d857744ff7938c_2;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_1bcd1bf519e2b38557d857744ff7938c_2 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_1bcd1bf519e2b38557d857744ff7938c_2 ) == 2 ); // Frame stack

    // Framed code:
    tmp_defaults_1 = PyTuple_New( 3 );
    tmp_source_name_2 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_sys );

    if (unlikely( tmp_source_name_2 == NULL ))
    {
        tmp_source_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_sys );
    }

    if ( tmp_source_name_2 == NULL )
    {
        Py_DECREF( tmp_defaults_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "sys" );
        exception_tb = NULL;

        exception_lineno = 107;
        type_description_2 = "oooooN";
        goto frame_exception_exit_2;
    }

    tmp_tuple_element_3 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_stdout );
    if ( tmp_tuple_element_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_defaults_1 );

        exception_lineno = 107;
        type_description_2 = "oooooN";
        goto frame_exception_exit_2;
    }
    PyTuple_SET_ITEM( tmp_defaults_1, 0, tmp_tuple_element_3 );
    tmp_tuple_element_3 = Py_None;
    Py_INCREF( tmp_tuple_element_3 );
    PyTuple_SET_ITEM( tmp_defaults_1, 1, tmp_tuple_element_3 );
    tmp_tuple_element_3 = Py_None;
    Py_INCREF( tmp_tuple_element_3 );
    PyTuple_SET_ITEM( tmp_defaults_1, 2, tmp_tuple_element_3 );
    tmp_assign_source_46 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_11_dump( tmp_defaults_1 );
    assert( outline_2_var_dump == NULL );
    outline_2_var_dump = tmp_assign_source_46;


#if 0
    RESTORE_FRAME_EXCEPTION( frame_1bcd1bf519e2b38557d857744ff7938c_2 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_2:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_1bcd1bf519e2b38557d857744ff7938c_2 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_1bcd1bf519e2b38557d857744ff7938c_2, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_1bcd1bf519e2b38557d857744ff7938c_2->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_1bcd1bf519e2b38557d857744ff7938c_2, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_1bcd1bf519e2b38557d857744ff7938c_2,
        type_description_2,
        outline_2_var___module__,
        outline_2_var___init__,
        outline_2_var___repr__,
        outline_2_var_use_cmap,
        outline_2_var_decode,
        outline_2_var_dump
    );


    // Release cached frame.
    if ( frame_1bcd1bf519e2b38557d857744ff7938c_2 == cache_frame_1bcd1bf519e2b38557d857744ff7938c_2 )
    {
        Py_DECREF( frame_1bcd1bf519e2b38557d857744ff7938c_2 );
    }
    cache_frame_1bcd1bf519e2b38557d857744ff7938c_2 = NULL;

    assertFrameObject( frame_1bcd1bf519e2b38557d857744ff7938c_2 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto nested_frame_exit_1;

    frame_no_exception_1:;

    goto skip_nested_handling_1;
    nested_frame_exit_1:;

    goto try_except_handler_8;
    skip_nested_handling_1:;
    tmp_outline_return_value_4 = _PyDict_NewPresized( 6 );
    tmp_dict_value_10 = outline_2_var___module__;

    CHECK_OBJECT( tmp_dict_value_10 );
    tmp_dict_key_10 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_10, tmp_dict_value_10 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_11 = outline_2_var___init__;

    CHECK_OBJECT( tmp_dict_value_11 );
    tmp_dict_key_11 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_11, tmp_dict_value_11 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_12 = outline_2_var___repr__;

    CHECK_OBJECT( tmp_dict_value_12 );
    tmp_dict_key_12 = const_str_plain___repr__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_12, tmp_dict_value_12 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_13 = outline_2_var_use_cmap;

    CHECK_OBJECT( tmp_dict_value_13 );
    tmp_dict_key_13 = const_str_plain_use_cmap;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_13, tmp_dict_value_13 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_14 = outline_2_var_decode;

    CHECK_OBJECT( tmp_dict_value_14 );
    tmp_dict_key_14 = const_str_plain_decode;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_14, tmp_dict_value_14 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_15 = outline_2_var_dump;

    CHECK_OBJECT( tmp_dict_value_15 );
    tmp_dict_key_15 = const_str_plain_dump;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_4, tmp_dict_key_15, tmp_dict_value_15 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_8;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_8:;
    CHECK_OBJECT( (PyObject *)outline_2_var___module__ );
    Py_DECREF( outline_2_var___module__ );
    outline_2_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var___init__ );
    Py_DECREF( outline_2_var___init__ );
    outline_2_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var___repr__ );
    Py_DECREF( outline_2_var___repr__ );
    outline_2_var___repr__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var_use_cmap );
    Py_DECREF( outline_2_var_use_cmap );
    outline_2_var_use_cmap = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var_decode );
    Py_DECREF( outline_2_var_decode );
    outline_2_var_decode = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var_dump );
    Py_DECREF( outline_2_var_dump );
    outline_2_var_dump = NULL;

    goto outline_result_4;
    // Exception handler code:
    try_except_handler_8:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)outline_2_var___module__ );
    Py_DECREF( outline_2_var___module__ );
    outline_2_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var___init__ );
    Py_DECREF( outline_2_var___init__ );
    outline_2_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var___repr__ );
    Py_DECREF( outline_2_var___repr__ );
    outline_2_var___repr__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var_use_cmap );
    Py_DECREF( outline_2_var_use_cmap );
    outline_2_var_use_cmap = NULL;

    CHECK_OBJECT( (PyObject *)outline_2_var_decode );
    Py_DECREF( outline_2_var_decode );
    outline_2_var_decode = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto outline_exception_1;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_exception_1:;
    exception_lineno = 68;
    goto try_except_handler_7;
    outline_result_4:;
    tmp_assign_source_40 = tmp_outline_return_value_4;
    assert( tmp_class_creation_3__class_dict == NULL );
    tmp_class_creation_3__class_dict = tmp_assign_source_40;

    tmp_compare_left_3 = const_str_plain___metaclass__;
    tmp_compare_right_3 = tmp_class_creation_3__class_dict;

    CHECK_OBJECT( tmp_compare_right_3 );
    tmp_cmp_In_3 = PySequence_Contains( tmp_compare_right_3, tmp_compare_left_3 );
    assert( !(tmp_cmp_In_3 == -1) );
    if ( tmp_cmp_In_3 == 1 )
    {
        goto condexpr_true_3;
    }
    else
    {
        goto condexpr_false_3;
    }
    condexpr_true_3:;
    tmp_dict_name_3 = tmp_class_creation_3__class_dict;

    CHECK_OBJECT( tmp_dict_name_3 );
    tmp_key_name_3 = const_str_plain___metaclass__;
    tmp_assign_source_47 = DICT_GET_ITEM( tmp_dict_name_3, tmp_key_name_3 );
    if ( tmp_assign_source_47 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 68;

        goto try_except_handler_7;
    }
    goto condexpr_end_3;
    condexpr_false_3:;
    tmp_subscribed_name_2 = tmp_class_creation_3__bases;

    CHECK_OBJECT( tmp_subscribed_name_2 );
    tmp_subscript_name_2 = const_int_0;
    tmp_assign_source_48 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_2, tmp_subscript_name_2 );
    if ( tmp_assign_source_48 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 68;

        goto try_except_handler_7;
    }
    assert( tmp_select_metaclass_3__base == NULL );
    tmp_select_metaclass_3__base = tmp_assign_source_48;

    // Tried code:
    // Tried code:
    tmp_source_name_3 = tmp_select_metaclass_3__base;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_outline_return_value_5 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_3 );
    if ( tmp_outline_return_value_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 68;

        goto try_except_handler_10;
    }
    goto try_return_handler_9;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_10:;
    exception_keeper_type_5 = exception_type;
    exception_keeper_value_5 = exception_value;
    exception_keeper_tb_5 = exception_tb;
    exception_keeper_lineno_5 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_5 );
    Py_XDECREF( exception_keeper_value_5 );
    Py_XDECREF( exception_keeper_tb_5 );
    tmp_type_arg_2 = tmp_select_metaclass_3__base;

    CHECK_OBJECT( tmp_type_arg_2 );
    tmp_outline_return_value_5 = BUILTIN_TYPE1( tmp_type_arg_2 );
    assert( tmp_outline_return_value_5 != NULL );
    goto try_return_handler_9;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_9:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_3__base );
    Py_DECREF( tmp_select_metaclass_3__base );
    tmp_select_metaclass_3__base = NULL;

    goto outline_result_5;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_3__base );
    Py_DECREF( tmp_select_metaclass_3__base );
    tmp_select_metaclass_3__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_5:;
    tmp_assign_source_47 = tmp_outline_return_value_5;
    condexpr_end_3:;
    assert( tmp_class_creation_3__metaclass == NULL );
    tmp_class_creation_3__metaclass = tmp_assign_source_47;

    tmp_called_name_3 = tmp_class_creation_3__metaclass;

    CHECK_OBJECT( tmp_called_name_3 );
    tmp_args_element_name_7 = const_str_plain_CMap;
    tmp_args_element_name_8 = tmp_class_creation_3__bases;

    CHECK_OBJECT( tmp_args_element_name_8 );
    tmp_args_element_name_9 = tmp_class_creation_3__class_dict;

    CHECK_OBJECT( tmp_args_element_name_9 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 68;
    {
        PyObject *call_args[] = { tmp_args_element_name_7, tmp_args_element_name_8, tmp_args_element_name_9 };
        tmp_assign_source_49 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_3, call_args );
    }

    if ( tmp_assign_source_49 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 68;

        goto try_except_handler_7;
    }
    assert( tmp_class_creation_3__class == NULL );
    tmp_class_creation_3__class = tmp_assign_source_49;

    goto try_end_3;
    // Exception handler code:
    try_except_handler_7:;
    exception_keeper_type_6 = exception_type;
    exception_keeper_value_6 = exception_value;
    exception_keeper_tb_6 = exception_tb;
    exception_keeper_lineno_6 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_3__bases );
    tmp_class_creation_3__bases = NULL;

    Py_XDECREF( tmp_class_creation_3__class_dict );
    tmp_class_creation_3__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_3__metaclass );
    tmp_class_creation_3__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_6;
    exception_value = exception_keeper_value_6;
    exception_tb = exception_keeper_tb_6;
    exception_lineno = exception_keeper_lineno_6;

    goto frame_exception_exit_1;
    // End of try:
    try_end_3:;
    tmp_assign_source_50 = tmp_class_creation_3__class;

    CHECK_OBJECT( tmp_assign_source_50 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMap, tmp_assign_source_50 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_3__class );
    Py_DECREF( tmp_class_creation_3__class );
    tmp_class_creation_3__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_3__bases );
    Py_DECREF( tmp_class_creation_3__bases );
    tmp_class_creation_3__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_3__class_dict );
    Py_DECREF( tmp_class_creation_3__class_dict );
    tmp_class_creation_3__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_3__metaclass );
    Py_DECREF( tmp_class_creation_3__metaclass );
    tmp_class_creation_3__metaclass = NULL;

    // Tried code:
    tmp_assign_source_51 = PyTuple_New( 1 );
    tmp_tuple_element_4 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase );

    if (unlikely( tmp_tuple_element_4 == NULL ))
    {
        tmp_tuple_element_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapBase );
    }

    if ( tmp_tuple_element_4 == NULL )
    {
        Py_DECREF( tmp_assign_source_51 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMapBase" );
        exception_tb = NULL;

        exception_lineno = 122;

        goto try_except_handler_11;
    }

    Py_INCREF( tmp_tuple_element_4 );
    PyTuple_SET_ITEM( tmp_assign_source_51, 0, tmp_tuple_element_4 );
    assert( tmp_class_creation_4__bases == NULL );
    tmp_class_creation_4__bases = tmp_assign_source_51;

    tmp_assign_source_53 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_3_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_53 );
    outline_3_var___module__ = tmp_assign_source_53;

    tmp_assign_source_54 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_12_decode(  );
    assert( outline_3_var_decode == NULL );
    outline_3_var_decode = tmp_assign_source_54;

    // Tried code:
    tmp_outline_return_value_6 = _PyDict_NewPresized( 2 );
    tmp_dict_value_16 = outline_3_var___module__;

    CHECK_OBJECT( tmp_dict_value_16 );
    tmp_dict_key_16 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_6, tmp_dict_key_16, tmp_dict_value_16 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_17 = outline_3_var_decode;

    CHECK_OBJECT( tmp_dict_value_17 );
    tmp_dict_key_17 = const_str_plain_decode;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_6, tmp_dict_key_17, tmp_dict_value_17 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_12;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_12:;
    CHECK_OBJECT( (PyObject *)outline_3_var___module__ );
    Py_DECREF( outline_3_var___module__ );
    outline_3_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_3_var_decode );
    Py_DECREF( outline_3_var_decode );
    outline_3_var_decode = NULL;

    goto outline_result_6;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_3_var___module__ );
    Py_DECREF( outline_3_var___module__ );
    outline_3_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_3_var_decode );
    Py_DECREF( outline_3_var_decode );
    outline_3_var_decode = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_6:;
    tmp_assign_source_52 = tmp_outline_return_value_6;
    assert( tmp_class_creation_4__class_dict == NULL );
    tmp_class_creation_4__class_dict = tmp_assign_source_52;

    tmp_compare_left_4 = const_str_plain___metaclass__;
    tmp_compare_right_4 = tmp_class_creation_4__class_dict;

    CHECK_OBJECT( tmp_compare_right_4 );
    tmp_cmp_In_4 = PySequence_Contains( tmp_compare_right_4, tmp_compare_left_4 );
    assert( !(tmp_cmp_In_4 == -1) );
    if ( tmp_cmp_In_4 == 1 )
    {
        goto condexpr_true_4;
    }
    else
    {
        goto condexpr_false_4;
    }
    condexpr_true_4:;
    tmp_dict_name_4 = tmp_class_creation_4__class_dict;

    CHECK_OBJECT( tmp_dict_name_4 );
    tmp_key_name_4 = const_str_plain___metaclass__;
    tmp_assign_source_55 = DICT_GET_ITEM( tmp_dict_name_4, tmp_key_name_4 );
    if ( tmp_assign_source_55 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 122;

        goto try_except_handler_11;
    }
    goto condexpr_end_4;
    condexpr_false_4:;
    tmp_subscribed_name_3 = tmp_class_creation_4__bases;

    CHECK_OBJECT( tmp_subscribed_name_3 );
    tmp_subscript_name_3 = const_int_0;
    tmp_assign_source_56 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_3, tmp_subscript_name_3 );
    if ( tmp_assign_source_56 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 122;

        goto try_except_handler_11;
    }
    assert( tmp_select_metaclass_4__base == NULL );
    tmp_select_metaclass_4__base = tmp_assign_source_56;

    // Tried code:
    // Tried code:
    tmp_source_name_4 = tmp_select_metaclass_4__base;

    CHECK_OBJECT( tmp_source_name_4 );
    tmp_outline_return_value_7 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_4 );
    if ( tmp_outline_return_value_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 122;

        goto try_except_handler_14;
    }
    goto try_return_handler_13;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_14:;
    exception_keeper_type_7 = exception_type;
    exception_keeper_value_7 = exception_value;
    exception_keeper_tb_7 = exception_tb;
    exception_keeper_lineno_7 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_7 );
    Py_XDECREF( exception_keeper_value_7 );
    Py_XDECREF( exception_keeper_tb_7 );
    tmp_type_arg_3 = tmp_select_metaclass_4__base;

    CHECK_OBJECT( tmp_type_arg_3 );
    tmp_outline_return_value_7 = BUILTIN_TYPE1( tmp_type_arg_3 );
    assert( tmp_outline_return_value_7 != NULL );
    goto try_return_handler_13;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_13:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_4__base );
    Py_DECREF( tmp_select_metaclass_4__base );
    tmp_select_metaclass_4__base = NULL;

    goto outline_result_7;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_4__base );
    Py_DECREF( tmp_select_metaclass_4__base );
    tmp_select_metaclass_4__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_7:;
    tmp_assign_source_55 = tmp_outline_return_value_7;
    condexpr_end_4:;
    assert( tmp_class_creation_4__metaclass == NULL );
    tmp_class_creation_4__metaclass = tmp_assign_source_55;

    tmp_called_name_4 = tmp_class_creation_4__metaclass;

    CHECK_OBJECT( tmp_called_name_4 );
    tmp_args_element_name_10 = const_str_plain_IdentityCMap;
    tmp_args_element_name_11 = tmp_class_creation_4__bases;

    CHECK_OBJECT( tmp_args_element_name_11 );
    tmp_args_element_name_12 = tmp_class_creation_4__class_dict;

    CHECK_OBJECT( tmp_args_element_name_12 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 122;
    {
        PyObject *call_args[] = { tmp_args_element_name_10, tmp_args_element_name_11, tmp_args_element_name_12 };
        tmp_assign_source_57 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_4, call_args );
    }

    if ( tmp_assign_source_57 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 122;

        goto try_except_handler_11;
    }
    assert( tmp_class_creation_4__class == NULL );
    tmp_class_creation_4__class = tmp_assign_source_57;

    goto try_end_4;
    // Exception handler code:
    try_except_handler_11:;
    exception_keeper_type_8 = exception_type;
    exception_keeper_value_8 = exception_value;
    exception_keeper_tb_8 = exception_tb;
    exception_keeper_lineno_8 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_4__bases );
    tmp_class_creation_4__bases = NULL;

    Py_XDECREF( tmp_class_creation_4__class_dict );
    tmp_class_creation_4__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_4__metaclass );
    tmp_class_creation_4__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_8;
    exception_value = exception_keeper_value_8;
    exception_tb = exception_keeper_tb_8;
    exception_lineno = exception_keeper_lineno_8;

    goto frame_exception_exit_1;
    // End of try:
    try_end_4:;
    tmp_assign_source_58 = tmp_class_creation_4__class;

    CHECK_OBJECT( tmp_assign_source_58 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_IdentityCMap, tmp_assign_source_58 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_4__class );
    Py_DECREF( tmp_class_creation_4__class );
    tmp_class_creation_4__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_4__bases );
    Py_DECREF( tmp_class_creation_4__bases );
    tmp_class_creation_4__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_4__class_dict );
    Py_DECREF( tmp_class_creation_4__class_dict );
    tmp_class_creation_4__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_4__metaclass );
    Py_DECREF( tmp_class_creation_4__metaclass );
    tmp_class_creation_4__metaclass = NULL;

    // Tried code:
    tmp_assign_source_59 = PyTuple_New( 1 );
    tmp_tuple_element_5 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapBase );

    if (unlikely( tmp_tuple_element_5 == NULL ))
    {
        tmp_tuple_element_5 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapBase );
    }

    if ( tmp_tuple_element_5 == NULL )
    {
        Py_DECREF( tmp_assign_source_59 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMapBase" );
        exception_tb = NULL;

        exception_lineno = 134;

        goto try_except_handler_15;
    }

    Py_INCREF( tmp_tuple_element_5 );
    PyTuple_SET_ITEM( tmp_assign_source_59, 0, tmp_tuple_element_5 );
    assert( tmp_class_creation_5__bases == NULL );
    tmp_class_creation_5__bases = tmp_assign_source_59;

    tmp_assign_source_61 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_4_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_61 );
    outline_4_var___module__ = tmp_assign_source_61;

    tmp_assign_source_62 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_13___init__(  );
    assert( outline_4_var___init__ == NULL );
    outline_4_var___init__ = tmp_assign_source_62;

    tmp_assign_source_63 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_14___repr__(  );
    assert( outline_4_var___repr__ == NULL );
    outline_4_var___repr__ = tmp_assign_source_63;

    tmp_assign_source_64 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_15_get_unichr(  );
    assert( outline_4_var_get_unichr == NULL );
    outline_4_var_get_unichr = tmp_assign_source_64;

    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_6e3884fccc459a164677932fec301eae_3, codeobj_6e3884fccc459a164677932fec301eae, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_6e3884fccc459a164677932fec301eae_3 = cache_frame_6e3884fccc459a164677932fec301eae_3;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_6e3884fccc459a164677932fec301eae_3 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_6e3884fccc459a164677932fec301eae_3 ) == 2 ); // Frame stack

    // Framed code:
    tmp_defaults_2 = PyTuple_New( 1 );
    tmp_source_name_5 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_sys );

    if (unlikely( tmp_source_name_5 == NULL ))
    {
        tmp_source_name_5 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_sys );
    }

    if ( tmp_source_name_5 == NULL )
    {
        Py_DECREF( tmp_defaults_2 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "sys" );
        exception_tb = NULL;

        exception_lineno = 149;
        type_description_2 = "ooooN";
        goto frame_exception_exit_3;
    }

    tmp_tuple_element_6 = LOOKUP_ATTRIBUTE( tmp_source_name_5, const_str_plain_stdout );
    if ( tmp_tuple_element_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_defaults_2 );

        exception_lineno = 149;
        type_description_2 = "ooooN";
        goto frame_exception_exit_3;
    }
    PyTuple_SET_ITEM( tmp_defaults_2, 0, tmp_tuple_element_6 );
    tmp_assign_source_65 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_16_dump( tmp_defaults_2 );
    assert( outline_4_var_dump == NULL );
    outline_4_var_dump = tmp_assign_source_65;


#if 0
    RESTORE_FRAME_EXCEPTION( frame_6e3884fccc459a164677932fec301eae_3 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_2;

    frame_exception_exit_3:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_6e3884fccc459a164677932fec301eae_3 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_6e3884fccc459a164677932fec301eae_3, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_6e3884fccc459a164677932fec301eae_3->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_6e3884fccc459a164677932fec301eae_3, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_6e3884fccc459a164677932fec301eae_3,
        type_description_2,
        outline_4_var___module__,
        outline_4_var___init__,
        outline_4_var___repr__,
        outline_4_var_get_unichr,
        outline_4_var_dump
    );


    // Release cached frame.
    if ( frame_6e3884fccc459a164677932fec301eae_3 == cache_frame_6e3884fccc459a164677932fec301eae_3 )
    {
        Py_DECREF( frame_6e3884fccc459a164677932fec301eae_3 );
    }
    cache_frame_6e3884fccc459a164677932fec301eae_3 = NULL;

    assertFrameObject( frame_6e3884fccc459a164677932fec301eae_3 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto nested_frame_exit_2;

    frame_no_exception_2:;

    goto skip_nested_handling_2;
    nested_frame_exit_2:;

    goto try_except_handler_16;
    skip_nested_handling_2:;
    tmp_outline_return_value_8 = _PyDict_NewPresized( 5 );
    tmp_dict_value_18 = outline_4_var___module__;

    CHECK_OBJECT( tmp_dict_value_18 );
    tmp_dict_key_18 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_8, tmp_dict_key_18, tmp_dict_value_18 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_19 = outline_4_var___init__;

    CHECK_OBJECT( tmp_dict_value_19 );
    tmp_dict_key_19 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_8, tmp_dict_key_19, tmp_dict_value_19 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_20 = outline_4_var___repr__;

    CHECK_OBJECT( tmp_dict_value_20 );
    tmp_dict_key_20 = const_str_plain___repr__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_8, tmp_dict_key_20, tmp_dict_value_20 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_21 = outline_4_var_get_unichr;

    CHECK_OBJECT( tmp_dict_value_21 );
    tmp_dict_key_21 = const_str_plain_get_unichr;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_8, tmp_dict_key_21, tmp_dict_value_21 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_22 = outline_4_var_dump;

    CHECK_OBJECT( tmp_dict_value_22 );
    tmp_dict_key_22 = const_str_plain_dump;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_8, tmp_dict_key_22, tmp_dict_value_22 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_16;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_16:;
    CHECK_OBJECT( (PyObject *)outline_4_var___module__ );
    Py_DECREF( outline_4_var___module__ );
    outline_4_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var___init__ );
    Py_DECREF( outline_4_var___init__ );
    outline_4_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var___repr__ );
    Py_DECREF( outline_4_var___repr__ );
    outline_4_var___repr__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var_get_unichr );
    Py_DECREF( outline_4_var_get_unichr );
    outline_4_var_get_unichr = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var_dump );
    Py_DECREF( outline_4_var_dump );
    outline_4_var_dump = NULL;

    goto outline_result_8;
    // Exception handler code:
    try_except_handler_16:;
    exception_keeper_type_9 = exception_type;
    exception_keeper_value_9 = exception_value;
    exception_keeper_tb_9 = exception_tb;
    exception_keeper_lineno_9 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)outline_4_var___module__ );
    Py_DECREF( outline_4_var___module__ );
    outline_4_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var___init__ );
    Py_DECREF( outline_4_var___init__ );
    outline_4_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var___repr__ );
    Py_DECREF( outline_4_var___repr__ );
    outline_4_var___repr__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_4_var_get_unichr );
    Py_DECREF( outline_4_var_get_unichr );
    outline_4_var_get_unichr = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_9;
    exception_value = exception_keeper_value_9;
    exception_tb = exception_keeper_tb_9;
    exception_lineno = exception_keeper_lineno_9;

    goto outline_exception_2;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_exception_2:;
    exception_lineno = 134;
    goto try_except_handler_15;
    outline_result_8:;
    tmp_assign_source_60 = tmp_outline_return_value_8;
    assert( tmp_class_creation_5__class_dict == NULL );
    tmp_class_creation_5__class_dict = tmp_assign_source_60;

    tmp_compare_left_5 = const_str_plain___metaclass__;
    tmp_compare_right_5 = tmp_class_creation_5__class_dict;

    CHECK_OBJECT( tmp_compare_right_5 );
    tmp_cmp_In_5 = PySequence_Contains( tmp_compare_right_5, tmp_compare_left_5 );
    assert( !(tmp_cmp_In_5 == -1) );
    if ( tmp_cmp_In_5 == 1 )
    {
        goto condexpr_true_5;
    }
    else
    {
        goto condexpr_false_5;
    }
    condexpr_true_5:;
    tmp_dict_name_5 = tmp_class_creation_5__class_dict;

    CHECK_OBJECT( tmp_dict_name_5 );
    tmp_key_name_5 = const_str_plain___metaclass__;
    tmp_assign_source_66 = DICT_GET_ITEM( tmp_dict_name_5, tmp_key_name_5 );
    if ( tmp_assign_source_66 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 134;

        goto try_except_handler_15;
    }
    goto condexpr_end_5;
    condexpr_false_5:;
    tmp_subscribed_name_4 = tmp_class_creation_5__bases;

    CHECK_OBJECT( tmp_subscribed_name_4 );
    tmp_subscript_name_4 = const_int_0;
    tmp_assign_source_67 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_4, tmp_subscript_name_4 );
    if ( tmp_assign_source_67 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 134;

        goto try_except_handler_15;
    }
    assert( tmp_select_metaclass_5__base == NULL );
    tmp_select_metaclass_5__base = tmp_assign_source_67;

    // Tried code:
    // Tried code:
    tmp_source_name_6 = tmp_select_metaclass_5__base;

    CHECK_OBJECT( tmp_source_name_6 );
    tmp_outline_return_value_9 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_6 );
    if ( tmp_outline_return_value_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 134;

        goto try_except_handler_18;
    }
    goto try_return_handler_17;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_18:;
    exception_keeper_type_10 = exception_type;
    exception_keeper_value_10 = exception_value;
    exception_keeper_tb_10 = exception_tb;
    exception_keeper_lineno_10 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_10 );
    Py_XDECREF( exception_keeper_value_10 );
    Py_XDECREF( exception_keeper_tb_10 );
    tmp_type_arg_4 = tmp_select_metaclass_5__base;

    CHECK_OBJECT( tmp_type_arg_4 );
    tmp_outline_return_value_9 = BUILTIN_TYPE1( tmp_type_arg_4 );
    assert( tmp_outline_return_value_9 != NULL );
    goto try_return_handler_17;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_17:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_5__base );
    Py_DECREF( tmp_select_metaclass_5__base );
    tmp_select_metaclass_5__base = NULL;

    goto outline_result_9;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_5__base );
    Py_DECREF( tmp_select_metaclass_5__base );
    tmp_select_metaclass_5__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_9:;
    tmp_assign_source_66 = tmp_outline_return_value_9;
    condexpr_end_5:;
    assert( tmp_class_creation_5__metaclass == NULL );
    tmp_class_creation_5__metaclass = tmp_assign_source_66;

    tmp_called_name_5 = tmp_class_creation_5__metaclass;

    CHECK_OBJECT( tmp_called_name_5 );
    tmp_args_element_name_13 = const_str_plain_UnicodeMap;
    tmp_args_element_name_14 = tmp_class_creation_5__bases;

    CHECK_OBJECT( tmp_args_element_name_14 );
    tmp_args_element_name_15 = tmp_class_creation_5__class_dict;

    CHECK_OBJECT( tmp_args_element_name_15 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 134;
    {
        PyObject *call_args[] = { tmp_args_element_name_13, tmp_args_element_name_14, tmp_args_element_name_15 };
        tmp_assign_source_68 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_5, call_args );
    }

    if ( tmp_assign_source_68 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 134;

        goto try_except_handler_15;
    }
    assert( tmp_class_creation_5__class == NULL );
    tmp_class_creation_5__class = tmp_assign_source_68;

    goto try_end_5;
    // Exception handler code:
    try_except_handler_15:;
    exception_keeper_type_11 = exception_type;
    exception_keeper_value_11 = exception_value;
    exception_keeper_tb_11 = exception_tb;
    exception_keeper_lineno_11 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_5__bases );
    tmp_class_creation_5__bases = NULL;

    Py_XDECREF( tmp_class_creation_5__class_dict );
    tmp_class_creation_5__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_5__metaclass );
    tmp_class_creation_5__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_11;
    exception_value = exception_keeper_value_11;
    exception_tb = exception_keeper_tb_11;
    exception_lineno = exception_keeper_lineno_11;

    goto frame_exception_exit_1;
    // End of try:
    try_end_5:;
    tmp_assign_source_69 = tmp_class_creation_5__class;

    CHECK_OBJECT( tmp_assign_source_69 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_UnicodeMap, tmp_assign_source_69 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_5__class );
    Py_DECREF( tmp_class_creation_5__class );
    tmp_class_creation_5__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_5__bases );
    Py_DECREF( tmp_class_creation_5__bases );
    tmp_class_creation_5__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_5__class_dict );
    Py_DECREF( tmp_class_creation_5__class_dict );
    tmp_class_creation_5__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_5__metaclass );
    Py_DECREF( tmp_class_creation_5__metaclass );
    tmp_class_creation_5__metaclass = NULL;

    // Tried code:
    tmp_assign_source_70 = PyTuple_New( 1 );
    tmp_tuple_element_7 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMap );

    if (unlikely( tmp_tuple_element_7 == NULL ))
    {
        tmp_tuple_element_7 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMap );
    }

    if ( tmp_tuple_element_7 == NULL )
    {
        Py_DECREF( tmp_assign_source_70 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMap" );
        exception_tb = NULL;

        exception_lineno = 157;

        goto try_except_handler_19;
    }

    Py_INCREF( tmp_tuple_element_7 );
    PyTuple_SET_ITEM( tmp_assign_source_70, 0, tmp_tuple_element_7 );
    assert( tmp_class_creation_6__bases == NULL );
    tmp_class_creation_6__bases = tmp_assign_source_70;

    tmp_assign_source_72 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_5_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_72 );
    outline_5_var___module__ = tmp_assign_source_72;

    tmp_assign_source_73 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_17_add_code2cid(  );
    assert( outline_5_var_add_code2cid == NULL );
    outline_5_var_add_code2cid = tmp_assign_source_73;

    // Tried code:
    tmp_outline_return_value_10 = _PyDict_NewPresized( 2 );
    tmp_dict_value_23 = outline_5_var___module__;

    CHECK_OBJECT( tmp_dict_value_23 );
    tmp_dict_key_23 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_10, tmp_dict_key_23, tmp_dict_value_23 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_24 = outline_5_var_add_code2cid;

    CHECK_OBJECT( tmp_dict_value_24 );
    tmp_dict_key_24 = const_str_plain_add_code2cid;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_10, tmp_dict_key_24, tmp_dict_value_24 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_20;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_20:;
    CHECK_OBJECT( (PyObject *)outline_5_var___module__ );
    Py_DECREF( outline_5_var___module__ );
    outline_5_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_5_var_add_code2cid );
    Py_DECREF( outline_5_var_add_code2cid );
    outline_5_var_add_code2cid = NULL;

    goto outline_result_10;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_5_var___module__ );
    Py_DECREF( outline_5_var___module__ );
    outline_5_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_5_var_add_code2cid );
    Py_DECREF( outline_5_var_add_code2cid );
    outline_5_var_add_code2cid = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_10:;
    tmp_assign_source_71 = tmp_outline_return_value_10;
    assert( tmp_class_creation_6__class_dict == NULL );
    tmp_class_creation_6__class_dict = tmp_assign_source_71;

    tmp_compare_left_6 = const_str_plain___metaclass__;
    tmp_compare_right_6 = tmp_class_creation_6__class_dict;

    CHECK_OBJECT( tmp_compare_right_6 );
    tmp_cmp_In_6 = PySequence_Contains( tmp_compare_right_6, tmp_compare_left_6 );
    assert( !(tmp_cmp_In_6 == -1) );
    if ( tmp_cmp_In_6 == 1 )
    {
        goto condexpr_true_6;
    }
    else
    {
        goto condexpr_false_6;
    }
    condexpr_true_6:;
    tmp_dict_name_6 = tmp_class_creation_6__class_dict;

    CHECK_OBJECT( tmp_dict_name_6 );
    tmp_key_name_6 = const_str_plain___metaclass__;
    tmp_assign_source_74 = DICT_GET_ITEM( tmp_dict_name_6, tmp_key_name_6 );
    if ( tmp_assign_source_74 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 157;

        goto try_except_handler_19;
    }
    goto condexpr_end_6;
    condexpr_false_6:;
    tmp_subscribed_name_5 = tmp_class_creation_6__bases;

    CHECK_OBJECT( tmp_subscribed_name_5 );
    tmp_subscript_name_5 = const_int_0;
    tmp_assign_source_75 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_5, tmp_subscript_name_5 );
    if ( tmp_assign_source_75 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 157;

        goto try_except_handler_19;
    }
    assert( tmp_select_metaclass_6__base == NULL );
    tmp_select_metaclass_6__base = tmp_assign_source_75;

    // Tried code:
    // Tried code:
    tmp_source_name_7 = tmp_select_metaclass_6__base;

    CHECK_OBJECT( tmp_source_name_7 );
    tmp_outline_return_value_11 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_7 );
    if ( tmp_outline_return_value_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 157;

        goto try_except_handler_22;
    }
    goto try_return_handler_21;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_22:;
    exception_keeper_type_12 = exception_type;
    exception_keeper_value_12 = exception_value;
    exception_keeper_tb_12 = exception_tb;
    exception_keeper_lineno_12 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_12 );
    Py_XDECREF( exception_keeper_value_12 );
    Py_XDECREF( exception_keeper_tb_12 );
    tmp_type_arg_5 = tmp_select_metaclass_6__base;

    CHECK_OBJECT( tmp_type_arg_5 );
    tmp_outline_return_value_11 = BUILTIN_TYPE1( tmp_type_arg_5 );
    assert( tmp_outline_return_value_11 != NULL );
    goto try_return_handler_21;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_21:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_6__base );
    Py_DECREF( tmp_select_metaclass_6__base );
    tmp_select_metaclass_6__base = NULL;

    goto outline_result_11;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_6__base );
    Py_DECREF( tmp_select_metaclass_6__base );
    tmp_select_metaclass_6__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_11:;
    tmp_assign_source_74 = tmp_outline_return_value_11;
    condexpr_end_6:;
    assert( tmp_class_creation_6__metaclass == NULL );
    tmp_class_creation_6__metaclass = tmp_assign_source_74;

    tmp_called_name_6 = tmp_class_creation_6__metaclass;

    CHECK_OBJECT( tmp_called_name_6 );
    tmp_args_element_name_16 = const_str_plain_FileCMap;
    tmp_args_element_name_17 = tmp_class_creation_6__bases;

    CHECK_OBJECT( tmp_args_element_name_17 );
    tmp_args_element_name_18 = tmp_class_creation_6__class_dict;

    CHECK_OBJECT( tmp_args_element_name_18 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 157;
    {
        PyObject *call_args[] = { tmp_args_element_name_16, tmp_args_element_name_17, tmp_args_element_name_18 };
        tmp_assign_source_76 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_6, call_args );
    }

    if ( tmp_assign_source_76 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 157;

        goto try_except_handler_19;
    }
    assert( tmp_class_creation_6__class == NULL );
    tmp_class_creation_6__class = tmp_assign_source_76;

    goto try_end_6;
    // Exception handler code:
    try_except_handler_19:;
    exception_keeper_type_13 = exception_type;
    exception_keeper_value_13 = exception_value;
    exception_keeper_tb_13 = exception_tb;
    exception_keeper_lineno_13 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_6__bases );
    tmp_class_creation_6__bases = NULL;

    Py_XDECREF( tmp_class_creation_6__class_dict );
    tmp_class_creation_6__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_6__metaclass );
    tmp_class_creation_6__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_13;
    exception_value = exception_keeper_value_13;
    exception_tb = exception_keeper_tb_13;
    exception_lineno = exception_keeper_lineno_13;

    goto frame_exception_exit_1;
    // End of try:
    try_end_6:;
    tmp_assign_source_77 = tmp_class_creation_6__class;

    CHECK_OBJECT( tmp_assign_source_77 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_FileCMap, tmp_assign_source_77 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_6__class );
    Py_DECREF( tmp_class_creation_6__class );
    tmp_class_creation_6__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_6__bases );
    Py_DECREF( tmp_class_creation_6__bases );
    tmp_class_creation_6__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_6__class_dict );
    Py_DECREF( tmp_class_creation_6__class_dict );
    tmp_class_creation_6__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_6__metaclass );
    Py_DECREF( tmp_class_creation_6__metaclass );
    tmp_class_creation_6__metaclass = NULL;

    // Tried code:
    tmp_assign_source_78 = PyTuple_New( 1 );
    tmp_tuple_element_8 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_UnicodeMap );

    if (unlikely( tmp_tuple_element_8 == NULL ))
    {
        tmp_tuple_element_8 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_UnicodeMap );
    }

    if ( tmp_tuple_element_8 == NULL )
    {
        Py_DECREF( tmp_assign_source_78 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "UnicodeMap" );
        exception_tb = NULL;

        exception_lineno = 177;

        goto try_except_handler_23;
    }

    Py_INCREF( tmp_tuple_element_8 );
    PyTuple_SET_ITEM( tmp_assign_source_78, 0, tmp_tuple_element_8 );
    assert( tmp_class_creation_7__bases == NULL );
    tmp_class_creation_7__bases = tmp_assign_source_78;

    tmp_assign_source_80 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_6_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_80 );
    outline_6_var___module__ = tmp_assign_source_80;

    tmp_assign_source_81 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_18_add_cid2unichr(  );
    assert( outline_6_var_add_cid2unichr == NULL );
    outline_6_var_add_cid2unichr = tmp_assign_source_81;

    // Tried code:
    tmp_outline_return_value_12 = _PyDict_NewPresized( 2 );
    tmp_dict_value_25 = outline_6_var___module__;

    CHECK_OBJECT( tmp_dict_value_25 );
    tmp_dict_key_25 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_12, tmp_dict_key_25, tmp_dict_value_25 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_26 = outline_6_var_add_cid2unichr;

    CHECK_OBJECT( tmp_dict_value_26 );
    tmp_dict_key_26 = const_str_plain_add_cid2unichr;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_12, tmp_dict_key_26, tmp_dict_value_26 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_24;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_24:;
    CHECK_OBJECT( (PyObject *)outline_6_var___module__ );
    Py_DECREF( outline_6_var___module__ );
    outline_6_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_6_var_add_cid2unichr );
    Py_DECREF( outline_6_var_add_cid2unichr );
    outline_6_var_add_cid2unichr = NULL;

    goto outline_result_12;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_6_var___module__ );
    Py_DECREF( outline_6_var___module__ );
    outline_6_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_6_var_add_cid2unichr );
    Py_DECREF( outline_6_var_add_cid2unichr );
    outline_6_var_add_cid2unichr = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_12:;
    tmp_assign_source_79 = tmp_outline_return_value_12;
    assert( tmp_class_creation_7__class_dict == NULL );
    tmp_class_creation_7__class_dict = tmp_assign_source_79;

    tmp_compare_left_7 = const_str_plain___metaclass__;
    tmp_compare_right_7 = tmp_class_creation_7__class_dict;

    CHECK_OBJECT( tmp_compare_right_7 );
    tmp_cmp_In_7 = PySequence_Contains( tmp_compare_right_7, tmp_compare_left_7 );
    assert( !(tmp_cmp_In_7 == -1) );
    if ( tmp_cmp_In_7 == 1 )
    {
        goto condexpr_true_7;
    }
    else
    {
        goto condexpr_false_7;
    }
    condexpr_true_7:;
    tmp_dict_name_7 = tmp_class_creation_7__class_dict;

    CHECK_OBJECT( tmp_dict_name_7 );
    tmp_key_name_7 = const_str_plain___metaclass__;
    tmp_assign_source_82 = DICT_GET_ITEM( tmp_dict_name_7, tmp_key_name_7 );
    if ( tmp_assign_source_82 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 177;

        goto try_except_handler_23;
    }
    goto condexpr_end_7;
    condexpr_false_7:;
    tmp_subscribed_name_6 = tmp_class_creation_7__bases;

    CHECK_OBJECT( tmp_subscribed_name_6 );
    tmp_subscript_name_6 = const_int_0;
    tmp_assign_source_83 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_6, tmp_subscript_name_6 );
    if ( tmp_assign_source_83 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 177;

        goto try_except_handler_23;
    }
    assert( tmp_select_metaclass_7__base == NULL );
    tmp_select_metaclass_7__base = tmp_assign_source_83;

    // Tried code:
    // Tried code:
    tmp_source_name_8 = tmp_select_metaclass_7__base;

    CHECK_OBJECT( tmp_source_name_8 );
    tmp_outline_return_value_13 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_8 );
    if ( tmp_outline_return_value_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 177;

        goto try_except_handler_26;
    }
    goto try_return_handler_25;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_26:;
    exception_keeper_type_14 = exception_type;
    exception_keeper_value_14 = exception_value;
    exception_keeper_tb_14 = exception_tb;
    exception_keeper_lineno_14 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_14 );
    Py_XDECREF( exception_keeper_value_14 );
    Py_XDECREF( exception_keeper_tb_14 );
    tmp_type_arg_6 = tmp_select_metaclass_7__base;

    CHECK_OBJECT( tmp_type_arg_6 );
    tmp_outline_return_value_13 = BUILTIN_TYPE1( tmp_type_arg_6 );
    assert( tmp_outline_return_value_13 != NULL );
    goto try_return_handler_25;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_25:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_7__base );
    Py_DECREF( tmp_select_metaclass_7__base );
    tmp_select_metaclass_7__base = NULL;

    goto outline_result_13;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_7__base );
    Py_DECREF( tmp_select_metaclass_7__base );
    tmp_select_metaclass_7__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_13:;
    tmp_assign_source_82 = tmp_outline_return_value_13;
    condexpr_end_7:;
    assert( tmp_class_creation_7__metaclass == NULL );
    tmp_class_creation_7__metaclass = tmp_assign_source_82;

    tmp_called_name_7 = tmp_class_creation_7__metaclass;

    CHECK_OBJECT( tmp_called_name_7 );
    tmp_args_element_name_19 = const_str_plain_FileUnicodeMap;
    tmp_args_element_name_20 = tmp_class_creation_7__bases;

    CHECK_OBJECT( tmp_args_element_name_20 );
    tmp_args_element_name_21 = tmp_class_creation_7__class_dict;

    CHECK_OBJECT( tmp_args_element_name_21 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 177;
    {
        PyObject *call_args[] = { tmp_args_element_name_19, tmp_args_element_name_20, tmp_args_element_name_21 };
        tmp_assign_source_84 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_7, call_args );
    }

    if ( tmp_assign_source_84 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 177;

        goto try_except_handler_23;
    }
    assert( tmp_class_creation_7__class == NULL );
    tmp_class_creation_7__class = tmp_assign_source_84;

    goto try_end_7;
    // Exception handler code:
    try_except_handler_23:;
    exception_keeper_type_15 = exception_type;
    exception_keeper_value_15 = exception_value;
    exception_keeper_tb_15 = exception_tb;
    exception_keeper_lineno_15 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_7__bases );
    tmp_class_creation_7__bases = NULL;

    Py_XDECREF( tmp_class_creation_7__class_dict );
    tmp_class_creation_7__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_7__metaclass );
    tmp_class_creation_7__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_15;
    exception_value = exception_keeper_value_15;
    exception_tb = exception_keeper_tb_15;
    exception_lineno = exception_keeper_lineno_15;

    goto frame_exception_exit_1;
    // End of try:
    try_end_7:;
    tmp_assign_source_85 = tmp_class_creation_7__class;

    CHECK_OBJECT( tmp_assign_source_85 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_FileUnicodeMap, tmp_assign_source_85 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_7__class );
    Py_DECREF( tmp_class_creation_7__class );
    tmp_class_creation_7__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_7__bases );
    Py_DECREF( tmp_class_creation_7__bases );
    tmp_class_creation_7__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_7__class_dict );
    Py_DECREF( tmp_class_creation_7__class_dict );
    tmp_class_creation_7__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_7__metaclass );
    Py_DECREF( tmp_class_creation_7__metaclass );
    tmp_class_creation_7__metaclass = NULL;

    // Tried code:
    tmp_assign_source_86 = PyTuple_New( 1 );
    tmp_tuple_element_9 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMap );

    if (unlikely( tmp_tuple_element_9 == NULL ))
    {
        tmp_tuple_element_9 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMap );
    }

    if ( tmp_tuple_element_9 == NULL )
    {
        Py_DECREF( tmp_assign_source_86 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMap" );
        exception_tb = NULL;

        exception_lineno = 196;

        goto try_except_handler_27;
    }

    Py_INCREF( tmp_tuple_element_9 );
    PyTuple_SET_ITEM( tmp_assign_source_86, 0, tmp_tuple_element_9 );
    assert( tmp_class_creation_8__bases == NULL );
    tmp_class_creation_8__bases = tmp_assign_source_86;

    tmp_assign_source_88 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_7_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_88 );
    outline_7_var___module__ = tmp_assign_source_88;

    tmp_assign_source_89 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_19___init__(  );
    assert( outline_7_var___init__ == NULL );
    outline_7_var___init__ = tmp_assign_source_89;

    // Tried code:
    tmp_outline_return_value_14 = _PyDict_NewPresized( 2 );
    tmp_dict_value_27 = outline_7_var___module__;

    CHECK_OBJECT( tmp_dict_value_27 );
    tmp_dict_key_27 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_14, tmp_dict_key_27, tmp_dict_value_27 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_28 = outline_7_var___init__;

    CHECK_OBJECT( tmp_dict_value_28 );
    tmp_dict_key_28 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_14, tmp_dict_key_28, tmp_dict_value_28 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_28;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_28:;
    CHECK_OBJECT( (PyObject *)outline_7_var___module__ );
    Py_DECREF( outline_7_var___module__ );
    outline_7_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_7_var___init__ );
    Py_DECREF( outline_7_var___init__ );
    outline_7_var___init__ = NULL;

    goto outline_result_14;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_7_var___module__ );
    Py_DECREF( outline_7_var___module__ );
    outline_7_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_7_var___init__ );
    Py_DECREF( outline_7_var___init__ );
    outline_7_var___init__ = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_14:;
    tmp_assign_source_87 = tmp_outline_return_value_14;
    assert( tmp_class_creation_8__class_dict == NULL );
    tmp_class_creation_8__class_dict = tmp_assign_source_87;

    tmp_compare_left_8 = const_str_plain___metaclass__;
    tmp_compare_right_8 = tmp_class_creation_8__class_dict;

    CHECK_OBJECT( tmp_compare_right_8 );
    tmp_cmp_In_8 = PySequence_Contains( tmp_compare_right_8, tmp_compare_left_8 );
    assert( !(tmp_cmp_In_8 == -1) );
    if ( tmp_cmp_In_8 == 1 )
    {
        goto condexpr_true_8;
    }
    else
    {
        goto condexpr_false_8;
    }
    condexpr_true_8:;
    tmp_dict_name_8 = tmp_class_creation_8__class_dict;

    CHECK_OBJECT( tmp_dict_name_8 );
    tmp_key_name_8 = const_str_plain___metaclass__;
    tmp_assign_source_90 = DICT_GET_ITEM( tmp_dict_name_8, tmp_key_name_8 );
    if ( tmp_assign_source_90 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 196;

        goto try_except_handler_27;
    }
    goto condexpr_end_8;
    condexpr_false_8:;
    tmp_subscribed_name_7 = tmp_class_creation_8__bases;

    CHECK_OBJECT( tmp_subscribed_name_7 );
    tmp_subscript_name_7 = const_int_0;
    tmp_assign_source_91 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_7, tmp_subscript_name_7 );
    if ( tmp_assign_source_91 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 196;

        goto try_except_handler_27;
    }
    assert( tmp_select_metaclass_8__base == NULL );
    tmp_select_metaclass_8__base = tmp_assign_source_91;

    // Tried code:
    // Tried code:
    tmp_source_name_9 = tmp_select_metaclass_8__base;

    CHECK_OBJECT( tmp_source_name_9 );
    tmp_outline_return_value_15 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_9 );
    if ( tmp_outline_return_value_15 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 196;

        goto try_except_handler_30;
    }
    goto try_return_handler_29;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_30:;
    exception_keeper_type_16 = exception_type;
    exception_keeper_value_16 = exception_value;
    exception_keeper_tb_16 = exception_tb;
    exception_keeper_lineno_16 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_16 );
    Py_XDECREF( exception_keeper_value_16 );
    Py_XDECREF( exception_keeper_tb_16 );
    tmp_type_arg_7 = tmp_select_metaclass_8__base;

    CHECK_OBJECT( tmp_type_arg_7 );
    tmp_outline_return_value_15 = BUILTIN_TYPE1( tmp_type_arg_7 );
    assert( tmp_outline_return_value_15 != NULL );
    goto try_return_handler_29;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_29:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_8__base );
    Py_DECREF( tmp_select_metaclass_8__base );
    tmp_select_metaclass_8__base = NULL;

    goto outline_result_15;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_8__base );
    Py_DECREF( tmp_select_metaclass_8__base );
    tmp_select_metaclass_8__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_15:;
    tmp_assign_source_90 = tmp_outline_return_value_15;
    condexpr_end_8:;
    assert( tmp_class_creation_8__metaclass == NULL );
    tmp_class_creation_8__metaclass = tmp_assign_source_90;

    tmp_called_name_8 = tmp_class_creation_8__metaclass;

    CHECK_OBJECT( tmp_called_name_8 );
    tmp_args_element_name_22 = const_str_plain_PyCMap;
    tmp_args_element_name_23 = tmp_class_creation_8__bases;

    CHECK_OBJECT( tmp_args_element_name_23 );
    tmp_args_element_name_24 = tmp_class_creation_8__class_dict;

    CHECK_OBJECT( tmp_args_element_name_24 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 196;
    {
        PyObject *call_args[] = { tmp_args_element_name_22, tmp_args_element_name_23, tmp_args_element_name_24 };
        tmp_assign_source_92 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_8, call_args );
    }

    if ( tmp_assign_source_92 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 196;

        goto try_except_handler_27;
    }
    assert( tmp_class_creation_8__class == NULL );
    tmp_class_creation_8__class = tmp_assign_source_92;

    goto try_end_8;
    // Exception handler code:
    try_except_handler_27:;
    exception_keeper_type_17 = exception_type;
    exception_keeper_value_17 = exception_value;
    exception_keeper_tb_17 = exception_tb;
    exception_keeper_lineno_17 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_8__bases );
    tmp_class_creation_8__bases = NULL;

    Py_XDECREF( tmp_class_creation_8__class_dict );
    tmp_class_creation_8__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_8__metaclass );
    tmp_class_creation_8__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_17;
    exception_value = exception_keeper_value_17;
    exception_tb = exception_keeper_tb_17;
    exception_lineno = exception_keeper_lineno_17;

    goto frame_exception_exit_1;
    // End of try:
    try_end_8:;
    tmp_assign_source_93 = tmp_class_creation_8__class;

    CHECK_OBJECT( tmp_assign_source_93 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PyCMap, tmp_assign_source_93 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_8__class );
    Py_DECREF( tmp_class_creation_8__class );
    tmp_class_creation_8__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_8__bases );
    Py_DECREF( tmp_class_creation_8__bases );
    tmp_class_creation_8__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_8__class_dict );
    Py_DECREF( tmp_class_creation_8__class_dict );
    tmp_class_creation_8__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_8__metaclass );
    Py_DECREF( tmp_class_creation_8__metaclass );
    tmp_class_creation_8__metaclass = NULL;

    // Tried code:
    tmp_assign_source_94 = PyTuple_New( 1 );
    tmp_tuple_element_10 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_UnicodeMap );

    if (unlikely( tmp_tuple_element_10 == NULL ))
    {
        tmp_tuple_element_10 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_UnicodeMap );
    }

    if ( tmp_tuple_element_10 == NULL )
    {
        Py_DECREF( tmp_assign_source_94 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "UnicodeMap" );
        exception_tb = NULL;

        exception_lineno = 208;

        goto try_except_handler_31;
    }

    Py_INCREF( tmp_tuple_element_10 );
    PyTuple_SET_ITEM( tmp_assign_source_94, 0, tmp_tuple_element_10 );
    assert( tmp_class_creation_9__bases == NULL );
    tmp_class_creation_9__bases = tmp_assign_source_94;

    tmp_assign_source_96 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_8_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_96 );
    outline_8_var___module__ = tmp_assign_source_96;

    tmp_assign_source_97 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_20___init__(  );
    assert( outline_8_var___init__ == NULL );
    outline_8_var___init__ = tmp_assign_source_97;

    // Tried code:
    tmp_outline_return_value_16 = _PyDict_NewPresized( 2 );
    tmp_dict_value_29 = outline_8_var___module__;

    CHECK_OBJECT( tmp_dict_value_29 );
    tmp_dict_key_29 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_16, tmp_dict_key_29, tmp_dict_value_29 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_30 = outline_8_var___init__;

    CHECK_OBJECT( tmp_dict_value_30 );
    tmp_dict_key_30 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_16, tmp_dict_key_30, tmp_dict_value_30 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_32;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_32:;
    CHECK_OBJECT( (PyObject *)outline_8_var___module__ );
    Py_DECREF( outline_8_var___module__ );
    outline_8_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_8_var___init__ );
    Py_DECREF( outline_8_var___init__ );
    outline_8_var___init__ = NULL;

    goto outline_result_16;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_8_var___module__ );
    Py_DECREF( outline_8_var___module__ );
    outline_8_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_8_var___init__ );
    Py_DECREF( outline_8_var___init__ );
    outline_8_var___init__ = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_16:;
    tmp_assign_source_95 = tmp_outline_return_value_16;
    assert( tmp_class_creation_9__class_dict == NULL );
    tmp_class_creation_9__class_dict = tmp_assign_source_95;

    tmp_compare_left_9 = const_str_plain___metaclass__;
    tmp_compare_right_9 = tmp_class_creation_9__class_dict;

    CHECK_OBJECT( tmp_compare_right_9 );
    tmp_cmp_In_9 = PySequence_Contains( tmp_compare_right_9, tmp_compare_left_9 );
    assert( !(tmp_cmp_In_9 == -1) );
    if ( tmp_cmp_In_9 == 1 )
    {
        goto condexpr_true_9;
    }
    else
    {
        goto condexpr_false_9;
    }
    condexpr_true_9:;
    tmp_dict_name_9 = tmp_class_creation_9__class_dict;

    CHECK_OBJECT( tmp_dict_name_9 );
    tmp_key_name_9 = const_str_plain___metaclass__;
    tmp_assign_source_98 = DICT_GET_ITEM( tmp_dict_name_9, tmp_key_name_9 );
    if ( tmp_assign_source_98 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 208;

        goto try_except_handler_31;
    }
    goto condexpr_end_9;
    condexpr_false_9:;
    tmp_subscribed_name_8 = tmp_class_creation_9__bases;

    CHECK_OBJECT( tmp_subscribed_name_8 );
    tmp_subscript_name_8 = const_int_0;
    tmp_assign_source_99 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_8, tmp_subscript_name_8 );
    if ( tmp_assign_source_99 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 208;

        goto try_except_handler_31;
    }
    assert( tmp_select_metaclass_9__base == NULL );
    tmp_select_metaclass_9__base = tmp_assign_source_99;

    // Tried code:
    // Tried code:
    tmp_source_name_10 = tmp_select_metaclass_9__base;

    CHECK_OBJECT( tmp_source_name_10 );
    tmp_outline_return_value_17 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_10 );
    if ( tmp_outline_return_value_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 208;

        goto try_except_handler_34;
    }
    goto try_return_handler_33;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_34:;
    exception_keeper_type_18 = exception_type;
    exception_keeper_value_18 = exception_value;
    exception_keeper_tb_18 = exception_tb;
    exception_keeper_lineno_18 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_18 );
    Py_XDECREF( exception_keeper_value_18 );
    Py_XDECREF( exception_keeper_tb_18 );
    tmp_type_arg_8 = tmp_select_metaclass_9__base;

    CHECK_OBJECT( tmp_type_arg_8 );
    tmp_outline_return_value_17 = BUILTIN_TYPE1( tmp_type_arg_8 );
    assert( tmp_outline_return_value_17 != NULL );
    goto try_return_handler_33;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_33:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_9__base );
    Py_DECREF( tmp_select_metaclass_9__base );
    tmp_select_metaclass_9__base = NULL;

    goto outline_result_17;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_9__base );
    Py_DECREF( tmp_select_metaclass_9__base );
    tmp_select_metaclass_9__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_17:;
    tmp_assign_source_98 = tmp_outline_return_value_17;
    condexpr_end_9:;
    assert( tmp_class_creation_9__metaclass == NULL );
    tmp_class_creation_9__metaclass = tmp_assign_source_98;

    tmp_called_name_9 = tmp_class_creation_9__metaclass;

    CHECK_OBJECT( tmp_called_name_9 );
    tmp_args_element_name_25 = const_str_plain_PyUnicodeMap;
    tmp_args_element_name_26 = tmp_class_creation_9__bases;

    CHECK_OBJECT( tmp_args_element_name_26 );
    tmp_args_element_name_27 = tmp_class_creation_9__class_dict;

    CHECK_OBJECT( tmp_args_element_name_27 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 208;
    {
        PyObject *call_args[] = { tmp_args_element_name_25, tmp_args_element_name_26, tmp_args_element_name_27 };
        tmp_assign_source_100 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_9, call_args );
    }

    if ( tmp_assign_source_100 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 208;

        goto try_except_handler_31;
    }
    assert( tmp_class_creation_9__class == NULL );
    tmp_class_creation_9__class = tmp_assign_source_100;

    goto try_end_9;
    // Exception handler code:
    try_except_handler_31:;
    exception_keeper_type_19 = exception_type;
    exception_keeper_value_19 = exception_value;
    exception_keeper_tb_19 = exception_tb;
    exception_keeper_lineno_19 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_9__bases );
    tmp_class_creation_9__bases = NULL;

    Py_XDECREF( tmp_class_creation_9__class_dict );
    tmp_class_creation_9__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_9__metaclass );
    tmp_class_creation_9__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_19;
    exception_value = exception_keeper_value_19;
    exception_tb = exception_keeper_tb_19;
    exception_lineno = exception_keeper_lineno_19;

    goto frame_exception_exit_1;
    // End of try:
    try_end_9:;
    tmp_assign_source_101 = tmp_class_creation_9__class;

    CHECK_OBJECT( tmp_assign_source_101 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PyUnicodeMap, tmp_assign_source_101 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_9__class );
    Py_DECREF( tmp_class_creation_9__class );
    tmp_class_creation_9__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_9__bases );
    Py_DECREF( tmp_class_creation_9__bases );
    tmp_class_creation_9__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_9__class_dict );
    Py_DECREF( tmp_class_creation_9__class_dict );
    tmp_class_creation_9__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_9__metaclass );
    Py_DECREF( tmp_class_creation_9__metaclass );
    tmp_class_creation_9__metaclass = NULL;

    // Tried code:
    tmp_assign_source_103 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_9_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_103 );
    outline_9_var___module__ = tmp_assign_source_103;

    tmp_assign_source_104 = PyDict_New();
    assert( outline_9_var__cmap_cache == NULL );
    outline_9_var__cmap_cache = tmp_assign_source_104;

    tmp_assign_source_105 = PyDict_New();
    assert( outline_9_var__umap_cache == NULL );
    outline_9_var__umap_cache = tmp_assign_source_105;

    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_e27dfacafd4f0c6cafc37ccc00e56d00_4, codeobj_e27dfacafd4f0c6cafc37ccc00e56d00, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 = cache_frame_e27dfacafd4f0c6cafc37ccc00e56d00_4;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 ) == 2 ); // Frame stack

    // Framed code:
    // Tried code:
    tmp_assign_source_106 = PyTuple_New( 1 );
    tmp_tuple_element_11 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapError );

    if (unlikely( tmp_tuple_element_11 == NULL ))
    {
        tmp_tuple_element_11 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapError );
    }

    if ( tmp_tuple_element_11 == NULL )
    {
        Py_DECREF( tmp_assign_source_106 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "CMapError" );
        exception_tb = NULL;

        exception_lineno = 227;
        type_description_2 = "oooNNNN";
        goto try_except_handler_37;
    }

    Py_INCREF( tmp_tuple_element_11 );
    PyTuple_SET_ITEM( tmp_assign_source_106, 0, tmp_tuple_element_11 );
    assert( tmp_CMapDB$class_creation_1__bases == NULL );
    tmp_CMapDB$class_creation_1__bases = tmp_assign_source_106;

    tmp_assign_source_108 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_10_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_108 );
    outline_10_var___module__ = tmp_assign_source_108;

    // Tried code:
    tmp_outline_return_value_19 = _PyDict_NewPresized( 1 );
    tmp_dict_value_31 = outline_10_var___module__;

    CHECK_OBJECT( tmp_dict_value_31 );
    tmp_dict_key_31 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_19, tmp_dict_key_31, tmp_dict_value_31 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_38;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_38:;
    CHECK_OBJECT( (PyObject *)outline_10_var___module__ );
    Py_DECREF( outline_10_var___module__ );
    outline_10_var___module__ = NULL;

    goto outline_result_19;
    // End of try:
    CHECK_OBJECT( (PyObject *)outline_10_var___module__ );
    Py_DECREF( outline_10_var___module__ );
    outline_10_var___module__ = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_19:;
    tmp_assign_source_107 = tmp_outline_return_value_19;
    assert( tmp_CMapDB$class_creation_1__class_dict == NULL );
    tmp_CMapDB$class_creation_1__class_dict = tmp_assign_source_107;

    tmp_compare_left_10 = const_str_plain___metaclass__;
    tmp_compare_right_10 = tmp_CMapDB$class_creation_1__class_dict;

    CHECK_OBJECT( tmp_compare_right_10 );
    tmp_cmp_In_10 = PySequence_Contains( tmp_compare_right_10, tmp_compare_left_10 );
    assert( !(tmp_cmp_In_10 == -1) );
    if ( tmp_cmp_In_10 == 1 )
    {
        goto condexpr_true_10;
    }
    else
    {
        goto condexpr_false_10;
    }
    condexpr_true_10:;
    tmp_dict_name_10 = tmp_CMapDB$class_creation_1__class_dict;

    CHECK_OBJECT( tmp_dict_name_10 );
    tmp_key_name_10 = const_str_plain___metaclass__;
    tmp_assign_source_109 = DICT_GET_ITEM( tmp_dict_name_10, tmp_key_name_10 );
    if ( tmp_assign_source_109 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 227;
        type_description_2 = "oooNNNN";
        goto try_except_handler_37;
    }
    goto condexpr_end_10;
    condexpr_false_10:;
    tmp_subscribed_name_9 = tmp_CMapDB$class_creation_1__bases;

    CHECK_OBJECT( tmp_subscribed_name_9 );
    tmp_subscript_name_9 = const_int_0;
    tmp_assign_source_110 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_9, tmp_subscript_name_9 );
    if ( tmp_assign_source_110 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 227;
        type_description_2 = "oooNNNN";
        goto try_except_handler_37;
    }
    assert( tmp_CMapDB$select_metaclass_1__base == NULL );
    tmp_CMapDB$select_metaclass_1__base = tmp_assign_source_110;

    // Tried code:
    // Tried code:
    tmp_source_name_11 = tmp_CMapDB$select_metaclass_1__base;

    CHECK_OBJECT( tmp_source_name_11 );
    tmp_outline_return_value_20 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_11 );
    if ( tmp_outline_return_value_20 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 227;
        type_description_2 = "oooNNNN";
        goto try_except_handler_40;
    }
    goto try_return_handler_39;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_40:;
    exception_keeper_type_20 = exception_type;
    exception_keeper_value_20 = exception_value;
    exception_keeper_tb_20 = exception_tb;
    exception_keeper_lineno_20 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_20 );
    Py_XDECREF( exception_keeper_value_20 );
    Py_XDECREF( exception_keeper_tb_20 );
    tmp_type_arg_9 = tmp_CMapDB$select_metaclass_1__base;

    CHECK_OBJECT( tmp_type_arg_9 );
    tmp_outline_return_value_20 = BUILTIN_TYPE1( tmp_type_arg_9 );
    assert( tmp_outline_return_value_20 != NULL );
    goto try_return_handler_39;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_39:;
    CHECK_OBJECT( (PyObject *)tmp_CMapDB$select_metaclass_1__base );
    Py_DECREF( tmp_CMapDB$select_metaclass_1__base );
    tmp_CMapDB$select_metaclass_1__base = NULL;

    goto outline_result_20;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_CMapDB$select_metaclass_1__base );
    Py_DECREF( tmp_CMapDB$select_metaclass_1__base );
    tmp_CMapDB$select_metaclass_1__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_20:;
    tmp_assign_source_109 = tmp_outline_return_value_20;
    condexpr_end_10:;
    assert( tmp_CMapDB$class_creation_1__metaclass == NULL );
    tmp_CMapDB$class_creation_1__metaclass = tmp_assign_source_109;

    tmp_called_name_10 = tmp_CMapDB$class_creation_1__metaclass;

    CHECK_OBJECT( tmp_called_name_10 );
    tmp_args_element_name_28 = const_str_plain_CMapNotFound;
    tmp_args_element_name_29 = tmp_CMapDB$class_creation_1__bases;

    CHECK_OBJECT( tmp_args_element_name_29 );
    tmp_args_element_name_30 = tmp_CMapDB$class_creation_1__class_dict;

    CHECK_OBJECT( tmp_args_element_name_30 );
    frame_e27dfacafd4f0c6cafc37ccc00e56d00_4->m_frame.f_lineno = 227;
    {
        PyObject *call_args[] = { tmp_args_element_name_28, tmp_args_element_name_29, tmp_args_element_name_30 };
        tmp_assign_source_111 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_10, call_args );
    }

    if ( tmp_assign_source_111 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 227;
        type_description_2 = "oooNNNN";
        goto try_except_handler_37;
    }
    assert( tmp_CMapDB$class_creation_1__class == NULL );
    tmp_CMapDB$class_creation_1__class = tmp_assign_source_111;

    goto try_end_10;
    // Exception handler code:
    try_except_handler_37:;
    exception_keeper_type_21 = exception_type;
    exception_keeper_value_21 = exception_value;
    exception_keeper_tb_21 = exception_tb;
    exception_keeper_lineno_21 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_CMapDB$class_creation_1__bases );
    tmp_CMapDB$class_creation_1__bases = NULL;

    Py_XDECREF( tmp_CMapDB$class_creation_1__class_dict );
    tmp_CMapDB$class_creation_1__class_dict = NULL;

    Py_XDECREF( tmp_CMapDB$class_creation_1__metaclass );
    tmp_CMapDB$class_creation_1__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_21;
    exception_value = exception_keeper_value_21;
    exception_tb = exception_keeper_tb_21;
    exception_lineno = exception_keeper_lineno_21;

    goto frame_exception_exit_4;
    // End of try:
    try_end_10:;
    tmp_assign_source_112 = tmp_CMapDB$class_creation_1__class;

    CHECK_OBJECT( tmp_assign_source_112 );
    assert( outline_9_var_CMapNotFound == NULL );
    Py_INCREF( tmp_assign_source_112 );
    outline_9_var_CMapNotFound = tmp_assign_source_112;

    CHECK_OBJECT( (PyObject *)tmp_CMapDB$class_creation_1__class );
    Py_DECREF( tmp_CMapDB$class_creation_1__class );
    tmp_CMapDB$class_creation_1__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_CMapDB$class_creation_1__bases );
    Py_DECREF( tmp_CMapDB$class_creation_1__bases );
    tmp_CMapDB$class_creation_1__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_CMapDB$class_creation_1__class_dict );
    Py_DECREF( tmp_CMapDB$class_creation_1__class_dict );
    tmp_CMapDB$class_creation_1__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_CMapDB$class_creation_1__metaclass );
    Py_DECREF( tmp_CMapDB$class_creation_1__metaclass );
    tmp_CMapDB$class_creation_1__metaclass = NULL;

    tmp_classmethod_arg_1 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_21__load_data(  );
    tmp_assign_source_113 = BUILTIN_CLASSMETHOD( tmp_classmethod_arg_1 );
    Py_DECREF( tmp_classmethod_arg_1 );
    if ( tmp_assign_source_113 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 230;
        type_description_2 = "ooooNNN";
        goto frame_exception_exit_4;
    }
    assert( outline_9_var__load_data == NULL );
    outline_9_var__load_data = tmp_assign_source_113;

    tmp_classmethod_arg_2 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_22_get_cmap(  );
    tmp_assign_source_114 = BUILTIN_CLASSMETHOD( tmp_classmethod_arg_2 );
    Py_DECREF( tmp_classmethod_arg_2 );
    if ( tmp_assign_source_114 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 247;
        type_description_2 = "oooooNN";
        goto frame_exception_exit_4;
    }
    assert( outline_9_var_get_cmap == NULL );
    outline_9_var_get_cmap = tmp_assign_source_114;

    tmp_defaults_3 = const_tuple_false_tuple;
    Py_INCREF( tmp_defaults_3 );
    tmp_classmethod_arg_3 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_23_get_unicode_map( tmp_defaults_3 );
    tmp_assign_source_115 = BUILTIN_CLASSMETHOD( tmp_classmethod_arg_3 );
    Py_DECREF( tmp_classmethod_arg_3 );
    if ( tmp_assign_source_115 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 261;
        type_description_2 = "ooooooN";
        goto frame_exception_exit_4;
    }
    assert( outline_9_var_get_unicode_map == NULL );
    outline_9_var_get_unicode_map = tmp_assign_source_115;


#if 0
    RESTORE_FRAME_EXCEPTION( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_3;

    frame_exception_exit_4:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_e27dfacafd4f0c6cafc37ccc00e56d00_4->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_e27dfacafd4f0c6cafc37ccc00e56d00_4, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_e27dfacafd4f0c6cafc37ccc00e56d00_4,
        type_description_2,
        outline_9_var___module__,
        outline_9_var__cmap_cache,
        outline_9_var__umap_cache,
        outline_9_var_CMapNotFound,
        outline_9_var__load_data,
        outline_9_var_get_cmap,
        outline_9_var_get_unicode_map
    );


    // Release cached frame.
    if ( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 == cache_frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 )
    {
        Py_DECREF( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 );
    }
    cache_frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 = NULL;

    assertFrameObject( frame_e27dfacafd4f0c6cafc37ccc00e56d00_4 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto nested_frame_exit_3;

    frame_no_exception_3:;

    goto skip_nested_handling_3;
    nested_frame_exit_3:;

    goto try_except_handler_36;
    skip_nested_handling_3:;
    tmp_outline_return_value_18 = _PyDict_NewPresized( 7 );
    tmp_dict_value_32 = outline_9_var___module__;

    CHECK_OBJECT( tmp_dict_value_32 );
    tmp_dict_key_32 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_32, tmp_dict_value_32 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_33 = outline_9_var__cmap_cache;

    CHECK_OBJECT( tmp_dict_value_33 );
    tmp_dict_key_33 = const_str_plain__cmap_cache;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_33, tmp_dict_value_33 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_34 = outline_9_var__umap_cache;

    CHECK_OBJECT( tmp_dict_value_34 );
    tmp_dict_key_34 = const_str_plain__umap_cache;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_34, tmp_dict_value_34 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_35 = outline_9_var_CMapNotFound;

    CHECK_OBJECT( tmp_dict_value_35 );
    tmp_dict_key_35 = const_str_plain_CMapNotFound;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_35, tmp_dict_value_35 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_36 = outline_9_var__load_data;

    CHECK_OBJECT( tmp_dict_value_36 );
    tmp_dict_key_36 = const_str_plain__load_data;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_36, tmp_dict_value_36 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_37 = outline_9_var_get_cmap;

    CHECK_OBJECT( tmp_dict_value_37 );
    tmp_dict_key_37 = const_str_plain_get_cmap;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_37, tmp_dict_value_37 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_38 = outline_9_var_get_unicode_map;

    CHECK_OBJECT( tmp_dict_value_38 );
    tmp_dict_key_38 = const_str_plain_get_unicode_map;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_18, tmp_dict_key_38, tmp_dict_value_38 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_36;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_36:;
    CHECK_OBJECT( (PyObject *)outline_9_var___module__ );
    Py_DECREF( outline_9_var___module__ );
    outline_9_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var__cmap_cache );
    Py_DECREF( outline_9_var__cmap_cache );
    outline_9_var__cmap_cache = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var__umap_cache );
    Py_DECREF( outline_9_var__umap_cache );
    outline_9_var__umap_cache = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var_CMapNotFound );
    Py_DECREF( outline_9_var_CMapNotFound );
    outline_9_var_CMapNotFound = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var__load_data );
    Py_DECREF( outline_9_var__load_data );
    outline_9_var__load_data = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var_get_cmap );
    Py_DECREF( outline_9_var_get_cmap );
    outline_9_var_get_cmap = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var_get_unicode_map );
    Py_DECREF( outline_9_var_get_unicode_map );
    outline_9_var_get_unicode_map = NULL;

    goto outline_result_18;
    // Exception handler code:
    try_except_handler_36:;
    exception_keeper_type_22 = exception_type;
    exception_keeper_value_22 = exception_value;
    exception_keeper_tb_22 = exception_tb;
    exception_keeper_lineno_22 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)outline_9_var___module__ );
    Py_DECREF( outline_9_var___module__ );
    outline_9_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var__cmap_cache );
    Py_DECREF( outline_9_var__cmap_cache );
    outline_9_var__cmap_cache = NULL;

    CHECK_OBJECT( (PyObject *)outline_9_var__umap_cache );
    Py_DECREF( outline_9_var__umap_cache );
    outline_9_var__umap_cache = NULL;

    Py_XDECREF( outline_9_var_CMapNotFound );
    outline_9_var_CMapNotFound = NULL;

    Py_XDECREF( outline_9_var__load_data );
    outline_9_var__load_data = NULL;

    Py_XDECREF( outline_9_var_get_cmap );
    outline_9_var_get_cmap = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_22;
    exception_value = exception_keeper_value_22;
    exception_tb = exception_keeper_tb_22;
    exception_lineno = exception_keeper_lineno_22;

    goto outline_exception_3;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_exception_3:;
    exception_lineno = 222;
    goto try_except_handler_35;
    outline_result_18:;
    tmp_assign_source_102 = tmp_outline_return_value_18;
    assert( tmp_class_creation_10__class_dict == NULL );
    tmp_class_creation_10__class_dict = tmp_assign_source_102;

    tmp_compare_left_11 = const_str_plain___metaclass__;
    tmp_compare_right_11 = tmp_class_creation_10__class_dict;

    CHECK_OBJECT( tmp_compare_right_11 );
    tmp_cmp_In_11 = PySequence_Contains( tmp_compare_right_11, tmp_compare_left_11 );
    assert( !(tmp_cmp_In_11 == -1) );
    if ( tmp_cmp_In_11 == 1 )
    {
        goto condexpr_true_11;
    }
    else
    {
        goto condexpr_false_11;
    }
    condexpr_true_11:;
    tmp_dict_name_11 = tmp_class_creation_10__class_dict;

    CHECK_OBJECT( tmp_dict_name_11 );
    tmp_key_name_11 = const_str_plain___metaclass__;
    tmp_assign_source_116 = DICT_GET_ITEM( tmp_dict_name_11, tmp_key_name_11 );
    if ( tmp_assign_source_116 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 222;

        goto try_except_handler_35;
    }
    goto condexpr_end_11;
    condexpr_false_11:;
    tmp_assign_source_116 = (PyObject *)&PyType_Type;
    Py_INCREF( tmp_assign_source_116 );
    condexpr_end_11:;
    assert( tmp_class_creation_10__metaclass == NULL );
    tmp_class_creation_10__metaclass = tmp_assign_source_116;

    tmp_called_name_11 = tmp_class_creation_10__metaclass;

    CHECK_OBJECT( tmp_called_name_11 );
    tmp_args_element_name_31 = const_str_plain_CMapDB;
    tmp_args_element_name_32 = const_tuple_type_object_tuple;
    tmp_args_element_name_33 = tmp_class_creation_10__class_dict;

    CHECK_OBJECT( tmp_args_element_name_33 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 222;
    {
        PyObject *call_args[] = { tmp_args_element_name_31, tmp_args_element_name_32, tmp_args_element_name_33 };
        tmp_assign_source_117 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_11, call_args );
    }

    if ( tmp_assign_source_117 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 222;

        goto try_except_handler_35;
    }
    assert( tmp_class_creation_10__class == NULL );
    tmp_class_creation_10__class = tmp_assign_source_117;

    goto try_end_11;
    // Exception handler code:
    try_except_handler_35:;
    exception_keeper_type_23 = exception_type;
    exception_keeper_value_23 = exception_value;
    exception_keeper_tb_23 = exception_tb;
    exception_keeper_lineno_23 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_10__class_dict );
    tmp_class_creation_10__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_10__metaclass );
    tmp_class_creation_10__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_23;
    exception_value = exception_keeper_value_23;
    exception_tb = exception_keeper_tb_23;
    exception_lineno = exception_keeper_lineno_23;

    goto frame_exception_exit_1;
    // End of try:
    try_end_11:;
    tmp_assign_source_118 = tmp_class_creation_10__class;

    CHECK_OBJECT( tmp_assign_source_118 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapDB, tmp_assign_source_118 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_10__class );
    Py_DECREF( tmp_class_creation_10__class );
    tmp_class_creation_10__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_10__class_dict );
    Py_DECREF( tmp_class_creation_10__class_dict );
    tmp_class_creation_10__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_10__metaclass );
    Py_DECREF( tmp_class_creation_10__metaclass );
    tmp_class_creation_10__metaclass = NULL;

    // Tried code:
    tmp_assign_source_119 = PyTuple_New( 1 );
    tmp_tuple_element_12 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_PSStackParser );

    if (unlikely( tmp_tuple_element_12 == NULL ))
    {
        tmp_tuple_element_12 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PSStackParser );
    }

    if ( tmp_tuple_element_12 == NULL )
    {
        Py_DECREF( tmp_assign_source_119 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "PSStackParser" );
        exception_tb = NULL;

        exception_lineno = 274;

        goto try_except_handler_41;
    }

    Py_INCREF( tmp_tuple_element_12 );
    PyTuple_SET_ITEM( tmp_assign_source_119, 0, tmp_tuple_element_12 );
    assert( tmp_class_creation_11__bases == NULL );
    tmp_class_creation_11__bases = tmp_assign_source_119;

    tmp_assign_source_121 = const_str_digest_a5f56e291553139a63a10626179e7804;
    assert( outline_11_var___module__ == NULL );
    Py_INCREF( tmp_assign_source_121 );
    outline_11_var___module__ = tmp_assign_source_121;

    tmp_assign_source_122 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_24___init__(  );
    assert( outline_11_var___init__ == NULL );
    outline_11_var___init__ = tmp_assign_source_122;

    tmp_assign_source_123 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_25_run(  );
    assert( outline_11_var_run == NULL );
    outline_11_var_run = tmp_assign_source_123;

    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_70c765a79ededee6fac819da4b485742_5, codeobj_70c765a79ededee6fac819da4b485742, module_pdfminer$cmapdb, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_70c765a79ededee6fac819da4b485742_5 = cache_frame_70c765a79ededee6fac819da4b485742_5;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_70c765a79ededee6fac819da4b485742_5 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_70c765a79ededee6fac819da4b485742_5 ) == 2 ); // Frame stack

    // Framed code:
    tmp_called_name_12 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_12 == NULL ))
    {
        tmp_called_name_12 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_12 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 290;
        type_description_2 = "oooNNNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 290;
    tmp_assign_source_124 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_12, &PyTuple_GET_ITEM( const_tuple_str_plain_begincmap_tuple, 0 ) );

    if ( tmp_assign_source_124 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 290;
        type_description_2 = "oooNNNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINCMAP == NULL );
    outline_11_var_KEYWORD_BEGINCMAP = tmp_assign_source_124;

    tmp_called_name_13 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_13 == NULL ))
    {
        tmp_called_name_13 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_13 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 291;
        type_description_2 = "ooooNNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 291;
    tmp_assign_source_125 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_13, &PyTuple_GET_ITEM( const_tuple_str_plain_endcmap_tuple, 0 ) );

    if ( tmp_assign_source_125 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 291;
        type_description_2 = "ooooNNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDCMAP == NULL );
    outline_11_var_KEYWORD_ENDCMAP = tmp_assign_source_125;

    tmp_called_name_14 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_14 == NULL ))
    {
        tmp_called_name_14 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_14 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 292;
        type_description_2 = "oooooNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 292;
    tmp_assign_source_126 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_14, &PyTuple_GET_ITEM( const_tuple_str_plain_usecmap_tuple, 0 ) );

    if ( tmp_assign_source_126 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 292;
        type_description_2 = "oooooNNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_USECMAP == NULL );
    outline_11_var_KEYWORD_USECMAP = tmp_assign_source_126;

    tmp_called_name_15 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_15 == NULL ))
    {
        tmp_called_name_15 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_15 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 293;
        type_description_2 = "ooooooNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 293;
    tmp_assign_source_127 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_15, &PyTuple_GET_ITEM( const_tuple_str_plain_def_tuple, 0 ) );

    if ( tmp_assign_source_127 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 293;
        type_description_2 = "ooooooNNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_DEF == NULL );
    outline_11_var_KEYWORD_DEF = tmp_assign_source_127;

    tmp_called_name_16 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_16 == NULL ))
    {
        tmp_called_name_16 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_16 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 294;
        type_description_2 = "oooooooNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 294;
    tmp_assign_source_128 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_16, &PyTuple_GET_ITEM( const_tuple_str_plain_begincodespacerange_tuple, 0 ) );

    if ( tmp_assign_source_128 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 294;
        type_description_2 = "oooooooNNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINCODESPACERANGE == NULL );
    outline_11_var_KEYWORD_BEGINCODESPACERANGE = tmp_assign_source_128;

    tmp_called_name_17 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_17 == NULL ))
    {
        tmp_called_name_17 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_17 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 295;
        type_description_2 = "ooooooooNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 295;
    tmp_assign_source_129 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_17, &PyTuple_GET_ITEM( const_tuple_str_plain_endcodespacerange_tuple, 0 ) );

    if ( tmp_assign_source_129 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 295;
        type_description_2 = "ooooooooNNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDCODESPACERANGE == NULL );
    outline_11_var_KEYWORD_ENDCODESPACERANGE = tmp_assign_source_129;

    tmp_called_name_18 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_18 == NULL ))
    {
        tmp_called_name_18 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_18 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 296;
        type_description_2 = "oooooooooNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 296;
    tmp_assign_source_130 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_18, &PyTuple_GET_ITEM( const_tuple_str_plain_begincidrange_tuple, 0 ) );

    if ( tmp_assign_source_130 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 296;
        type_description_2 = "oooooooooNNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINCIDRANGE == NULL );
    outline_11_var_KEYWORD_BEGINCIDRANGE = tmp_assign_source_130;

    tmp_called_name_19 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_19 == NULL ))
    {
        tmp_called_name_19 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_19 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 297;
        type_description_2 = "ooooooooooNNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 297;
    tmp_assign_source_131 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_19, &PyTuple_GET_ITEM( const_tuple_str_plain_endcidrange_tuple, 0 ) );

    if ( tmp_assign_source_131 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 297;
        type_description_2 = "ooooooooooNNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDCIDRANGE == NULL );
    outline_11_var_KEYWORD_ENDCIDRANGE = tmp_assign_source_131;

    tmp_called_name_20 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_20 == NULL ))
    {
        tmp_called_name_20 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_20 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 298;
        type_description_2 = "oooooooooooNNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 298;
    tmp_assign_source_132 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_20, &PyTuple_GET_ITEM( const_tuple_str_plain_begincidchar_tuple, 0 ) );

    if ( tmp_assign_source_132 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 298;
        type_description_2 = "oooooooooooNNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINCIDCHAR == NULL );
    outline_11_var_KEYWORD_BEGINCIDCHAR = tmp_assign_source_132;

    tmp_called_name_21 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_21 == NULL ))
    {
        tmp_called_name_21 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_21 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 299;
        type_description_2 = "ooooooooooooNNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 299;
    tmp_assign_source_133 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_21, &PyTuple_GET_ITEM( const_tuple_str_plain_endcidchar_tuple, 0 ) );

    if ( tmp_assign_source_133 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 299;
        type_description_2 = "ooooooooooooNNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDCIDCHAR == NULL );
    outline_11_var_KEYWORD_ENDCIDCHAR = tmp_assign_source_133;

    tmp_called_name_22 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_22 == NULL ))
    {
        tmp_called_name_22 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_22 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 300;
        type_description_2 = "oooooooooooooNNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 300;
    tmp_assign_source_134 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_22, &PyTuple_GET_ITEM( const_tuple_str_plain_beginbfrange_tuple, 0 ) );

    if ( tmp_assign_source_134 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 300;
        type_description_2 = "oooooooooooooNNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINBFRANGE == NULL );
    outline_11_var_KEYWORD_BEGINBFRANGE = tmp_assign_source_134;

    tmp_called_name_23 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_23 == NULL ))
    {
        tmp_called_name_23 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_23 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 301;
        type_description_2 = "ooooooooooooooNNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 301;
    tmp_assign_source_135 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_23, &PyTuple_GET_ITEM( const_tuple_str_plain_endbfrange_tuple, 0 ) );

    if ( tmp_assign_source_135 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 301;
        type_description_2 = "ooooooooooooooNNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDBFRANGE == NULL );
    outline_11_var_KEYWORD_ENDBFRANGE = tmp_assign_source_135;

    tmp_called_name_24 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_24 == NULL ))
    {
        tmp_called_name_24 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_24 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 302;
        type_description_2 = "oooooooooooooooNNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 302;
    tmp_assign_source_136 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_24, &PyTuple_GET_ITEM( const_tuple_str_plain_beginbfchar_tuple, 0 ) );

    if ( tmp_assign_source_136 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 302;
        type_description_2 = "oooooooooooooooNNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINBFCHAR == NULL );
    outline_11_var_KEYWORD_BEGINBFCHAR = tmp_assign_source_136;

    tmp_called_name_25 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_25 == NULL ))
    {
        tmp_called_name_25 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_25 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 303;
        type_description_2 = "ooooooooooooooooNNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 303;
    tmp_assign_source_137 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_25, &PyTuple_GET_ITEM( const_tuple_str_plain_endbfchar_tuple, 0 ) );

    if ( tmp_assign_source_137 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 303;
        type_description_2 = "ooooooooooooooooNNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDBFCHAR == NULL );
    outline_11_var_KEYWORD_ENDBFCHAR = tmp_assign_source_137;

    tmp_called_name_26 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_26 == NULL ))
    {
        tmp_called_name_26 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_26 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 304;
        type_description_2 = "oooooooooooooooooNNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 304;
    tmp_assign_source_138 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_26, &PyTuple_GET_ITEM( const_tuple_str_plain_beginnotdefrange_tuple, 0 ) );

    if ( tmp_assign_source_138 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 304;
        type_description_2 = "oooooooooooooooooNNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_BEGINNOTDEFRANGE == NULL );
    outline_11_var_KEYWORD_BEGINNOTDEFRANGE = tmp_assign_source_138;

    tmp_called_name_27 = GET_STRING_DICT_VALUE( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_KWD );

    if (unlikely( tmp_called_name_27 == NULL ))
    {
        tmp_called_name_27 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_KWD );
    }

    if ( tmp_called_name_27 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "KWD" );
        exception_tb = NULL;

        exception_lineno = 305;
        type_description_2 = "ooooooooooooooooooNN";
        goto frame_exception_exit_5;
    }

    frame_70c765a79ededee6fac819da4b485742_5->m_frame.f_lineno = 305;
    tmp_assign_source_139 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_27, &PyTuple_GET_ITEM( const_tuple_str_plain_endnotdefrange_tuple, 0 ) );

    if ( tmp_assign_source_139 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 305;
        type_description_2 = "ooooooooooooooooooNN";
        goto frame_exception_exit_5;
    }
    assert( outline_11_var_KEYWORD_ENDNOTDEFRANGE == NULL );
    outline_11_var_KEYWORD_ENDNOTDEFRANGE = tmp_assign_source_139;


#if 0
    RESTORE_FRAME_EXCEPTION( frame_70c765a79ededee6fac819da4b485742_5 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_4;

    frame_exception_exit_5:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_70c765a79ededee6fac819da4b485742_5 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_70c765a79ededee6fac819da4b485742_5, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_70c765a79ededee6fac819da4b485742_5->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_70c765a79ededee6fac819da4b485742_5, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_70c765a79ededee6fac819da4b485742_5,
        type_description_2,
        outline_11_var___module__,
        outline_11_var___init__,
        outline_11_var_run,
        outline_11_var_KEYWORD_BEGINCMAP,
        outline_11_var_KEYWORD_ENDCMAP,
        outline_11_var_KEYWORD_USECMAP,
        outline_11_var_KEYWORD_DEF,
        outline_11_var_KEYWORD_BEGINCODESPACERANGE,
        outline_11_var_KEYWORD_ENDCODESPACERANGE,
        outline_11_var_KEYWORD_BEGINCIDRANGE,
        outline_11_var_KEYWORD_ENDCIDRANGE,
        outline_11_var_KEYWORD_BEGINCIDCHAR,
        outline_11_var_KEYWORD_ENDCIDCHAR,
        outline_11_var_KEYWORD_BEGINBFRANGE,
        outline_11_var_KEYWORD_ENDBFRANGE,
        outline_11_var_KEYWORD_BEGINBFCHAR,
        outline_11_var_KEYWORD_ENDBFCHAR,
        outline_11_var_KEYWORD_BEGINNOTDEFRANGE,
        outline_11_var_KEYWORD_ENDNOTDEFRANGE,
        NULL
    );


    // Release cached frame.
    if ( frame_70c765a79ededee6fac819da4b485742_5 == cache_frame_70c765a79ededee6fac819da4b485742_5 )
    {
        Py_DECREF( frame_70c765a79ededee6fac819da4b485742_5 );
    }
    cache_frame_70c765a79ededee6fac819da4b485742_5 = NULL;

    assertFrameObject( frame_70c765a79ededee6fac819da4b485742_5 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto nested_frame_exit_4;

    frame_no_exception_4:;

    goto skip_nested_handling_4;
    nested_frame_exit_4:;

    goto try_except_handler_42;
    skip_nested_handling_4:;
    tmp_assign_source_140 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_26_do_keyword(  );
    assert( outline_11_var_do_keyword == NULL );
    outline_11_var_do_keyword = tmp_assign_source_140;

    tmp_outline_return_value_21 = _PyDict_NewPresized( 20 );
    tmp_dict_value_39 = outline_11_var___module__;

    CHECK_OBJECT( tmp_dict_value_39 );
    tmp_dict_key_39 = const_str_plain___module__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_39, tmp_dict_value_39 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_40 = outline_11_var___init__;

    CHECK_OBJECT( tmp_dict_value_40 );
    tmp_dict_key_40 = const_str_plain___init__;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_40, tmp_dict_value_40 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_41 = outline_11_var_run;

    CHECK_OBJECT( tmp_dict_value_41 );
    tmp_dict_key_41 = const_str_plain_run;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_41, tmp_dict_value_41 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_42 = outline_11_var_KEYWORD_BEGINCMAP;

    CHECK_OBJECT( tmp_dict_value_42 );
    tmp_dict_key_42 = const_str_plain_KEYWORD_BEGINCMAP;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_42, tmp_dict_value_42 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_43 = outline_11_var_KEYWORD_ENDCMAP;

    CHECK_OBJECT( tmp_dict_value_43 );
    tmp_dict_key_43 = const_str_plain_KEYWORD_ENDCMAP;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_43, tmp_dict_value_43 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_44 = outline_11_var_KEYWORD_USECMAP;

    CHECK_OBJECT( tmp_dict_value_44 );
    tmp_dict_key_44 = const_str_plain_KEYWORD_USECMAP;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_44, tmp_dict_value_44 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_45 = outline_11_var_KEYWORD_DEF;

    CHECK_OBJECT( tmp_dict_value_45 );
    tmp_dict_key_45 = const_str_plain_KEYWORD_DEF;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_45, tmp_dict_value_45 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_46 = outline_11_var_KEYWORD_BEGINCODESPACERANGE;

    CHECK_OBJECT( tmp_dict_value_46 );
    tmp_dict_key_46 = const_str_plain_KEYWORD_BEGINCODESPACERANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_46, tmp_dict_value_46 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_47 = outline_11_var_KEYWORD_ENDCODESPACERANGE;

    CHECK_OBJECT( tmp_dict_value_47 );
    tmp_dict_key_47 = const_str_plain_KEYWORD_ENDCODESPACERANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_47, tmp_dict_value_47 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_48 = outline_11_var_KEYWORD_BEGINCIDRANGE;

    CHECK_OBJECT( tmp_dict_value_48 );
    tmp_dict_key_48 = const_str_plain_KEYWORD_BEGINCIDRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_48, tmp_dict_value_48 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_49 = outline_11_var_KEYWORD_ENDCIDRANGE;

    CHECK_OBJECT( tmp_dict_value_49 );
    tmp_dict_key_49 = const_str_plain_KEYWORD_ENDCIDRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_49, tmp_dict_value_49 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_50 = outline_11_var_KEYWORD_BEGINCIDCHAR;

    CHECK_OBJECT( tmp_dict_value_50 );
    tmp_dict_key_50 = const_str_plain_KEYWORD_BEGINCIDCHAR;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_50, tmp_dict_value_50 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_51 = outline_11_var_KEYWORD_ENDCIDCHAR;

    CHECK_OBJECT( tmp_dict_value_51 );
    tmp_dict_key_51 = const_str_plain_KEYWORD_ENDCIDCHAR;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_51, tmp_dict_value_51 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_52 = outline_11_var_KEYWORD_BEGINBFRANGE;

    CHECK_OBJECT( tmp_dict_value_52 );
    tmp_dict_key_52 = const_str_plain_KEYWORD_BEGINBFRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_52, tmp_dict_value_52 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_53 = outline_11_var_KEYWORD_ENDBFRANGE;

    CHECK_OBJECT( tmp_dict_value_53 );
    tmp_dict_key_53 = const_str_plain_KEYWORD_ENDBFRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_53, tmp_dict_value_53 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_54 = outline_11_var_KEYWORD_BEGINBFCHAR;

    CHECK_OBJECT( tmp_dict_value_54 );
    tmp_dict_key_54 = const_str_plain_KEYWORD_BEGINBFCHAR;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_54, tmp_dict_value_54 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_55 = outline_11_var_KEYWORD_ENDBFCHAR;

    CHECK_OBJECT( tmp_dict_value_55 );
    tmp_dict_key_55 = const_str_plain_KEYWORD_ENDBFCHAR;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_55, tmp_dict_value_55 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_56 = outline_11_var_KEYWORD_BEGINNOTDEFRANGE;

    CHECK_OBJECT( tmp_dict_value_56 );
    tmp_dict_key_56 = const_str_plain_KEYWORD_BEGINNOTDEFRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_56, tmp_dict_value_56 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_57 = outline_11_var_KEYWORD_ENDNOTDEFRANGE;

    CHECK_OBJECT( tmp_dict_value_57 );
    tmp_dict_key_57 = const_str_plain_KEYWORD_ENDNOTDEFRANGE;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_57, tmp_dict_value_57 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_58 = outline_11_var_do_keyword;

    CHECK_OBJECT( tmp_dict_value_58 );
    tmp_dict_key_58 = const_str_plain_do_keyword;
    tmp_res = PyDict_SetItem( tmp_outline_return_value_21, tmp_dict_key_58, tmp_dict_value_58 );
    assert( !(tmp_res != 0) );
    goto try_return_handler_42;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_42:;
    CHECK_OBJECT( (PyObject *)outline_11_var___module__ );
    Py_DECREF( outline_11_var___module__ );
    outline_11_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var___init__ );
    Py_DECREF( outline_11_var___init__ );
    outline_11_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_run );
    Py_DECREF( outline_11_var_run );
    outline_11_var_run = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINCMAP );
    Py_DECREF( outline_11_var_KEYWORD_BEGINCMAP );
    outline_11_var_KEYWORD_BEGINCMAP = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDCMAP );
    Py_DECREF( outline_11_var_KEYWORD_ENDCMAP );
    outline_11_var_KEYWORD_ENDCMAP = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_USECMAP );
    Py_DECREF( outline_11_var_KEYWORD_USECMAP );
    outline_11_var_KEYWORD_USECMAP = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_DEF );
    Py_DECREF( outline_11_var_KEYWORD_DEF );
    outline_11_var_KEYWORD_DEF = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINCODESPACERANGE );
    Py_DECREF( outline_11_var_KEYWORD_BEGINCODESPACERANGE );
    outline_11_var_KEYWORD_BEGINCODESPACERANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDCODESPACERANGE );
    Py_DECREF( outline_11_var_KEYWORD_ENDCODESPACERANGE );
    outline_11_var_KEYWORD_ENDCODESPACERANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINCIDRANGE );
    Py_DECREF( outline_11_var_KEYWORD_BEGINCIDRANGE );
    outline_11_var_KEYWORD_BEGINCIDRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDCIDRANGE );
    Py_DECREF( outline_11_var_KEYWORD_ENDCIDRANGE );
    outline_11_var_KEYWORD_ENDCIDRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINCIDCHAR );
    Py_DECREF( outline_11_var_KEYWORD_BEGINCIDCHAR );
    outline_11_var_KEYWORD_BEGINCIDCHAR = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDCIDCHAR );
    Py_DECREF( outline_11_var_KEYWORD_ENDCIDCHAR );
    outline_11_var_KEYWORD_ENDCIDCHAR = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINBFRANGE );
    Py_DECREF( outline_11_var_KEYWORD_BEGINBFRANGE );
    outline_11_var_KEYWORD_BEGINBFRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDBFRANGE );
    Py_DECREF( outline_11_var_KEYWORD_ENDBFRANGE );
    outline_11_var_KEYWORD_ENDBFRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINBFCHAR );
    Py_DECREF( outline_11_var_KEYWORD_BEGINBFCHAR );
    outline_11_var_KEYWORD_BEGINBFCHAR = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDBFCHAR );
    Py_DECREF( outline_11_var_KEYWORD_ENDBFCHAR );
    outline_11_var_KEYWORD_ENDBFCHAR = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_BEGINNOTDEFRANGE );
    Py_DECREF( outline_11_var_KEYWORD_BEGINNOTDEFRANGE );
    outline_11_var_KEYWORD_BEGINNOTDEFRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_KEYWORD_ENDNOTDEFRANGE );
    Py_DECREF( outline_11_var_KEYWORD_ENDNOTDEFRANGE );
    outline_11_var_KEYWORD_ENDNOTDEFRANGE = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_do_keyword );
    Py_DECREF( outline_11_var_do_keyword );
    outline_11_var_do_keyword = NULL;

    goto outline_result_21;
    // Exception handler code:
    try_except_handler_42:;
    exception_keeper_type_24 = exception_type;
    exception_keeper_value_24 = exception_value;
    exception_keeper_tb_24 = exception_tb;
    exception_keeper_lineno_24 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)outline_11_var___module__ );
    Py_DECREF( outline_11_var___module__ );
    outline_11_var___module__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var___init__ );
    Py_DECREF( outline_11_var___init__ );
    outline_11_var___init__ = NULL;

    CHECK_OBJECT( (PyObject *)outline_11_var_run );
    Py_DECREF( outline_11_var_run );
    outline_11_var_run = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINCMAP );
    outline_11_var_KEYWORD_BEGINCMAP = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDCMAP );
    outline_11_var_KEYWORD_ENDCMAP = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_USECMAP );
    outline_11_var_KEYWORD_USECMAP = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_DEF );
    outline_11_var_KEYWORD_DEF = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINCODESPACERANGE );
    outline_11_var_KEYWORD_BEGINCODESPACERANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDCODESPACERANGE );
    outline_11_var_KEYWORD_ENDCODESPACERANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINCIDRANGE );
    outline_11_var_KEYWORD_BEGINCIDRANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDCIDRANGE );
    outline_11_var_KEYWORD_ENDCIDRANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINCIDCHAR );
    outline_11_var_KEYWORD_BEGINCIDCHAR = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDCIDCHAR );
    outline_11_var_KEYWORD_ENDCIDCHAR = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINBFRANGE );
    outline_11_var_KEYWORD_BEGINBFRANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDBFRANGE );
    outline_11_var_KEYWORD_ENDBFRANGE = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINBFCHAR );
    outline_11_var_KEYWORD_BEGINBFCHAR = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_ENDBFCHAR );
    outline_11_var_KEYWORD_ENDBFCHAR = NULL;

    Py_XDECREF( outline_11_var_KEYWORD_BEGINNOTDEFRANGE );
    outline_11_var_KEYWORD_BEGINNOTDEFRANGE = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_24;
    exception_value = exception_keeper_value_24;
    exception_tb = exception_keeper_tb_24;
    exception_lineno = exception_keeper_lineno_24;

    goto outline_exception_4;
    // End of try:
    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_exception_4:;
    exception_lineno = 274;
    goto try_except_handler_41;
    outline_result_21:;
    tmp_assign_source_120 = tmp_outline_return_value_21;
    assert( tmp_class_creation_11__class_dict == NULL );
    tmp_class_creation_11__class_dict = tmp_assign_source_120;

    tmp_compare_left_12 = const_str_plain___metaclass__;
    tmp_compare_right_12 = tmp_class_creation_11__class_dict;

    CHECK_OBJECT( tmp_compare_right_12 );
    tmp_cmp_In_12 = PySequence_Contains( tmp_compare_right_12, tmp_compare_left_12 );
    assert( !(tmp_cmp_In_12 == -1) );
    if ( tmp_cmp_In_12 == 1 )
    {
        goto condexpr_true_12;
    }
    else
    {
        goto condexpr_false_12;
    }
    condexpr_true_12:;
    tmp_dict_name_12 = tmp_class_creation_11__class_dict;

    CHECK_OBJECT( tmp_dict_name_12 );
    tmp_key_name_12 = const_str_plain___metaclass__;
    tmp_assign_source_141 = DICT_GET_ITEM( tmp_dict_name_12, tmp_key_name_12 );
    if ( tmp_assign_source_141 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 274;

        goto try_except_handler_41;
    }
    goto condexpr_end_12;
    condexpr_false_12:;
    tmp_subscribed_name_10 = tmp_class_creation_11__bases;

    CHECK_OBJECT( tmp_subscribed_name_10 );
    tmp_subscript_name_10 = const_int_0;
    tmp_assign_source_142 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_10, tmp_subscript_name_10 );
    if ( tmp_assign_source_142 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 274;

        goto try_except_handler_41;
    }
    assert( tmp_select_metaclass_11__base == NULL );
    tmp_select_metaclass_11__base = tmp_assign_source_142;

    // Tried code:
    // Tried code:
    tmp_source_name_12 = tmp_select_metaclass_11__base;

    CHECK_OBJECT( tmp_source_name_12 );
    tmp_outline_return_value_22 = LOOKUP_ATTRIBUTE_CLASS_SLOT( tmp_source_name_12 );
    if ( tmp_outline_return_value_22 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 274;

        goto try_except_handler_44;
    }
    goto try_return_handler_43;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Exception handler code:
    try_except_handler_44:;
    exception_keeper_type_25 = exception_type;
    exception_keeper_value_25 = exception_value;
    exception_keeper_tb_25 = exception_tb;
    exception_keeper_lineno_25 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_DECREF( exception_keeper_type_25 );
    Py_XDECREF( exception_keeper_value_25 );
    Py_XDECREF( exception_keeper_tb_25 );
    tmp_type_arg_10 = tmp_select_metaclass_11__base;

    CHECK_OBJECT( tmp_type_arg_10 );
    tmp_outline_return_value_22 = BUILTIN_TYPE1( tmp_type_arg_10 );
    assert( tmp_outline_return_value_22 != NULL );
    goto try_return_handler_43;
    // End of try:
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    // Return handler code:
    try_return_handler_43:;
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_11__base );
    Py_DECREF( tmp_select_metaclass_11__base );
    tmp_select_metaclass_11__base = NULL;

    goto outline_result_22;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_select_metaclass_11__base );
    Py_DECREF( tmp_select_metaclass_11__base );
    tmp_select_metaclass_11__base = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( pdfminer$cmapdb );
    return MOD_RETURN_VALUE( NULL );
    outline_result_22:;
    tmp_assign_source_141 = tmp_outline_return_value_22;
    condexpr_end_12:;
    assert( tmp_class_creation_11__metaclass == NULL );
    tmp_class_creation_11__metaclass = tmp_assign_source_141;

    tmp_called_name_28 = tmp_class_creation_11__metaclass;

    CHECK_OBJECT( tmp_called_name_28 );
    tmp_args_element_name_34 = const_str_plain_CMapParser;
    tmp_args_element_name_35 = tmp_class_creation_11__bases;

    CHECK_OBJECT( tmp_args_element_name_35 );
    tmp_args_element_name_36 = tmp_class_creation_11__class_dict;

    CHECK_OBJECT( tmp_args_element_name_36 );
    frame_453c250602a3594a72d093020d99368b->m_frame.f_lineno = 274;
    {
        PyObject *call_args[] = { tmp_args_element_name_34, tmp_args_element_name_35, tmp_args_element_name_36 };
        tmp_assign_source_143 = CALL_FUNCTION_WITH_ARGS3( tmp_called_name_28, call_args );
    }

    if ( tmp_assign_source_143 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 274;

        goto try_except_handler_41;
    }
    assert( tmp_class_creation_11__class == NULL );
    tmp_class_creation_11__class = tmp_assign_source_143;

    goto try_end_12;
    // Exception handler code:
    try_except_handler_41:;
    exception_keeper_type_26 = exception_type;
    exception_keeper_value_26 = exception_value;
    exception_keeper_tb_26 = exception_tb;
    exception_keeper_lineno_26 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_class_creation_11__bases );
    tmp_class_creation_11__bases = NULL;

    Py_XDECREF( tmp_class_creation_11__class_dict );
    tmp_class_creation_11__class_dict = NULL;

    Py_XDECREF( tmp_class_creation_11__metaclass );
    tmp_class_creation_11__metaclass = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_26;
    exception_value = exception_keeper_value_26;
    exception_tb = exception_keeper_tb_26;
    exception_lineno = exception_keeper_lineno_26;

    goto frame_exception_exit_1;
    // End of try:
    try_end_12:;

    // Restore frame exception if necessary.
#if 0
    RESTORE_FRAME_EXCEPTION( frame_453c250602a3594a72d093020d99368b );
#endif
    popFrameStack();

    assertFrameObject( frame_453c250602a3594a72d093020d99368b );

    goto frame_no_exception_5;
    frame_exception_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_453c250602a3594a72d093020d99368b );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_453c250602a3594a72d093020d99368b, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_453c250602a3594a72d093020d99368b->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_453c250602a3594a72d093020d99368b, exception_lineno );
    }

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto module_exception_exit;
    frame_no_exception_5:;
    tmp_assign_source_144 = tmp_class_creation_11__class;

    CHECK_OBJECT( tmp_assign_source_144 );
    UPDATE_STRING_DICT0( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_CMapParser, tmp_assign_source_144 );
    CHECK_OBJECT( (PyObject *)tmp_class_creation_11__class );
    Py_DECREF( tmp_class_creation_11__class );
    tmp_class_creation_11__class = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_11__bases );
    Py_DECREF( tmp_class_creation_11__bases );
    tmp_class_creation_11__bases = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_11__class_dict );
    Py_DECREF( tmp_class_creation_11__class_dict );
    tmp_class_creation_11__class_dict = NULL;

    CHECK_OBJECT( (PyObject *)tmp_class_creation_11__metaclass );
    Py_DECREF( tmp_class_creation_11__metaclass );
    tmp_class_creation_11__metaclass = NULL;

    tmp_assign_source_145 = MAKE_FUNCTION_pdfminer$cmapdb$$$function_27_main(  );
    UPDATE_STRING_DICT1( moduledict_pdfminer$cmapdb, (Nuitka_StringObject *)const_str_plain_main, tmp_assign_source_145 );

    return MOD_RETURN_VALUE( module_pdfminer$cmapdb );
    module_exception_exit:
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );
    return MOD_RETURN_VALUE( NULL );
}
