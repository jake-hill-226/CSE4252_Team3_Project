/* Generated code for Python source for module '__main__'
 * created by Nuitka version 0.5.28.1
 *
 * This code is in part copyright 2017 Kay Hayen.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "nuitka/prelude.h"

#include "__helpers.h"

/* The _module___main__ is a Python object pointer of module type. */

/* Note: For full compatibility with CPython, every module variable access
 * needs to go through it except for cases where the module cannot possibly
 * have changed in the mean time.
 */

PyObject *module___main__;
PyDictObject *moduledict___main__;

/* The module constants used, if any. */
extern PyObject *const_str_plain___package__;
extern PyObject *const_str_plain_maxpages;
static PyObject *const_str_digest_d53cbfa1c290fabaad865ce93b11e777;
extern PyObject *const_str_plain_ImageWriter;
extern PyObject *const_dict_empty;
extern PyObject *const_str_plain_PDFResourceManager;
extern PyObject *const_str_plain_PDFParser;
extern PyObject *const_int_pos_100;
extern PyObject *const_str_plain_check_extractable;
static PyObject *const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple;
static PyObject *const_str_digest_d577b8f49b7cb9dcdb74f76e27464b19;
static PyObject *const_str_digest_7436cd68ba8ffbc71baa1bc9f27efa15;
static PyObject *const_str_digest_068eb885e4aaedf6bb189a0c4eb85723;
extern PyObject *const_str_plain_get_pages;
static PyObject *const_str_digest_e22d9173bccdc16d4477eee43c8497ac;
static PyObject *const_str_digest_c836122af34ee7a172b779f26da7801f;
extern PyObject *const_str_plain_layoutmode;
extern PyObject *const_str_plain_TagExtractor;
extern PyObject *const_str_digest_c075052d723d6707083e869a0e3659bb;
extern PyObject *const_tuple_empty;
static PyObject *const_str_digest_352c4dca5759fe5938694f4c56145f58;
static PyObject *const_str_plain_html;
extern PyObject *const_str_plain_close;
static PyObject *const_tuple_str_digest_215503f2c4e6161a6262d87acf44fc46_tuple;
extern PyObject *const_str_plain_PDFDevice;
extern PyObject *const_tuple_str_plain_PDFParser_tuple;
extern PyObject *const_str_plain_debug;
static PyObject *const_str_digest_661170a362c0712dfb804f7826b521cc;
extern PyObject *const_str_plain_argv;
static PyObject *const_str_digest_59bdb53e22971cd7d7e7b286d1104da6;
static PyObject *const_str_digest_e023af1ef281d8d55c1e56d49000f818;
extern PyObject *const_str_plain___main__;
static PyObject *const_str_digest_d312566fe84d6b0b90952b7c0274f1c6;
static PyObject *const_str_digest_a91b838d0c6058724804b19c9c797846;
extern PyObject *const_str_plain_detect_vertical;
extern PyObject *const_str_digest_89cffbfc3ef10076664cbfd1fe7e6033;
extern PyObject *const_str_plain_site;
static PyObject *const_tuple_str_chr_44_tuple;
extern PyObject *const_str_plain_split;
extern PyObject *const_str_plain_PDFDocument;
extern PyObject *const_str_digest_b9c4baf879ebd882d40843df3a4dead7;
static PyObject *const_str_digest_8d3cddc28d1cfe9a772f5c088dbdc34e;
extern PyObject *const_str_plain_XMLConverter;
extern PyObject *const_str_plain_process_page;
extern PyObject *const_str_plain_tag;
extern PyObject *const_str_plain_PDFPage;
extern PyObject *const_str_digest_b3b014cceb34671e9d2eebc9b6361b5c;
extern PyObject *const_str_plain___file__;
extern PyObject *const_str_plain_PDFPageInterpreter;
extern PyObject *const_str_plain_line_margin;
extern PyObject *const_str_plain_update;
extern PyObject *const_str_plain_main;
static PyObject *const_str_angle_module;
extern PyObject *const_int_pos_1;
extern PyObject *const_str_plain_normal;
static PyObject *const_tuple_ea81004a93d6c0e4525ec4808d049a91_tuple;
extern PyObject *const_str_plain_all_texts;
static PyObject *const_tuple_str_plain_argv_tuple;
extern PyObject *const_str_plain_rb;
static PyObject *const_str_digest_c74b8fc24b688b8525cf2e0b3a7db16d;
extern PyObject *const_str_plain_HTMLConverter;
static PyObject *const_tuple_str_digest_e023af1ef281d8d55c1e56d49000f818_tuple;
extern PyObject *const_str_digest_f6a581251841acee771bacb236f706e6;
static PyObject *const_str_digest_9870a3ace7357eb3938eb55819eb2a49;
extern PyObject *const_str_plain_text;
extern PyObject *const_str_chr_44;
extern PyObject *const_tuple_str_digest_b9c4baf879ebd882d40843df3a4dead7_str_plain_x_tuple;
static PyObject *const_str_digest_9af6a916e27455174f6c68a9ca039e38;
static PyObject *const_str_digest_215503f2c4e6161a6262d87acf44fc46;
static PyObject *const_str_digest_00f6bb4ae24a38adbf86d65a0bf1ce49;
extern PyObject *const_str_angle_genexpr;
static PyObject *const_str_plain_exit;
extern PyObject *const_str_digest_4b5c38a441de1271115ffc49566d0c91;
extern PyObject *const_str_plain_caching;
extern PyObject *const_str_plain_TextConverter;
static PyObject *const_str_digest_72d141c52db040978cbd3b9c9b26d684;
static PyObject *const_str_plain_usage;
extern PyObject *const_str_plain_LAParams;
static PyObject *const_tuple_str_digest_d312566fe84d6b0b90952b7c0274f1c6_tuple;
static PyObject *const_tuple_str_plain_PDFPage_tuple;
extern PyObject *const_str_plain_boxes_flow;
static PyObject *const_tuple_str_digest_e9c9f62ca34577b9e8d22e82b5b67334_tuple;
extern PyObject *const_str_plain_scale;
extern PyObject *const_str_digest_4d088de100fe5354b20a010ce1db7f29;
extern PyObject *const_str_plain_stdout;
extern PyObject *const_str_plain_rotate;
static PyObject *const_str_plain_endswith;
extern PyObject *const_str_plain_CMapDB;
static PyObject *const_str_plain_GetoptError;
extern PyObject *const_str_plain_laparams;
static PyObject *const_tuple_str_plain_LAParams_tuple;
extern PyObject *const_str_plain_char_margin;
extern PyObject *const_str_plain_x;
extern PyObject *const_str_plain_w;
static PyObject *const_tuple_str_plain_PDFResourceManager_str_plain_PDFPageInterpreter_tuple;
static PyObject *const_str_digest_8b4c8c81913e132a2fb432c041f3150f;
extern PyObject *const_str_digest_a5f56e291553139a63a10626179e7804;
extern PyObject *const_str_plain_password;
extern PyObject *const_int_pos_360;
static PyObject *const_str_digest_b041246024923f1165c753b18abd73f2;
static PyObject *const_str_plain_getopt;
extern PyObject *const_str_plain_word_margin;
static PyObject *const_tuple_str_plain_PDFDevice_str_plain_TagExtractor_tuple;
extern PyObject *const_tuple_str_plain_CMapDB_tuple;
static PyObject *const_tuple_str_plain_ImageWriter_tuple;
extern PyObject *const_str_plain_stripcontrol;
extern PyObject *const_tuple_str_plain_PDFDocument_tuple;
extern PyObject *const_str_plain___doc__;
extern PyObject *const_str_plain_sys;
static PyObject *const_str_digest_59859f73ac9e852f31ad1e0e17633e44;
extern PyObject *const_int_0;
static PyObject *const_str_digest_7e4d5f61da83915c471a6b053ed5943b;
static PyObject *const_str_digest_b345f7ac08de941e36d960ec9fd0356a;
extern PyObject *const_str_digest_06b582bb8a7d7354812dca18aef147d5;
extern PyObject *const_str_digest_d1e9155136963092d9fab9b67fbb0f7f;
static PyObject *const_str_digest_203ab1e8ea4c9d7501c11522e92c4853;
extern PyObject *const_str_plain_imagewriter;
extern PyObject *const_str_empty;
static PyObject *const_str_digest_2bd42c6a2818e6cbec3eb55292ba946c;
static PyObject *const_str_digest_e9c9f62ca34577b9e8d22e82b5b67334;
static PyObject *const_str_plain_xml;
extern PyObject *const_str_digest_5bc6acbbb9e0adb8dabbc1a8cf202f2d;
extern PyObject *const_str_plain_codec;
static PyObject *module_filename_obj;

static bool constants_created = false;

static void createModuleConstants( void )
{
    const_str_digest_d53cbfa1c290fabaad865ce93b11e777 = UNSTREAM_STRING( &constant_bin[ 0 ], 2, 0 );
    const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple = PyTuple_New( 3 );
    PyTuple_SET_ITEM( const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple, 0, const_str_plain_XMLConverter ); Py_INCREF( const_str_plain_XMLConverter );
    PyTuple_SET_ITEM( const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple, 1, const_str_plain_HTMLConverter ); Py_INCREF( const_str_plain_HTMLConverter );
    PyTuple_SET_ITEM( const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple, 2, const_str_plain_TextConverter ); Py_INCREF( const_str_plain_TextConverter );
    const_str_digest_d577b8f49b7cb9dcdb74f76e27464b19 = UNSTREAM_STRING( &constant_bin[ 2 ], 2, 0 );
    const_str_digest_7436cd68ba8ffbc71baa1bc9f27efa15 = UNSTREAM_STRING( &constant_bin[ 4 ], 2, 0 );
    const_str_digest_068eb885e4aaedf6bb189a0c4eb85723 = UNSTREAM_STRING( &constant_bin[ 6 ], 2, 0 );
    const_str_digest_e22d9173bccdc16d4477eee43c8497ac = UNSTREAM_STRING( &constant_bin[ 8 ], 2, 0 );
    const_str_digest_c836122af34ee7a172b779f26da7801f = UNSTREAM_STRING( &constant_bin[ 10 ], 2, 0 );
    const_str_digest_352c4dca5759fe5938694f4c56145f58 = UNSTREAM_STRING( &constant_bin[ 12 ], 2, 0 );
    const_str_plain_html = UNSTREAM_STRING( &constant_bin[ 14 ], 4, 1 );
    const_tuple_str_digest_215503f2c4e6161a6262d87acf44fc46_tuple = PyTuple_New( 1 );
    const_str_digest_215503f2c4e6161a6262d87acf44fc46 = UNSTREAM_STRING( &constant_bin[ 18 ], 5, 0 );
    PyTuple_SET_ITEM( const_tuple_str_digest_215503f2c4e6161a6262d87acf44fc46_tuple, 0, const_str_digest_215503f2c4e6161a6262d87acf44fc46 ); Py_INCREF( const_str_digest_215503f2c4e6161a6262d87acf44fc46 );
    const_str_digest_661170a362c0712dfb804f7826b521cc = UNSTREAM_STRING( &constant_bin[ 23 ], 2, 0 );
    const_str_digest_59bdb53e22971cd7d7e7b286d1104da6 = UNSTREAM_STRING( &constant_bin[ 25 ], 2, 0 );
    const_str_digest_e023af1ef281d8d55c1e56d49000f818 = UNSTREAM_STRING( &constant_bin[ 18 ], 4, 0 );
    const_str_digest_d312566fe84d6b0b90952b7c0274f1c6 = UNSTREAM_STRING( &constant_bin[ 27 ], 4, 0 );
    const_str_digest_a91b838d0c6058724804b19c9c797846 = UNSTREAM_STRING( &constant_bin[ 31 ], 2, 0 );
    const_tuple_str_chr_44_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_chr_44_tuple, 0, const_str_chr_44 ); Py_INCREF( const_str_chr_44 );
    const_str_digest_8d3cddc28d1cfe9a772f5c088dbdc34e = UNSTREAM_STRING( &constant_bin[ 33 ], 2, 0 );
    const_str_angle_module = UNSTREAM_STRING( &constant_bin[ 35 ], 8, 0 );
    const_tuple_ea81004a93d6c0e4525ec4808d049a91_tuple = PyMarshal_ReadObjectFromString( (char *)&constant_bin[ 43 ], 344 );
    const_tuple_str_plain_argv_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_argv_tuple, 0, const_str_plain_argv ); Py_INCREF( const_str_plain_argv );
    const_str_digest_c74b8fc24b688b8525cf2e0b3a7db16d = UNSTREAM_STRING( &constant_bin[ 387 ], 2, 0 );
    const_tuple_str_digest_e023af1ef281d8d55c1e56d49000f818_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_digest_e023af1ef281d8d55c1e56d49000f818_tuple, 0, const_str_digest_e023af1ef281d8d55c1e56d49000f818 ); Py_INCREF( const_str_digest_e023af1ef281d8d55c1e56d49000f818 );
    const_str_digest_9870a3ace7357eb3938eb55819eb2a49 = UNSTREAM_STRING( &constant_bin[ 389 ], 2, 0 );
    const_str_digest_9af6a916e27455174f6c68a9ca039e38 = UNSTREAM_STRING( &constant_bin[ 391 ], 2, 0 );
    const_str_digest_00f6bb4ae24a38adbf86d65a0bf1ce49 = UNSTREAM_STRING( &constant_bin[ 393 ], 2, 0 );
    const_str_plain_exit = UNSTREAM_STRING( &constant_bin[ 395 ], 4, 1 );
    const_str_digest_72d141c52db040978cbd3b9c9b26d684 = UNSTREAM_STRING( &constant_bin[ 399 ], 260, 0 );
    const_str_plain_usage = UNSTREAM_STRING( &constant_bin[ 73 ], 5, 1 );
    const_tuple_str_digest_d312566fe84d6b0b90952b7c0274f1c6_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_digest_d312566fe84d6b0b90952b7c0274f1c6_tuple, 0, const_str_digest_d312566fe84d6b0b90952b7c0274f1c6 ); Py_INCREF( const_str_digest_d312566fe84d6b0b90952b7c0274f1c6 );
    const_tuple_str_plain_PDFPage_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_PDFPage_tuple, 0, const_str_plain_PDFPage ); Py_INCREF( const_str_plain_PDFPage );
    const_tuple_str_digest_e9c9f62ca34577b9e8d22e82b5b67334_tuple = PyTuple_New( 1 );
    const_str_digest_e9c9f62ca34577b9e8d22e82b5b67334 = UNSTREAM_STRING( &constant_bin[ 659 ], 4, 0 );
    PyTuple_SET_ITEM( const_tuple_str_digest_e9c9f62ca34577b9e8d22e82b5b67334_tuple, 0, const_str_digest_e9c9f62ca34577b9e8d22e82b5b67334 ); Py_INCREF( const_str_digest_e9c9f62ca34577b9e8d22e82b5b67334 );
    const_str_plain_endswith = UNSTREAM_STRING( &constant_bin[ 663 ], 8, 1 );
    const_str_plain_GetoptError = UNSTREAM_STRING( &constant_bin[ 671 ], 11, 1 );
    const_tuple_str_plain_LAParams_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_LAParams_tuple, 0, const_str_plain_LAParams ); Py_INCREF( const_str_plain_LAParams );
    const_tuple_str_plain_PDFResourceManager_str_plain_PDFPageInterpreter_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_str_plain_PDFResourceManager_str_plain_PDFPageInterpreter_tuple, 0, const_str_plain_PDFResourceManager ); Py_INCREF( const_str_plain_PDFResourceManager );
    PyTuple_SET_ITEM( const_tuple_str_plain_PDFResourceManager_str_plain_PDFPageInterpreter_tuple, 1, const_str_plain_PDFPageInterpreter ); Py_INCREF( const_str_plain_PDFPageInterpreter );
    const_str_digest_8b4c8c81913e132a2fb432c041f3150f = UNSTREAM_STRING( &constant_bin[ 630 ], 2, 0 );
    const_str_digest_b041246024923f1165c753b18abd73f2 = UNSTREAM_STRING( &constant_bin[ 483 ], 2, 0 );
    const_str_plain_getopt = UNSTREAM_STRING( &constant_bin[ 62 ], 6, 1 );
    const_tuple_str_plain_PDFDevice_str_plain_TagExtractor_tuple = PyTuple_New( 2 );
    PyTuple_SET_ITEM( const_tuple_str_plain_PDFDevice_str_plain_TagExtractor_tuple, 0, const_str_plain_PDFDevice ); Py_INCREF( const_str_plain_PDFDevice );
    PyTuple_SET_ITEM( const_tuple_str_plain_PDFDevice_str_plain_TagExtractor_tuple, 1, const_str_plain_TagExtractor ); Py_INCREF( const_str_plain_TagExtractor );
    const_tuple_str_plain_ImageWriter_tuple = PyTuple_New( 1 );
    PyTuple_SET_ITEM( const_tuple_str_plain_ImageWriter_tuple, 0, const_str_plain_ImageWriter ); Py_INCREF( const_str_plain_ImageWriter );
    const_str_digest_59859f73ac9e852f31ad1e0e17633e44 = UNSTREAM_STRING( &constant_bin[ 607 ], 2, 0 );
    const_str_digest_7e4d5f61da83915c471a6b053ed5943b = UNSTREAM_STRING( &constant_bin[ 682 ], 34, 0 );
    const_str_digest_b345f7ac08de941e36d960ec9fd0356a = UNSTREAM_STRING( &constant_bin[ 410 ], 2, 0 );
    const_str_digest_203ab1e8ea4c9d7501c11522e92c4853 = UNSTREAM_STRING( &constant_bin[ 716 ], 66, 0 );
    const_str_digest_2bd42c6a2818e6cbec3eb55292ba946c = UNSTREAM_STRING( &constant_bin[ 555 ], 2, 0 );
    const_str_plain_xml = UNSTREAM_STRING( &constant_bin[ 620 ], 3, 1 );

    constants_created = true;
}

#ifndef __NUITKA_NO_ASSERT__
void checkModuleConstants___main__( void )
{
    // The module may not have been used at all.
    if (constants_created == false) return;


}
#endif

// The module code objects.
static PyCodeObject *codeobj_3edeffe4a6db7b702d15782c9f35531c;
static PyCodeObject *codeobj_a4e2b497cc9e3edf66e14fcb7f090f24;
static PyCodeObject *codeobj_96e3437d96ef4905aa04c5d1cf4aca51;
static PyCodeObject *codeobj_fcda504b2c96a18fd21f67c08ac97475;
/* For use in "MainProgram.c". */
PyCodeObject *codeobj_main = NULL;

static void createModuleCodeObjects(void)
{
    module_filename_obj = const_str_digest_203ab1e8ea4c9d7501c11522e92c4853;
    codeobj_3edeffe4a6db7b702d15782c9f35531c = MAKE_CODEOBJ( module_filename_obj, const_str_angle_genexpr, 49, const_tuple_str_digest_b9c4baf879ebd882d40843df3a4dead7_str_plain_x_tuple, 1, CO_GENERATOR | CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_a4e2b497cc9e3edf66e14fcb7f090f24 = MAKE_CODEOBJ( module_filename_obj, const_str_angle_module, 1, const_tuple_empty, 0, CO_NOFREE );
    codeobj_main = codeobj_a4e2b497cc9e3edf66e14fcb7f090f24;
    codeobj_96e3437d96ef4905aa04c5d1cf4aca51 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_main, 14, const_tuple_ea81004a93d6c0e4525ec4808d049a91_tuple, 1, CO_OPTIMIZED | CO_NEWLOCALS | CO_NOFREE );
    codeobj_fcda504b2c96a18fd21f67c08ac97475 = MAKE_CODEOBJ( module_filename_obj, const_str_plain_usage, 16, const_tuple_str_plain_argv_tuple, 0, CO_OPTIMIZED | CO_NEWLOCALS );
}

// The module function declarations.
#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
static PyObject *__main__$$$function_1_main$$$genexpr_1_genexpr_context( struct Nuitka_GeneratorObject *generator, PyObject *yield_return_value );
#else
static void __main__$$$function_1_main$$$genexpr_1_genexpr_context( struct Nuitka_GeneratorObject *generator );
#endif


static PyObject *MAKE_FUNCTION___main__$$$function_1_main(  );


static PyObject *MAKE_FUNCTION___main__$$$function_1_main$$$function_1_usage( struct Nuitka_CellObject *closure_argv );


// The module function definitions.
static PyObject *impl___main__$$$function_1_main( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    struct Nuitka_CellObject *par_argv = PyCell_NEW1( python_pars[ 0 ] );
    PyObject *var_getopt = NULL;
    PyObject *var_usage = NULL;
    PyObject *var_opts = NULL;
    PyObject *var_args = NULL;
    PyObject *var_debug = NULL;
    PyObject *var_password = NULL;
    PyObject *var_pagenos = NULL;
    PyObject *var_maxpages = NULL;
    PyObject *var_outfile = NULL;
    PyObject *var_outtype = NULL;
    PyObject *var_imagewriter = NULL;
    PyObject *var_rotation = NULL;
    PyObject *var_stripcontrol = NULL;
    PyObject *var_layoutmode = NULL;
    PyObject *var_codec = NULL;
    PyObject *var_scale = NULL;
    PyObject *var_caching = NULL;
    PyObject *var_laparams = NULL;
    PyObject *var_k = NULL;
    PyObject *var_v = NULL;
    PyObject *var_rsrcmgr = NULL;
    PyObject *var_outfp = NULL;
    PyObject *var_device = NULL;
    PyObject *var_fname = NULL;
    PyObject *var_fp = NULL;
    PyObject *var_interpreter = NULL;
    PyObject *var_page = NULL;
    PyObject *tmp_for_loop_1__for_iterator = NULL;
    PyObject *tmp_for_loop_1__iter_value = NULL;
    PyObject *tmp_for_loop_2__for_iterator = NULL;
    PyObject *tmp_for_loop_2__iter_value = NULL;
    PyObject *tmp_for_loop_3__for_iterator = NULL;
    PyObject *tmp_for_loop_3__iter_value = NULL;
    PyObject *tmp_genexpr_1__$0 = NULL;
    PyObject *tmp_tuple_unpack_1__element_1 = NULL;
    PyObject *tmp_tuple_unpack_1__element_2 = NULL;
    PyObject *tmp_tuple_unpack_1__source_iter = NULL;
    PyObject *tmp_tuple_unpack_2__element_1 = NULL;
    PyObject *tmp_tuple_unpack_2__element_2 = NULL;
    PyObject *tmp_tuple_unpack_2__source_iter = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *exception_keeper_type_4;
    PyObject *exception_keeper_value_4;
    PyTracebackObject *exception_keeper_tb_4;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_4;
    PyObject *exception_keeper_type_5;
    PyObject *exception_keeper_value_5;
    PyTracebackObject *exception_keeper_tb_5;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_5;
    PyObject *exception_keeper_type_6;
    PyObject *exception_keeper_value_6;
    PyTracebackObject *exception_keeper_tb_6;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_6;
    PyObject *exception_keeper_type_7;
    PyObject *exception_keeper_value_7;
    PyTracebackObject *exception_keeper_tb_7;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_7;
    PyObject *exception_keeper_type_8;
    PyObject *exception_keeper_value_8;
    PyTracebackObject *exception_keeper_tb_8;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_8;
    PyObject *exception_keeper_type_9;
    PyObject *exception_keeper_value_9;
    PyTracebackObject *exception_keeper_tb_9;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_9;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_args_element_name_3;
    PyObject *tmp_args_element_name_4;
    PyObject *tmp_args_element_name_5;
    PyObject *tmp_args_element_name_6;
    PyObject *tmp_args_element_name_7;
    PyObject *tmp_args_element_name_8;
    PyObject *tmp_args_element_name_9;
    PyObject *tmp_args_element_name_10;
    PyObject *tmp_args_element_name_11;
    PyObject *tmp_args_name_1;
    PyObject *tmp_args_name_2;
    PyObject *tmp_args_name_3;
    PyObject *tmp_args_name_4;
    PyObject *tmp_args_name_5;
    PyObject *tmp_assattr_name_1;
    PyObject *tmp_assattr_name_2;
    PyObject *tmp_assattr_name_3;
    PyObject *tmp_assattr_name_4;
    PyObject *tmp_assattr_name_5;
    PyObject *tmp_assattr_name_6;
    PyObject *tmp_assattr_name_7;
    PyObject *tmp_assattr_name_8;
    PyObject *tmp_assattr_name_9;
    PyObject *tmp_assattr_name_10;
    PyObject *tmp_assattr_name_11;
    PyObject *tmp_assattr_target_1;
    PyObject *tmp_assattr_target_2;
    PyObject *tmp_assattr_target_3;
    PyObject *tmp_assattr_target_4;
    PyObject *tmp_assattr_target_5;
    PyObject *tmp_assattr_target_6;
    PyObject *tmp_assattr_target_7;
    PyObject *tmp_assattr_target_8;
    PyObject *tmp_assattr_target_9;
    PyObject *tmp_assattr_target_10;
    PyObject *tmp_assattr_target_11;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    PyObject *tmp_assign_source_10;
    PyObject *tmp_assign_source_11;
    PyObject *tmp_assign_source_12;
    PyObject *tmp_assign_source_13;
    PyObject *tmp_assign_source_14;
    PyObject *tmp_assign_source_15;
    PyObject *tmp_assign_source_16;
    PyObject *tmp_assign_source_17;
    PyObject *tmp_assign_source_18;
    PyObject *tmp_assign_source_19;
    PyObject *tmp_assign_source_20;
    PyObject *tmp_assign_source_21;
    PyObject *tmp_assign_source_22;
    PyObject *tmp_assign_source_23;
    PyObject *tmp_assign_source_24;
    PyObject *tmp_assign_source_25;
    PyObject *tmp_assign_source_26;
    PyObject *tmp_assign_source_27;
    PyObject *tmp_assign_source_28;
    PyObject *tmp_assign_source_29;
    PyObject *tmp_assign_source_30;
    PyObject *tmp_assign_source_31;
    PyObject *tmp_assign_source_32;
    PyObject *tmp_assign_source_33;
    PyObject *tmp_assign_source_34;
    PyObject *tmp_assign_source_35;
    PyObject *tmp_assign_source_36;
    PyObject *tmp_assign_source_37;
    PyObject *tmp_assign_source_38;
    PyObject *tmp_assign_source_39;
    PyObject *tmp_assign_source_40;
    PyObject *tmp_assign_source_41;
    PyObject *tmp_assign_source_42;
    PyObject *tmp_assign_source_43;
    PyObject *tmp_assign_source_44;
    PyObject *tmp_assign_source_45;
    PyObject *tmp_assign_source_46;
    PyObject *tmp_assign_source_47;
    PyObject *tmp_assign_source_48;
    PyObject *tmp_assign_source_49;
    PyObject *tmp_assign_source_50;
    PyObject *tmp_assign_source_51;
    PyObject *tmp_assign_source_52;
    PyObject *tmp_assign_source_53;
    PyObject *tmp_assign_source_54;
    PyObject *tmp_assign_source_55;
    PyObject *tmp_assign_source_56;
    PyObject *tmp_assign_source_57;
    PyObject *tmp_assign_source_58;
    PyObject *tmp_assign_source_59;
    PyObject *tmp_assign_source_60;
    PyObject *tmp_assign_source_61;
    PyObject *tmp_called_instance_1;
    PyObject *tmp_called_instance_2;
    PyObject *tmp_called_instance_3;
    PyObject *tmp_called_instance_4;
    PyObject *tmp_called_instance_5;
    PyObject *tmp_called_instance_6;
    PyObject *tmp_called_instance_7;
    PyObject *tmp_called_instance_8;
    PyObject *tmp_called_instance_9;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_called_name_3;
    PyObject *tmp_called_name_4;
    PyObject *tmp_called_name_5;
    PyObject *tmp_called_name_6;
    PyObject *tmp_called_name_7;
    PyObject *tmp_called_name_8;
    PyObject *tmp_called_name_9;
    PyObject *tmp_called_name_10;
    PyObject *tmp_called_name_11;
    PyObject *tmp_called_name_12;
    PyObject *tmp_called_name_13;
    PyObject *tmp_called_name_14;
    PyObject *tmp_called_name_15;
    PyObject *tmp_called_name_16;
    int tmp_cmp_Eq_1;
    int tmp_cmp_Eq_2;
    int tmp_cmp_Eq_3;
    int tmp_cmp_Eq_4;
    int tmp_cmp_Eq_5;
    int tmp_cmp_Eq_6;
    int tmp_cmp_Eq_7;
    int tmp_cmp_Eq_8;
    int tmp_cmp_Eq_9;
    int tmp_cmp_Eq_10;
    int tmp_cmp_Eq_11;
    int tmp_cmp_Eq_12;
    int tmp_cmp_Eq_13;
    int tmp_cmp_Eq_14;
    int tmp_cmp_Eq_15;
    int tmp_cmp_Eq_16;
    int tmp_cmp_Eq_17;
    int tmp_cmp_Eq_18;
    int tmp_cmp_Eq_19;
    int tmp_cmp_Eq_20;
    int tmp_cmp_Eq_21;
    int tmp_cmp_Eq_22;
    int tmp_cmp_Eq_23;
    int tmp_cmp_Eq_24;
    PyObject *tmp_compare_left_1;
    PyObject *tmp_compare_left_2;
    PyObject *tmp_compare_left_3;
    PyObject *tmp_compare_left_4;
    PyObject *tmp_compare_left_5;
    PyObject *tmp_compare_left_6;
    PyObject *tmp_compare_left_7;
    PyObject *tmp_compare_left_8;
    PyObject *tmp_compare_left_9;
    PyObject *tmp_compare_left_10;
    PyObject *tmp_compare_left_11;
    PyObject *tmp_compare_left_12;
    PyObject *tmp_compare_left_13;
    PyObject *tmp_compare_left_14;
    PyObject *tmp_compare_left_15;
    PyObject *tmp_compare_left_16;
    PyObject *tmp_compare_left_17;
    PyObject *tmp_compare_left_18;
    PyObject *tmp_compare_left_19;
    PyObject *tmp_compare_left_20;
    PyObject *tmp_compare_left_21;
    PyObject *tmp_compare_left_22;
    PyObject *tmp_compare_left_23;
    PyObject *tmp_compare_left_24;
    PyObject *tmp_compare_left_25;
    PyObject *tmp_compare_right_1;
    PyObject *tmp_compare_right_2;
    PyObject *tmp_compare_right_3;
    PyObject *tmp_compare_right_4;
    PyObject *tmp_compare_right_5;
    PyObject *tmp_compare_right_6;
    PyObject *tmp_compare_right_7;
    PyObject *tmp_compare_right_8;
    PyObject *tmp_compare_right_9;
    PyObject *tmp_compare_right_10;
    PyObject *tmp_compare_right_11;
    PyObject *tmp_compare_right_12;
    PyObject *tmp_compare_right_13;
    PyObject *tmp_compare_right_14;
    PyObject *tmp_compare_right_15;
    PyObject *tmp_compare_right_16;
    PyObject *tmp_compare_right_17;
    PyObject *tmp_compare_right_18;
    PyObject *tmp_compare_right_19;
    PyObject *tmp_compare_right_20;
    PyObject *tmp_compare_right_21;
    PyObject *tmp_compare_right_22;
    PyObject *tmp_compare_right_23;
    PyObject *tmp_compare_right_24;
    PyObject *tmp_compare_right_25;
    int tmp_cond_truth_1;
    int tmp_cond_truth_2;
    int tmp_cond_truth_3;
    int tmp_cond_truth_4;
    int tmp_cond_truth_5;
    int tmp_cond_truth_6;
    int tmp_cond_truth_7;
    PyObject *tmp_cond_value_1;
    PyObject *tmp_cond_value_2;
    PyObject *tmp_cond_value_3;
    PyObject *tmp_cond_value_4;
    PyObject *tmp_cond_value_5;
    PyObject *tmp_cond_value_6;
    PyObject *tmp_cond_value_7;
    PyObject *tmp_dict_key_1;
    PyObject *tmp_dict_key_2;
    PyObject *tmp_dict_key_3;
    PyObject *tmp_dict_key_4;
    PyObject *tmp_dict_key_5;
    PyObject *tmp_dict_key_6;
    PyObject *tmp_dict_key_7;
    PyObject *tmp_dict_key_8;
    PyObject *tmp_dict_key_9;
    PyObject *tmp_dict_key_10;
    PyObject *tmp_dict_key_11;
    PyObject *tmp_dict_key_12;
    PyObject *tmp_dict_key_13;
    PyObject *tmp_dict_key_14;
    PyObject *tmp_dict_key_15;
    PyObject *tmp_dict_key_16;
    PyObject *tmp_dict_key_17;
    PyObject *tmp_dict_key_18;
    PyObject *tmp_dict_key_19;
    PyObject *tmp_dict_value_1;
    PyObject *tmp_dict_value_2;
    PyObject *tmp_dict_value_3;
    PyObject *tmp_dict_value_4;
    PyObject *tmp_dict_value_5;
    PyObject *tmp_dict_value_6;
    PyObject *tmp_dict_value_7;
    PyObject *tmp_dict_value_8;
    PyObject *tmp_dict_value_9;
    PyObject *tmp_dict_value_10;
    PyObject *tmp_dict_value_11;
    PyObject *tmp_dict_value_12;
    PyObject *tmp_dict_value_13;
    PyObject *tmp_dict_value_14;
    PyObject *tmp_dict_value_15;
    PyObject *tmp_dict_value_16;
    PyObject *tmp_dict_value_17;
    PyObject *tmp_dict_value_18;
    PyObject *tmp_dict_value_19;
    int tmp_exc_match_exception_match_1;
    PyObject *tmp_float_arg_1;
    PyObject *tmp_float_arg_2;
    PyObject *tmp_float_arg_3;
    PyObject *tmp_float_arg_4;
    PyObject *tmp_float_arg_5;
    PyObject *tmp_fromlist_name_1;
    PyObject *tmp_globals_name_1;
    PyObject *tmp_int_arg_1;
    PyObject *tmp_int_arg_2;
    PyObject *tmp_iter_arg_1;
    PyObject *tmp_iter_arg_2;
    PyObject *tmp_iter_arg_3;
    PyObject *tmp_iter_arg_4;
    PyObject *tmp_iter_arg_5;
    PyObject *tmp_iter_arg_6;
    PyObject *tmp_iterator_attempt;
    PyObject *tmp_iterator_name_1;
    PyObject *tmp_iterator_name_2;
    PyObject *tmp_kw_name_1;
    PyObject *tmp_kw_name_2;
    PyObject *tmp_kw_name_3;
    PyObject *tmp_kw_name_4;
    PyObject *tmp_kw_name_5;
    PyObject *tmp_kw_name_6;
    PyObject *tmp_left_name_1;
    PyObject *tmp_left_name_2;
    PyObject *tmp_left_name_3;
    PyObject *tmp_locals_name_1;
    PyObject *tmp_name_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_next_source_2;
    PyObject *tmp_next_source_3;
    int tmp_or_left_truth_1;
    PyObject *tmp_or_left_value_1;
    PyObject *tmp_or_right_value_1;
    PyObject *tmp_outline_return_value_1;
    int tmp_res;
    bool tmp_result;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_right_name_2;
    PyObject *tmp_right_name_3;
    Py_ssize_t tmp_slice_index_upper_1;
    PyObject *tmp_slice_source_1;
    Py_ssize_t tmp_sliceslicedel_index_lower_1;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    PyObject *tmp_source_name_3;
    PyObject *tmp_source_name_4;
    PyObject *tmp_source_name_5;
    PyObject *tmp_source_name_6;
    PyObject *tmp_tuple_element_1;
    PyObject *tmp_tuple_element_2;
    PyObject *tmp_tuple_element_3;
    PyObject *tmp_tuple_element_4;
    PyObject *tmp_tuple_element_5;
    PyObject *tmp_unpack_1;
    PyObject *tmp_unpack_2;
    PyObject *tmp_unpack_3;
    PyObject *tmp_unpack_4;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_96e3437d96ef4905aa04c5d1cf4aca51 = NULL;

    struct Nuitka_FrameObject *frame_96e3437d96ef4905aa04c5d1cf4aca51;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;
    tmp_outline_return_value_1 = NULL;

    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_96e3437d96ef4905aa04c5d1cf4aca51, codeobj_96e3437d96ef4905aa04c5d1cf4aca51, module___main__, sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *)+sizeof(void *) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51 = cache_frame_96e3437d96ef4905aa04c5d1cf4aca51;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_96e3437d96ef4905aa04c5d1cf4aca51 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_96e3437d96ef4905aa04c5d1cf4aca51 ) == 2 ); // Frame stack

    // Framed code:
    tmp_name_name_1 = const_str_plain_getopt;
    tmp_globals_name_1 = (PyObject *)moduledict___main__;
    tmp_locals_name_1 = Py_None;
    tmp_fromlist_name_1 = Py_None;
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 15;
    tmp_assign_source_1 = IMPORT_MODULE4( tmp_name_name_1, tmp_globals_name_1, tmp_locals_name_1, tmp_fromlist_name_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 15;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_getopt == NULL );
    var_getopt = tmp_assign_source_1;

    tmp_assign_source_2 = MAKE_FUNCTION___main__$$$function_1_main$$$function_1_usage( par_argv );
    assert( var_usage == NULL );
    var_usage = tmp_assign_source_2;

    // Tried code:
    // Tried code:
    tmp_source_name_1 = var_getopt;

    CHECK_OBJECT( tmp_source_name_1 );
    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_getopt );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 24;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_3;
    }
    tmp_sliceslicedel_index_lower_1 = 1;
    tmp_slice_index_upper_1 = PY_SSIZE_T_MAX;
    if ( par_argv == NULL )
    {
        tmp_slice_source_1 = NULL;
    }
    else
    {
        tmp_slice_source_1 = PyCell_GET( par_argv );
    }

    if ( tmp_slice_source_1 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "argv" );
        exception_tb = NULL;

        exception_lineno = 24;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_3;
    }

    tmp_args_element_name_1 = LOOKUP_INDEX_SLICE( tmp_slice_source_1, tmp_sliceslicedel_index_lower_1, tmp_slice_index_upper_1 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 24;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_3;
    }
    tmp_args_element_name_2 = const_str_digest_7e4d5f61da83915c471a6b053ed5943b;
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 24;
    {
        PyObject *call_args[] = { tmp_args_element_name_1, tmp_args_element_name_2 };
        tmp_iter_arg_1 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_iter_arg_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 24;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_3;
    }
    tmp_assign_source_3 = MAKE_ITERATOR( tmp_iter_arg_1 );
    Py_DECREF( tmp_iter_arg_1 );
    if ( tmp_assign_source_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 24;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_3;
    }
    assert( tmp_tuple_unpack_1__source_iter == NULL );
    tmp_tuple_unpack_1__source_iter = tmp_assign_source_3;

    // Tried code:
    tmp_unpack_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_1 );
    tmp_assign_source_4 = UNPACK_NEXT( tmp_unpack_1, 0 );
    if ( tmp_assign_source_4 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 24;
        goto try_except_handler_4;
    }
    assert( tmp_tuple_unpack_1__element_1 == NULL );
    tmp_tuple_unpack_1__element_1 = tmp_assign_source_4;

    tmp_unpack_2 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_unpack_2 );
    tmp_assign_source_5 = UNPACK_NEXT( tmp_unpack_2, 1 );
    if ( tmp_assign_source_5 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 24;
        goto try_except_handler_4;
    }
    assert( tmp_tuple_unpack_1__element_2 == NULL );
    tmp_tuple_unpack_1__element_2 = tmp_assign_source_5;

    tmp_iterator_name_1 = tmp_tuple_unpack_1__source_iter;

    CHECK_OBJECT( tmp_iterator_name_1 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_1 ); assert( HAS_ITERNEXT( tmp_iterator_name_1 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_1 )->tp_iternext)( tmp_iterator_name_1 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "coooooooooooooooNooNoooooooooo";
                exception_lineno = 24;
                goto try_except_handler_4;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 24;
        goto try_except_handler_4;
    }
    goto try_end_1;
    // Exception handler code:
    try_except_handler_4:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto try_except_handler_3;
    // End of try:
    try_end_1:;
    goto try_end_2;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto try_except_handler_2;
    // End of try:
    try_end_2:;
    goto try_end_3;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    // Preserve existing published exception.
    PRESERVE_FRAME_EXCEPTION( frame_96e3437d96ef4905aa04c5d1cf4aca51 );
    if ( exception_keeper_tb_3 == NULL )
    {
        exception_keeper_tb_3 = MAKE_TRACEBACK( frame_96e3437d96ef4905aa04c5d1cf4aca51, exception_keeper_lineno_3 );
    }
    else if ( exception_keeper_lineno_3 != 0 )
    {
        exception_keeper_tb_3 = ADD_TRACEBACK( exception_keeper_tb_3, frame_96e3437d96ef4905aa04c5d1cf4aca51, exception_keeper_lineno_3 );
    }

    NORMALIZE_EXCEPTION( &exception_keeper_type_3, &exception_keeper_value_3, &exception_keeper_tb_3 );
    PUBLISH_EXCEPTION( &exception_keeper_type_3, &exception_keeper_value_3, &exception_keeper_tb_3 );
    tmp_compare_left_1 = PyThreadState_GET()->exc_type;
    tmp_source_name_2 = var_getopt;

    CHECK_OBJECT( tmp_source_name_2 );
    tmp_compare_right_1 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_GetoptError );
    if ( tmp_compare_right_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 25;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_exc_match_exception_match_1 = EXCEPTION_MATCH_BOOL( tmp_compare_left_1, tmp_compare_right_1 );
    if ( tmp_exc_match_exception_match_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_compare_right_1 );

        exception_lineno = 25;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_compare_right_1 );
    if ( tmp_exc_match_exception_match_1 == 1 )
    {
        goto branch_yes_1;
    }
    else
    {
        goto branch_no_1;
    }
    branch_yes_1:;
    tmp_called_name_2 = var_usage;

    CHECK_OBJECT( tmp_called_name_2 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 26;
    tmp_return_value = CALL_FUNCTION_NO_ARGS( tmp_called_name_2 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 26;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    goto branch_end_1;
    branch_no_1:;
    tmp_result = RERAISE_EXCEPTION( &exception_type, &exception_value, &exception_tb );
    if (unlikely( tmp_result == false ))
    {
        exception_lineno = 23;
    }

    if (exception_tb && exception_tb->tb_frame == &frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame) frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = exception_tb->tb_lineno;
    type_description_1 = "coooooooooooooooNooNoooooooooo";
    goto frame_exception_exit_1;
    branch_end_1:;
    // End of try:
    try_end_3:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_1__source_iter );
    Py_DECREF( tmp_tuple_unpack_1__source_iter );
    tmp_tuple_unpack_1__source_iter = NULL;

    tmp_assign_source_6 = tmp_tuple_unpack_1__element_1;

    CHECK_OBJECT( tmp_assign_source_6 );
    assert( var_opts == NULL );
    Py_INCREF( tmp_assign_source_6 );
    var_opts = tmp_assign_source_6;

    Py_XDECREF( tmp_tuple_unpack_1__element_1 );
    tmp_tuple_unpack_1__element_1 = NULL;

    tmp_assign_source_7 = tmp_tuple_unpack_1__element_2;

    CHECK_OBJECT( tmp_assign_source_7 );
    assert( var_args == NULL );
    Py_INCREF( tmp_assign_source_7 );
    var_args = tmp_assign_source_7;

    Py_XDECREF( tmp_tuple_unpack_1__element_2 );
    tmp_tuple_unpack_1__element_2 = NULL;

    tmp_cond_value_1 = var_args;

    CHECK_OBJECT( tmp_cond_value_1 );
    tmp_cond_truth_1 = CHECK_IF_TRUE( tmp_cond_value_1 );
    if ( tmp_cond_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 27;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_1 == 1 )
    {
        goto branch_no_2;
    }
    else
    {
        goto branch_yes_2;
    }
    branch_yes_2:;
    tmp_called_name_3 = var_usage;

    CHECK_OBJECT( tmp_called_name_3 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 27;
    tmp_return_value = CALL_FUNCTION_NO_ARGS( tmp_called_name_3 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 27;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    branch_no_2:;
    tmp_assign_source_8 = const_int_0;
    assert( var_debug == NULL );
    Py_INCREF( tmp_assign_source_8 );
    var_debug = tmp_assign_source_8;

    tmp_assign_source_9 = const_str_empty;
    assert( var_password == NULL );
    Py_INCREF( tmp_assign_source_9 );
    var_password = tmp_assign_source_9;

    tmp_assign_source_10 = PySet_New( NULL );
    assert( var_pagenos == NULL );
    var_pagenos = tmp_assign_source_10;

    tmp_assign_source_11 = const_int_0;
    assert( var_maxpages == NULL );
    Py_INCREF( tmp_assign_source_11 );
    var_maxpages = tmp_assign_source_11;

    tmp_assign_source_12 = Py_None;
    assert( var_outfile == NULL );
    Py_INCREF( tmp_assign_source_12 );
    var_outfile = tmp_assign_source_12;

    tmp_assign_source_13 = Py_None;
    assert( var_outtype == NULL );
    Py_INCREF( tmp_assign_source_13 );
    var_outtype = tmp_assign_source_13;

    tmp_assign_source_14 = Py_None;
    assert( var_imagewriter == NULL );
    Py_INCREF( tmp_assign_source_14 );
    var_imagewriter = tmp_assign_source_14;

    tmp_assign_source_15 = const_int_0;
    assert( var_rotation == NULL );
    Py_INCREF( tmp_assign_source_15 );
    var_rotation = tmp_assign_source_15;

    tmp_assign_source_16 = Py_False;
    assert( var_stripcontrol == NULL );
    Py_INCREF( tmp_assign_source_16 );
    var_stripcontrol = tmp_assign_source_16;

    tmp_assign_source_17 = const_str_plain_normal;
    assert( var_layoutmode == NULL );
    Py_INCREF( tmp_assign_source_17 );
    var_layoutmode = tmp_assign_source_17;

    tmp_assign_source_18 = const_str_digest_c075052d723d6707083e869a0e3659bb;
    assert( var_codec == NULL );
    Py_INCREF( tmp_assign_source_18 );
    var_codec = tmp_assign_source_18;

    tmp_assign_source_19 = const_int_pos_1;
    assert( var_scale == NULL );
    Py_INCREF( tmp_assign_source_19 );
    var_scale = tmp_assign_source_19;

    tmp_assign_source_20 = Py_True;
    assert( var_caching == NULL );
    Py_INCREF( tmp_assign_source_20 );
    var_caching = tmp_assign_source_20;

    tmp_called_name_4 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_LAParams );

    if (unlikely( tmp_called_name_4 == NULL ))
    {
        tmp_called_name_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_LAParams );
    }

    if ( tmp_called_name_4 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "LAParams" );
        exception_tb = NULL;

        exception_lineno = 46;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 46;
    tmp_assign_source_21 = CALL_FUNCTION_NO_ARGS( tmp_called_name_4 );
    if ( tmp_assign_source_21 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 46;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_laparams == NULL );
    var_laparams = tmp_assign_source_21;

    tmp_iter_arg_2 = var_opts;

    CHECK_OBJECT( tmp_iter_arg_2 );
    tmp_assign_source_22 = MAKE_ITERATOR( tmp_iter_arg_2 );
    if ( tmp_assign_source_22 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 47;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_1__for_iterator == NULL );
    tmp_for_loop_1__for_iterator = tmp_assign_source_22;

    // Tried code:
    loop_start_1:;
    tmp_next_source_1 = tmp_for_loop_1__for_iterator;

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_23 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_23 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "coooooooooooooooNooNoooooooooo";
            exception_lineno = 47;
            goto try_except_handler_5;
        }
    }

    {
        PyObject *old = tmp_for_loop_1__iter_value;
        tmp_for_loop_1__iter_value = tmp_assign_source_23;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_iter_arg_3 = tmp_for_loop_1__iter_value;

    CHECK_OBJECT( tmp_iter_arg_3 );
    tmp_assign_source_24 = MAKE_ITERATOR( tmp_iter_arg_3 );
    if ( tmp_assign_source_24 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 47;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_6;
    }
    {
        PyObject *old = tmp_tuple_unpack_2__source_iter;
        tmp_tuple_unpack_2__source_iter = tmp_assign_source_24;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_unpack_3 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_3 );
    tmp_assign_source_25 = UNPACK_NEXT( tmp_unpack_3, 0 );
    if ( tmp_assign_source_25 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 47;
        goto try_except_handler_7;
    }
    {
        PyObject *old = tmp_tuple_unpack_2__element_1;
        tmp_tuple_unpack_2__element_1 = tmp_assign_source_25;
        Py_XDECREF( old );
    }

    tmp_unpack_4 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_unpack_4 );
    tmp_assign_source_26 = UNPACK_NEXT( tmp_unpack_4, 1 );
    if ( tmp_assign_source_26 == NULL )
    {
        if ( !ERROR_OCCURRED() )
        {
            exception_type = PyExc_StopIteration;
            Py_INCREF( exception_type );
            exception_value = NULL;
            exception_tb = NULL;
        }
        else
        {
            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        }


        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 47;
        goto try_except_handler_7;
    }
    {
        PyObject *old = tmp_tuple_unpack_2__element_2;
        tmp_tuple_unpack_2__element_2 = tmp_assign_source_26;
        Py_XDECREF( old );
    }

    tmp_iterator_name_2 = tmp_tuple_unpack_2__source_iter;

    CHECK_OBJECT( tmp_iterator_name_2 );
    // Check if iterator has left-over elements.
    CHECK_OBJECT( tmp_iterator_name_2 ); assert( HAS_ITERNEXT( tmp_iterator_name_2 ) );

    tmp_iterator_attempt = (*Py_TYPE( tmp_iterator_name_2 )->tp_iternext)( tmp_iterator_name_2 );

    if (likely( tmp_iterator_attempt == NULL ))
    {
        PyObject *error = GET_ERROR_OCCURRED();

        if ( error != NULL )
        {
            if ( EXCEPTION_MATCH_BOOL_SINGLE( error, PyExc_StopIteration ))
            {
                CLEAR_ERROR_OCCURRED();
            }
            else
            {
                FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

                type_description_1 = "coooooooooooooooNooNoooooooooo";
                exception_lineno = 47;
                goto try_except_handler_7;
            }
        }
    }
    else
    {
        Py_DECREF( tmp_iterator_attempt );

        // TODO: Could avoid PyErr_Format.
#if PYTHON_VERSION < 300
        PyErr_Format( PyExc_ValueError, "too many values to unpack" );
#else
        PyErr_Format( PyExc_ValueError, "too many values to unpack (expected 2)" );
#endif
        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );

        type_description_1 = "coooooooooooooooNooNoooooooooo";
        exception_lineno = 47;
        goto try_except_handler_7;
    }
    goto try_end_4;
    // Exception handler code:
    try_except_handler_7:;
    exception_keeper_type_4 = exception_type;
    exception_keeper_value_4 = exception_value;
    exception_keeper_tb_4 = exception_tb;
    exception_keeper_lineno_4 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_2__source_iter );
    Py_DECREF( tmp_tuple_unpack_2__source_iter );
    tmp_tuple_unpack_2__source_iter = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_4;
    exception_value = exception_keeper_value_4;
    exception_tb = exception_keeper_tb_4;
    exception_lineno = exception_keeper_lineno_4;

    goto try_except_handler_6;
    // End of try:
    try_end_4:;
    goto try_end_5;
    // Exception handler code:
    try_except_handler_6:;
    exception_keeper_type_5 = exception_type;
    exception_keeper_value_5 = exception_value;
    exception_keeper_tb_5 = exception_tb;
    exception_keeper_lineno_5 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_tuple_unpack_2__element_1 );
    tmp_tuple_unpack_2__element_1 = NULL;

    Py_XDECREF( tmp_tuple_unpack_2__element_2 );
    tmp_tuple_unpack_2__element_2 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_5;
    exception_value = exception_keeper_value_5;
    exception_tb = exception_keeper_tb_5;
    exception_lineno = exception_keeper_lineno_5;

    goto try_except_handler_5;
    // End of try:
    try_end_5:;
    CHECK_OBJECT( (PyObject *)tmp_tuple_unpack_2__source_iter );
    Py_DECREF( tmp_tuple_unpack_2__source_iter );
    tmp_tuple_unpack_2__source_iter = NULL;

    tmp_assign_source_27 = tmp_tuple_unpack_2__element_1;

    CHECK_OBJECT( tmp_assign_source_27 );
    {
        PyObject *old = var_k;
        var_k = tmp_assign_source_27;
        Py_INCREF( var_k );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_2__element_1 );
    tmp_tuple_unpack_2__element_1 = NULL;

    tmp_assign_source_28 = tmp_tuple_unpack_2__element_2;

    CHECK_OBJECT( tmp_assign_source_28 );
    {
        PyObject *old = var_v;
        var_v = tmp_assign_source_28;
        Py_INCREF( var_v );
        Py_XDECREF( old );
    }

    Py_XDECREF( tmp_tuple_unpack_2__element_2 );
    tmp_tuple_unpack_2__element_2 = NULL;

    tmp_compare_left_2 = var_k;

    CHECK_OBJECT( tmp_compare_left_2 );
    tmp_compare_right_2 = const_str_digest_b345f7ac08de941e36d960ec9fd0356a;
    tmp_cmp_Eq_1 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_2, tmp_compare_right_2 );
    if ( tmp_cmp_Eq_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 48;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_1 == 1 )
    {
        goto branch_yes_3;
    }
    else
    {
        goto branch_no_3;
    }
    branch_yes_3:;
    tmp_left_name_1 = var_debug;

    if ( tmp_left_name_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 48;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_right_name_1 = const_int_pos_1;
    tmp_result = BINARY_OPERATION_ADD_INPLACE( &tmp_left_name_1, tmp_right_name_1 );
    tmp_assign_source_29 = tmp_left_name_1;
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 48;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    var_debug = tmp_assign_source_29;

    goto branch_end_3;
    branch_no_3:;
    tmp_compare_left_3 = var_k;

    CHECK_OBJECT( tmp_compare_left_3 );
    tmp_compare_right_3 = const_str_digest_068eb885e4aaedf6bb189a0c4eb85723;
    tmp_cmp_Eq_2 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_3, tmp_compare_right_3 );
    if ( tmp_cmp_Eq_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_2 == 1 )
    {
        goto branch_yes_4;
    }
    else
    {
        goto branch_no_4;
    }
    branch_yes_4:;
    tmp_source_name_3 = var_pagenos;

    CHECK_OBJECT( tmp_source_name_3 );
    tmp_called_name_5 = LOOKUP_ATTRIBUTE( tmp_source_name_3, const_str_plain_update );
    if ( tmp_called_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_called_instance_1 = var_v;

    CHECK_OBJECT( tmp_called_instance_1 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 49;
    tmp_iter_arg_4 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_1, const_str_plain_split, &PyTuple_GET_ITEM( const_tuple_str_chr_44_tuple, 0 ) );

    if ( tmp_iter_arg_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_assign_source_30 = MAKE_ITERATOR( tmp_iter_arg_4 );
    Py_DECREF( tmp_iter_arg_4 );
    if ( tmp_assign_source_30 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    {
        PyObject *old = tmp_genexpr_1__$0;
        tmp_genexpr_1__$0 = tmp_assign_source_30;
        Py_XDECREF( old );
    }

    // Tried code:
    tmp_outline_return_value_1 = Nuitka_Generator_New(
        __main__$$$function_1_main$$$genexpr_1_genexpr_context,
        module___main__,
        const_str_angle_genexpr,
#if PYTHON_VERSION >= 350
        NULL,
#endif
        codeobj_3edeffe4a6db7b702d15782c9f35531c,
        1
    );

    ((struct Nuitka_GeneratorObject *)tmp_outline_return_value_1)->m_closure[0] = PyCell_NEW0( tmp_genexpr_1__$0 );
    assert( Py_SIZE( tmp_outline_return_value_1 ) >= 1 ); 


    goto try_return_handler_8;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( __main__$$$function_1_main );
    return NULL;
    // Return handler code:
    try_return_handler_8:;
    CHECK_OBJECT( (PyObject *)tmp_genexpr_1__$0 );
    Py_DECREF( tmp_genexpr_1__$0 );
    tmp_genexpr_1__$0 = NULL;

    goto outline_result_1;
    // End of try:
    CHECK_OBJECT( (PyObject *)tmp_genexpr_1__$0 );
    Py_DECREF( tmp_genexpr_1__$0 );
    tmp_genexpr_1__$0 = NULL;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( __main__$$$function_1_main );
    return NULL;
    outline_result_1:;
    tmp_args_element_name_3 = tmp_outline_return_value_1;
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 49;
    {
        PyObject *call_args[] = { tmp_args_element_name_3 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_5, call_args );
    }

    Py_DECREF( tmp_called_name_5 );
    Py_DECREF( tmp_args_element_name_3 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    Py_DECREF( tmp_unused );
    goto branch_end_4;
    branch_no_4:;
    tmp_compare_left_4 = var_k;

    CHECK_OBJECT( tmp_compare_left_4 );
    tmp_compare_right_4 = const_str_digest_d577b8f49b7cb9dcdb74f76e27464b19;
    tmp_cmp_Eq_3 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_4, tmp_compare_right_4 );
    if ( tmp_cmp_Eq_3 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 50;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_3 == 1 )
    {
        goto branch_yes_5;
    }
    else
    {
        goto branch_no_5;
    }
    branch_yes_5:;
    tmp_int_arg_1 = var_v;

    CHECK_OBJECT( tmp_int_arg_1 );
    tmp_assign_source_31 = PyNumber_Int( tmp_int_arg_1 );
    if ( tmp_assign_source_31 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 50;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    {
        PyObject *old = var_maxpages;
        var_maxpages = tmp_assign_source_31;
        Py_XDECREF( old );
    }

    goto branch_end_5;
    branch_no_5:;
    tmp_compare_left_5 = var_k;

    CHECK_OBJECT( tmp_compare_left_5 );
    tmp_compare_right_5 = const_str_digest_00f6bb4ae24a38adbf86d65a0bf1ce49;
    tmp_cmp_Eq_4 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_5, tmp_compare_right_5 );
    if ( tmp_cmp_Eq_4 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 51;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_4 == 1 )
    {
        goto branch_yes_6;
    }
    else
    {
        goto branch_no_6;
    }
    branch_yes_6:;
    tmp_assign_source_32 = var_v;

    CHECK_OBJECT( tmp_assign_source_32 );
    {
        PyObject *old = var_password;
        var_password = tmp_assign_source_32;
        Py_INCREF( var_password );
        Py_XDECREF( old );
    }

    goto branch_end_6;
    branch_no_6:;
    tmp_compare_left_6 = var_k;

    CHECK_OBJECT( tmp_compare_left_6 );
    tmp_compare_right_6 = const_str_digest_c74b8fc24b688b8525cf2e0b3a7db16d;
    tmp_cmp_Eq_5 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_6, tmp_compare_right_6 );
    if ( tmp_cmp_Eq_5 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 52;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_5 == 1 )
    {
        goto branch_yes_7;
    }
    else
    {
        goto branch_no_7;
    }
    branch_yes_7:;
    tmp_assign_source_33 = var_v;

    CHECK_OBJECT( tmp_assign_source_33 );
    {
        PyObject *old = var_outfile;
        var_outfile = tmp_assign_source_33;
        Py_INCREF( var_outfile );
        Py_XDECREF( old );
    }

    goto branch_end_7;
    branch_no_7:;
    tmp_compare_left_7 = var_k;

    CHECK_OBJECT( tmp_compare_left_7 );
    tmp_compare_right_7 = const_str_digest_9af6a916e27455174f6c68a9ca039e38;
    tmp_cmp_Eq_6 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_7, tmp_compare_right_7 );
    if ( tmp_cmp_Eq_6 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 53;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_6 == 1 )
    {
        goto branch_yes_8;
    }
    else
    {
        goto branch_no_8;
    }
    branch_yes_8:;
    tmp_assign_source_34 = Py_False;
    {
        PyObject *old = var_caching;
        var_caching = tmp_assign_source_34;
        Py_INCREF( var_caching );
        Py_XDECREF( old );
    }

    goto branch_end_8;
    branch_no_8:;
    tmp_compare_left_8 = var_k;

    CHECK_OBJECT( tmp_compare_left_8 );
    tmp_compare_right_8 = const_str_digest_7436cd68ba8ffbc71baa1bc9f27efa15;
    tmp_cmp_Eq_7 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_8, tmp_compare_right_8 );
    if ( tmp_cmp_Eq_7 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 54;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_7 == 1 )
    {
        goto branch_yes_9;
    }
    else
    {
        goto branch_no_9;
    }
    branch_yes_9:;
    tmp_assign_source_35 = Py_None;
    {
        PyObject *old = var_laparams;
        var_laparams = tmp_assign_source_35;
        Py_INCREF( var_laparams );
        Py_XDECREF( old );
    }

    goto branch_end_9;
    branch_no_9:;
    tmp_compare_left_9 = var_k;

    CHECK_OBJECT( tmp_compare_left_9 );
    tmp_compare_right_9 = const_str_digest_a91b838d0c6058724804b19c9c797846;
    tmp_cmp_Eq_8 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_9, tmp_compare_right_9 );
    if ( tmp_cmp_Eq_8 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 55;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_8 == 1 )
    {
        goto branch_yes_10;
    }
    else
    {
        goto branch_no_10;
    }
    branch_yes_10:;
    tmp_assattr_name_1 = Py_True;
    tmp_assattr_target_1 = var_laparams;

    if ( tmp_assattr_target_1 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 55;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_1, const_str_plain_all_texts, tmp_assattr_name_1 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 55;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    goto branch_end_10;
    branch_no_10:;
    tmp_compare_left_10 = var_k;

    CHECK_OBJECT( tmp_compare_left_10 );
    tmp_compare_right_10 = const_str_digest_b041246024923f1165c753b18abd73f2;
    tmp_cmp_Eq_9 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_10, tmp_compare_right_10 );
    if ( tmp_cmp_Eq_9 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 56;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_9 == 1 )
    {
        goto branch_yes_11;
    }
    else
    {
        goto branch_no_11;
    }
    branch_yes_11:;
    tmp_assattr_name_2 = Py_True;
    tmp_assattr_target_2 = var_laparams;

    if ( tmp_assattr_target_2 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 56;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_2, const_str_plain_detect_vertical, tmp_assattr_name_2 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 56;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    goto branch_end_11;
    branch_no_11:;
    tmp_compare_left_11 = var_k;

    CHECK_OBJECT( tmp_compare_left_11 );
    tmp_compare_right_11 = const_str_digest_8d3cddc28d1cfe9a772f5c088dbdc34e;
    tmp_cmp_Eq_10 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_11, tmp_compare_right_11 );
    if ( tmp_cmp_Eq_10 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 57;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_10 == 1 )
    {
        goto branch_yes_12;
    }
    else
    {
        goto branch_no_12;
    }
    branch_yes_12:;
    tmp_float_arg_1 = var_v;

    CHECK_OBJECT( tmp_float_arg_1 );
    tmp_assattr_name_3 = TO_FLOAT( tmp_float_arg_1 );
    if ( tmp_assattr_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 57;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_assattr_target_3 = var_laparams;

    if ( tmp_assattr_target_3 == NULL )
    {
        Py_DECREF( tmp_assattr_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 57;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_3, const_str_plain_char_margin, tmp_assattr_name_3 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_3 );

        exception_lineno = 57;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    Py_DECREF( tmp_assattr_name_3 );
    goto branch_end_12;
    branch_no_12:;
    tmp_compare_left_12 = var_k;

    CHECK_OBJECT( tmp_compare_left_12 );
    tmp_compare_right_12 = const_str_digest_9870a3ace7357eb3938eb55819eb2a49;
    tmp_cmp_Eq_11 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_12, tmp_compare_right_12 );
    if ( tmp_cmp_Eq_11 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 58;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_11 == 1 )
    {
        goto branch_yes_13;
    }
    else
    {
        goto branch_no_13;
    }
    branch_yes_13:;
    tmp_float_arg_2 = var_v;

    CHECK_OBJECT( tmp_float_arg_2 );
    tmp_assattr_name_4 = TO_FLOAT( tmp_float_arg_2 );
    if ( tmp_assattr_name_4 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 58;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_assattr_target_4 = var_laparams;

    if ( tmp_assattr_target_4 == NULL )
    {
        Py_DECREF( tmp_assattr_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 58;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_4, const_str_plain_line_margin, tmp_assattr_name_4 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_4 );

        exception_lineno = 58;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    Py_DECREF( tmp_assattr_name_4 );
    goto branch_end_13;
    branch_no_13:;
    tmp_compare_left_13 = var_k;

    CHECK_OBJECT( tmp_compare_left_13 );
    tmp_compare_right_13 = const_str_digest_d53cbfa1c290fabaad865ce93b11e777;
    tmp_cmp_Eq_12 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_13, tmp_compare_right_13 );
    if ( tmp_cmp_Eq_12 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 59;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_12 == 1 )
    {
        goto branch_yes_14;
    }
    else
    {
        goto branch_no_14;
    }
    branch_yes_14:;
    tmp_float_arg_3 = var_v;

    CHECK_OBJECT( tmp_float_arg_3 );
    tmp_assattr_name_5 = TO_FLOAT( tmp_float_arg_3 );
    if ( tmp_assattr_name_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 59;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_assattr_target_5 = var_laparams;

    if ( tmp_assattr_target_5 == NULL )
    {
        Py_DECREF( tmp_assattr_name_5 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 59;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_5, const_str_plain_word_margin, tmp_assattr_name_5 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_5 );

        exception_lineno = 59;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    Py_DECREF( tmp_assattr_name_5 );
    goto branch_end_14;
    branch_no_14:;
    tmp_compare_left_14 = var_k;

    CHECK_OBJECT( tmp_compare_left_14 );
    tmp_compare_right_14 = const_str_digest_352c4dca5759fe5938694f4c56145f58;
    tmp_cmp_Eq_13 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_14, tmp_compare_right_14 );
    if ( tmp_cmp_Eq_13 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 60;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_13 == 1 )
    {
        goto branch_yes_15;
    }
    else
    {
        goto branch_no_15;
    }
    branch_yes_15:;
    tmp_float_arg_4 = var_v;

    CHECK_OBJECT( tmp_float_arg_4 );
    tmp_assattr_name_6 = TO_FLOAT( tmp_float_arg_4 );
    if ( tmp_assattr_name_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 60;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    tmp_assattr_target_6 = var_laparams;

    if ( tmp_assattr_target_6 == NULL )
    {
        Py_DECREF( tmp_assattr_name_6 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 60;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_6, const_str_plain_boxes_flow, tmp_assattr_name_6 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_6 );

        exception_lineno = 60;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    Py_DECREF( tmp_assattr_name_6 );
    goto branch_end_15;
    branch_no_15:;
    tmp_compare_left_15 = var_k;

    CHECK_OBJECT( tmp_compare_left_15 );
    tmp_compare_right_15 = const_str_digest_2bd42c6a2818e6cbec3eb55292ba946c;
    tmp_cmp_Eq_14 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_15, tmp_compare_right_15 );
    if ( tmp_cmp_Eq_14 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 61;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_14 == 1 )
    {
        goto branch_yes_16;
    }
    else
    {
        goto branch_no_16;
    }
    branch_yes_16:;
    tmp_assign_source_36 = var_v;

    CHECK_OBJECT( tmp_assign_source_36 );
    {
        PyObject *old = var_layoutmode;
        var_layoutmode = tmp_assign_source_36;
        Py_INCREF( var_layoutmode );
        Py_XDECREF( old );
    }

    goto branch_end_16;
    branch_no_16:;
    tmp_compare_left_16 = var_k;

    CHECK_OBJECT( tmp_compare_left_16 );
    tmp_compare_right_16 = const_str_digest_e22d9173bccdc16d4477eee43c8497ac;
    tmp_cmp_Eq_15 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_16, tmp_compare_right_16 );
    if ( tmp_cmp_Eq_15 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 62;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_15 == 1 )
    {
        goto branch_yes_17;
    }
    else
    {
        goto branch_no_17;
    }
    branch_yes_17:;
    tmp_called_name_6 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_ImageWriter );

    if (unlikely( tmp_called_name_6 == NULL ))
    {
        tmp_called_name_6 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_ImageWriter );
    }

    if ( tmp_called_name_6 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "ImageWriter" );
        exception_tb = NULL;

        exception_lineno = 62;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }

    tmp_args_element_name_4 = var_v;

    CHECK_OBJECT( tmp_args_element_name_4 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 62;
    {
        PyObject *call_args[] = { tmp_args_element_name_4 };
        tmp_assign_source_37 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_6, call_args );
    }

    if ( tmp_assign_source_37 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 62;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    {
        PyObject *old = var_imagewriter;
        var_imagewriter = tmp_assign_source_37;
        Py_XDECREF( old );
    }

    goto branch_end_17;
    branch_no_17:;
    tmp_compare_left_17 = var_k;

    CHECK_OBJECT( tmp_compare_left_17 );
    tmp_compare_right_17 = const_str_digest_661170a362c0712dfb804f7826b521cc;
    tmp_cmp_Eq_16 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_17, tmp_compare_right_17 );
    if ( tmp_cmp_Eq_16 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 63;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_16 == 1 )
    {
        goto branch_yes_18;
    }
    else
    {
        goto branch_no_18;
    }
    branch_yes_18:;
    tmp_int_arg_2 = var_v;

    CHECK_OBJECT( tmp_int_arg_2 );
    tmp_assign_source_38 = PyNumber_Int( tmp_int_arg_2 );
    if ( tmp_assign_source_38 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 63;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    {
        PyObject *old = var_rotation;
        var_rotation = tmp_assign_source_38;
        Py_XDECREF( old );
    }

    goto branch_end_18;
    branch_no_18:;
    tmp_compare_left_18 = var_k;

    CHECK_OBJECT( tmp_compare_left_18 );
    tmp_compare_right_18 = const_str_digest_59bdb53e22971cd7d7e7b286d1104da6;
    tmp_cmp_Eq_17 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_18, tmp_compare_right_18 );
    if ( tmp_cmp_Eq_17 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 64;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_17 == 1 )
    {
        goto branch_yes_19;
    }
    else
    {
        goto branch_no_19;
    }
    branch_yes_19:;
    tmp_assign_source_39 = Py_True;
    {
        PyObject *old = var_stripcontrol;
        var_stripcontrol = tmp_assign_source_39;
        Py_INCREF( var_stripcontrol );
        Py_XDECREF( old );
    }

    goto branch_end_19;
    branch_no_19:;
    tmp_compare_left_19 = var_k;

    CHECK_OBJECT( tmp_compare_left_19 );
    tmp_compare_right_19 = const_str_digest_59859f73ac9e852f31ad1e0e17633e44;
    tmp_cmp_Eq_18 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_19, tmp_compare_right_19 );
    if ( tmp_cmp_Eq_18 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 65;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_18 == 1 )
    {
        goto branch_yes_20;
    }
    else
    {
        goto branch_no_20;
    }
    branch_yes_20:;
    tmp_assign_source_40 = var_v;

    CHECK_OBJECT( tmp_assign_source_40 );
    {
        PyObject *old = var_outtype;
        var_outtype = tmp_assign_source_40;
        Py_INCREF( var_outtype );
        Py_XDECREF( old );
    }

    goto branch_end_20;
    branch_no_20:;
    tmp_compare_left_20 = var_k;

    CHECK_OBJECT( tmp_compare_left_20 );
    tmp_compare_right_20 = const_str_digest_8b4c8c81913e132a2fb432c041f3150f;
    tmp_cmp_Eq_19 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_20, tmp_compare_right_20 );
    if ( tmp_cmp_Eq_19 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 66;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_19 == 1 )
    {
        goto branch_yes_21;
    }
    else
    {
        goto branch_no_21;
    }
    branch_yes_21:;
    tmp_assign_source_41 = var_v;

    CHECK_OBJECT( tmp_assign_source_41 );
    {
        PyObject *old = var_codec;
        var_codec = tmp_assign_source_41;
        Py_INCREF( var_codec );
        Py_XDECREF( old );
    }

    goto branch_end_21;
    branch_no_21:;
    tmp_compare_left_21 = var_k;

    CHECK_OBJECT( tmp_compare_left_21 );
    tmp_compare_right_21 = const_str_digest_c836122af34ee7a172b779f26da7801f;
    tmp_cmp_Eq_20 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_21, tmp_compare_right_21 );
    if ( tmp_cmp_Eq_20 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 67;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    if ( tmp_cmp_Eq_20 == 1 )
    {
        goto branch_yes_22;
    }
    else
    {
        goto branch_no_22;
    }
    branch_yes_22:;
    tmp_float_arg_5 = var_v;

    CHECK_OBJECT( tmp_float_arg_5 );
    tmp_assign_source_42 = TO_FLOAT( tmp_float_arg_5 );
    if ( tmp_assign_source_42 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 67;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    {
        PyObject *old = var_scale;
        var_scale = tmp_assign_source_42;
        Py_XDECREF( old );
    }

    branch_no_22:;
    branch_end_21:;
    branch_end_20:;
    branch_end_19:;
    branch_end_18:;
    branch_end_17:;
    branch_end_16:;
    branch_end_15:;
    branch_end_14:;
    branch_end_13:;
    branch_end_12:;
    branch_end_11:;
    branch_end_10:;
    branch_end_9:;
    branch_end_8:;
    branch_end_7:;
    branch_end_6:;
    branch_end_5:;
    branch_end_4:;
    branch_end_3:;
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 47;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_5;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_6;
    // Exception handler code:
    try_except_handler_5:;
    exception_keeper_type_6 = exception_type;
    exception_keeper_value_6 = exception_value;
    exception_keeper_tb_6 = exception_tb;
    exception_keeper_lineno_6 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_6;
    exception_value = exception_keeper_value_6;
    exception_tb = exception_keeper_tb_6;
    exception_lineno = exception_keeper_lineno_6;

    goto frame_exception_exit_1;
    // End of try:
    try_end_6:;
    Py_XDECREF( tmp_for_loop_1__iter_value );
    tmp_for_loop_1__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_1__for_iterator );
    Py_DECREF( tmp_for_loop_1__for_iterator );
    tmp_for_loop_1__for_iterator = NULL;

    tmp_assattr_name_7 = var_debug;

    if ( tmp_assattr_name_7 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 69;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_assattr_target_7 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFDocument );

    if (unlikely( tmp_assattr_target_7 == NULL ))
    {
        tmp_assattr_target_7 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFDocument );
    }

    if ( tmp_assattr_target_7 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFDocument" );
        exception_tb = NULL;

        exception_lineno = 69;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_7, const_str_plain_debug, tmp_assattr_name_7 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 69;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_name_8 = var_debug;

    if ( tmp_assattr_name_8 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 70;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_assattr_target_8 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFParser );

    if (unlikely( tmp_assattr_target_8 == NULL ))
    {
        tmp_assattr_target_8 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFParser );
    }

    if ( tmp_assattr_target_8 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFParser" );
        exception_tb = NULL;

        exception_lineno = 70;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_8, const_str_plain_debug, tmp_assattr_name_8 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 70;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_name_9 = var_debug;

    if ( tmp_assattr_name_9 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 71;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_assattr_target_9 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_CMapDB );

    if (unlikely( tmp_assattr_target_9 == NULL ))
    {
        tmp_assattr_target_9 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_CMapDB );
    }

    if ( tmp_assattr_target_9 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "CMapDB" );
        exception_tb = NULL;

        exception_lineno = 71;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_9, const_str_plain_debug, tmp_assattr_name_9 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 71;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_assattr_name_10 = var_debug;

    if ( tmp_assattr_name_10 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 72;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_assattr_target_10 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFPageInterpreter );

    if (unlikely( tmp_assattr_target_10 == NULL ))
    {
        tmp_assattr_target_10 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFPageInterpreter );
    }

    if ( tmp_assattr_target_10 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFPageInterpreter" );
        exception_tb = NULL;

        exception_lineno = 72;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_10, const_str_plain_debug, tmp_assattr_name_10 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 72;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_called_name_7 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFResourceManager );

    if (unlikely( tmp_called_name_7 == NULL ))
    {
        tmp_called_name_7 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFResourceManager );
    }

    if ( tmp_called_name_7 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFResourceManager" );
        exception_tb = NULL;

        exception_lineno = 74;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_kw_name_1 = _PyDict_NewPresized( 1 );
    tmp_dict_value_1 = var_caching;

    if ( tmp_dict_value_1 == NULL )
    {
        Py_DECREF( tmp_kw_name_1 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "caching" );
        exception_tb = NULL;

        exception_lineno = 74;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_1 = const_str_plain_caching;
    tmp_res = PyDict_SetItem( tmp_kw_name_1, tmp_dict_key_1, tmp_dict_value_1 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 74;
    tmp_assign_source_43 = CALL_FUNCTION_WITH_KEYARGS( tmp_called_name_7, tmp_kw_name_1 );
    Py_DECREF( tmp_kw_name_1 );
    if ( tmp_assign_source_43 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 74;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_rsrcmgr == NULL );
    var_rsrcmgr = tmp_assign_source_43;

    tmp_cond_value_2 = var_outtype;

    if ( tmp_cond_value_2 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outtype" );
        exception_tb = NULL;

        exception_lineno = 75;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_cond_truth_2 = CHECK_IF_TRUE( tmp_cond_value_2 );
    if ( tmp_cond_truth_2 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 75;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_2 == 1 )
    {
        goto branch_no_23;
    }
    else
    {
        goto branch_yes_23;
    }
    branch_yes_23:;
    tmp_assign_source_44 = const_str_plain_text;
    {
        PyObject *old = var_outtype;
        var_outtype = tmp_assign_source_44;
        Py_INCREF( var_outtype );
        Py_XDECREF( old );
    }

    tmp_cond_value_3 = var_outfile;

    if ( tmp_cond_value_3 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 77;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_cond_truth_3 = CHECK_IF_TRUE( tmp_cond_value_3 );
    if ( tmp_cond_truth_3 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 77;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_3 == 1 )
    {
        goto branch_yes_24;
    }
    else
    {
        goto branch_no_24;
    }
    branch_yes_24:;
    tmp_called_instance_2 = var_outfile;

    if ( tmp_called_instance_2 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 78;
    tmp_or_left_value_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_2, const_str_plain_endswith, &PyTuple_GET_ITEM( const_tuple_str_digest_e023af1ef281d8d55c1e56d49000f818_tuple, 0 ) );

    if ( tmp_or_left_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_or_left_truth_1 = CHECK_IF_TRUE( tmp_or_left_value_1 );
    if ( tmp_or_left_truth_1 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_or_left_value_1 );

        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_or_left_truth_1 == 1 )
    {
        goto or_left_1;
    }
    else
    {
        goto or_right_1;
    }
    or_right_1:;
    Py_DECREF( tmp_or_left_value_1 );
    tmp_called_instance_3 = var_outfile;

    if ( tmp_called_instance_3 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 78;
    tmp_or_right_value_1 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_3, const_str_plain_endswith, &PyTuple_GET_ITEM( const_tuple_str_digest_215503f2c4e6161a6262d87acf44fc46_tuple, 0 ) );

    if ( tmp_or_right_value_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_value_4 = tmp_or_right_value_1;
    goto or_end_1;
    or_left_1:;
    tmp_cond_value_4 = tmp_or_left_value_1;
    or_end_1:;
    tmp_cond_truth_4 = CHECK_IF_TRUE( tmp_cond_value_4 );
    if ( tmp_cond_truth_4 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_4 );

        exception_lineno = 78;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_4 );
    if ( tmp_cond_truth_4 == 1 )
    {
        goto branch_yes_25;
    }
    else
    {
        goto branch_no_25;
    }
    branch_yes_25:;
    tmp_assign_source_45 = const_str_plain_html;
    {
        PyObject *old = var_outtype;
        assert( old != NULL );
        var_outtype = tmp_assign_source_45;
        Py_INCREF( var_outtype );
        Py_DECREF( old );
    }

    goto branch_end_25;
    branch_no_25:;
    tmp_called_instance_4 = var_outfile;

    if ( tmp_called_instance_4 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 80;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 80;
    tmp_cond_value_5 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_4, const_str_plain_endswith, &PyTuple_GET_ITEM( const_tuple_str_digest_e9c9f62ca34577b9e8d22e82b5b67334_tuple, 0 ) );

    if ( tmp_cond_value_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 80;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_5 = CHECK_IF_TRUE( tmp_cond_value_5 );
    if ( tmp_cond_truth_5 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_5 );

        exception_lineno = 80;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_5 );
    if ( tmp_cond_truth_5 == 1 )
    {
        goto branch_yes_26;
    }
    else
    {
        goto branch_no_26;
    }
    branch_yes_26:;
    tmp_assign_source_46 = const_str_plain_xml;
    {
        PyObject *old = var_outtype;
        assert( old != NULL );
        var_outtype = tmp_assign_source_46;
        Py_INCREF( var_outtype );
        Py_DECREF( old );
    }

    goto branch_end_26;
    branch_no_26:;
    tmp_called_instance_5 = var_outfile;

    if ( tmp_called_instance_5 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 82;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 82;
    tmp_cond_value_6 = CALL_METHOD_WITH_ARGS1( tmp_called_instance_5, const_str_plain_endswith, &PyTuple_GET_ITEM( const_tuple_str_digest_d312566fe84d6b0b90952b7c0274f1c6_tuple, 0 ) );

    if ( tmp_cond_value_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 82;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    tmp_cond_truth_6 = CHECK_IF_TRUE( tmp_cond_value_6 );
    if ( tmp_cond_truth_6 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_cond_value_6 );

        exception_lineno = 82;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_cond_value_6 );
    if ( tmp_cond_truth_6 == 1 )
    {
        goto branch_yes_27;
    }
    else
    {
        goto branch_no_27;
    }
    branch_yes_27:;
    tmp_assign_source_47 = const_str_plain_tag;
    {
        PyObject *old = var_outtype;
        assert( old != NULL );
        var_outtype = tmp_assign_source_47;
        Py_INCREF( var_outtype );
        Py_DECREF( old );
    }

    branch_no_27:;
    branch_end_26:;
    branch_end_25:;
    branch_no_24:;
    branch_no_23:;
    tmp_cond_value_7 = var_outfile;

    if ( tmp_cond_value_7 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 84;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_cond_truth_7 = CHECK_IF_TRUE( tmp_cond_value_7 );
    if ( tmp_cond_truth_7 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 84;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cond_truth_7 == 1 )
    {
        goto branch_yes_28;
    }
    else
    {
        goto branch_no_28;
    }
    branch_yes_28:;
    tmp_called_name_8 = (PyObject *)&PyFile_Type;
    tmp_args_element_name_5 = var_outfile;

    if ( tmp_args_element_name_5 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outfile" );
        exception_tb = NULL;

        exception_lineno = 85;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_element_name_6 = const_str_plain_w;
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 85;
    {
        PyObject *call_args[] = { tmp_args_element_name_5, tmp_args_element_name_6 };
        tmp_assign_source_48 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_8, call_args );
    }

    if ( tmp_assign_source_48 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 85;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_outfp == NULL );
    var_outfp = tmp_assign_source_48;

    goto branch_end_28;
    branch_no_28:;
    tmp_source_name_4 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_sys );

    if (unlikely( tmp_source_name_4 == NULL ))
    {
        tmp_source_name_4 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_sys );
    }

    if ( tmp_source_name_4 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "sys" );
        exception_tb = NULL;

        exception_lineno = 87;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_assign_source_49 = LOOKUP_ATTRIBUTE( tmp_source_name_4, const_str_plain_stdout );
    if ( tmp_assign_source_49 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 87;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_outfp == NULL );
    var_outfp = tmp_assign_source_49;

    branch_end_28:;
    tmp_compare_left_22 = var_outtype;

    if ( tmp_compare_left_22 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outtype" );
        exception_tb = NULL;

        exception_lineno = 88;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_compare_right_22 = const_str_plain_text;
    tmp_cmp_Eq_21 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_22, tmp_compare_right_22 );
    if ( tmp_cmp_Eq_21 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 88;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_21 == 1 )
    {
        goto branch_yes_29;
    }
    else
    {
        goto branch_no_29;
    }
    branch_yes_29:;
    tmp_called_name_9 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_TextConverter );

    if (unlikely( tmp_called_name_9 == NULL ))
    {
        tmp_called_name_9 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_TextConverter );
    }

    if ( tmp_called_name_9 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "TextConverter" );
        exception_tb = NULL;

        exception_lineno = 89;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_name_1 = PyTuple_New( 2 );
    tmp_tuple_element_1 = var_rsrcmgr;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_name_1, 0, tmp_tuple_element_1 );
    tmp_tuple_element_1 = var_outfp;

    CHECK_OBJECT( tmp_tuple_element_1 );
    Py_INCREF( tmp_tuple_element_1 );
    PyTuple_SET_ITEM( tmp_args_name_1, 1, tmp_tuple_element_1 );
    tmp_kw_name_2 = _PyDict_NewPresized( 3 );
    tmp_dict_value_2 = var_codec;

    if ( tmp_dict_value_2 == NULL )
    {
        Py_DECREF( tmp_args_name_1 );
        Py_DECREF( tmp_kw_name_2 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "codec" );
        exception_tb = NULL;

        exception_lineno = 89;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_2 = const_str_plain_codec;
    tmp_res = PyDict_SetItem( tmp_kw_name_2, tmp_dict_key_2, tmp_dict_value_2 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_3 = var_laparams;

    if ( tmp_dict_value_3 == NULL )
    {
        Py_DECREF( tmp_args_name_1 );
        Py_DECREF( tmp_kw_name_2 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 89;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_3 = const_str_plain_laparams;
    tmp_res = PyDict_SetItem( tmp_kw_name_2, tmp_dict_key_3, tmp_dict_value_3 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_4 = var_imagewriter;

    if ( tmp_dict_value_4 == NULL )
    {
        Py_DECREF( tmp_args_name_1 );
        Py_DECREF( tmp_kw_name_2 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "imagewriter" );
        exception_tb = NULL;

        exception_lineno = 90;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_4 = const_str_plain_imagewriter;
    tmp_res = PyDict_SetItem( tmp_kw_name_2, tmp_dict_key_4, tmp_dict_value_4 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 89;
    tmp_assign_source_50 = CALL_FUNCTION( tmp_called_name_9, tmp_args_name_1, tmp_kw_name_2 );
    Py_DECREF( tmp_args_name_1 );
    Py_DECREF( tmp_kw_name_2 );
    if ( tmp_assign_source_50 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 89;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_device == NULL );
    var_device = tmp_assign_source_50;

    goto branch_end_29;
    branch_no_29:;
    tmp_compare_left_23 = var_outtype;

    if ( tmp_compare_left_23 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outtype" );
        exception_tb = NULL;

        exception_lineno = 91;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_compare_right_23 = const_str_plain_xml;
    tmp_cmp_Eq_22 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_23, tmp_compare_right_23 );
    if ( tmp_cmp_Eq_22 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 91;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_22 == 1 )
    {
        goto branch_yes_30;
    }
    else
    {
        goto branch_no_30;
    }
    branch_yes_30:;
    tmp_called_name_10 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_XMLConverter );

    if (unlikely( tmp_called_name_10 == NULL ))
    {
        tmp_called_name_10 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_XMLConverter );
    }

    if ( tmp_called_name_10 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "XMLConverter" );
        exception_tb = NULL;

        exception_lineno = 92;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_name_2 = PyTuple_New( 2 );
    tmp_tuple_element_2 = var_rsrcmgr;

    CHECK_OBJECT( tmp_tuple_element_2 );
    Py_INCREF( tmp_tuple_element_2 );
    PyTuple_SET_ITEM( tmp_args_name_2, 0, tmp_tuple_element_2 );
    tmp_tuple_element_2 = var_outfp;

    CHECK_OBJECT( tmp_tuple_element_2 );
    Py_INCREF( tmp_tuple_element_2 );
    PyTuple_SET_ITEM( tmp_args_name_2, 1, tmp_tuple_element_2 );
    tmp_kw_name_3 = _PyDict_NewPresized( 4 );
    tmp_dict_value_5 = var_codec;

    if ( tmp_dict_value_5 == NULL )
    {
        Py_DECREF( tmp_args_name_2 );
        Py_DECREF( tmp_kw_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "codec" );
        exception_tb = NULL;

        exception_lineno = 92;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_5 = const_str_plain_codec;
    tmp_res = PyDict_SetItem( tmp_kw_name_3, tmp_dict_key_5, tmp_dict_value_5 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_6 = var_laparams;

    if ( tmp_dict_value_6 == NULL )
    {
        Py_DECREF( tmp_args_name_2 );
        Py_DECREF( tmp_kw_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 92;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_6 = const_str_plain_laparams;
    tmp_res = PyDict_SetItem( tmp_kw_name_3, tmp_dict_key_6, tmp_dict_value_6 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_7 = var_imagewriter;

    if ( tmp_dict_value_7 == NULL )
    {
        Py_DECREF( tmp_args_name_2 );
        Py_DECREF( tmp_kw_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "imagewriter" );
        exception_tb = NULL;

        exception_lineno = 93;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_7 = const_str_plain_imagewriter;
    tmp_res = PyDict_SetItem( tmp_kw_name_3, tmp_dict_key_7, tmp_dict_value_7 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_8 = var_stripcontrol;

    if ( tmp_dict_value_8 == NULL )
    {
        Py_DECREF( tmp_args_name_2 );
        Py_DECREF( tmp_kw_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "stripcontrol" );
        exception_tb = NULL;

        exception_lineno = 94;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_8 = const_str_plain_stripcontrol;
    tmp_res = PyDict_SetItem( tmp_kw_name_3, tmp_dict_key_8, tmp_dict_value_8 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 92;
    tmp_assign_source_51 = CALL_FUNCTION( tmp_called_name_10, tmp_args_name_2, tmp_kw_name_3 );
    Py_DECREF( tmp_args_name_2 );
    Py_DECREF( tmp_kw_name_3 );
    if ( tmp_assign_source_51 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 92;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_device == NULL );
    var_device = tmp_assign_source_51;

    goto branch_end_30;
    branch_no_30:;
    tmp_compare_left_24 = var_outtype;

    if ( tmp_compare_left_24 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outtype" );
        exception_tb = NULL;

        exception_lineno = 95;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_compare_right_24 = const_str_plain_html;
    tmp_cmp_Eq_23 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_24, tmp_compare_right_24 );
    if ( tmp_cmp_Eq_23 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 95;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_23 == 1 )
    {
        goto branch_yes_31;
    }
    else
    {
        goto branch_no_31;
    }
    branch_yes_31:;
    tmp_called_name_11 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_HTMLConverter );

    if (unlikely( tmp_called_name_11 == NULL ))
    {
        tmp_called_name_11 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_HTMLConverter );
    }

    if ( tmp_called_name_11 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "HTMLConverter" );
        exception_tb = NULL;

        exception_lineno = 96;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_name_3 = PyTuple_New( 2 );
    tmp_tuple_element_3 = var_rsrcmgr;

    CHECK_OBJECT( tmp_tuple_element_3 );
    Py_INCREF( tmp_tuple_element_3 );
    PyTuple_SET_ITEM( tmp_args_name_3, 0, tmp_tuple_element_3 );
    tmp_tuple_element_3 = var_outfp;

    CHECK_OBJECT( tmp_tuple_element_3 );
    Py_INCREF( tmp_tuple_element_3 );
    PyTuple_SET_ITEM( tmp_args_name_3, 1, tmp_tuple_element_3 );
    tmp_kw_name_4 = _PyDict_NewPresized( 6 );
    tmp_dict_value_9 = var_codec;

    if ( tmp_dict_value_9 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "codec" );
        exception_tb = NULL;

        exception_lineno = 96;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_9 = const_str_plain_codec;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_9, tmp_dict_value_9 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_10 = var_scale;

    if ( tmp_dict_value_10 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "scale" );
        exception_tb = NULL;

        exception_lineno = 96;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_10 = const_str_plain_scale;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_10, tmp_dict_value_10 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_11 = var_layoutmode;

    if ( tmp_dict_value_11 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "layoutmode" );
        exception_tb = NULL;

        exception_lineno = 97;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_11 = const_str_plain_layoutmode;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_11, tmp_dict_value_11 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_12 = var_laparams;

    if ( tmp_dict_value_12 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "laparams" );
        exception_tb = NULL;

        exception_lineno = 97;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_12 = const_str_plain_laparams;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_12, tmp_dict_value_12 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_13 = var_imagewriter;

    if ( tmp_dict_value_13 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "imagewriter" );
        exception_tb = NULL;

        exception_lineno = 98;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_13 = const_str_plain_imagewriter;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_13, tmp_dict_value_13 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_14 = var_debug;

    if ( tmp_dict_value_14 == NULL )
    {
        Py_DECREF( tmp_args_name_3 );
        Py_DECREF( tmp_kw_name_4 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "debug" );
        exception_tb = NULL;

        exception_lineno = 98;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_14 = const_str_plain_debug;
    tmp_res = PyDict_SetItem( tmp_kw_name_4, tmp_dict_key_14, tmp_dict_value_14 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 96;
    tmp_assign_source_52 = CALL_FUNCTION( tmp_called_name_11, tmp_args_name_3, tmp_kw_name_4 );
    Py_DECREF( tmp_args_name_3 );
    Py_DECREF( tmp_kw_name_4 );
    if ( tmp_assign_source_52 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 96;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_device == NULL );
    var_device = tmp_assign_source_52;

    goto branch_end_31;
    branch_no_31:;
    tmp_compare_left_25 = var_outtype;

    if ( tmp_compare_left_25 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "outtype" );
        exception_tb = NULL;

        exception_lineno = 99;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_compare_right_25 = const_str_plain_tag;
    tmp_cmp_Eq_24 = RICH_COMPARE_BOOL_EQ( tmp_compare_left_25, tmp_compare_right_25 );
    if ( tmp_cmp_Eq_24 == -1 )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 99;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    if ( tmp_cmp_Eq_24 == 1 )
    {
        goto branch_yes_32;
    }
    else
    {
        goto branch_no_32;
    }
    branch_yes_32:;
    tmp_called_name_12 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_TagExtractor );

    if (unlikely( tmp_called_name_12 == NULL ))
    {
        tmp_called_name_12 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_TagExtractor );
    }

    if ( tmp_called_name_12 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "TagExtractor" );
        exception_tb = NULL;

        exception_lineno = 100;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_args_name_4 = PyTuple_New( 2 );
    tmp_tuple_element_4 = var_rsrcmgr;

    CHECK_OBJECT( tmp_tuple_element_4 );
    Py_INCREF( tmp_tuple_element_4 );
    PyTuple_SET_ITEM( tmp_args_name_4, 0, tmp_tuple_element_4 );
    tmp_tuple_element_4 = var_outfp;

    CHECK_OBJECT( tmp_tuple_element_4 );
    Py_INCREF( tmp_tuple_element_4 );
    PyTuple_SET_ITEM( tmp_args_name_4, 1, tmp_tuple_element_4 );
    tmp_kw_name_5 = _PyDict_NewPresized( 1 );
    tmp_dict_value_15 = var_codec;

    if ( tmp_dict_value_15 == NULL )
    {
        Py_DECREF( tmp_args_name_4 );
        Py_DECREF( tmp_kw_name_5 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "codec" );
        exception_tb = NULL;

        exception_lineno = 100;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    tmp_dict_key_15 = const_str_plain_codec;
    tmp_res = PyDict_SetItem( tmp_kw_name_5, tmp_dict_key_15, tmp_dict_value_15 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 100;
    tmp_assign_source_53 = CALL_FUNCTION( tmp_called_name_12, tmp_args_name_4, tmp_kw_name_5 );
    Py_DECREF( tmp_args_name_4 );
    Py_DECREF( tmp_kw_name_5 );
    if ( tmp_assign_source_53 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 100;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( var_device == NULL );
    var_device = tmp_assign_source_53;

    goto branch_end_32;
    branch_no_32:;
    tmp_called_name_13 = var_usage;

    CHECK_OBJECT( tmp_called_name_13 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 102;
    tmp_return_value = CALL_FUNCTION_NO_ARGS( tmp_called_name_13 );
    if ( tmp_return_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 102;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    goto frame_return_exit_1;
    branch_end_32:;
    branch_end_31:;
    branch_end_30:;
    branch_end_29:;
    tmp_iter_arg_5 = var_args;

    CHECK_OBJECT( tmp_iter_arg_5 );
    tmp_assign_source_54 = MAKE_ITERATOR( tmp_iter_arg_5 );
    if ( tmp_assign_source_54 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 103;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    assert( tmp_for_loop_2__for_iterator == NULL );
    tmp_for_loop_2__for_iterator = tmp_assign_source_54;

    // Tried code:
    loop_start_2:;
    tmp_next_source_2 = tmp_for_loop_2__for_iterator;

    CHECK_OBJECT( tmp_next_source_2 );
    tmp_assign_source_55 = ITERATOR_NEXT( tmp_next_source_2 );
    if ( tmp_assign_source_55 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_2;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "coooooooooooooooNooNoooooooooo";
            exception_lineno = 103;
            goto try_except_handler_9;
        }
    }

    {
        PyObject *old = tmp_for_loop_2__iter_value;
        tmp_for_loop_2__iter_value = tmp_assign_source_55;
        Py_XDECREF( old );
    }

    tmp_assign_source_56 = tmp_for_loop_2__iter_value;

    CHECK_OBJECT( tmp_assign_source_56 );
    {
        PyObject *old = var_fname;
        var_fname = tmp_assign_source_56;
        Py_INCREF( var_fname );
        Py_XDECREF( old );
    }

    tmp_called_name_14 = (PyObject *)&PyFile_Type;
    tmp_args_element_name_7 = var_fname;

    CHECK_OBJECT( tmp_args_element_name_7 );
    tmp_args_element_name_8 = const_str_plain_rb;
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 104;
    {
        PyObject *call_args[] = { tmp_args_element_name_7, tmp_args_element_name_8 };
        tmp_assign_source_57 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_14, call_args );
    }

    if ( tmp_assign_source_57 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 104;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    {
        PyObject *old = var_fp;
        var_fp = tmp_assign_source_57;
        Py_XDECREF( old );
    }

    tmp_called_name_15 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFPageInterpreter );

    if (unlikely( tmp_called_name_15 == NULL ))
    {
        tmp_called_name_15 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFPageInterpreter );
    }

    if ( tmp_called_name_15 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFPageInterpreter" );
        exception_tb = NULL;

        exception_lineno = 105;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    tmp_args_element_name_9 = var_rsrcmgr;

    CHECK_OBJECT( tmp_args_element_name_9 );
    tmp_args_element_name_10 = var_device;

    if ( tmp_args_element_name_10 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "device" );
        exception_tb = NULL;

        exception_lineno = 105;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 105;
    {
        PyObject *call_args[] = { tmp_args_element_name_9, tmp_args_element_name_10 };
        tmp_assign_source_58 = CALL_FUNCTION_WITH_ARGS2( tmp_called_name_15, call_args );
    }

    if ( tmp_assign_source_58 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 105;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    {
        PyObject *old = var_interpreter;
        var_interpreter = tmp_assign_source_58;
        Py_XDECREF( old );
    }

    tmp_source_name_5 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFPage );

    if (unlikely( tmp_source_name_5 == NULL ))
    {
        tmp_source_name_5 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_PDFPage );
    }

    if ( tmp_source_name_5 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "global name '%s' is not defined", "PDFPage" );
        exception_tb = NULL;

        exception_lineno = 106;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    tmp_called_name_16 = LOOKUP_ATTRIBUTE( tmp_source_name_5, const_str_plain_get_pages );
    if ( tmp_called_name_16 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 106;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    tmp_args_name_5 = PyTuple_New( 2 );
    tmp_tuple_element_5 = var_fp;

    CHECK_OBJECT( tmp_tuple_element_5 );
    Py_INCREF( tmp_tuple_element_5 );
    PyTuple_SET_ITEM( tmp_args_name_5, 0, tmp_tuple_element_5 );
    tmp_tuple_element_5 = var_pagenos;

    CHECK_OBJECT( tmp_tuple_element_5 );
    Py_INCREF( tmp_tuple_element_5 );
    PyTuple_SET_ITEM( tmp_args_name_5, 1, tmp_tuple_element_5 );
    tmp_kw_name_6 = _PyDict_NewPresized( 4 );
    tmp_dict_value_16 = var_maxpages;

    if ( tmp_dict_value_16 == NULL )
    {
        Py_DECREF( tmp_called_name_16 );
        Py_DECREF( tmp_args_name_5 );
        Py_DECREF( tmp_kw_name_6 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "maxpages" );
        exception_tb = NULL;

        exception_lineno = 107;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    tmp_dict_key_16 = const_str_plain_maxpages;
    tmp_res = PyDict_SetItem( tmp_kw_name_6, tmp_dict_key_16, tmp_dict_value_16 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_17 = var_password;

    if ( tmp_dict_value_17 == NULL )
    {
        Py_DECREF( tmp_called_name_16 );
        Py_DECREF( tmp_args_name_5 );
        Py_DECREF( tmp_kw_name_6 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "password" );
        exception_tb = NULL;

        exception_lineno = 107;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    tmp_dict_key_17 = const_str_plain_password;
    tmp_res = PyDict_SetItem( tmp_kw_name_6, tmp_dict_key_17, tmp_dict_value_17 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_18 = var_caching;

    if ( tmp_dict_value_18 == NULL )
    {
        Py_DECREF( tmp_called_name_16 );
        Py_DECREF( tmp_args_name_5 );
        Py_DECREF( tmp_kw_name_6 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "caching" );
        exception_tb = NULL;

        exception_lineno = 108;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }

    tmp_dict_key_18 = const_str_plain_caching;
    tmp_res = PyDict_SetItem( tmp_kw_name_6, tmp_dict_key_18, tmp_dict_value_18 );
    assert( !(tmp_res != 0) );
    tmp_dict_value_19 = Py_True;
    tmp_dict_key_19 = const_str_plain_check_extractable;
    tmp_res = PyDict_SetItem( tmp_kw_name_6, tmp_dict_key_19, tmp_dict_value_19 );
    assert( !(tmp_res != 0) );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 106;
    tmp_iter_arg_6 = CALL_FUNCTION( tmp_called_name_16, tmp_args_name_5, tmp_kw_name_6 );
    Py_DECREF( tmp_called_name_16 );
    Py_DECREF( tmp_args_name_5 );
    Py_DECREF( tmp_kw_name_6 );
    if ( tmp_iter_arg_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 106;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    tmp_assign_source_59 = MAKE_ITERATOR( tmp_iter_arg_6 );
    Py_DECREF( tmp_iter_arg_6 );
    if ( tmp_assign_source_59 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 106;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    {
        PyObject *old = tmp_for_loop_3__for_iterator;
        tmp_for_loop_3__for_iterator = tmp_assign_source_59;
        Py_XDECREF( old );
    }

    // Tried code:
    loop_start_3:;
    tmp_next_source_3 = tmp_for_loop_3__for_iterator;

    CHECK_OBJECT( tmp_next_source_3 );
    tmp_assign_source_60 = ITERATOR_NEXT( tmp_next_source_3 );
    if ( tmp_assign_source_60 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_3;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "coooooooooooooooNooNoooooooooo";
            exception_lineno = 106;
            goto try_except_handler_10;
        }
    }

    {
        PyObject *old = tmp_for_loop_3__iter_value;
        tmp_for_loop_3__iter_value = tmp_assign_source_60;
        Py_XDECREF( old );
    }

    tmp_assign_source_61 = tmp_for_loop_3__iter_value;

    CHECK_OBJECT( tmp_assign_source_61 );
    {
        PyObject *old = var_page;
        var_page = tmp_assign_source_61;
        Py_INCREF( var_page );
        Py_XDECREF( old );
    }

    tmp_source_name_6 = var_page;

    CHECK_OBJECT( tmp_source_name_6 );
    tmp_left_name_3 = LOOKUP_ATTRIBUTE( tmp_source_name_6, const_str_plain_rotate );
    if ( tmp_left_name_3 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 109;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    tmp_right_name_2 = var_rotation;

    if ( tmp_right_name_2 == NULL )
    {
        Py_DECREF( tmp_left_name_3 );
        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "rotation" );
        exception_tb = NULL;

        exception_lineno = 109;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }

    tmp_left_name_2 = BINARY_OPERATION_ADD( tmp_left_name_3, tmp_right_name_2 );
    Py_DECREF( tmp_left_name_3 );
    if ( tmp_left_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 109;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    tmp_right_name_3 = const_int_pos_360;
    tmp_assattr_name_11 = BINARY_OPERATION_REMAINDER( tmp_left_name_2, tmp_right_name_3 );
    Py_DECREF( tmp_left_name_2 );
    if ( tmp_assattr_name_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 109;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    tmp_assattr_target_11 = var_page;

    CHECK_OBJECT( tmp_assattr_target_11 );
    tmp_result = SET_ATTRIBUTE( tmp_assattr_target_11, const_str_plain_rotate, tmp_assattr_name_11 );
    if ( tmp_result == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_assattr_name_11 );

        exception_lineno = 109;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    Py_DECREF( tmp_assattr_name_11 );
    tmp_called_instance_6 = var_interpreter;

    CHECK_OBJECT( tmp_called_instance_6 );
    tmp_args_element_name_11 = var_page;

    CHECK_OBJECT( tmp_args_element_name_11 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 110;
    {
        PyObject *call_args[] = { tmp_args_element_name_11 };
        tmp_unused = CALL_METHOD_WITH_ARGS1( tmp_called_instance_6, const_str_plain_process_page, call_args );
    }

    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 110;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 106;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_10;
    }
    goto loop_start_3;
    loop_end_3:;
    goto try_end_7;
    // Exception handler code:
    try_except_handler_10:;
    exception_keeper_type_7 = exception_type;
    exception_keeper_value_7 = exception_value;
    exception_keeper_tb_7 = exception_tb;
    exception_keeper_lineno_7 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_3__iter_value );
    tmp_for_loop_3__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_3__for_iterator );
    Py_DECREF( tmp_for_loop_3__for_iterator );
    tmp_for_loop_3__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_7;
    exception_value = exception_keeper_value_7;
    exception_tb = exception_keeper_tb_7;
    exception_lineno = exception_keeper_lineno_7;

    goto try_except_handler_9;
    // End of try:
    try_end_7:;
    Py_XDECREF( tmp_for_loop_3__iter_value );
    tmp_for_loop_3__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_3__for_iterator );
    Py_DECREF( tmp_for_loop_3__for_iterator );
    tmp_for_loop_3__for_iterator = NULL;

    tmp_called_instance_7 = var_fp;

    CHECK_OBJECT( tmp_called_instance_7 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 111;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_7, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 111;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    Py_DECREF( tmp_unused );
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 103;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto try_except_handler_9;
    }
    goto loop_start_2;
    loop_end_2:;
    goto try_end_8;
    // Exception handler code:
    try_except_handler_9:;
    exception_keeper_type_8 = exception_type;
    exception_keeper_value_8 = exception_value;
    exception_keeper_tb_8 = exception_tb;
    exception_keeper_lineno_8 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_for_loop_2__iter_value );
    tmp_for_loop_2__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_2__for_iterator );
    Py_DECREF( tmp_for_loop_2__for_iterator );
    tmp_for_loop_2__for_iterator = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_8;
    exception_value = exception_keeper_value_8;
    exception_tb = exception_keeper_tb_8;
    exception_lineno = exception_keeper_lineno_8;

    goto frame_exception_exit_1;
    // End of try:
    try_end_8:;
    Py_XDECREF( tmp_for_loop_2__iter_value );
    tmp_for_loop_2__iter_value = NULL;

    CHECK_OBJECT( (PyObject *)tmp_for_loop_2__for_iterator );
    Py_DECREF( tmp_for_loop_2__for_iterator );
    tmp_for_loop_2__for_iterator = NULL;

    tmp_called_instance_8 = var_device;

    if ( tmp_called_instance_8 == NULL )
    {

        exception_type = PyExc_UnboundLocalError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "local variable '%s' referenced before assignment", "device" );
        exception_tb = NULL;

        exception_lineno = 112;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }

    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 112;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_8, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 112;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_called_instance_9 = var_outfp;

    CHECK_OBJECT( tmp_called_instance_9 );
    frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame.f_lineno = 113;
    tmp_unused = CALL_METHOD_NO_ARGS( tmp_called_instance_9, const_str_plain_close );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 113;
        type_description_1 = "coooooooooooooooNooNoooooooooo";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );

#if 1
    RESTORE_FRAME_EXCEPTION( frame_96e3437d96ef4905aa04c5d1cf4aca51 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_return_exit_1:;
#if 1
    RESTORE_FRAME_EXCEPTION( frame_96e3437d96ef4905aa04c5d1cf4aca51 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto try_return_handler_1;

    frame_exception_exit_1:;

#if 1
    RESTORE_FRAME_EXCEPTION( frame_96e3437d96ef4905aa04c5d1cf4aca51 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_96e3437d96ef4905aa04c5d1cf4aca51, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_96e3437d96ef4905aa04c5d1cf4aca51->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_96e3437d96ef4905aa04c5d1cf4aca51, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_96e3437d96ef4905aa04c5d1cf4aca51,
        type_description_1,
        par_argv,
        var_getopt,
        var_usage,
        var_opts,
        var_args,
        var_debug,
        var_password,
        var_pagenos,
        var_maxpages,
        var_outfile,
        var_outtype,
        var_imagewriter,
        var_rotation,
        var_stripcontrol,
        var_layoutmode,
        var_codec,
        NULL,
        var_scale,
        var_caching,
        NULL,
        var_laparams,
        var_k,
        var_v,
        var_rsrcmgr,
        var_outfp,
        var_device,
        var_fname,
        var_fp,
        var_interpreter,
        var_page
    );


    // Release cached frame.
    if ( frame_96e3437d96ef4905aa04c5d1cf4aca51 == cache_frame_96e3437d96ef4905aa04c5d1cf4aca51 )
    {
        Py_DECREF( frame_96e3437d96ef4905aa04c5d1cf4aca51 );
    }
    cache_frame_96e3437d96ef4905aa04c5d1cf4aca51 = NULL;

    assertFrameObject( frame_96e3437d96ef4905aa04c5d1cf4aca51 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    tmp_return_value = Py_None;
    Py_INCREF( tmp_return_value );
    goto try_return_handler_1;
    // tried codes exits in all cases
    NUITKA_CANNOT_GET_HERE( __main__$$$function_1_main );
    return NULL;
    // Return handler code:
    try_return_handler_1:;
    CHECK_OBJECT( (PyObject *)par_argv );
    Py_DECREF( par_argv );
    par_argv = NULL;

    CHECK_OBJECT( (PyObject *)var_getopt );
    Py_DECREF( var_getopt );
    var_getopt = NULL;

    CHECK_OBJECT( (PyObject *)var_usage );
    Py_DECREF( var_usage );
    var_usage = NULL;

    Py_XDECREF( var_opts );
    var_opts = NULL;

    Py_XDECREF( var_args );
    var_args = NULL;

    Py_XDECREF( var_debug );
    var_debug = NULL;

    Py_XDECREF( var_password );
    var_password = NULL;

    Py_XDECREF( var_pagenos );
    var_pagenos = NULL;

    Py_XDECREF( var_maxpages );
    var_maxpages = NULL;

    Py_XDECREF( var_outfile );
    var_outfile = NULL;

    Py_XDECREF( var_outtype );
    var_outtype = NULL;

    Py_XDECREF( var_imagewriter );
    var_imagewriter = NULL;

    Py_XDECREF( var_rotation );
    var_rotation = NULL;

    Py_XDECREF( var_stripcontrol );
    var_stripcontrol = NULL;

    Py_XDECREF( var_layoutmode );
    var_layoutmode = NULL;

    Py_XDECREF( var_codec );
    var_codec = NULL;

    Py_XDECREF( var_scale );
    var_scale = NULL;

    Py_XDECREF( var_caching );
    var_caching = NULL;

    Py_XDECREF( var_laparams );
    var_laparams = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_rsrcmgr );
    var_rsrcmgr = NULL;

    Py_XDECREF( var_outfp );
    var_outfp = NULL;

    Py_XDECREF( var_device );
    var_device = NULL;

    Py_XDECREF( var_fname );
    var_fname = NULL;

    Py_XDECREF( var_fp );
    var_fp = NULL;

    Py_XDECREF( var_interpreter );
    var_interpreter = NULL;

    Py_XDECREF( var_page );
    var_page = NULL;

    goto function_return_exit;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_9 = exception_type;
    exception_keeper_value_9 = exception_value;
    exception_keeper_tb_9 = exception_tb;
    exception_keeper_lineno_9 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)par_argv );
    Py_DECREF( par_argv );
    par_argv = NULL;

    Py_XDECREF( var_getopt );
    var_getopt = NULL;

    Py_XDECREF( var_usage );
    var_usage = NULL;

    Py_XDECREF( var_opts );
    var_opts = NULL;

    Py_XDECREF( var_args );
    var_args = NULL;

    Py_XDECREF( var_debug );
    var_debug = NULL;

    Py_XDECREF( var_password );
    var_password = NULL;

    Py_XDECREF( var_pagenos );
    var_pagenos = NULL;

    Py_XDECREF( var_maxpages );
    var_maxpages = NULL;

    Py_XDECREF( var_outfile );
    var_outfile = NULL;

    Py_XDECREF( var_outtype );
    var_outtype = NULL;

    Py_XDECREF( var_imagewriter );
    var_imagewriter = NULL;

    Py_XDECREF( var_rotation );
    var_rotation = NULL;

    Py_XDECREF( var_stripcontrol );
    var_stripcontrol = NULL;

    Py_XDECREF( var_layoutmode );
    var_layoutmode = NULL;

    Py_XDECREF( var_codec );
    var_codec = NULL;

    Py_XDECREF( var_scale );
    var_scale = NULL;

    Py_XDECREF( var_caching );
    var_caching = NULL;

    Py_XDECREF( var_laparams );
    var_laparams = NULL;

    Py_XDECREF( var_k );
    var_k = NULL;

    Py_XDECREF( var_v );
    var_v = NULL;

    Py_XDECREF( var_rsrcmgr );
    var_rsrcmgr = NULL;

    Py_XDECREF( var_outfp );
    var_outfp = NULL;

    Py_XDECREF( var_device );
    var_device = NULL;

    Py_XDECREF( var_fname );
    var_fname = NULL;

    Py_XDECREF( var_fp );
    var_fp = NULL;

    Py_XDECREF( var_interpreter );
    var_interpreter = NULL;

    Py_XDECREF( var_page );
    var_page = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_9;
    exception_value = exception_keeper_value_9;
    exception_tb = exception_keeper_tb_9;
    exception_lineno = exception_keeper_lineno_9;

    goto function_exception_exit;
    // End of try:

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( __main__$$$function_1_main );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}


static PyObject *impl___main__$$$function_1_main$$$function_1_usage( struct Nuitka_FunctionObject const *self, PyObject **python_pars )
{
    // Preserve error status for checks
#ifndef __NUITKA_NO_ASSERT__
    NUITKA_MAY_BE_UNUSED bool had_error = ERROR_OCCURRED();
#endif

    // Local variable declarations.
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *tmp_left_name_1;
    PyObject *tmp_print_value;
    PyObject *tmp_return_value;
    PyObject *tmp_right_name_1;
    PyObject *tmp_subscribed_name_1;
    PyObject *tmp_subscript_name_1;
    static struct Nuitka_FrameObject *cache_frame_fcda504b2c96a18fd21f67c08ac97475 = NULL;

    struct Nuitka_FrameObject *frame_fcda504b2c96a18fd21f67c08ac97475;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;
    tmp_return_value = NULL;

    // Actual function code.
    MAKE_OR_REUSE_FRAME( cache_frame_fcda504b2c96a18fd21f67c08ac97475, codeobj_fcda504b2c96a18fd21f67c08ac97475, module___main__, sizeof(void *) );
    frame_fcda504b2c96a18fd21f67c08ac97475 = cache_frame_fcda504b2c96a18fd21f67c08ac97475;

    // Push the new frame as the currently active one.
    pushFrameStack( frame_fcda504b2c96a18fd21f67c08ac97475 );

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    assert( Py_REFCNT( frame_fcda504b2c96a18fd21f67c08ac97475 ) == 2 ); // Frame stack

    // Framed code:
    tmp_left_name_1 = const_str_digest_72d141c52db040978cbd3b9c9b26d684;
    if ( self->m_closure[0] == NULL )
    {
        tmp_subscribed_name_1 = NULL;
    }
    else
    {
        tmp_subscribed_name_1 = PyCell_GET( self->m_closure[0] );
    }

    if ( tmp_subscribed_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "free variable '%s' referenced before assignment in enclosing scope", "argv" );
        exception_tb = NULL;

        exception_lineno = 21;
        type_description_1 = "c";
        goto frame_exception_exit_1;
    }

    tmp_subscript_name_1 = const_int_0;
    tmp_right_name_1 = LOOKUP_SUBSCRIPT( tmp_subscribed_name_1, tmp_subscript_name_1 );
    if ( tmp_right_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 21;
        type_description_1 = "c";
        goto frame_exception_exit_1;
    }
    tmp_print_value = BINARY_OPERATION_REMAINDER( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_right_name_1 );
    if ( tmp_print_value == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 17;
        type_description_1 = "c";
        goto frame_exception_exit_1;
    }
    if ( PRINT_ITEM( tmp_print_value ) == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_print_value );

        exception_lineno = 17;
        type_description_1 = "c";
        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_print_value );
    if ( PRINT_NEW_LINE() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 17;
        type_description_1 = "c";
        goto frame_exception_exit_1;
    }

#if 0
    RESTORE_FRAME_EXCEPTION( frame_fcda504b2c96a18fd21f67c08ac97475 );
#endif

    // Put the previous frame back on top.
    popFrameStack();

    goto frame_no_exception_1;

    frame_exception_exit_1:;

#if 0
    RESTORE_FRAME_EXCEPTION( frame_fcda504b2c96a18fd21f67c08ac97475 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_fcda504b2c96a18fd21f67c08ac97475, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_fcda504b2c96a18fd21f67c08ac97475->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_fcda504b2c96a18fd21f67c08ac97475, exception_lineno );
    }

    // Attachs locals to frame if any.
    Nuitka_Frame_AttachLocals(
        (struct Nuitka_FrameObject *)frame_fcda504b2c96a18fd21f67c08ac97475,
        type_description_1,
        self->m_closure[0]
    );


    // Release cached frame.
    if ( frame_fcda504b2c96a18fd21f67c08ac97475 == cache_frame_fcda504b2c96a18fd21f67c08ac97475 )
    {
        Py_DECREF( frame_fcda504b2c96a18fd21f67c08ac97475 );
    }
    cache_frame_fcda504b2c96a18fd21f67c08ac97475 = NULL;

    assertFrameObject( frame_fcda504b2c96a18fd21f67c08ac97475 );

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto function_exception_exit;

    frame_no_exception_1:;

    tmp_return_value = const_int_pos_100;
    Py_INCREF( tmp_return_value );
    goto function_return_exit;

    // Return statement must have exited already.
    NUITKA_CANNOT_GET_HERE( __main__$$$function_1_main$$$function_1_usage );
    return NULL;

function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

    return NULL;
    function_return_exit:

    CHECK_OBJECT( tmp_return_value );
    assert( had_error || !ERROR_OCCURRED() );
    return tmp_return_value;

}



#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
struct __main__$$$function_1_main$$$genexpr_1_genexpr_locals {
    PyObject *var_x
    PyObject *tmp_iter_value_0
    PyObject *exception_type
    PyObject *exception_value
    PyTracebackObject *exception_tb
    int exception_lineno
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    int exception_keeper_lineno_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_expression_name_1;
    PyObject *tmp_int_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_right_name_1;
    char const *type_description_1
};
#endif

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
static PyObject *__main__$$$function_1_main$$$genexpr_1_genexpr_context( struct Nuitka_GeneratorObject *generator, PyObject *yield_return_value )
#else
static void __main__$$$function_1_main$$$genexpr_1_genexpr_context( struct Nuitka_GeneratorObject *generator )
#endif
{
    CHECK_OBJECT( (PyObject *)generator );
    assert( Nuitka_Generator_Check( (PyObject *)generator ) );

    // Local variable initialization
    PyObject *var_x = NULL;
    PyObject *tmp_iter_value_0 = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_expression_name_1;
    PyObject *tmp_int_arg_1;
    PyObject *tmp_left_name_1;
    PyObject *tmp_next_source_1;
    PyObject *tmp_right_name_1;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    static struct Nuitka_FrameObject *cache_frame_generator = NULL;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;

    // Dispatch to yield based on return label index:


    // Actual function code.
    // Tried code:
    MAKE_OR_REUSE_FRAME( cache_frame_generator, codeobj_3edeffe4a6db7b702d15782c9f35531c, module___main__, sizeof(void *)+sizeof(void *) );
    generator->m_frame = cache_frame_generator;

    // Mark the frame object as in use, ref count 1 will be up for reuse.
    Py_INCREF( generator->m_frame );
    assert( Py_REFCNT( generator->m_frame ) == 2 ); // Frame stack

#if PYTHON_VERSION >= 340
    generator->m_frame->m_frame.f_gen = (PyObject *)generator;
#endif

    Py_CLEAR( generator->m_frame->m_frame.f_back );

    generator->m_frame->m_frame.f_back = PyThreadState_GET()->frame;
    Py_INCREF( generator->m_frame->m_frame.f_back );

    PyThreadState_GET()->frame = &generator->m_frame->m_frame;
    Py_INCREF( generator->m_frame );

    Nuitka_Frame_MarkAsExecuting( generator->m_frame );

#if PYTHON_VERSION >= 300
    // Accept currently existing exception as the one to publish again when we
    // yield or yield from.

    PyThreadState *thread_state = PyThreadState_GET();

    generator->m_frame->m_frame.f_exc_type = thread_state->exc_type;
    if ( generator->m_frame->m_frame.f_exc_type == Py_None ) generator->m_frame->m_frame.f_exc_type = NULL;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_type );
    generator->m_frame->m_frame.f_exc_value = thread_state->exc_value;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_value );
    generator->m_frame->m_frame.f_exc_traceback = thread_state->exc_traceback;
    Py_XINCREF( generator->m_frame->m_frame.f_exc_traceback );
#endif

    // Framed code:
    // Tried code:
    loop_start_1:;
    if ( generator->m_closure[0] == NULL )
    {
        tmp_next_source_1 = NULL;
    }
    else
    {
        tmp_next_source_1 = PyCell_GET( generator->m_closure[0] );
    }

    CHECK_OBJECT( tmp_next_source_1 );
    tmp_assign_source_1 = ITERATOR_NEXT( tmp_next_source_1 );
    if ( tmp_assign_source_1 == NULL )
    {
        if ( CHECK_AND_CLEAR_STOP_ITERATION_OCCURRED() )
        {

            goto loop_end_1;
        }
        else
        {

            FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
            type_description_1 = "No";
            exception_lineno = 49;
            goto try_except_handler_2;
        }
    }

    {
        PyObject *old = tmp_iter_value_0;
        tmp_iter_value_0 = tmp_assign_source_1;
        Py_XDECREF( old );
    }

    tmp_assign_source_2 = tmp_iter_value_0;

    CHECK_OBJECT( tmp_assign_source_2 );
    {
        PyObject *old = var_x;
        var_x = tmp_assign_source_2;
        Py_INCREF( var_x );
        Py_XDECREF( old );
    }

    tmp_int_arg_1 = var_x;

    CHECK_OBJECT( tmp_int_arg_1 );
    tmp_left_name_1 = PyNumber_Int( tmp_int_arg_1 );
    if ( tmp_left_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "No";
        goto try_except_handler_2;
    }
    tmp_right_name_1 = const_int_pos_1;
    tmp_expression_name_1 = BINARY_OPERATION_SUB( tmp_left_name_1, tmp_right_name_1 );
    Py_DECREF( tmp_left_name_1 );
    if ( tmp_expression_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "No";
        goto try_except_handler_2;
    }
    tmp_unused = GENERATOR_YIELD( generator, tmp_expression_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "No";
        goto try_except_handler_2;
    }
    if ( CONSIDER_THREADING() == false )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 49;
        type_description_1 = "No";
        goto try_except_handler_2;
    }
    goto loop_start_1;
    loop_end_1:;
    goto try_end_1;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( tmp_iter_value_0 );
    tmp_iter_value_0 = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;

    Nuitka_Frame_MarkAsNotExecuting( generator->m_frame );

#if PYTHON_VERSION >= 300
    Py_CLEAR( generator->m_frame->m_frame.f_exc_type );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_value );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_traceback );
#endif

    // Allow re-use of the frame again.
    Py_DECREF( generator->m_frame );
    goto frame_no_exception_1;

    frame_exception_exit_1:;

    // If it's not an exit exception, consider and create a traceback for it.
    if ( !EXCEPTION_MATCH_GENERATOR( exception_type ) )
    {
        if ( exception_tb == NULL )
        {
            exception_tb = MAKE_TRACEBACK( generator->m_frame, exception_lineno );
        }
        else if ( exception_tb->tb_frame != &generator->m_frame->m_frame )
        {
            exception_tb = ADD_TRACEBACK( exception_tb, generator->m_frame, exception_lineno );
        }

        Nuitka_Frame_AttachLocals(
            (struct Nuitka_FrameObject *)generator->m_frame,
            type_description_1,
            NULL,
            var_x
        );


        // Release cached frame.
        if ( generator->m_frame == cache_frame_generator )
        {
            Py_DECREF( generator->m_frame );
        }
        cache_frame_generator = NULL;

        assertFrameObject( generator->m_frame );
    }

#if PYTHON_VERSION >= 300
    Py_CLEAR( generator->m_frame->m_frame.f_exc_type );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_value );
    Py_CLEAR( generator->m_frame->m_frame.f_exc_traceback );
#endif

    Py_DECREF( generator->m_frame );
    // Return the error.
    goto try_except_handler_1;

    frame_no_exception_1:;

    goto try_end_2;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    Py_XDECREF( var_x );
    var_x = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto function_exception_exit;
    // End of try:
    try_end_2:;
    Py_XDECREF( tmp_iter_value_0 );
    tmp_iter_value_0 = NULL;

    Py_XDECREF( var_x );
    var_x = NULL;


#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
    return NULL;
#else
    generator->m_yielded = NULL;
    return;
#endif

    function_exception_exit:
    assert( exception_type );
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );

#if _NUITKA_EXPERIMENTAL_GENERATOR_GOTO
    return NULL;
#else
    generator->m_yielded = NULL;
    return;
#endif

}



static PyObject *MAKE_FUNCTION___main__$$$function_1_main(  )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl___main__$$$function_1_main,
        const_str_plain_main,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_96e3437d96ef4905aa04c5d1cf4aca51,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module___main__,
        Py_None,
        0
    );


    return (PyObject *)result;
}



static PyObject *MAKE_FUNCTION___main__$$$function_1_main$$$function_1_usage( struct Nuitka_CellObject *closure_argv )
{
    struct Nuitka_FunctionObject *result = Nuitka_Function_New(
        impl___main__$$$function_1_main$$$function_1_usage,
        const_str_plain_usage,
#if PYTHON_VERSION >= 330
        NULL,
#endif
        codeobj_fcda504b2c96a18fd21f67c08ac97475,
        NULL,
#if PYTHON_VERSION >= 300
        NULL,
        const_dict_empty,
#endif
        module___main__,
        Py_None,
        1
    );

result->m_closure[0] = closure_argv;
Py_INCREF( result->m_closure[0] );

    return (PyObject *)result;
}



#if PYTHON_VERSION >= 300
static struct PyModuleDef mdef___main__ =
{
    PyModuleDef_HEAD_INIT,
    "__main__",   /* m_name */
    NULL,                /* m_doc */
    -1,                  /* m_size */
    NULL,                /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
  };
#endif

#if PYTHON_VERSION >= 300
extern PyObject *metapath_based_loader;
#endif
#if PYTHON_VERSION >= 330
extern PyObject *const_str_plain___loader__;
#endif

extern void _initCompiledCellType();
extern void _initCompiledGeneratorType();
extern void _initCompiledFunctionType();
extern void _initCompiledMethodType();
extern void _initCompiledFrameType();
#if PYTHON_VERSION >= 350
extern void _initCompiledCoroutineTypes();
#endif
#if PYTHON_VERSION >= 360
extern void _initCompiledAsyncgenTypes();
#endif

// The exported interface to CPython. On import of the module, this function
// gets called. It has to have an exact function name, in cases it's a shared
// library export. This is hidden behind the MOD_INIT_DECL.

MOD_INIT_DECL( __main__ )
{
#if defined(_NUITKA_EXE) || PYTHON_VERSION >= 300
    static bool _init_done = false;

    // Modules might be imported repeatedly, which is to be ignored.
    if ( _init_done )
    {
        return MOD_RETURN_VALUE( module___main__ );
    }
    else
    {
        _init_done = true;
    }
#endif

#ifdef _NUITKA_MODULE
    // In case of a stand alone extension module, need to call initialization
    // the init here because that's the first and only time we are going to get
    // called here.

    // Initialize the constant values used.
    _initBuiltinModule();
    createGlobalConstants();

    /* Initialize the compiled types of Nuitka. */
    _initCompiledCellType();
    _initCompiledGeneratorType();
    _initCompiledFunctionType();
    _initCompiledMethodType();
    _initCompiledFrameType();
#if PYTHON_VERSION >= 350
    _initCompiledCoroutineTypes();
#endif
#if PYTHON_VERSION >= 360
    _initCompiledAsyncgenTypes();
#endif

#if PYTHON_VERSION < 300
    _initSlotCompare();
#endif
#if PYTHON_VERSION >= 270
    _initSlotIternext();
#endif

    patchBuiltinModule();
    patchTypeComparison();

    // Enable meta path based loader if not already done.
    setupMetaPathBasedLoader();

#if PYTHON_VERSION >= 300
    patchInspectModule();
#endif

#endif

    /* The constants only used by this module are created now. */
#ifdef _NUITKA_TRACE
    puts("__main__: Calling createModuleConstants().");
#endif
    createModuleConstants();

    /* The code objects used by this module are created now. */
#ifdef _NUITKA_TRACE
    puts("__main__: Calling createModuleCodeObjects().");
#endif
    createModuleCodeObjects();

    // puts( "in init__main__" );

    // Create the module object first. There are no methods initially, all are
    // added dynamically in actual code only.  Also no "__doc__" is initially
    // set at this time, as it could not contain NUL characters this way, they
    // are instead set in early module code.  No "self" for modules, we have no
    // use for it.
#if PYTHON_VERSION < 300
    module___main__ = Py_InitModule4(
        "__main__",       // Module Name
        NULL,                    // No methods initially, all are added
                                 // dynamically in actual module code only.
        NULL,                    // No __doc__ is initially set, as it could
                                 // not contain NUL this way, added early in
                                 // actual code.
        NULL,                    // No self for modules, we don't use it.
        PYTHON_API_VERSION
    );
#else
    module___main__ = PyModule_Create( &mdef___main__ );
#endif

    moduledict___main__ = MODULE_DICT( module___main__ );

    CHECK_OBJECT( module___main__ );

// Seems to work for Python2.7 out of the box, but for Python3, the module
// doesn't automatically enter "sys.modules", so do it manually.
#if PYTHON_VERSION >= 300
    {
        int r = PyObject_SetItem( PySys_GetObject( (char *)"modules" ), const_str_plain___main__, module___main__ );

        assert( r != -1 );
    }
#endif

    // For deep importing of a module we need to have "__builtins__", so we set
    // it ourselves in the same way than CPython does. Note: This must be done
    // before the frame object is allocated, or else it may fail.

    if ( GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain___builtins__ ) == NULL )
    {
        PyObject *value = (PyObject *)builtin_module;

        // Check if main module, not a dict then but the module itself.
#if !defined(_NUITKA_EXE) || !1
        value = PyModule_GetDict( value );
#endif

        UPDATE_STRING_DICT0( moduledict___main__, (Nuitka_StringObject *)const_str_plain___builtins__, value );
    }

#if PYTHON_VERSION >= 330
    UPDATE_STRING_DICT0( moduledict___main__, (Nuitka_StringObject *)const_str_plain___loader__, metapath_based_loader );
#endif

    // Temp variables if any
    PyObject *tmp_import_from_1__module = NULL;
    PyObject *tmp_import_from_2__module = NULL;
    PyObject *tmp_import_from_3__module = NULL;
    PyObject *exception_type = NULL;
    PyObject *exception_value = NULL;
    PyTracebackObject *exception_tb = NULL;
    NUITKA_MAY_BE_UNUSED int exception_lineno = 0;
    PyObject *exception_keeper_type_1;
    PyObject *exception_keeper_value_1;
    PyTracebackObject *exception_keeper_tb_1;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_1;
    PyObject *exception_keeper_type_2;
    PyObject *exception_keeper_value_2;
    PyTracebackObject *exception_keeper_tb_2;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_2;
    PyObject *exception_keeper_type_3;
    PyObject *exception_keeper_value_3;
    PyTracebackObject *exception_keeper_tb_3;
    NUITKA_MAY_BE_UNUSED int exception_keeper_lineno_3;
    PyObject *tmp_args_element_name_1;
    PyObject *tmp_args_element_name_2;
    PyObject *tmp_assign_source_1;
    PyObject *tmp_assign_source_2;
    PyObject *tmp_assign_source_3;
    PyObject *tmp_assign_source_4;
    PyObject *tmp_assign_source_5;
    PyObject *tmp_assign_source_6;
    PyObject *tmp_assign_source_7;
    PyObject *tmp_assign_source_8;
    PyObject *tmp_assign_source_9;
    PyObject *tmp_assign_source_10;
    PyObject *tmp_assign_source_11;
    PyObject *tmp_assign_source_12;
    PyObject *tmp_assign_source_13;
    PyObject *tmp_assign_source_14;
    PyObject *tmp_assign_source_15;
    PyObject *tmp_assign_source_16;
    PyObject *tmp_assign_source_17;
    PyObject *tmp_assign_source_18;
    PyObject *tmp_assign_source_19;
    PyObject *tmp_assign_source_20;
    PyObject *tmp_assign_source_21;
    PyObject *tmp_called_name_1;
    PyObject *tmp_called_name_2;
    PyObject *tmp_fromlist_name_2;
    PyObject *tmp_fromlist_name_3;
    PyObject *tmp_fromlist_name_4;
    PyObject *tmp_fromlist_name_5;
    PyObject *tmp_fromlist_name_6;
    PyObject *tmp_fromlist_name_7;
    PyObject *tmp_fromlist_name_8;
    PyObject *tmp_fromlist_name_9;
    PyObject *tmp_fromlist_name_10;
    PyObject *tmp_fromlist_name_11;
    PyObject *tmp_globals_name_2;
    PyObject *tmp_globals_name_3;
    PyObject *tmp_globals_name_4;
    PyObject *tmp_globals_name_5;
    PyObject *tmp_globals_name_6;
    PyObject *tmp_globals_name_7;
    PyObject *tmp_globals_name_8;
    PyObject *tmp_globals_name_9;
    PyObject *tmp_globals_name_10;
    PyObject *tmp_globals_name_11;
    PyObject *tmp_import_name_from_1;
    PyObject *tmp_import_name_from_2;
    PyObject *tmp_import_name_from_3;
    PyObject *tmp_import_name_from_4;
    PyObject *tmp_import_name_from_5;
    PyObject *tmp_import_name_from_6;
    PyObject *tmp_import_name_from_7;
    PyObject *tmp_import_name_from_8;
    PyObject *tmp_import_name_from_9;
    PyObject *tmp_import_name_from_10;
    PyObject *tmp_import_name_from_11;
    PyObject *tmp_import_name_from_12;
    PyObject *tmp_import_name_from_13;
    PyObject *tmp_level_name_1;
    PyObject *tmp_locals_name_2;
    PyObject *tmp_locals_name_3;
    PyObject *tmp_locals_name_4;
    PyObject *tmp_locals_name_5;
    PyObject *tmp_locals_name_6;
    PyObject *tmp_locals_name_7;
    PyObject *tmp_locals_name_8;
    PyObject *tmp_locals_name_9;
    PyObject *tmp_locals_name_10;
    PyObject *tmp_locals_name_11;
    PyObject *tmp_name_name_1;
    PyObject *tmp_name_name_2;
    PyObject *tmp_name_name_3;
    PyObject *tmp_name_name_4;
    PyObject *tmp_name_name_5;
    PyObject *tmp_name_name_6;
    PyObject *tmp_name_name_7;
    PyObject *tmp_name_name_8;
    PyObject *tmp_name_name_9;
    PyObject *tmp_name_name_10;
    PyObject *tmp_name_name_11;
    PyObject *tmp_source_name_1;
    PyObject *tmp_source_name_2;
    NUITKA_MAY_BE_UNUSED PyObject *tmp_unused;
    struct Nuitka_FrameObject *frame_a4e2b497cc9e3edf66e14fcb7f090f24;

    NUITKA_MAY_BE_UNUSED char const *type_description_1 = NULL;

    // Module code.
    // Frame without reuse.
    frame_a4e2b497cc9e3edf66e14fcb7f090f24 = MAKE_MODULE_FRAME( codeobj_a4e2b497cc9e3edf66e14fcb7f090f24, module___main__ );

    // Push the new frame as the currently active one, and we should be exclusively
    // owning it.
    pushFrameStack( frame_a4e2b497cc9e3edf66e14fcb7f090f24 );
    assert( Py_REFCNT( frame_a4e2b497cc9e3edf66e14fcb7f090f24 ) == 2 );

    // Framed code:
    tmp_name_name_1 = const_str_plain_site;
    tmp_level_name_1 = const_int_0;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 1;
    tmp_unused = IMPORT_MODULE_KW( tmp_name_name_1, NULL, NULL, NULL, tmp_level_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 1;

        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );
    tmp_assign_source_1 = Py_None;
    UPDATE_STRING_DICT0( moduledict___main__, (Nuitka_StringObject *)const_str_plain___doc__, tmp_assign_source_1 );
    tmp_assign_source_2 = const_str_digest_203ab1e8ea4c9d7501c11522e92c4853;
    UPDATE_STRING_DICT0( moduledict___main__, (Nuitka_StringObject *)const_str_plain___file__, tmp_assign_source_2 );
    tmp_assign_source_3 = Py_None;
    UPDATE_STRING_DICT0( moduledict___main__, (Nuitka_StringObject *)const_str_plain___package__, tmp_assign_source_3 );
    tmp_name_name_2 = const_str_plain_sys;
    tmp_globals_name_2 = (PyObject *)moduledict___main__;
    tmp_locals_name_2 = Py_None;
    tmp_fromlist_name_2 = Py_None;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 2;
    tmp_assign_source_4 = IMPORT_MODULE4( tmp_name_name_2, tmp_globals_name_2, tmp_locals_name_2, tmp_fromlist_name_2 );
    assert( tmp_assign_source_4 != NULL );
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_sys, tmp_assign_source_4 );
    tmp_name_name_3 = const_str_digest_06b582bb8a7d7354812dca18aef147d5;
    tmp_globals_name_3 = (PyObject *)moduledict___main__;
    tmp_locals_name_3 = Py_None;
    tmp_fromlist_name_3 = const_tuple_str_plain_PDFDocument_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 3;
    tmp_import_name_from_1 = IMPORT_MODULE4( tmp_name_name_3, tmp_globals_name_3, tmp_locals_name_3, tmp_fromlist_name_3 );
    if ( tmp_import_name_from_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 3;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_5 = IMPORT_NAME( tmp_import_name_from_1, const_str_plain_PDFDocument );
    Py_DECREF( tmp_import_name_from_1 );
    if ( tmp_assign_source_5 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 3;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFDocument, tmp_assign_source_5 );
    tmp_name_name_4 = const_str_digest_f6a581251841acee771bacb236f706e6;
    tmp_globals_name_4 = (PyObject *)moduledict___main__;
    tmp_locals_name_4 = Py_None;
    tmp_fromlist_name_4 = const_tuple_str_plain_PDFParser_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 4;
    tmp_import_name_from_2 = IMPORT_MODULE4( tmp_name_name_4, tmp_globals_name_4, tmp_locals_name_4, tmp_fromlist_name_4 );
    if ( tmp_import_name_from_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 4;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_6 = IMPORT_NAME( tmp_import_name_from_2, const_str_plain_PDFParser );
    Py_DECREF( tmp_import_name_from_2 );
    if ( tmp_assign_source_6 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 4;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFParser, tmp_assign_source_6 );
    tmp_name_name_5 = const_str_digest_89cffbfc3ef10076664cbfd1fe7e6033;
    tmp_globals_name_5 = (PyObject *)moduledict___main__;
    tmp_locals_name_5 = Py_None;
    tmp_fromlist_name_5 = const_tuple_str_plain_PDFResourceManager_str_plain_PDFPageInterpreter_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 5;
    tmp_assign_source_7 = IMPORT_MODULE4( tmp_name_name_5, tmp_globals_name_5, tmp_locals_name_5, tmp_fromlist_name_5 );
    if ( tmp_assign_source_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 5;

        goto frame_exception_exit_1;
    }
    assert( tmp_import_from_1__module == NULL );
    tmp_import_from_1__module = tmp_assign_source_7;

    // Tried code:
    tmp_import_name_from_3 = tmp_import_from_1__module;

    CHECK_OBJECT( tmp_import_name_from_3 );
    tmp_assign_source_8 = IMPORT_NAME( tmp_import_name_from_3, const_str_plain_PDFResourceManager );
    if ( tmp_assign_source_8 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 5;

        goto try_except_handler_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFResourceManager, tmp_assign_source_8 );
    tmp_import_name_from_4 = tmp_import_from_1__module;

    CHECK_OBJECT( tmp_import_name_from_4 );
    tmp_assign_source_9 = IMPORT_NAME( tmp_import_name_from_4, const_str_plain_PDFPageInterpreter );
    if ( tmp_assign_source_9 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 5;

        goto try_except_handler_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFPageInterpreter, tmp_assign_source_9 );
    goto try_end_1;
    // Exception handler code:
    try_except_handler_1:;
    exception_keeper_type_1 = exception_type;
    exception_keeper_value_1 = exception_value;
    exception_keeper_tb_1 = exception_tb;
    exception_keeper_lineno_1 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_import_from_1__module );
    Py_DECREF( tmp_import_from_1__module );
    tmp_import_from_1__module = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_1;
    exception_value = exception_keeper_value_1;
    exception_tb = exception_keeper_tb_1;
    exception_lineno = exception_keeper_lineno_1;

    goto frame_exception_exit_1;
    // End of try:
    try_end_1:;
    CHECK_OBJECT( (PyObject *)tmp_import_from_1__module );
    Py_DECREF( tmp_import_from_1__module );
    tmp_import_from_1__module = NULL;

    tmp_name_name_6 = const_str_digest_d1e9155136963092d9fab9b67fbb0f7f;
    tmp_globals_name_6 = (PyObject *)moduledict___main__;
    tmp_locals_name_6 = Py_None;
    tmp_fromlist_name_6 = const_tuple_str_plain_PDFDevice_str_plain_TagExtractor_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 6;
    tmp_assign_source_10 = IMPORT_MODULE4( tmp_name_name_6, tmp_globals_name_6, tmp_locals_name_6, tmp_fromlist_name_6 );
    if ( tmp_assign_source_10 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 6;

        goto frame_exception_exit_1;
    }
    assert( tmp_import_from_2__module == NULL );
    tmp_import_from_2__module = tmp_assign_source_10;

    // Tried code:
    tmp_import_name_from_5 = tmp_import_from_2__module;

    CHECK_OBJECT( tmp_import_name_from_5 );
    tmp_assign_source_11 = IMPORT_NAME( tmp_import_name_from_5, const_str_plain_PDFDevice );
    if ( tmp_assign_source_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 6;

        goto try_except_handler_2;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFDevice, tmp_assign_source_11 );
    tmp_import_name_from_6 = tmp_import_from_2__module;

    CHECK_OBJECT( tmp_import_name_from_6 );
    tmp_assign_source_12 = IMPORT_NAME( tmp_import_name_from_6, const_str_plain_TagExtractor );
    if ( tmp_assign_source_12 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 6;

        goto try_except_handler_2;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_TagExtractor, tmp_assign_source_12 );
    goto try_end_2;
    // Exception handler code:
    try_except_handler_2:;
    exception_keeper_type_2 = exception_type;
    exception_keeper_value_2 = exception_value;
    exception_keeper_tb_2 = exception_tb;
    exception_keeper_lineno_2 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_import_from_2__module );
    Py_DECREF( tmp_import_from_2__module );
    tmp_import_from_2__module = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_2;
    exception_value = exception_keeper_value_2;
    exception_tb = exception_keeper_tb_2;
    exception_lineno = exception_keeper_lineno_2;

    goto frame_exception_exit_1;
    // End of try:
    try_end_2:;
    CHECK_OBJECT( (PyObject *)tmp_import_from_2__module );
    Py_DECREF( tmp_import_from_2__module );
    tmp_import_from_2__module = NULL;

    tmp_name_name_7 = const_str_digest_5bc6acbbb9e0adb8dabbc1a8cf202f2d;
    tmp_globals_name_7 = (PyObject *)moduledict___main__;
    tmp_locals_name_7 = Py_None;
    tmp_fromlist_name_7 = const_tuple_str_plain_PDFPage_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 7;
    tmp_import_name_from_7 = IMPORT_MODULE4( tmp_name_name_7, tmp_globals_name_7, tmp_locals_name_7, tmp_fromlist_name_7 );
    if ( tmp_import_name_from_7 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 7;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_13 = IMPORT_NAME( tmp_import_name_from_7, const_str_plain_PDFPage );
    Py_DECREF( tmp_import_name_from_7 );
    if ( tmp_assign_source_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 7;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_PDFPage, tmp_assign_source_13 );
    tmp_name_name_8 = const_str_digest_b3b014cceb34671e9d2eebc9b6361b5c;
    tmp_globals_name_8 = (PyObject *)moduledict___main__;
    tmp_locals_name_8 = Py_None;
    tmp_fromlist_name_8 = const_tuple_4f56711aeb7a968ce73a215cc6172d84_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 8;
    tmp_assign_source_14 = IMPORT_MODULE4( tmp_name_name_8, tmp_globals_name_8, tmp_locals_name_8, tmp_fromlist_name_8 );
    if ( tmp_assign_source_14 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 8;

        goto frame_exception_exit_1;
    }
    assert( tmp_import_from_3__module == NULL );
    tmp_import_from_3__module = tmp_assign_source_14;

    // Tried code:
    tmp_import_name_from_8 = tmp_import_from_3__module;

    CHECK_OBJECT( tmp_import_name_from_8 );
    tmp_assign_source_15 = IMPORT_NAME( tmp_import_name_from_8, const_str_plain_XMLConverter );
    if ( tmp_assign_source_15 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 8;

        goto try_except_handler_3;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_XMLConverter, tmp_assign_source_15 );
    tmp_import_name_from_9 = tmp_import_from_3__module;

    CHECK_OBJECT( tmp_import_name_from_9 );
    tmp_assign_source_16 = IMPORT_NAME( tmp_import_name_from_9, const_str_plain_HTMLConverter );
    if ( tmp_assign_source_16 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 8;

        goto try_except_handler_3;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_HTMLConverter, tmp_assign_source_16 );
    tmp_import_name_from_10 = tmp_import_from_3__module;

    CHECK_OBJECT( tmp_import_name_from_10 );
    tmp_assign_source_17 = IMPORT_NAME( tmp_import_name_from_10, const_str_plain_TextConverter );
    if ( tmp_assign_source_17 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 8;

        goto try_except_handler_3;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_TextConverter, tmp_assign_source_17 );
    goto try_end_3;
    // Exception handler code:
    try_except_handler_3:;
    exception_keeper_type_3 = exception_type;
    exception_keeper_value_3 = exception_value;
    exception_keeper_tb_3 = exception_tb;
    exception_keeper_lineno_3 = exception_lineno;
    exception_type = NULL;
    exception_value = NULL;
    exception_tb = NULL;
    exception_lineno = 0;

    CHECK_OBJECT( (PyObject *)tmp_import_from_3__module );
    Py_DECREF( tmp_import_from_3__module );
    tmp_import_from_3__module = NULL;

    // Re-raise.
    exception_type = exception_keeper_type_3;
    exception_value = exception_keeper_value_3;
    exception_tb = exception_keeper_tb_3;
    exception_lineno = exception_keeper_lineno_3;

    goto frame_exception_exit_1;
    // End of try:
    try_end_3:;
    CHECK_OBJECT( (PyObject *)tmp_import_from_3__module );
    Py_DECREF( tmp_import_from_3__module );
    tmp_import_from_3__module = NULL;

    tmp_name_name_9 = const_str_digest_a5f56e291553139a63a10626179e7804;
    tmp_globals_name_9 = (PyObject *)moduledict___main__;
    tmp_locals_name_9 = Py_None;
    tmp_fromlist_name_9 = const_tuple_str_plain_CMapDB_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 9;
    tmp_import_name_from_11 = IMPORT_MODULE4( tmp_name_name_9, tmp_globals_name_9, tmp_locals_name_9, tmp_fromlist_name_9 );
    if ( tmp_import_name_from_11 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 9;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_18 = IMPORT_NAME( tmp_import_name_from_11, const_str_plain_CMapDB );
    Py_DECREF( tmp_import_name_from_11 );
    if ( tmp_assign_source_18 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 9;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_CMapDB, tmp_assign_source_18 );
    tmp_name_name_10 = const_str_digest_4b5c38a441de1271115ffc49566d0c91;
    tmp_globals_name_10 = (PyObject *)moduledict___main__;
    tmp_locals_name_10 = Py_None;
    tmp_fromlist_name_10 = const_tuple_str_plain_LAParams_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 10;
    tmp_import_name_from_12 = IMPORT_MODULE4( tmp_name_name_10, tmp_globals_name_10, tmp_locals_name_10, tmp_fromlist_name_10 );
    if ( tmp_import_name_from_12 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 10;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_19 = IMPORT_NAME( tmp_import_name_from_12, const_str_plain_LAParams );
    Py_DECREF( tmp_import_name_from_12 );
    if ( tmp_assign_source_19 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 10;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_LAParams, tmp_assign_source_19 );
    tmp_name_name_11 = const_str_digest_4d088de100fe5354b20a010ce1db7f29;
    tmp_globals_name_11 = (PyObject *)moduledict___main__;
    tmp_locals_name_11 = Py_None;
    tmp_fromlist_name_11 = const_tuple_str_plain_ImageWriter_tuple;
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 11;
    tmp_import_name_from_13 = IMPORT_MODULE4( tmp_name_name_11, tmp_globals_name_11, tmp_locals_name_11, tmp_fromlist_name_11 );
    if ( tmp_import_name_from_13 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 11;

        goto frame_exception_exit_1;
    }
    tmp_assign_source_20 = IMPORT_NAME( tmp_import_name_from_13, const_str_plain_ImageWriter );
    Py_DECREF( tmp_import_name_from_13 );
    if ( tmp_assign_source_20 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 11;

        goto frame_exception_exit_1;
    }
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_ImageWriter, tmp_assign_source_20 );
    tmp_assign_source_21 = MAKE_FUNCTION___main__$$$function_1_main(  );
    UPDATE_STRING_DICT1( moduledict___main__, (Nuitka_StringObject *)const_str_plain_main, tmp_assign_source_21 );
    tmp_source_name_1 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_sys );

    if (unlikely( tmp_source_name_1 == NULL ))
    {
        tmp_source_name_1 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_sys );
    }

    if ( tmp_source_name_1 == NULL )
    {

        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "sys" );
        exception_tb = NULL;

        exception_lineno = 116;

        goto frame_exception_exit_1;
    }

    tmp_called_name_1 = LOOKUP_ATTRIBUTE( tmp_source_name_1, const_str_plain_exit );
    if ( tmp_called_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 116;

        goto frame_exception_exit_1;
    }
    tmp_called_name_2 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_main );

    if (unlikely( tmp_called_name_2 == NULL ))
    {
        tmp_called_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_main );
    }

    if ( tmp_called_name_2 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "main" );
        exception_tb = NULL;

        exception_lineno = 116;

        goto frame_exception_exit_1;
    }

    tmp_source_name_2 = GET_STRING_DICT_VALUE( moduledict___main__, (Nuitka_StringObject *)const_str_plain_sys );

    if (unlikely( tmp_source_name_2 == NULL ))
    {
        tmp_source_name_2 = GET_STRING_DICT_VALUE( dict_builtin, (Nuitka_StringObject *)const_str_plain_sys );
    }

    if ( tmp_source_name_2 == NULL )
    {
        Py_DECREF( tmp_called_name_1 );
        exception_type = PyExc_NameError;
        Py_INCREF( exception_type );
        exception_value = PyString_FromFormat( "name '%s' is not defined", "sys" );
        exception_tb = NULL;

        exception_lineno = 116;

        goto frame_exception_exit_1;
    }

    tmp_args_element_name_2 = LOOKUP_ATTRIBUTE( tmp_source_name_2, const_str_plain_argv );
    if ( tmp_args_element_name_2 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 116;

        goto frame_exception_exit_1;
    }
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 116;
    {
        PyObject *call_args[] = { tmp_args_element_name_2 };
        tmp_args_element_name_1 = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_2, call_args );
    }

    Py_DECREF( tmp_args_element_name_2 );
    if ( tmp_args_element_name_1 == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );
        Py_DECREF( tmp_called_name_1 );

        exception_lineno = 116;

        goto frame_exception_exit_1;
    }
    frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame.f_lineno = 116;
    {
        PyObject *call_args[] = { tmp_args_element_name_1 };
        tmp_unused = CALL_FUNCTION_WITH_ARGS1( tmp_called_name_1, call_args );
    }

    Py_DECREF( tmp_called_name_1 );
    Py_DECREF( tmp_args_element_name_1 );
    if ( tmp_unused == NULL )
    {
        assert( ERROR_OCCURRED() );

        FETCH_ERROR_OCCURRED( &exception_type, &exception_value, &exception_tb );


        exception_lineno = 116;

        goto frame_exception_exit_1;
    }
    Py_DECREF( tmp_unused );

    // Restore frame exception if necessary.
#if 0
    RESTORE_FRAME_EXCEPTION( frame_a4e2b497cc9e3edf66e14fcb7f090f24 );
#endif
    popFrameStack();

    assertFrameObject( frame_a4e2b497cc9e3edf66e14fcb7f090f24 );

    goto frame_no_exception_1;
    frame_exception_exit_1:;
#if 0
    RESTORE_FRAME_EXCEPTION( frame_a4e2b497cc9e3edf66e14fcb7f090f24 );
#endif

    if ( exception_tb == NULL )
    {
        exception_tb = MAKE_TRACEBACK( frame_a4e2b497cc9e3edf66e14fcb7f090f24, exception_lineno );
    }
    else if ( exception_tb->tb_frame != &frame_a4e2b497cc9e3edf66e14fcb7f090f24->m_frame )
    {
        exception_tb = ADD_TRACEBACK( exception_tb, frame_a4e2b497cc9e3edf66e14fcb7f090f24, exception_lineno );
    }

    // Put the previous frame back on top.
    popFrameStack();

    // Return the error.
    goto module_exception_exit;
    frame_no_exception_1:;

    return MOD_RETURN_VALUE( module___main__ );
    module_exception_exit:
    RESTORE_ERROR_OCCURRED( exception_type, exception_value, exception_tb );
    return MOD_RETURN_VALUE( NULL );
}
